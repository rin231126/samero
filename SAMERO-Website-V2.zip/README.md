# SAMERO — Pixel AI Studio

Static bilingual product site for the independent SAMERO Codex Manager. Includes the original 1.9.0-studio-rc1 executable, portable archive, release checksums, pixel assets and 36-second product trailer.

To publish for free via GitHub Pages, upload the contents of this folder (not the ZIP itself) to `rin231126/samero`, keeping `index.html` at the root. In Settings → Pages choose Deploy from a branch → main → /(root) → Save. The URL is expected to be `https://rin231126.github.io/samero/` after a successful Pages deployment. Custom domains are optional and not provisioned.

The Windows binary is an unsigned release candidate; real Windows and authenticated Codex testing are incomplete. The illustrated previews are not live agent activity. This repository does not include personal workspace, account credentials or API tokens.
