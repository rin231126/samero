# Rà soát kế hoạch SAMERO Animation AI — revision 61

Nguồn: TASK_QUEUE.json và PROJECT_STATUS.md do người dùng gửi. Hàng đợi ghi index 1/16, mode review, phase verify, attempt 2, test PASS, build NOT VERIFIED. Task 1 mang trạng thái PASS trong journal; chưa tái kiểm chứng toàn bộ tệp dự án trên Windows. Các checkpoint, manifest và log được nhắc tới trong hai tệp không được gửi kèm, vì vậy đây là rà soát kế hoạch, không phải nghiệm thu Animation AI.

## Nguyên nhân đã xác định

Task 2 yêu cầu có toàn bộ lệnh của các tác vụ lịch sử. Bản ghi mới nhất nêu rằng lệnh gốc tạo TAKEOVER_BASELINE.csv đã mất; dữ liệu delta 561 đường dẫn thuộc một khoảng quan sát gồm cả hợp nhất, không đủ để gán toàn bộ cho Task 1. Việc tiếp tục tìm lại một lệnh không còn tồn tại không tạo ra tiến triển. Migration giới hạn của Manager chỉ thay cách xác minh phần lịch sử này: ghi NOT RECORDED khi không còn lệnh gốc, dùng bằng chứng còn lưu, chạy lại phép kiểm có thể tái hiện và giữ mọi yêu cầu thực chất. Không có cơ chế nhập PASS từ file công khai.

## Kiểm tra từng nhiệm vụ và điều kiện dừng thực sự

| Task | Rà soát và điều kiện cần để tiếp tục |
| --- | --- |
| 1. Chốt mốc tiếp quản | Đã được Manager ghi PASS; bảo toàn tiêu chí và receipt. Không yêu cầu hàng đợi hiện tại rỗng, không gọi 561 đường dẫn là delta chính xác của riêng Task 1. |
| 2. Sao lưu/hợp nhất | Chuyển cách xác minh lịch sử đã mất bằng migration giới hạn; vẫn kiểm tra SHA-256, hai bản khôi phục, quyết định hợp nhất, giữ dữ liệu, checkpoint và STOP. |
| 3. Tái kiểm chứng nền | PROJECT_STATUS nêu log test/build/Edge/Windows 0.4.1-dev; phần ma trận và nghiên cứu/giấy phép còn thiếu. Tái hiện lỗi và đọc nguồn thực; không dùng PASS cũ thay test mới. |
| 4. Import/Canvas/layer | Dùng fixture hợp pháp và các tệp hợp lệ/lỗi; so RGBA, Fit/zoom/pan, undo, nhiều định dạng. Không chỉ nhìn ảnh UI. |
| 5. Mô hình và bộ tranh | Cần dữ liệu có quyền sử dụng, nhãn, seed, hash và kết quả đo. Nếu thiếu tài nguyên hoặc dữ liệu, ghi giới hạn; không tạo số đo giả hoặc tự train lại GPT. |
| 6. Phân tích nhân vật | Cần nhãn/ảnh giữ lại cho nhiều loại nhân vật, xác minh mask và layer. Vùng khuất suy đoán phải riêng và chờ duyệt theo tiêu chí. |
| 7. Rig/mesh | Cần pose, xương, weights, IK/FK và clip biến dạng thực tế; báo thiếu khớp thay vì bỏ qua. |
| 8. Motion tự nhiên | Cần ngưỡng đo trước và clip thực ở tốc độ thật. Không thay kiểm tra định lượng bằng cảm nhận của AI. |
| 9. Sinh clip prompt | Kiểm toàn bộ hành động được yêu cầu, sửa track được; ghi rõ template, quy tắc hoặc mô hình thực tế. |
| 10. Skin/physics | So alpha, màu, palette, liên kết xương và key bake trên ít nhất hai skin; dữ liệu thật mới có giá trị. |
| 11. Pixel Studio | Kiểm các công cụ trên nhiều kích thước, undo, 4/8 hướng có ảnh tham chiếu, thứ tự và timing xuất. |
| 12. Timeline | Kiểm keyframe, đường cong, blend, lưu/mở, undo/redo qua UI; không chỉ kiểm engine. |
| 13. Định dạng và tương thích | Cần bộ đọc độc lập và công cụ đích đúng phiên bản; phạm vi editor/runtime nào chưa chạy phải ghi NOT VERIFIED. |
| 14. UI/hiệu năng/recovery | Cần môi trường Web/Electron, nhiều kích thước/DPI, số đo thiết bị và kiểm thử ngắt tiến trình. Không coi số đo môi trường khác là máy người dùng. |
| 15. Windows ZIP | Cần Windows x64 thực, chạy mặc định ngoại tuyến, đối chiếu hash ZIP/EXE/HTML. Có thể tạo build cần kiểm trong task; build Release cuối của Manager là cổng riêng. |
| 16. Nghiệm thu | Phải kiểm từng yêu cầu gắn với đúng bản phát hành, bao gồm hash của gói sau build cuối. Nếu build cuối tạo hash khác, cần nghiệm thu lại bằng chứng bị ảnh hưởng. Không tuyên bố hoàn thành vì hàng đợi chạy hết. |

Task 3–16 giữ nguyên tiêu chí gốc. Tất cả phụ thuộc tuần tự; không bỏ qua task chưa đạt chỉ để tiếp tục. Manager vẫn dừng khi thực sự thiếu quyền, dữ liệu, thiết bị, bằng chứng bắt buộc, bị người dùng STOP hoặc hết ngân sách/hạn mức. Không tự sửa tiêu chí khác bằng phỏng đoán.

## Phạm vi nâng cấp Manager

- Exact legacy migration: chỉ khớp đủ 16 task, index 1, tiêu đề Task 1/2, dependency và nguyên văn tiêu chí Task 2; cần journal/queue ổn định. Sao lưu journal gốc trước đổi. Sau đó test và VERIFY mới, chỉ PASS qua cơ chế checkpoint hiện có.
- Log lệnh quan sát cho task mới; không tạo lịch sử đã mất. Một lượt xác minh chỉ đọc bổ sung khi reviewer trả needsReview, có giới hạn per-task và không áp dụng cho từ chối quyền.
- Giữ tiêu chí đầy đủ trong prompt; phần chẩn đoán cũ có thể rút gọn theo số byte JSON. Giao diện hiển thị hồ sơ lệnh và chẩn đoán.
- Mục tiêu là giảm can thiệp, không cam kết phần mềm hoàn hảo hoặc chạy bất chấp mọi lỗi.
