# Public launch 1.0.0-rc1

The first public release line is intentionally numbered 1.0.0-rc1 after the internal 1.9.0-studio-rc1 development build. Existing data directory and runner behavior are preserved. This is not a stable or signed release. The six canonical role sprites live in `tools/launch-role-art/` and are embedded in the EXE from `web/mascot/`.

# SAMERO Codex Manager 1.8.1-pixel-rc1

Bản ứng viên nâng cấp cơ chế điều phối và phục hồi Autonomous. Mục tiêu là tự xử lý thiếu dữ liệu nội bộ, không bỏ qua yêu cầu nghiệm thu. Giữ nguyên AI Workforce, ChatGPT Web và Local Bridge. ChatGPT Web vẫn yêu cầu người dùng gửi prompt và duyệt bản sửa, không phải các AI độc lập chạy nền.

## Ocean Edition — mascot cáo đội mũ cá mập

- Giao diện xanh dương Dark/Light, 9 biểu cảm mascot, icon menu và từng vai trò Workforce. Nhấp logo để mở/đóng mũ. Khi mũ mở, giữ biểu cảm mở đến khi nhấp lần nữa; lúc đóng mũ, biểu cảm tự động dựa trên trạng thái có thật.
- Vào Cài đặt → Mascot SAMERO: xem thử từng biểu cảm, bật/tắt biểu cảm tự động và hiệu ứng chuyển trạng thái. Thiết lập lưu trong trình duyệt theo origin; Manager dùng cổng localhost động nên cài đặt có thể cần đặt lại sau khi mở phiên Manager mới.
- Khi không có công việc và không thao tác 8 phút, mascot nghỉ chờ; 20 phút, ngủ. Không có lời nhắc quay lại, không tự phát âm thanh, không tạo tác vụ hoặc ảnh hưởng đến Codex.
- EXE nhúng ảnh PNG, ICO nhiều kích thước và toàn bộ giao diện, không cần tải ảnh bên ngoài. Trạng thái công việc chỉ hiển thị từ dữ liệu Manager; các vai trò ChatGPT Web vẫn phối hợp qua prompt, không phải tiến trình AI chạy nền.
- Bản 1.8.0 thay đổi giao diện, không thay đổi logic điều phối của 1.7.3. Xem TEST-RESULTS.txt về các ca chạy lại trên binary mới.

## Tiếp tục revision 61 đang kẹt Task 2

- Đóng Manager cũ bằng Cài đặt → Thoát Manager; giữ bản cũ và sao lưu workspace cùng dữ liệu Manager. Không sửa JSON bằng tay, không tạo hàng đợi mới.
- Mở bản 1.7.3, chọn Hạn mức → Autonomous Mode → **RESUME**. Chỉ khi hai tiêu đề, thứ tự, số nhiệm vụ và nguyên văn tiêu chí Task 2 khớp đúng kế hoạch legacy đã rà soát, backend tự sao lưu journal cũ rồi diễn đạt lại phần lịch sử mất dữ liệu. Điều kiện SHA-256, khôi phục, hợp nhất, bảo toàn dữ liệu, các bước trước PASS và STOP không bị bỏ. Tiêu chí các task khác giữ nguyên. Nếu journal/queue đã thay đổi ngoài Manager, vẫn phải đối chiếu an toàn.
- Manager bắt buộc chạy test và nghiệm thu lại trước khi Task 2 được PASS. Không đánh dấu PASS theo thông báo chat hoặc chỉ vì tiêu chí đã sửa.
- Mỗi task được ghi các lệnh đã quan sát (App Server commandExecution hoàn tất, test được Manager chạy có mã thoát). Không phải transcript hoàn chỉnh; preview tối đa 4 KiB, lệnh dài/nhạy cảm được ẩn, có trạng thái OBSERVED/PARTIAL/NOT RECORDED. Bộ lọc bí mật theo mẫu không đảm bảo phát hiện mọi định dạng. Không đưa token hoặc mật khẩu vào lệnh.
- Khi VERIFY trả needsReview, Manager tự thực hiện tối đa một lần chẩn đoán chỉ đọc nữa cho task, giữ nguyên tiêu chí. Nếu có phương án sửa an toàn, quay lại vòng sửa/test; nếu thiếu quyền, dữ liệu, thiết bị hoặc bằng chứng bắt buộc thì dừng. Từ chối quyền không đi qua vòng này. Retry và watchdog vẫn có giới hạn. Lỗi không tiến triển không được thử vô hạn.
- Prompt điều phối giữ nguyên tiêu chí, mục tiêu và hợp đồng JSON. Chỉ rút gọn phần chẩn đoán cũ nếu cần, theo đúng giới hạn JSON của kênh RPC 4 KiB; bản đầy đủ vẫn trong journal. Giới hạn chat nhập tay không đổi.
- Xem `AUTONOMOUS-PLAN-AUDIT.md` để biết những điều kiện của 16 task cần bằng chứng thực tế. Báo cáo này không đánh dấu thêm task nào PASS trên dự án Animation AI.

## Hướng dẫn phục hồi bản cũ

1. Thoát Manager cũ bình thường, đóng tác vụ bên ngoài đang ghi, giữ bản Portable cũ và sao lưu workspace cùng dữ liệu Manager. Không xóa `TASK_QUEUE.json`, `PROJECT_STATUS.md`, journal hoặc thư mục checkpoint.
2. Giải nén bản mới vào thư mục riêng. Mở EXE, chọn **Hạn mức → Autonomous Mode → RESUME** một lần ở hàng đợi cũ (không START hàng đợi mới).
3. Manager tự tạo checkpoint và bổ sung hồ sơ nghiệm thu cho task đã PASS. Bản mới tìm tối đa 64 checkpoint gần đây của đúng workspace; đọc queue lịch sử có SHA-256 khớp manifest, so sánh tệp giữa các mốc có thật, và lấy lý do lỗi đã ghi nhận. `HISTORICAL OBSERVATION` là mốc quan sát sau PASS, không phải khẳng định đó là checkpoint nghiệm thu gốc. `NOT RECORDED` nghĩa là lịch sử chưa đủ, không đồng nghĩa không có lỗi hay không sửa tệp.
4. Task mới lưu checkpoint trước khi làm, checkpoint nghiệm thu, dấu hash nguồn, phiên test/verify, danh sách thay đổi theo manifest và lỗi vào TASK_QUEUE.json và PROJECT_STATUS.md. Danh sách xem trước giới hạn khoảng 4 KiB, lỗi khoảng 2 KiB, có chỉ báo nếu bị cắt. Tệp được lọc khỏi manifest không nằm trong phạm vi so sánh. Các delta là khác biệt của các snapshot, không xác định tác giả của từng thay đổi.
5. Nếu mất kết nối lượt ghi mà tiến trình đã kết thúc, Manager có thể chụp checkpoint, chạy test và nghiệm thu một lần trước khi sửa tiếp; không gửi lại lệnh ghi cũ. Lỗi phản hồi chỉ đọc được thử lại có giới hạn. Nếu cần bằng chứng có thể tạo lại trong workspace, Codex được hướng dẫn xử lý bằng nhiệm vụ sửa thay vì xin người dùng. Các lỗi thật, thiếu bằng chứng không thể phục hồi, từ chối quyền hoặc xung đột bên ngoài vẫn có thể dừng.
6. Nếu còn **Cần đối chiếu**, mở **Chẩn đoán**, xem trích đoạn task hiện tại/task trước, revision, lỗi và biên nhận. Kiểm tra tên tệp/nội dung dự án trước khi sao chép để chia sẻ. Không gửi thông tin xác thực, CODEX_HOME hoặc toàn bộ AppData. Không đổi tiêu chí chỉ để đạt PASS.

Các phần dưới là hướng dẫn chức năng kế thừa. Xem TEST-RESULTS.txt để biết phạm vi kiểm thử trên chính phiên bản này.

# SAMERO Codex Manager 1.6.2-rc2

Ứng dụng portable cho Windows 10/11 x64 (Intel/AMD). Giao diện tiếng Việt mở bằng Microsoft Edge ở chế độ cửa sổ ứng dụng hoặc trình duyệt mặc định. EXE chứa giao diện và chương trình xử lý. Dữ liệu ứng dụng ở `%LOCALAPPDATA%\SAMERO Codex Manager`.

**1.6.2-rc2 là bản ứng viên cho Windows x64.** Phạm vi đã xác minh và các mục còn mở được ghi trong TEST-RESULTS.txt.

## Khôi phục Autonomous Mode bị kẹt do tiêu chí cũ

1. Đóng Manager cũ bằng Cài đặt → Thoát Manager; sao lưu dữ liệu cục bộ và workspace khi không còn tiến trình ghi.
2. Mở 1.8.1-pixel-rc1, chọn Hạn mức → Autonomous Mode. Không START hàng đợi mới.
3. Mở Hàng đợi và nhật ký để đọc đầy đủ tiêu chí của nhiệm vụ đang chặn. RESUME sẽ chạy test và nghiệm thu lại. Nếu tiêu chí tự mâu thuẫn (ví dụ yêu cầu hàng đợi 0 nhiệm vụ ở pha nghiệm thu), reviewer được yêu cầu trả needsReview thay vì lặp sửa vô ích.
4. Khi hàng đợi đã ổn định, nút **Sửa tiêu chí** cho phép sửa riêng tiêu chí của nhiệm vụ chưa đạt. Chỉ sửa điều kiện lỗi thời, giữ nguyên yêu cầu thực chất và kiểm tra bằng chứng lịch sử. Không bỏ điều kiện thực chất chỉ để nhận PASS. Bản journal gốc được giữ trong runrecovery. Chọn **Lưu và tiếp tục**: Manager tự chờ checkpoint rồi chạy test, nghiệm thu. Không tự cấp PASS.
5. Nếu TASK_QUEUE.json không khớp journal hoặc đang có đối chiếu bản mới hơn, Manager từ chối sửa tiêu chí. Giữ nguyên dữ liệu để chẩn đoán, không chỉnh JSON bằng tay.

Bản rc2 chưa được chạy trên Windows thật hay Codex thật trong lượt sửa này. Xem TEST-RESULTS.txt.

## Mở ứng dụng

Mở nút **Hướng dẫn** trên thanh trên cùng để xem các bước cài đặt, đăng nhập, kiểm tra hạn mức, mở dự án và bàn giao.

1. Nếu đang chạy bản cũ, chọn **Cài đặt → Thoát Manager** trong cửa sổ đó. Giải nén gói 1.8.1-pixel-rc1 rồi mở `SAMERO-Codex-Manager-1.8.1-pixel-rc1.exe`. Xem số **1.8.1-pixel-rc1** dưới thanh bên hoặc trong Cài đặt. Chọn **Cài đặt → Kiểm tra CLI** để xác nhận Codex.
2. Nếu cần, cài [Codex CLI](https://developers.openai.com/codex/cli) và [Git cho Windows](https://git-scm.com/downloads/win). Bạn có thể chọn tệp `codex.exe` của [bản phát hành OpenAI](https://github.com/openai/codex/releases) và `git.exe` bằng đường dẫn tuyệt đối.
3. Thêm mỗi hồ sơ trong **Hồ sơ Codex**. Để trống CODEX_HOME để tạo thư mục riêng. Bấm **Đăng nhập** để mở quy trình chính thức của Codex. Khi trình duyệt dùng lại đăng nhập, hãy chọn đúng tài khoản cho hồ sơ đang tạo.
4. Vào **Dự án → Thêm dự án** và nhập tên cùng thư mục mã nguồn. Nút **Chọn…** mở trình chọn Windows với thanh địa chỉ. Có thể dán đường dẫn trực tiếp. Sau khi lưu, **Chi tiết dự án** hiển thị Git, tệp cấu hình, tiến độ và checkpoint.
5. Dùng mục **Cài đặt → Thoát Manager** để thoát sau khi các tiến trình đã kết thúc. Mở lại EXE để mở lại giao diện nếu đóng nhầm cửa sổ.

**Hồ sơ Codex → Sửa → Xác thực Codex** cho phép chọn cách dùng kho xác thực. **Tự động** dùng tệp riêng với các thư mục do Manager tạo, và giữ cấu hình Codex với các thư mục có sẵn. Hồ sơ từng đăng nhập qua Manager với tệp riêng có thể chọn **Tệp xác thực riêng trong CODEX_HOME**. Với hồ sơ Terminal dùng kho hệ điều hành, chọn **Theo cấu hình của CODEX_HOME**. Codex CLI quản lý thông tin đăng nhập.

## Khi bấm chọn hoặc gửi chat

Trong **Workspace**, bấm vào tên **Dự án** hoặc **Hồ sơ Codex** để mở danh sách. Bạn có thể dùng Tab, Enter và Escape. Chọn **Mở phiên**, nhập tin nhắn rồi bấm **Gửi** hoặc Ctrl + Enter. Hai thanh bên trái là hạn mức của hồ sơ đang chọn. Hai thanh tổng đếm số hồ sơ còn hạn trong từng kỳ.

Nếu kết nối ngắt trong lúc Codex đang xử lý, mở **Phiên chat → Lịch sử** trước khi gửi tiếp. Manager thử nối lại một lần nếu phiên đang rảnh, đã có lịch sử và vượt qua kiểm tra khóa. Yêu cầu gửi có mã riêng để nhận ra lần thử lại. Nếu thiếu luồng hoặc thư mục dự án khác với lịch sử, chọn lại hồ sơ và thư mục gốc, hoặc dùng **Tạo luồng mới**.

### Khi gặp thread not loaded hoặc no rollout found

Giữ nguyên thư mục dự án và CODEX_HOME mà bạn đã dùng để tạo luồng. Để tiếp tục hội thoại, vào **Phiên chat**, chọn đúng phiên và bấm **Tiếp tục**. Manager kiểm tra lịch sử và chờ App Server xác nhận luồng đã nạp trước khi gửi. Khi Codex chưa nạp ID, Manager cũng có thể đối chiếu metadata của tệp rollout trong thư mục `sessions` của hồ sơ. Nếu lịch sử chưa tìm thấy, bạn có thể kiểm tra lại hồ sơ hoặc bấm **Workspace → Tạo luồng mới** để bắt đầu hội thoại khác trong cùng thư mục dự án.

## Tiếp tục phiên Codex Terminal cũ

1. Vào **Workspace → Tiếp tục phiên cũ**, chọn nguồn **CODEX_HOME của Terminal** hoặc chọn một hồ sơ SAMERO. Ô **Thư mục CODEX_HOME** có thể để trống để dùng đường dẫn phát hiện từ môi trường và Windows. Bạn cũng có thể chọn thư mục đã dùng trước đó.
2. Bấm **Tìm phiên cũ**, chọn theo ID và workspace, rồi bấm **Nhập phiên cũ**. Nếu nguồn không liệt kê phiên, dùng **Nhập Session ID** và chọn thư mục gốc. Manager chỉ đăng ký metadata. Lịch sử và dữ liệu đăng nhập vẫn trong CODEX_HOME gốc.
3. Thoát Codex ở terminal đang chạy và đóng tác vụ ghi ngoài Manager. Chọn **Mở trong chat** để tiếp tục bằng App Server. Cần có hồ sơ trỏ đến đúng CODEX_HOME và dự án trỏ đến đúng thư mục gốc. Codex tiếp tục với ngữ cảnh của luồng cũ. Workspace hiển thị tin nhắn đã lưu trong Manager và các lượt mới.
4. Chọn **Tiếp tục phiên đã chọn** để mở cửa sổ do Manager quản lý, hoặc **Mở trong terminal ngoài** để chọn CMD, PowerShell hoặc Windows Terminal. Cả hai dùng `codex resume <ID>` với CODEX_HOME gốc.
5. Muốn mở Codex mới từ terminal ngoài, dùng **Workspace → Tiếp tục phiên cũ → Terminal bên ngoài → Mở Codex mới**. Nếu cửa sổ đóng đột ngột và khóa vẫn hiện, dùng **Giải phóng khóa** sau khi thoát Codex.

Manager tìm CLI qua PATH của tiến trình và Windows Registry, npm và trình cài Codex gốc, các thư mục cài đặt thông dụng và đường dẫn tiến trình Codex Windows khi chỉ tìm được một đường dẫn phù hợp. Với npm, có thể nhập đường dẫn tới shim `codex.cmd` hoặc `codex.ps1` khi thư mục đó chứa gói Codex được hỗ trợ. Nếu terminal có alias, lệnh PowerShell tự viết hoặc biến môi trường chỉ tồn tại trong tab, chạy `Get-Command codex | Select-Object CommandType,Source` và `$env:CODEX_HOME` trong đúng tab để tra thông tin. Dùng đường dẫn đến CLI Windows gốc và nguyên thư mục CODEX_HOME. Lệnh bên trong WSL cần được tiếp tục từ WSL.

Đọc danh sách qua chỉ mục `thread/list` chế độ state DB hoặc dòng metadata đầu của nhật ký JSONL. Mỗi lần tìm hiển thị tối đa 400 kết quả. Trạng thái lịch sử và trạng thái tiến trình bên ngoài là hai thông tin riêng. Cửa sổ do Manager mở có khóa workspace. Manager phân loại CLI, App Server, daemon, Code Mode Host và tiến trình do app mở. Một tiến trình bên ngoài chỉ chặn resume khi đối số xác nhận cùng Session ID hoặc cùng workspace. Khi thiếu quyền đọc hoặc thiếu phạm vi, trạng thái là Unknown. Hãy thoát CLI cũ bằng terminal trước khi xác nhận. Resume mở một tiến trình mới để tiếp tục cuộc hội thoại đã lưu. Khi thiếu thư mục gốc, hãy khôi phục nó trước khi tiếp tục.

- [Codex resume](https://developers.openai.com/codex/cli/reference)
- [Codex App Server](https://developers.openai.com/codex/app-server)
- [Lệnh Windows Terminal](https://learn.microsoft.com/en-us/windows/terminal/command-line-arguments)

## Workspace và chuyển hồ sơ

1. Trong **Hồ sơ Codex**, tạo và đăng nhập các hồ sơ cần dùng. Sau đó thêm workspace trong **Dự án**.
2. Trong **Workspace**, bấm tên ở ô **Dự án** hoặc **Hồ sơ Codex** để chọn hay thêm. Bấm **Mở phiên** hoặc nhập yêu cầu để bật **Gửi**. Dùng **Ctrl + Enter** để gửi bằng bàn phím. Mỗi tin nhắn tối đa 3.000 byte UTF-8.
3. Bạn có thể theo dõi câu trả lời, dừng lượt hoặc xử lý yêu cầu phê duyệt lệnh và tệp trong chat. Chỉ cấp phép một lần sau khi xem nội dung. Nếu CLI yêu cầu một loại tương tác chưa hỗ trợ, thử tiếp tục bằng terminal Codex.
4. Nếu dự án đã có lịch sử chat, chọn hồ sơ khác trong menu **Hồ sơ Codex** để mở hộp thoại bàn giao. Kiểm tra bản xem trước rồi bấm **Mở chat với hồ sơ đích**. Đợi hoặc dừng lượt đang chạy trước khi chuyển.
5. Hồ sơ đích mở luồng mới và nhận hướng dẫn đọc checkpoint trong cùng workspace. Lịch sử chat gần đây theo dự án vẫn xem được trong Manager. Nội dung chat trước đó chỉ lưu trên máy và chỉ hướng dẫn cùng các tệp checkpoint được đưa vào luồng mới.
6. **Đóng phiên** khi đã xong để nhả khóa workspace. Khi gửi lại vào đúng hồ sơ, ứng dụng tiếp tục luồng đã lưu trong Codex. Để bắt đầu luồng mới, bấm **Tạo luồng mới → Tạo và mở luồng**.
7. Nếu Workspace hiện **Cần đăng nhập**, dùng **Đăng nhập** để mở cửa sổ Codex và bấm **Mở lại phiên** sau khi đăng nhập thành công. Khi khởi động lỗi, **Lấy lại tin nhắn** đưa nội dung vừa gửi về ô nhập. Kiểm tra lịch sử phiên trước khi gửi lại yêu cầu đã được Codex xác nhận.

Manager dùng Codex CLI ở chế độ App Server với sandbox `workspace-write` và chính sách phê duyệt `on-request`. Phần chat lưu tối đa 160 tin nhắn gần nhất hoặc khoảng 2 MiB lịch sử mỗi dự án. Codex lưu luồng riêng trong `CODEX_HOME`. Các mẫu xác thực được nhận diện có thể được ẩn trong bản ghi của Manager. [Tài liệu Codex App Server](https://developers.openai.com/codex/app-server)

- **Hồ sơ Codex → Nhập hồ sơ hiện có** liệt kê các thư mục `.codex` và `.codex-*` trong thư mục người dùng. Chọn đúng thư mục rồi lưu hồ sơ. Thao tác đăng ký đường dẫn không xuất thông tin xác thực.
- **Phiên chat** tìm theo dự án, hồ sơ hoặc ID. **Lịch sử** đọc tối đa 12 lượt gần nhất do Codex cung cấp và dùng nhật ký Manager nếu CLI chưa hỗ trợ truy vấn. **Sửa** lưu tên hiển thị, ghim và trạng thái lưu trữ trong SAMERO. **Tiếp tục** mở chính xác luồng đã chọn.
- Trong **Workspace**, bấm **Tìm trong chat** hoặc `Ctrl + F` để tìm trong các tin nhắn đang có. Công cụ, output và diff của lượt hiện tại nằm trong **Hoạt động, tệp và workspace**. Nháp được lưu cục bộ sau khi ngừng gõ. Kết quả lệnh và diff chi tiết nằm trong bộ nhớ của phiên đang mở.

## Kiểm tra khởi động trên Windows

Nếu Windows báo không thể chạy, vào **Cài đặt → Hệ thống → Giới thiệu → Loại hệ thống** để kiểm tra kiến trúc. Bản này được biên dịch cho Windows x64. Có thể kiểm tra mã thoát bằng PowerShell trong thư mục giải nén:

```powershell
(Start-Process -FilePath .\SAMERO-Codex-Manager-1.6.2-rc2.exe -ArgumentList '--self-test' -Wait -PassThru).ExitCode
```

Mã `0` cho biết EXE đã vào được điểm khởi động và tự kiểm tra SHA-256 thành công. Bài kiểm tra đầy đủ hơn có trong gói mã nguồn.

## Bàn giao

1. Lưu tiến độ trong `PROJECT_STATUS.md` của workspace hoặc trong **Dự án → Chi tiết → Sửa thông tin**.
2. Thoát Codex từ terminal. Đợi các tác vụ ghi ngoài Manager kết thúc.
3. Vào **Bàn giao → Chuẩn bị bàn giao** hoặc chọn **Bàn giao hồ sơ** trong Workspace. Chọn dự án và hồ sơ đích, xác nhận workspace đã ngừng ghi rồi bấm **Kiểm tra và sao lưu**.
4. Kiểm tra bản xem trước và danh sách loại trừ. Bấm **Mở phiên đích** và xác nhận. Manager xác minh ZIP, báo cáo và trạng thái workspace một lần nữa trước khi mở Codex.
5. Codex nhận đường dẫn đến bộ tài liệu trong `.samero-handover/<checkpoint>/`. Git index và worktree gốc tiếp tục ở cùng vị trí.

Manager theo dõi cây tiến trình do mình khởi chạy. Công cụ bên ngoài có thể ghi vào workspace. Các lần quét và kiểm tra checksum phát hiện nhiều thay đổi khi tạo hoặc sử dụng checkpoint. Người dùng chịu trách nhiệm đóng các công cụ bên ngoài trước bàn giao. Nếu Codex đích hiển thị yêu cầu phê duyệt, xử lý trực tiếp trong terminal.

## Tiến độ dự án

Trong **Dự án → Chi tiết**, nút **Làm mới** đọc branch, Git status và văn bản hiện có. Kết quả build/test lấy từ các tác vụ do Manager ghi nhận. Các tệp cấu hình phổ biến được liệt kê theo tên. Nếu chưa có `PROJECT_STATUS.md`, bấm **Tạo tệp trạng thái**. Tệp đang tồn tại được bảo toàn. Bạn có thể dùng **Soạn yêu cầu cập nhật** để gửi cho Codex sau mỗi giai đoạn.

Khi bàn giao, chọn dự án và hồ sơ đích, xác nhận các tiến trình ghi đã đóng rồi bấm **Kiểm tra và sao lưu**. Xem checkpoint và xác nhận mở hồ sơ đích. Bản báo cáo lấy thêm nội dung từ `PROJECT_STATUS.md` trong dự án khi đọc được.

## Sao lưu và khôi phục

- Mỗi checkpoint có `workspace.zip`, `MANIFEST.json`, `CODEX_HANDOVER.md`, `CODEX_HANDOVER.json` và `PROJECT_STATUS.md`.
- ZIP giữ các tệp workspace đủ điều kiện. Các phiên bản staged riêng lưu trong `.samero-staged/<stage>/`. Báo cáo ghi branch, HEAD và trạng thái thay đổi, gồm những mục Git báo đã xóa.
- **Khôi phục** giải nén vào thư mục mới. Bản khôi phục là ảnh chụp mã nguồn. Lịch sử Git và Git index có thể tái tạo từ repository gốc cùng thông tin checkpoint theo nhu cầu.
- Manager loại trừ Git metadata, cache đã cấu hình, đường dẫn xác thực đã biết, liên kết, điểm reparse và nội dung khớp mẫu bí mật. Bộ lọc mẫu có thể bỏ sót định dạng chưa biết hoặc loại trừ tệp hợp lệ. Giữ dữ liệu xác thực bên ngoài workspace. Xem danh sách loại trừ trong manifest và JSON.
- Gói dùng ZIP32 dạng store, tối đa gần 4 GiB và 65.534 mục. Nếu vượt giới hạn, dùng thư mục dự án nhỏ hơn hoặc loại trừ thêm thư mục cache. Tên thư mục cache được so khớp theo từng thành phần, ngăn cách bằng dấu phẩy.
- Tác vụ build/test chạy tệp thực thi do bạn chọn. Manager ghi trạng thái, thời gian và mã thoát. Nội dung console nằm trong cửa sổ tiến trình. Chỉ chạy chương trình bạn tin cậy.

## Hạn mức

- **Workspace** hiển thị hai thanh cho hồ sơ đang chọn và hai thanh tổng. **Hồ sơ Codex** hiển thị hai thanh cho mỗi hồ sơ. Mỗi kỳ có phần trăm còn lại, giờ reset và đếm ngược khi Codex cung cấp dữ liệu.
- **Tổng 5 giờ** và **Tổng 1 tuần** đếm riêng số hồ sơ còn hạn đã xác minh theo từng kỳ. Các số **chờ reset** và **chưa rõ** hiển thị bên dưới. Số liệu nhập tay hiển thị riêng từng hồ sơ.
- Sau giờ reset, mẫu cũ chuyển về **Chưa rõ**. Manager tự hỏi lại Codex khi đến mốc reset, khi mở ứng dụng, khi kết thúc đăng nhập và sau khi máy thức dậy. Khi hoạt động bình thường, mỗi hồ sơ được kiểm tra khoảng 5 phút một lần. Lỗi kết nối làm giãn khoảng thử lại từ 30 giây đến 8 phút. Phiên chat đang mở cũng nhận các cập nhật hạn mức từ Codex App Server. **Live** là số vừa xác minh trong lần chạy hiện tại, **Cached** là mẫu đã lưu, **Offline** là lần kiểm tra gặp lỗi, **Unknown** là chưa có số được hỗ trợ. Trang **Hạn mức** hiển thị bảng và biểu đồ theo hồ sơ.

Nút **Làm mới hạn mức** gọi `account/read` và `account/rateLimits/read` của Codex App Server. Manager dùng thời lượng 300 phút và 10.080 phút để nhận diện cửa sổ 5 giờ và 7 ngày. Nếu CLI hoặc tài khoản chưa hỗ trợ, ứng dụng hiển thị **Unknown** hoặc giữ mẫu thủ công trước đó. Credit tăng thêm và lượt reset kiếm được là hai đơn vị riêng. Dashboard chỉ tổng hợp credit thủ công có cùng đơn vị và mã nhóm do người dùng xác minh. Biểu đồ dùng những mẫu lưu cục bộ.

- [Codex App Server](https://developers.openai.com/codex/app-server)
- [Lệnh Codex CLI](https://developers.openai.com/codex/cli/reference)
- [Cấu hình Codex](https://developers.openai.com/codex/config-reference)

## Mã nguồn và kiểm thử

Manager viết bằng C với Win32 API, Windows Job Object và giao diện HTML/CSS/JavaScript nhúng. Backend lắng nghe trên `127.0.0.1`, xác thực yêu cầu giao diện bằng khóa ngẫu nhiên mỗi lần mở. Metadata JSON ghi theo tệp với ghi thay thế nguyên tử. Bản Linux phục vụ kiểm thử. Bản Windows dùng các DLL hệ thống và trình duyệt đã cài.

Từ thư mục mã nguồn trên Linux x86-64, dùng GCC, GNU binutils và Python:

```sh
python3 tools/build.py linux /tmp/samero-linux
python3 tests/integration.py /tmp/samero-linux --codex /path/to/codex
python3 tools/build.py windows SAMERO-Codex-Manager.exe
python3 tests/pe_image.py SAMERO-Codex-Manager.exe
```

`--codex` kiểm tra giao tiếp với Codex thật qua một CODEX_HOME thử nghiệm trống. Bộ test còn có Codex CLI giả lập để kiểm tra hạn mức, workspace và mã thoát theo dữ liệu xác định. Test trình duyệt dùng Playwright và Chromium trong `tests/ui-smoke.cjs`. Xem `PROJECT_STATUS.md` để biết phạm vi đã kiểm chứng.

## Kiểm tra trên Windows 11

Trong gói mã nguồn, chạy `tests/windows-smoke.ps1` với `-Exe` trỏ tới EXE mới. Thêm `-Pickers` để tự kiểm tra chọn thư mục Unicode và chọn EXE. Chế độ này mở hai hộp thoại thật. Kết quả kiểm thử đóng gói hiện có trong `TEST-RESULTS.txt`.

Thêm `-LiveChat -CodexExe <codex.exe> -CodexHome <thư mục hồ sơ thử nghiệm>` để kiểm tra chat thật với một hồ sơ thử nghiệm đã đăng nhập. Bài kiểm tra tạo một luồng và gửi ba lượt ngắn có dùng hạn mức. Hai lượt đầu kiểm tra khả năng nhớ một mã ngẫu nhiên. Lượt cuối kiểm tra lại mã đó sau khi thoát hẳn Manager, chạy lại EXE và mở đúng luồng cũ. Lịch sử kiểm thử nằm trong hồ sơ đã chọn.

## Autonomous Mode

Trong **Dashboard → Autonomous Mode → Chọn dự án và START**, chọn một hồ sơ và nhập mục tiêu. Cargo dùng `cargo test` và `cargo build --release`. Go dùng `go test ./...` và `go build -trimpath ./...`. Python có pyproject.toml dùng pytest và python -m build. Node.js cần khai báo hai script test và build trong package.json. Với hệ thống khác, nhập đường dẫn chương trình test/build và mỗi đối số trên một dòng. Chỉ dùng lệnh đã biết phù hợp với dự án. Lệnh chạy với quyền người dùng hiện tại.

Runner lập kế hoạch trong lượt Codex chỉ đọc. Sau khi sửa, Manager chạy lệnh test đã xác nhận tại START và ghi ID phiên cùng mã thoát. Lượt nghiệm thu tiếp theo đọc mã nguồn và kiểm tra tiêu chí. Manager ghi PASS khi test đạt, lượt nghiệm thu trả đủ bằng chứng và checkpoint xác nhận nội dung dự án ổn định trong lúc nghiệm thu. Cuối hàng đợi còn một lần test hồi quy và build Release. Hạn mức là hai lần sửa cho mỗi nhiệm vụ. Có thể mở Workspace để xem log Codex hoặc xử lý yêu cầu phê duyệt.

PAUSE đợi giai đoạn hiện tại kết thúc. STOP dừng cây tiến trình do Manager quản lý và sao lưu phần đã ghi. RESUME sau một lượt sửa bị gián đoạn chạy lại test của nhiệm vụ chưa được xác nhận, rồi nghiệm thu chỉ đọc. Nếu test/build bị ngắt, đọc log và kiểm tra tác dụng phụ trước khi xác nhận chạy lại. HANDOVER cần chọn hồ sơ đích và xác nhận. Auto Resume chỉ áp dụng cho cùng hồ sơ sau khi có mẫu hạn mức chính thức mới và hợp lệ. Manager phải đang mở để tiếp tục chạy.

Hàng đợi và nhật ký nằm trong dữ liệu cục bộ của Manager. Workspace nhận TASK_QUEUE.json và các dòng tiến độ ghi nối tiếp trong PROJECT_STATUS.md. Khi phát hiện hàng đợi có sẵn từ nguồn khác hoặc đã bị sửa ngoài Manager, thao tác dừng để đối chiếu. Các checkpoint dùng quy tắc lọc tệp và sao lưu Git hiện có.

**Nếu bản cũ đang kẹt 0/16:** Mở đúng dự án và chọn **Dashboard → Autonomous Mode → RESUME**. Manager giữ các nhiệm vụ đã nghiệm thu, chạy test và đối chiếu phần việc đang có trong workspace trước khi yêu cầu sửa thêm. Khi tệp hàng đợi cùng kế hoạch có revision mới hơn, bản gốc được giữ trong thư mục dữ liệu `runrecovery`. Manager đối chiếu lần lượt các nhiệm vụ mà tệp đó báo đã xong. Nhật ký kiểm thử và ID phiên nghiệm thu được lưu theo từng nhiệm vụ. Nếu thiếu bằng chứng, xem lý do và tiêu chí còn thiếu ở **Hàng đợi và nhật ký**.

Bộ giám sát dừng giai đoạn sau 15 phút thiếu tín hiệu tiến triển hoặc sau 60 phút tổng cộng. Tiến trình tạo checkpoint chạy riêng và có thời hạn 30 phút. Trên Windows 11, kịch bản `tests/windows-smoke.ps1` hỗ trợ `-LiveChat` (hai lượt, đóng và mở lại) và `-LiveAutonomous` (tạo, kiểm thử, build và chạy chương trình C# thật trong thư mục tạm). Hai tùy chọn cần `-CodexExe` và `-CodexHome` trỏ tới CLI và hồ sơ đã đăng nhập.

## Approve for me

Trong Cài đặt, bật **Approve for me** rồi chọn **Lưu cài đặt**. Cài đặt có hiệu lực từ lần mở hoặc tiếp tục Chat, Autonomous Mode hoặc Codex Terminal do SAMERO quản lý. Mặc định là tắt. Phiên đang chạy giữ chính sách lúc mở. Có thể dùng STOP ngay cả khi reviewer đang xử lý yêu cầu.

SAMERO yêu cầu reviewer chính thức `auto_review` trong giai đoạn ghi. Manager kiểm tra reviewer, thư mục làm việc, phạm vi ghi, mạng và chính sách quyền mà App Server trả về trước khi gửi lượt đầu tiên. Chính sách granular chỉ bật xét duyệt cho yêu cầu từ quy tắc lệnh. SAMERO tắt các nhóm xin thoát sandbox và xin cấp thêm quyền. Bước lập kế hoạch và nghiệm thu vẫn chỉ đọc. Nếu CLI hoặc quản trị viên không cho phép chế độ đã chọn, phiên ghi dừng để kiểm tra.

Chọn **Nhật ký xét duyệt** trong Dashboard Autonomous hoặc phần Hoạt động Codex của Workspace để xem 200 quyết định/yêu cầu gần đây của dự án. Lượt đang chờ hiện *Đang xét*. Nếu phiên đóng trước khi có kết quả, nhật ký hiện *Chưa xác nhận*. Một quyết định bị từ chối, hết giờ hoặc bị hủy sẽ đưa nhiệm vụ Autonomous về *Cần đối chiếu*. Sau khi lưu checkpoint, RESUME một lượt ghi bị ngắt bắt đầu bằng test đã cấu hình và nghiệm thu chỉ đọc.

Codex xét những thao tác thực sự phát sinh yêu cầu quyền. Một thao tác vốn được sandbox cho phép có thể chạy ngay và không có bản ghi review. Vì vậy, Auto Approval không đảm bảo hỏi trước mọi lần xóa tệp trong dự án hoặc đọc một tệp mà sandbox đã cho phép. Lệnh test/build chạy trực tiếp bằng Manager tiếp tục dùng ủy quyền riêng ở START. Với Terminal Codex do Manager mở, các ghi đè cấu hình chỉ áp dụng cho tiến trình con. Khi bật, SAMERO kiểm tra cấu hình qua App Server trước khi mở CLI. Quyết định trong giao diện TUI được hiển thị bởi Codex. Terminal bên ngoài tiếp tục dùng cấu hình của chính nó. Trên Windows, tùy chọn `-LiveAutoApproval` của kịch bản smoke chạy Autonomous qua Codex đã đăng nhập và báo riêng nếu không phát sinh sự kiện xét duyệt.

## Continuous Development (ChatGPT Web, bán tự động)

Xem `CONTINUOUS-HUONG-DAN.txt`. Manager lưu mục tiêu, nhiệm vụ, ưu tiên, vòng phát triển và nhật ký theo dự án. START tạo trạng thái chờ người dùng; PAUSE/STOP lưu trạng thái, RESUME tiếp tục. Prompt đưa sáu vòng gần nhất; người dùng xem trước và tự gửi vào ChatGPT, dùng Local Bridge để xem trước và xác nhận từng bản sửa. Kết quả được ghi thủ công; tùy chọn liên kết một phiên test thực tế do Manager ghi nhận. Không tự điều khiển trang ChatGPT, không có AI nền, không truy cập token/cookie và không tự huấn luyện GPT. Xem TEST-RESULTS.txt về phạm vi kiểm thử.


## Pixel Edition 1.8.1
Mascot cáo cá mập 48×48, 9 biểu cảm. Nhấp logo mở/đóng mũ. Nhấn ♪ Nhạc ở thanh trên để bật/tắt Blue Current; thanh trượt chỉnh âm lượng. Mặc định không tự phát nhạc. Xem TEST-RESULTS.txt để biết phạm vi kiểm thử.

## Pixel AI Studio (1.9.0-studio-rc1)
Chọn Pixel Studio trong sidebar để mở Ocean Lab, văn phòng AI, mốc công việc và sáu theme. Cài đặt → Pixel Studio cho phép đổi màu nhấn, họa tiết, hoạt ảnh, âm thanh và mascot mini. Mascot mini có thể hiện trong Manager hoặc mở popup nếu trình duyệt hỗ trợ, không đảm bảo always-on-top. Chọn một trong ba nhạc nền trên topbar rồi nhấn bật; Focus Mode tắt nhạc và hiệu ứng, không đổi công việc. Các vai trò Workforce vẫn phối hợp qua prompt do người dùng chuyển giao. Mốc tiến độ lấy từ trạng thái Manager, không phải đánh giá hoàn hảo. Xem TEST-RESULTS.txt về giới hạn kiểm chứng.
