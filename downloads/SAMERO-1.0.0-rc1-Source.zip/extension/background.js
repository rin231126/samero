'use strict';
chrome.runtime.onInstalled.addListener(()=>{
  chrome.contextMenus.removeAll(()=>chrome.contextMenus.create({id:'samero-select',title:'SAMERO: giữ đoạn JSON đã chọn',contexts:['selection'],documentUrlPatterns:['https://chatgpt.com/*']}));
});
chrome.contextMenus.onClicked.addListener(async(info)=>{
  if(info.menuItemId!=='samero-select'||!info.pageUrl?.startsWith('https://chatgpt.com/'))return;
  const text=info.selectionText||'';
  if(text.length>250000){await chrome.storage.session.remove('patch');await chrome.action.setBadgeText({text:'ERR'});return;}
  await chrome.storage.session.set({patch:text});await chrome.action.setBadgeText({text:'1'});
});
