'use strict';
const $=id=>document.getElementById(id);
async function load(){const {patch}=await chrome.storage.session.get('patch');$('text').value=patch||'';}
load().catch(e=>$('status').textContent=e.message);
$('clear').onclick=async()=>{await chrome.storage.session.remove('patch');await chrome.action.setBadgeText({text:''});await load();$('status').textContent='Đã xóa.';};
$('send').onclick=async()=>{
  try{
    const text=$('text').value;if(!text)throw Error('Chưa có đoạn JSON đã chọn.');
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id||!/^http:\/\/127\.0\.0\.1:\d+\/$/.test(tab.url||''))throw Error('Mở tab Manager cục bộ và chọn mục ChatGPT Web trước.');
    const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:(value)=>{
      if(document.title!=='SAMERO Codex Manager'||!document.querySelector('[data-bridge-ui="1"]'))return false;
      const el=document.getElementById('bridge-patch');if(!el||el.tagName!=='TEXTAREA')return false;
      el.value=value;el.dispatchEvent(new Event('input',{bubbles:true}));el.focus();return true;
    },args:[text]});
    if(!result)throw Error('Không tìm thấy ô bản sửa trong Manager.');
    await chrome.storage.session.remove('patch');await chrome.action.setBadgeText({text:''});await load();$('status').textContent='Đã chuyển. Hãy xem trước và xác nhận trong Manager.';
  }catch(e){$('status').textContent=e.message;}
};
