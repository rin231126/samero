#include "archive.h"

static const uint32_t sha_k[] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
};
static uint32_t rotate(uint32_t x, unsigned n) { return x >> n | x << (32 - n); }
static void sha_block(Sha256 *h, const unsigned char *buf) {
    uint32_t w[64];
    for (int i = 0; i < 16; ++i)
        w[i] = (uint32_t)buf[i*4] << 24 | (uint32_t)buf[i*4+1] << 16 |
            (uint32_t)buf[i*4+2] << 8 | buf[i*4+3];
    for (int i = 16; i < 64; ++i) {
        uint32_t a = w[i-15], b = w[i-2];
        w[i] = w[i-16] + (rotate(a,7) ^ rotate(a,18) ^ (a >> 3)) + w[i-7] +
            (rotate(b,17) ^ rotate(b,19) ^ (b >> 10));
    }
    uint32_t a=h->state[0], b=h->state[1], c=h->state[2], d=h->state[3];
    uint32_t e=h->state[4], f=h->state[5], g=h->state[6], z=h->state[7];
    for (int i = 0; i < 64; ++i) {
        uint32_t t1 = z + (rotate(e,6) ^ rotate(e,11) ^ rotate(e,25)) +
            ((e & f) ^ (~e & g)) + sha_k[i] + w[i];
        uint32_t t2 = (rotate(a,2) ^ rotate(a,13) ^ rotate(a,22)) + ((a & b) ^ (a & c) ^ (b & c));
        z=g; g=f; f=e; e=d + t1; d=c; c=b; b=a; a=t1 + t2;
    }
    h->state[0] += a; h->state[1] += b; h->state[2] += c; h->state[3] += d;
    h->state[4] += e; h->state[5] += f; h->state[6] += g; h->state[7] += z;
}
void sha_update(Sha256 *s, const void *data, size_t len) {
    if (!s->bytes) {
        const uint32_t initial[] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
            0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
        memcpy(s->state, initial, sizeof(initial));
    }
    const unsigned char *begin = data;
    size_t used = s->bytes & 63;
    s->bytes += len;
    while (len) {
        size_t n = 64 - used < len ? 64 - used : len;
        memcpy(s->pending + used, begin, n);
        begin += n; used += n; len -= n;
        if (used == 64) { sha_block(s, s->pending); used = 0; }
    }
}
void sha_finish(Sha256 *s, char hex[65]) {
    uint64_t bits = s->bytes * 8;
    unsigned char pad[128] = {0x80};
    size_t len = 64 - (s->bytes & 63);
    if (len < 9) len += 64;
    for (int i = 0; i < 8; ++i) pad[len-i-1] = (unsigned char)(bits >> (8*i));
    sha_update(s, pad, len);
    for (int i = 0; i < 8; ++i) sam_format(hex + i*8, 9, "%08x", s->state[i]);
}
int digest_file(const char *path, char hex[65], Error *e) {
    Info info;
    FILE *f = file_info(path, &info) && info.kind == 1 ? file_open(path, 0) : NULL;
    if (!f) return errorf(e, "Không đọc được tệp để tính SHA-256.");
    unsigned char *data = allocate(65536);
    Sha256 sha = {0};
    size_t n;
    uint64_t total = 0;
    while ((n = fread(data, 1, 65536, f))) { sha_update(&sha, data, n); total += n; }
    int ok = !ferror(f) && total == info.size;
    fclose(f); free(data);
    if (!ok) return errorf(e, "Tệp thay đổi khi tính SHA-256.");
    sha_finish(&sha, hex);
    return 1;
}
static uint32_t crc_update(uint32_t value, const unsigned char *p, size_t n) {
    static uint32_t table[256];
    if (!table[1]) {
        for (unsigned i = 0; i < 256; ++i) {
            uint32_t x = i;
            for (int bit = 0; bit < 8; ++bit) x = (x >> 1) ^ (0xedb88320 & (uint32_t)-(int)(x & 1));
            table[i] = x;
        }
    }
    for (size_t i = 0; i < n; ++i) value = (value >> 8) ^ table[(value ^ p[i]) & 255];
    return value;
}
static int same_file(const Info *a, const Info *b) {
    return a->kind == b->kind && a->size == b->size && a->mtime == b->mtime &&
        a->inode == b->inode && a->device == b->device && a->mode == b->mode;
}
static int safe_path(const char *rel) {
    if (!*rel || strlen(rel) >= PATH_CAP) return 0;
    for (const char *p = rel; *p;) {
        size_t len = strcspn(p, "/");
        char part[256];
        if (!len || len >= sizeof(part)) return 0;
        memcpy(part, p, len); part[len] = 0;
        if (!path_valid_component(part) || credential_path(part) || secret_text(part)) return 0;
        p += len;
        if (*p) { ++p; if (!*p) return 0; }
    }
    return 1;
}
static int file_bytes(const char *path, const Info *wanted, FILE *destination, int scan,
                      char hex[65], uint32_t *crc, int *sensitive, Error *e) {
    Info before, after;
    if (!file_info(path, &before) || before.kind != 1 || !same_file(&before, wanted))
        return errorf(e, "Tệp đã đổi trước khi sao lưu: %s", path);
    FILE *f = file_open(path, 0);
    if (!f) return errorf(e, "Không mở được tệp dự án: %s", path);
    unsigned char *data = allocate(65536);
    char *text = scan ? allocate(65536 + 129) : NULL;
    size_t n, overlap = 0;
    uint64_t total = 0;
    Sha256 sha = {0};
    uint32_t crc32 = UINT32_MAX;
    int ok = 1;
    *sensitive = 0;
    while ((n = fread(data, 1, 65536, f))) {
        if (text && !*sensitive) {
            for (size_t i = 0; i < n; ++i) text[overlap + i] = data[i] ? (char)data[i] : ' ';
            size_t len = overlap + n;
            text[len] = 0;
            *sensitive = secret_text(text);
            overlap = len < 128 ? len : 128;
            memmove(text, text + len - overlap, overlap);
            if (*sensitive) break;
        }
        if (destination && fwrite(data, 1, n, destination) != n) { ok = 0; break; }
        total += n;
        sha_update(&sha, data, n);
        crc32 = crc_update(crc32, data, n);
    }
    if (ferror(f)) ok = 0;
    fclose(f); free(data); free(text);
    if (*sensitive) return 1;
    if (!ok || total != wanted->size || !file_info(path, &after) || !same_file(&before, &after))
        return errorf(e, "Tệp đổi trong lúc đọc hoặc ổ đĩa ghi lỗi: %s", path);
    sha_finish(&sha, hex);
    *crc = ~crc32;
    return 1;
}

void snapshot_exclude(Snapshot *s, const char *rel, const char *reason) {
    ++s->excluded_count;
    if (s->excluded.n < 512 * 1024) {
        if (s->excluded.n) buffer_char(&s->excluded, ',');
        buffer_char(&s->excluded, '{');
        json_pair(&s->excluded, "path", secret_text(rel) ? "[redacted]" : rel);
        buffer_char(&s->excluded, ',');
        json_pair(&s->excluded, "reason", reason);
        buffer_char(&s->excluded, '}');
    }
}
static int cache_match(const Snapshot *s, const char *name) {
    if (!s->cache_names) return 0;
    for (const char *p = s->cache_names; *p;) {
        size_t len = strcspn(p, ",");
        if (len < 256) {
            char key[256];
            memcpy(key, p, len); key[len] = 0;
            if (ascii_equal(key, name)) return 1;
        }
        p += len + (p[len] == ',');
    }
    return 0;
}
static void append_entry(Snapshot *s, Entry *item, const char *rel) {
    if (s->n == s->cap) {
        s->cap = s->cap ? s->cap * 2 : 128;
        Entry *entries = realloc(s->entries, s->cap * sizeof(*entries));
        if (!entries) abort();
        s->entries = entries;
    }
    item->name = allocate(strlen(rel) + 1);
    memcpy(item->name, rel, strlen(rel) + 1);
    s->entries[s->n++] = *item;
}
typedef struct { Snapshot *s; const char *dir, *relative; int depth; } Walk;
static int visit_project(const char *name, const Info *listed, void *context, Error *e) {
    Walk *walk = context;
    Snapshot *s = walk->s;
    Path *dirs = allocate(3 * sizeof(Path));
    Path *absolute = &dirs[0], *relative = &dirs[1], *resolved = &dirs[2];
    int ok = 1;
    if (!path_join(absolute, walk->dir, name) || !path_join(relative, walk->relative, name)) {
        ok = errorf(e, "Đường dẫn quá dài trong dự án."); goto done;
    }
    if (credential_path(name) || secret_text(name)) {
        snapshot_exclude(s, relative->p, "credentials/Git metadata"); goto done;
    }
    if (!walk->depth && (ascii_equal(name, ".samero-handover") || ascii_equal(name, ".samero-staged"))) {
        goto done;
    }
    if (listed->kind == 2 && cache_match(s, name)) { snapshot_exclude(s, relative->p, "cache"); goto done; }
    if (listed->kind == 3) { snapshot_exclude(s, relative->p, "symbolic link/reparse point"); goto done; }
    if (listed->kind != 1 && listed->kind != 2) { ok = errorf(e, "Loại tệp không hỗ trợ."); goto done; }
    if (!canonical(absolute->p, resolved) || !within(absolute->p, resolved->p) || !within(resolved->p, absolute->p)) {
        ok = errorf(e, "Đường dẫn thay đổi trong lúc duyệt dự án: %s", relative->p); goto done;
    }
    for (size_t i = 0; i < s->root_count; ++i) {
        if (within(s->roots[i], resolved->p)) {
            snapshot_exclude(s, relative->p, "protected directory"); goto done;
        }
    }
    if (!safe_path(relative->p)) { ok = errorf(e, "Tên tệp không tương thích Windows: %s", relative->p); goto done; }
    if (s->n >= 65534 || walk->depth >= 64) { ok = errorf(e, "Dự án vượt giới hạn số mục hoặc độ sâu ZIP."); goto done; }
    Entry item;
    memset(&item, 0, sizeof(item));
    if (!file_info(absolute->p, &item.info) || item.info.kind != listed->kind) {
        ok = errorf(e, "Tệp thay đổi trong lúc duyệt: %s", relative->p); goto done;
    }
    if (item.info.kind == 2) {
        append_entry(s, &item, relative->p);
        Walk nested = {s, absolute->p, relative->p, walk->depth + 1};
        ok = list_dir(absolute->p, visit_project, &nested, e);
    } else {
        if (item.info.size >= UINT32_MAX) { ok = errorf(e, "Tệp vượt giới hạn ZIP32: %s", relative->p); goto done; }
        int sensitive;
        ok = file_bytes(absolute->p, &item.info, NULL, 1, item.sha, &item.crc, &sensitive, e);
        if (ok && sensitive) snapshot_exclude(s, relative->p, "potential secret");
        else if (ok) append_entry(s, &item, relative->p);
    }
done:
    free(dirs);
    return ok;
}
int snapshot_walk(Snapshot *s, const char *workspace, Error *e) {
    Walk walk = {s, workspace, "", 0};
    return list_dir(workspace, visit_project, &walk, e);
}
int snapshot_blob(Snapshot *s, const char *name, Buf *bytes, unsigned mode, Error *e) {
    if (!safe_path(name)) { snapshot_exclude(s, name, "protected staged path"); return 1; }
    if (s->n >= 65534) return errorf(e, "Dự án vượt giới hạn số mục ZIP.");
    char *copy = allocate(bytes->n + 1);
    for (size_t i = 0; i < bytes->n; ++i) copy[i] = bytes->s[i] ? bytes->s[i] : ' ';
    int sensitive = secret_text(copy);
    free(copy);
    if (sensitive) { snapshot_exclude(s, name, "potential secret in staged blob"); return 1; }
    Entry entry = {.info={.kind=1, .mode=mode, .size=bytes->n}, .bytes=bytes->s};
    if (!entry.bytes) entry.bytes = allocate(1);
    Sha256 sha = {0};
    sha_update(&sha, entry.bytes, bytes->n); sha_finish(&sha, entry.sha);
    entry.crc = ~crc_update(UINT32_MAX, (const unsigned char *)entry.bytes, bytes->n);
    append_entry(s, &entry, name);
    *bytes = (Buf){0};
    return 1;
}
static int compare_entry(const void *a, const void *b) {
    return strcmp(((const Entry *)a)->name, ((const Entry *)b)->name);
}
void snapshot_fingerprint(Snapshot *s, char hex[65]) {
    if (s->n) qsort(s->entries, s->n, sizeof(*s->entries), compare_entry);
    Sha256 sha = {0};
    for (size_t i = 0; i < s->n; ++i) {
        Entry *x = &s->entries[i];
        sha_update(&sha, x->name, strlen(x->name) + 1);
        sha_update(&sha, &x->info.kind, sizeof(x->info.kind));
        sha_update(&sha, &x->info.mode, sizeof(x->info.mode));
        sha_update(&sha, x->sha, sizeof(x->sha));
    }
    sha_finish(&sha, hex);
}
void snapshot_free(Snapshot *s) {
    for (size_t i = 0; i < s->n; ++i) { free(s->entries[i].name); free(s->entries[i].bytes); }
    free(s->entries); buffer_free(&s->excluded);
    *s = (Snapshot){0};
}

static void put16(unsigned char *p, unsigned x) { p[0] = (unsigned char)x; p[1] = (unsigned char)(x >> 8); }
static void put32(unsigned char *p, uint32_t x) { put16(p, x); put16(p+2, x >> 16); }
static unsigned get16(const unsigned char *p) { return (unsigned)p[0] | (unsigned)p[1] << 8; }
static uint32_t get32(const unsigned char *p) { return get16(p) | (uint32_t)get16(p+2) << 16; }
static int zip_name(FILE *f, const Entry *x) {
    size_t len = strlen(x->name);
    return fwrite(x->name, 1, len, f) == len && (x->info.kind != 2 || fwrite("/", 1, 1, f) == 1);
}
int archive_write(Snapshot *s, const char *workspace, const char *zip, Error *e) {
    FILE *f = file_open_new(zip);
    if (!f) return errorf(e, "Không tạo được ZIP.");
    uint64_t offset = 0;
    int ok = 1;
    Path *path = allocate(sizeof(*path));
    for (size_t i = 0; i < s->n && ok; ++i) {
        Entry *x = &s->entries[i];
        unsigned char h[30] = {0};
        unsigned len = (unsigned)strlen(x->name) + (x->info.kind == 2);
        uint64_t size = x->info.kind == 2 ? 0 : x->info.size;
        if (offset + sizeof(h) + len + size >= UINT32_MAX) { ok = 0; break; }
        x->offset = (uint32_t)offset;
        put32(h, 0x04034b50); put16(h+4, 20); put16(h+6, 0x0800); put16(h+12, 33);
        put32(h+14, x->crc); put32(h+18, (uint32_t)size); put32(h+22, (uint32_t)size); put16(h+26, len);
        ok = fwrite(h, 1, sizeof(h), f) == sizeof(h) && zip_name(f, x);
        offset += sizeof(h) + len + size;
        if (ok && x->info.kind == 1) {
            if (x->bytes) ok = fwrite(x->bytes, 1, (size_t)size, f) == size;
            else {
                char sha[65]; uint32_t crc; int sensitive;
                ok = path_join(path, workspace, x->name) &&
                    file_bytes(path->p, &x->info, f, 0, sha, &crc, &sensitive, e) &&
                    crc == x->crc && !strcmp(sha, x->sha);
            }
        }
    }
    uint32_t central = (uint32_t)offset;
    for (size_t i = 0; i < s->n && ok; ++i) {
        Entry *x = &s->entries[i];
        unsigned char h[46] = {0};
        int directory = x->info.kind == 2;
        unsigned len = (unsigned)strlen(x->name) + directory;
        uint32_t size = directory ? 0 : (uint32_t)x->info.size;
        offset += sizeof(h) + len;
        if (offset + 22 >= UINT32_MAX) { ok = 0; break; }
        put32(h, 0x02014b50); put16(h+4, 0x0314); put16(h+6, 20); put16(h+8, 0x0800); put16(h+14, 33);
        put32(h+16, x->crc); put32(h+20, size); put32(h+24, size); put16(h+28, len);
        put32(h+38, ((directory ? 0040000u | 0755u : 0100000u | x->info.mode) << 16) | (directory ? 16u : 0u));
        put32(h+42, x->offset);
        ok = fwrite(h, 1, sizeof(h), f) == sizeof(h) && zip_name(f, x);
    }
    unsigned char end[22] = {0};
    put32(end, 0x06054b50); put16(end+8, (unsigned)s->n); put16(end+10, (unsigned)s->n);
    put32(end+12, (uint32_t)(offset-central)); put32(end+16, central);
    if (ok) ok = fwrite(end, 1, sizeof(end), f) == sizeof(end) && file_flush(f);
    if (fclose(f)) ok = 0;
    free(path);
    if (ok) return 1;
    remove_file(zip);
    return e->msg[0] ? 0 : errorf(e, "Dữ liệu đổi trong lúc đóng gói, ZIP32 vượt 4 GiB, hoặc ổ đĩa ghi lỗi.");
}

static int prepare_restore(const char *root, char *name, int directory, Path *path) {
    if (!path_join(path, root, name)) return 0;
    char *start = path->p + strlen(root);
    if (*start == '/') ++start;
    for (char *c = start; *c; ++c) {
        if (*c != '/') continue;
        *c = 0;
        Info info;
        int ok = mkdir_new(path->p) || (file_info(path->p, &info) && info.kind == 2);
        *c = '/';
        if (!ok) return 0;
    }
    if (!directory) return 1;
    Info info;
    return mkdir_new(path->p) || (file_info(path->p, &info) && info.kind == 2);
}

int archive_read(const char *zip, const char *restore, Error *e) {
    Info meta;
    FILE *in = file_info(zip, &meta) && meta.kind == 1 ? file_open(zip, 0) : NULL;
    if (!in) return errorf(e, "Không mở được ZIP để xác minh.");
    unsigned char tail[22], central[46], local[30];
    uint64_t cursor = 0, end = 0, next_local = 0;
    unsigned count = 0;
    int ok = meta.size >= sizeof(tail) && meta.size < UINT32_MAX &&
        file_seek(in, meta.size - sizeof(tail)) && fread(tail, 1, sizeof(tail), in) == sizeof(tail) &&
        get32(tail) == 0x06054b50 && !get32(tail+4) && !get16(tail+20) && get16(tail+8) == get16(tail+10);
    if (ok) {
        count = get16(tail+10);
        cursor = get32(tail+16);
        end = cursor + get32(tail+12);
        ok = end == meta.size - sizeof(tail);
    }
    uint64_t central_start = cursor;
    char *name = allocate(PATH_CAP), *other = allocate(PATH_CAP);
    Path *path = allocate(sizeof(*path));
    unsigned char *data = allocate(65536);
    for (unsigned i = 0; i < count && ok; ++i) {
        ok = cursor + sizeof(central) <= end && file_seek(in, cursor) &&
            fread(central, 1, sizeof(central), in) == sizeof(central) && get32(central) == 0x02014b50;
        if (!ok) break;
        unsigned length = get16(central+28);
        uint32_t crc = get32(central+16), size = get32(central+24), offset = get32(central+42);
        ok = length && length < PATH_CAP && get16(central+8) == 0x0800 && !get16(central+10) &&
            !get16(central+30) && !get16(central+32) && !get16(central+34) && size == get32(central+20) &&
            offset == next_local && cursor + sizeof(central) + length <= end &&
            (uint64_t)offset + sizeof(local) + length + size <= central_start &&
            fread(name, 1, length, in) == length && !memchr(name, 0, length) &&
            file_seek(in, offset) && fread(local, 1, sizeof(local), in) == sizeof(local) &&
            get32(local) == 0x04034b50 && get16(local+6) == 0x0800 && !get16(local+8) &&
            get32(local+14) == crc && get32(local+18) == size && get32(local+22) == size &&
            get16(local+26) == length && !get16(local+28) &&
            fread(other, 1, length, in) == length && !memcmp(name, other, length);
        if (!ok) break;
        cursor += sizeof(central) + length;
        next_local = (uint64_t)offset + sizeof(local) + length + size;
        int directory = name[length-1] == '/';
        name[length-directory] = 0;
        ok = safe_path(name) && (!directory || (!size && !crc));
        FILE *out = NULL;
        if (ok && restore) {
            ok = prepare_restore(restore, name, directory, path);
            if (ok && !directory) { out = file_open_new(path->p); ok = out != NULL; }
        }
        uint32_t actual = UINT32_MAX;
        while (ok && size) {
            size_t chunk = size < 65536 ? size : 65536;
            ok = fread(data, 1, chunk, in) == chunk && (!out || fwrite(data, 1, chunk, out) == chunk);
            if (ok) { actual = crc_update(actual, data, chunk); size -= (uint32_t)chunk; }
        }
        if (out) {
            int flushed = file_flush(out);
            if (fclose(out) || !flushed) ok = 0;
            if (ok) restore_mode(path->p, (get32(central+38) >> 16) & 0777);
        }
        ok = ok && ~actual == crc;
    }
    ok = ok && cursor == end && next_local == central_start;
    fclose(in); free(name); free(other); free(path); free(data);
    return ok ? 1 : errorf(e, "ZIP lỗi cấu trúc, sai CRC hoặc không thể khôi phục tệp.");
}

/* Read one stored ZIP32 member without extracting any paths. The caller must
   compare the returned bytes against a trusted manifest's SHA-256. */
int archive_member(const char *zip,const char *wanted,size_t limit,Buf *out,Error *e) {
    Info meta; FILE *in=file_info(zip,&meta) && meta.kind==1?file_open(zip,0):NULL;
    if (!in) return errorf(e,"Không mở được ZIP lịch sử.");
    unsigned char tail[22],central[46],local[30]; uint64_t cursor=0,end=0,start=0;
    int found=0,ok=meta.size>=sizeof(tail) && meta.size<UINT32_MAX &&
        file_seek(in,meta.size-sizeof(tail)) && fread(tail,1,sizeof(tail),in)==sizeof(tail) &&
        get32(tail)==0x06054b50 && !get32(tail+4) && !get16(tail+20) && get16(tail+8)==get16(tail+10);
    if (ok) {start=cursor=get32(tail+16); end=cursor+get32(tail+12); ok=end==meta.size-sizeof(tail);}
    char *name=allocate(PATH_CAP),*other=allocate(PATH_CAP); unsigned char *chunk=allocate(65536);
    for (unsigned i=0;ok && i<get16(tail+10);++i) {
        ok=cursor+sizeof(central)<=end && file_seek(in,cursor) && fread(central,1,sizeof(central),in)==sizeof(central) && get32(central)==0x02014b50;
        if (!ok) break;
        unsigned n=get16(central+28); uint32_t size=get32(central+24),offset=get32(central+42),crc=get32(central+16);
        ok=n && n<PATH_CAP && !get16(central+30) && !get16(central+32) && !get16(central+34) &&
            cursor+sizeof(central)+n<=end && fread(name,1,n,in)==n && !memchr(name,0,n);
        if (!ok) break;
        name[n]=0; cursor+=sizeof(central)+n;
        if (strcmp(name,wanted)) continue;
        ok=!found && size<=limit && get16(central+8)==0x0800 && !get16(central+10) && size==get32(central+20) &&
            (uint64_t)offset+sizeof(local)+n+size<=start && file_seek(in,offset) && fread(local,1,sizeof(local),in)==sizeof(local) &&
            get32(local)==0x04034b50 && get16(local+6)==0x0800 && !get16(local+8) && get32(local+14)==crc &&
            get32(local+18)==size && get32(local+22)==size && get16(local+26)==n && !get16(local+28) &&
            fread(other,1,n,in)==n && !memcmp(name,other,n);
        uint32_t actual=UINT32_MAX;
        while (ok && size) {
            size_t take=size<65536?size:65536; ok=fread(chunk,1,take,in)==take;
            if (ok) {actual=crc_update(actual,chunk,take); buffer_add(out,chunk,take); size-=(uint32_t)take;}
        }
        ok=ok && ~actual==crc; found=1;
    }
    ok=ok && found && cursor==end;
    fclose(in); free(name); free(other); free(chunk);
    return ok?1:errorf(e,"Không đọc được mục ZIP lịch sử đã yêu cầu.");
}
