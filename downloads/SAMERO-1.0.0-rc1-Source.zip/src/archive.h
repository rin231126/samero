#ifndef SAM_ARCHIVE
#define SAM_ARCHIVE
#include "base.h"

typedef struct {
    uint32_t state[8];
    uint64_t bytes;
    unsigned char pending[64];
} Sha256;
void sha_update(Sha256 *s, const void *data, size_t len);
void sha_finish(Sha256 *s, char hex[65]);
int digest_file(const char *path, char hex[65], Error *e);

typedef struct {
    char *name;
    Info info;
    uint32_t crc, offset;
    char sha[65];
    char *bytes; /* In-memory entry for a staged Git blob. */
} Entry;
typedef struct {
    Entry *entries;
    size_t n, cap;
    Buf excluded;
    size_t excluded_count;
    const char *const *roots;
    size_t root_count;
    const char *cache_names;
} Snapshot;
int snapshot_walk(Snapshot *s, const char *workspace, Error *e);
void snapshot_exclude(Snapshot *s, const char *rel, const char *reason);
int snapshot_blob(Snapshot *s, const char *name, Buf *bytes, unsigned mode, Error *e);
void snapshot_fingerprint(Snapshot *s, char hex[65]);
void snapshot_free(Snapshot *s);
int archive_write(Snapshot *s, const char *workspace, const char *zip, Error *e);
int archive_read(const char *zip, const char *restore, Error *e);
int archive_member(const char *zip,const char *wanted,size_t limit,Buf *out,Error *e);
#endif
