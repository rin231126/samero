#include "base.h"
#ifdef SAM_WINDOWS
extern int __stdio_common_vsprintf(uint64_t, char *, size_t, const char *, void *, va_list);
#endif

static int vformat(char *out, size_t cap, const char *fmt, va_list args) {
#ifdef SAM_WINDOWS
    return __stdio_common_vsprintf(2, out, cap, fmt, NULL, args);
#else
    return vsnprintf(out, cap, fmt, args);
#endif
}

int sam_format(char *out, size_t cap, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    int n = vformat(out, cap, fmt, args);
    va_end(args);
    return n;
}

int errorf(Error *e, const char *fmt, ...) {
    va_list args;
    va_start(args, fmt);
    vformat(e->msg, sizeof(e->msg), fmt, args);
    va_end(args);
    return 0;
}

void *allocate(size_t count) {
    void *p = calloc(1, count);
    if (!p) abort();
    return p;
}

void buffer_add(Buf *b, const void *data, size_t size) {
    if (size > SIZE_MAX - b->n - 1) abort();
    size_t need = b->n + size + 1;
    if (b->cap < need) {
        size_t cap = b->cap ? b->cap : 256;
        while (cap < need) cap = cap <= SIZE_MAX / 2 ? cap * 2 : need;
        char *s = realloc(b->s, cap);
        if (!s) abort();
        b->s = s;
        b->cap = cap;
    }
    if (size) memcpy(b->s + b->n, data, size);
    b->n += size;
    b->s[b->n] = 0;
}

void buffer_text(Buf *b, const char *s) { buffer_add(b, s, strlen(s)); }
void buffer_char(Buf *b, char c) { buffer_add(b, &c, 1); }

void buffer_fmt(Buf *b, const char *fmt, ...) {
    va_list args;
    char temp[512];
    va_start(args, fmt);
    int n = vformat(temp, sizeof(temp), fmt, args);
    va_end(args);
    if (n < 0) abort();
    if ((size_t)n < sizeof(temp)) {
        buffer_add(b, temp, (size_t)n);
    } else {
        char *large = allocate((size_t)n + 1);
        va_start(args, fmt);
        vformat(large, (size_t)n + 1, fmt, args);
        va_end(args);
        buffer_add(b, large, (size_t)n);
        free(large);
    }
}

void buffer_free(Buf *b) {
    free(b->s);
    memset(b, 0, sizeof(*b));
}

void json_quote(Buf *b, const char *s) {
    buffer_char(b, '"');
    for (; *s; ++s) {
        unsigned char c = (unsigned char)*s;
        if (c == '"' || c == '\\') buffer_char(b, '\\');
        if (c < 32) buffer_fmt(b, "\\u%04x", (unsigned)c);
        else buffer_char(b, (char)c);
    }
    buffer_char(b, '"');
}

void json_key(Buf *b, const char *key) { json_quote(b, key); buffer_char(b, ':'); }
void json_pair(Buf *b, const char *key, const char *value) { json_key(b, key); json_quote(b, value); }

static int lower_ascii(int c) { return c >= 'A' && c <= 'Z' ? c + 32 : c; }
int ascii_equal(const char *a, const char *b) {
    for (; *a && *b; ++a, ++b) if (lower_ascii(*a) != lower_ascii(*b)) return 0;
    return *a == *b;
}
int has_suffix(const char *s, const char *suffix) {
    size_t n = strlen(s), m = strlen(suffix);
    return n >= m && ascii_equal(s + n - m, suffix);
}
int contains_ci(const char *text, const char *needle) {
    for (; *text; ++text) {
        size_t i = 0;
        while (needle[i] && text[i] && lower_ascii(text[i]) == lower_ascii(needle[i])) ++i;
        if (!needle[i]) return 1;
    }
    return 0;
}
int path_join(Path *out, const char *dir, const char *tail) {
    size_t n = strlen(dir), m = strlen(tail);
    int slash = n && dir[n-1] != '/' && dir[n-1] != '\\';
    if (n + m + slash >= sizeof(out->p)) return 0;
    memmove(out->p, dir, n);
    if (slash) out->p[n++] = '/';
    memmove(out->p + n, tail, m + 1);
    return 1;
}
const char *base_name(const char *path) {
    const char *last = path;
    for (; *path; ++path) if (*path == '/' || *path == '\\') last = path + 1;
    return last;
}
static int path_separator(char c) {
#ifdef SAM_WINDOWS
    return c=='/' || c=='\\';
#else
    return c=='/';
#endif
}
int within(const char *root, const char *path) {
    size_t n = strlen(root);
    while (n > 1 && path_separator(root[n-1])) --n;
    for (size_t i = 0; i < n; ++i) {
#ifdef SAM_WINDOWS
        if (path_separator(root[i]) && path_separator(path[i])) continue;
        if (!path[i] || lower_ascii(root[i]) != lower_ascii(path[i])) return 0;
#else
        if (!path[i] || root[i] != path[i]) return 0;
#endif
    }
    return (n == 1 && path_separator(root[0])) || !path[n] || path_separator(path[n]);
}

int path_valid_component(const char *name) {
    size_t length = strlen(name);
    if (!length || name[length-1] == '.' || name[length-1] == ' ' || length > 255)
        return 0;
    for (const unsigned char *p = (const unsigned char *)name; *p; ++p)
        if (*p < 32 || strchr("<>:\"/\\|?*", *p)) return 0;
    char stem[256];
    size_t n = strcspn(name, ".");
    memcpy(stem, name, n);
    stem[n] = 0;
    while (n && stem[n-1] == ' ') stem[--n] = 0;
    const char *reserved[] = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
        "COM¹", "COM²", "COM³", "LPT¹", "LPT²", "LPT³"};
    for (size_t i = 0; i < ARRAY_LEN(reserved); ++i) if (ascii_equal(stem, reserved[i])) return 0;
    return 1;
}

int credential_path(const char *rel) {
    const char *p = base_name(rel);
    const char *exact[] = {".git", ".codex", ".ssh", ".gnupg", ".aws", ".azure", ".kube", ".netrc",
        "_netrc", ".npmrc", ".pypirc", "auth.json", "access_token", "refresh_token", "cookies",
        "cookies.sqlite", ".git-credentials", "credentials", "credentials.json", "secrets.json",
        "secrets.yml", "secrets.yaml", "id_rsa", "id_ed25519", "id_ecdsa", "id_dsa", "known_hosts",
        "passwords.txt", "Login Data", "Local State", "key4.db"};
    for (size_t i = 0; i < ARRAY_LEN(exact); ++i) if (ascii_equal(p, exact[i])) return 1;
    size_t n = strlen(p);
    if (n >= 4 && p[0] == '.' && lower_ascii(p[1]) == 'e' &&
        lower_ascii(p[2]) == 'n' && lower_ascii(p[3]) == 'v' &&
        (p[4] == 0 || p[4] == '.' || p[4] == '-')) return 1;
    return has_suffix(p, ".pem") || has_suffix(p, ".p12") || has_suffix(p, ".pfx") ||
        has_suffix(p, ".key") || has_suffix(p, ".kdbx") || has_suffix(p, ".jks") ||
        contains_ci(p, "credential") || contains_ci(p, "apikey") || contains_ci(p, "api-key");
}

int secret_text(const char *s) {
    static const char *markers[] = {"-----BEGIN PRIVATE KEY", "-----BEGIN RSA PRIVATE KEY",
        "-----BEGIN OPENSSH PRIVATE KEY", "-----BEGIN ENCRYPTED PRIVATE KEY", "-----BEGIN EC PRIVATE KEY",
        "sk-proj-", "sk-svcacct-", "github_pat_", "ghp_", "gho_", "xoxb-", "xoxp-", "authorization: bearer ",
        "\"refresh_token\"", "\"access_token\"", "-----BEGIN PGP PRIVATE KEY", "password=", "password:",
        "api_key=", "openai_api_key=", "access_token=", "client_secret=", "AKIA"};
    for (size_t i = 0; i < ARRAY_LEN(markers); ++i) if (contains_ci(s, markers[i])) return 1;
    return 0;
}

int valid_id(const char *id) {
    if (strlen(id) != 32) return 0;
    for (const char *p = id; *p; ++p)
        if (!(*p >= '0' && *p <= '9') && !(*p >= 'a' && *p <= 'f')) return 0;
    return 1;
}
void new_id(char out[33]) {
    unsigned char bytes[16];
    const char *hex = "0123456789abcdef";
    if (!system_random(bytes, sizeof(bytes))) abort();
    for (size_t i = 0; i < sizeof(bytes); ++i) {
        out[i*2] = hex[bytes[i] >> 4];
        out[i*2+1] = hex[bytes[i] & 15];
    }
    out[32] = 0;
}
long long timestamp(void) {
#ifdef SAM_WINDOWS
    extern long long _time64(long long *);
    return _time64(NULL);
#else
    return (long long)time(NULL);
#endif
}

static void white(JSON *j) {
    while (j->pos < j->size && strchr(" \t\r\n", j->raw[j->pos]) && j->raw[j->pos]) j->pos++;
}
static int hex_value(int c) {
    if (c >= '0' && c <= '9') return c - '0';
    c = lower_ascii(c);
    return c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1;
}
static int parse_string(JSON *j) {
    while (++j->pos < j->size) {
        unsigned char c = (unsigned char)j->raw[j->pos];
        if (c == '"') { ++j->pos; return 1; }
        if (c < 32) return 0;
        if (c != '\\') continue;
        if (++j->pos == j->size) return 0;
        c = (unsigned char)j->raw[j->pos];
        if (c == 'u') {
            if (j->pos + 4 >= j->size) return 0;
            for (int i = 0; i < 4; ++i) if (hex_value(j->raw[++j->pos]) < 0) return 0;
        } else if (!c || !strchr("\"\\/bfnrt", c)) return 0;
    }
    return 0;
}
static int digit(int c) { return c >= '0' && c <= '9'; }
static int parse_number(JSON *j) {
    const char *s = j->raw;
    size_t p = j->pos;
    if (s[p] == '-') ++p;
    if (p == j->size || !digit(s[p])) return 0;
    if (s[p++] != '0') while (p < j->size && digit(s[p])) ++p;
    if (p < j->size && s[p] == '.') {
        if (++p == j->size || !digit(s[p])) return 0;
        while (p < j->size && digit(s[p])) ++p;
    }
    if (p < j->size && (s[p] == 'e' || s[p] == 'E')) {
        ++p;
        if (p < j->size && (s[p] == '+' || s[p] == '-')) ++p;
        if (p == j->size || !digit(s[p])) return 0;
        while (p < j->size && digit(s[p])) ++p;
    }
    j->pos = p;
    return 1;
}
static int parse_value(JSON *j, int depth) {
    white(j);
    if (j->pos >= j->size || depth > 48 || j->n >= 200000) return -1;
    if (j->n >= j->cap) {
        j->cap = j->cap ? j->cap * 2 : 64;
        Token *t = realloc(j->t, (size_t)j->cap * sizeof(*t));
        if (!t) abort();
        j->t = t;
    }
    int i = j->n++;
    char c = j->raw[j->pos];
    j->t[i] = (Token){ .first = j->pos, .type = c };
    if (c == '{' || c == '[') {
        char end = c == '{' ? '}' : ']';
        ++j->pos;
        white(j);
        if (j->pos < j->size && j->raw[j->pos] != end) {
            for (;;) {
                if (c == '{') {
                    if (j->pos >= j->size || j->raw[j->pos] != '"' || parse_value(j, depth+1) < 0) return -1;
                    white(j);
                    if (j->pos >= j->size || j->raw[j->pos++] != ':') return -1;
                }
                if (parse_value(j, depth+1) < 0) return -1;
                ++j->t[i].count;
                white(j);
                if (j->pos >= j->size || j->raw[j->pos] != ',') break;
                ++j->pos;
                white(j);
            }
        }
        if (j->pos >= j->size || j->raw[j->pos++] != end) return -1;
    } else if (c == '"') {
        if (!parse_string(j)) return -1;
    } else if (c == '-' || digit(c)) {
        if (!parse_number(j)) return -1;
        j->t[i].type = '0';
    } else {
        const char *value = c == 't' ? "true" : c == 'f' ? "false" : c == 'n' ? "null" : "";
        size_t len = strlen(value);
        if (!len || j->size - j->pos < len || memcmp(j->raw + j->pos, value, len)) return -1;
        j->pos += len;
    }
    j->t[i].last = j->pos;
    j->t[i].after = j->n;
    return i;
}
int json_parse(JSON *j, const char *raw, size_t size) {
    *j = (JSON){.raw = raw, .size = size};
    if (parse_value(j, 0) < 0) { json_free(j); return 0; }
    white(j);
    if (j->pos != size) { json_free(j); return 0; }
    return 1;
}
void json_free(JSON *j) { free(j->t); *j = (JSON){0}; }
static int utf8_encode(char *out, unsigned value) {
    if (value < 0x80) { out[0] = (char)value; return 1; }
    if (value < 0x800) {
        out[0] = (char)(0xc0 | value >> 6); out[1] = (char)(0x80 | (value & 63)); return 2;
    }
    if (value < 0x10000) {
        out[0] = (char)(0xe0 | value >> 12); out[1] = (char)(0x80 | ((value >> 6) & 63));
        out[2] = (char)(0x80 | (value & 63)); return 3;
    }
    out[0] = (char)(0xf0 | value >> 18); out[1] = (char)(0x80 | ((value >> 12) & 63));
    out[2] = (char)(0x80 | ((value >> 6) & 63)); out[3] = (char)(0x80 | (value & 63)); return 4;
}
static unsigned codepoint(const char *s) {
    unsigned code = 0;
    for (int i = 0; i < 4; ++i) code = (code << 4) | (unsigned)hex_value(s[i]);
    return code;
}
int json_string(const JSON *j, int token, char *out, size_t cap) {
    if (cap) out[0] = 0;
    if (token < 0 || token >= j->n || j->t[token].type != '"' || !cap) return 0;
    size_t n = 0;
    const char *s = j->raw + j->t[token].first + 1, *end = j->raw + j->t[token].last - 1;
    while (s < end) {
        char utf[4], c = *s++;
        size_t m = 1;
        if (c == '\\') {
            c = *s++;
            if (c == 'u') {
                unsigned cp = codepoint(s);
                s += 4;
                if (cp >= 0xd800 && cp <= 0xdbff) {
                    if (end - s < 6 || s[0] != '\\' || s[1] != 'u') return 0;
                    unsigned low = codepoint(s + 2);
                    if (low < 0xdc00 || low > 0xdfff) return 0;
                    cp = 0x10000 + ((cp - 0xd800) << 10) + (low - 0xdc00);
                    s += 6;
                }
                if (!cp || (cp >= 0xdc00 && cp <= 0xdfff)) return 0;
                m = (size_t)utf8_encode(utf, cp);
            } else {
                const char *escape = "bfnrt", *codes = "\b\f\n\r\t", *at = strchr(escape, c);
                utf[0] = at ? codes[at - escape] : c;
            }
        } else utf[0] = c;
        if (n + m >= cap) { out[0] = 0; return 0; }
        memcpy(out + n, utf, m);
        n += m;
    }
    out[n] = 0;
    return 1;
}
int json_get(const JSON *j, int obj, const char *name) {
    if (obj < 0 || obj >= j->n || j->t[obj].type != '{') return -1;
    for (int i = obj + 1; i < j->t[obj].after; i = j->t[i+1].after) {
        char key[128];
        if (json_string(j, i, key, sizeof(key)) && !strcmp(key, name)) return i + 1;
    }
    return -1;
}
int json_field(const JSON *j, int obj, const char *name, char *out, size_t cap) {
    return json_string(j, json_get(j, obj, name), out, cap);
}
long long json_int(const JSON *j, int token, long long fallback) {
    if (token < 0 || j->t[token].type != '0') return fallback;
    const char *p = j->raw + j->t[token].first, *end = j->raw + j->t[token].last;
    int negative = p[0] == '-';
    unsigned long long n = 0, limit = UINT64_C(9223372036854775807);
    p += negative;
    for (; p < end; ++p) {
        if (!digit(*p) || n > (limit - (unsigned)(*p - '0')) / 10) return fallback;
        n = n * 10 + (unsigned)(*p - '0');
    }
    return negative ? -(long long)n : (long long)n;
}
int json_bool(const JSON *j, int token) { return token >= 0 && j->t[token].type == 't'; }
void json_raw(Buf *out, const JSON *j, int token) {
    if (token < 0) buffer_text(out, "null");
    else buffer_add(out, j->raw + j->t[token].first, j->t[token].last - j->t[token].first);
}

int text_utf8(const char *s,size_t len) {
    const unsigned char *p=(const unsigned char *)s;
    for (size_t i=0;i<len;) {
        unsigned first=p[i++];
        if (first<0x80) {
            if (first<32 && first!='\n' && first!='\r' && first!='\t') return 0;
            continue;
        }
        unsigned n=first>=0xc2 && first<=0xdf ? 1 : first>=0xe0 && first<=0xef ? 2 : first>=0xf0 && first<=0xf4 ? 3 : 0;
        if (!n || i+n>len) return 0;
        unsigned next=p[i];
        if ((first==0xe0 && next<0xa0) || (first==0xed && next>=0xa0) ||
            (first==0xf0 && next<0x90) || (first==0xf4 && next>=0x90)) return 0;
        for (unsigned k=0;k<n;++k) if ((p[i++]&0xc0)!=0x80) return 0;
    }
    return 1;
}
