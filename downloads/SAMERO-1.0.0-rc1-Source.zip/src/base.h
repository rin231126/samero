#ifndef SAM_BASE
#define SAM_BASE
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>
#include <ctype.h>

#define PATH_CAP 4096
#define ERROR_CAP 1024
#define MIB (1024u * 1024u)
#define ARRAY_LEN(a) (sizeof(a) / sizeof((a)[0]))
typedef struct { char p[PATH_CAP]; } Path;
typedef struct { char msg[ERROR_CAP]; } Error;
typedef struct { char *s; size_t n, cap; } Buf;

int sam_format(char *out, size_t cap, const char *fmt, ...);
int errorf(Error *e, const char *fmt, ...);
void *allocate(size_t count);
void buffer_add(Buf *b, const void *data, size_t size);
void buffer_text(Buf *b, const char *s);
void buffer_char(Buf *b, char c);
void buffer_fmt(Buf *b, const char *fmt, ...);
void buffer_free(Buf *b);
void json_quote(Buf *b, const char *s);
int ascii_equal(const char *a, const char *b);
int has_suffix(const char *s, const char *suffix);
int path_join(Path *out, const char *dir, const char *tail);
const char *base_name(const char *path);
int within(const char *root, const char *path);
int path_valid_component(const char *name);
int credential_path(const char *rel);
int text_utf8(const char *,size_t);
int contains_ci(const char *, const char *);
int secret_text(const char *s);
int valid_id(const char *id);
void new_id(char out[33]);
long long timestamp(void);

typedef struct { size_t first, last; int after, count; char type; } Token;
typedef struct { const char *raw; size_t size, pos; Token *t; int n, cap; } JSON;
int json_parse(JSON *j, const char *raw, size_t size);
void json_free(JSON *j);
int json_get(const JSON *j, int obj, const char *name);
int json_string(const JSON *j, int token, char *out, size_t cap);
int json_field(const JSON *j, int obj, const char *name, char *out, size_t cap);
long long json_int(const JSON *j, int token, long long fallback);
int json_bool(const JSON *j, int token);
void json_raw(Buf *out, const JSON *j, int token);
void json_key(Buf *b, const char *key);
void json_pair(Buf *b, const char *key, const char *value);

typedef struct {
    int kind; /* 1 regular, 2 directory, 3 link/reparse, 0 absent */
    unsigned mode;
    uint64_t size, mtime, inode, device, links;
} Info;
typedef int (*Visitor)(const char *, const Info *, void *, Error *);
int file_info(const char *path, Info *info);
int list_dir(const char *dir, Visitor cb, void *ctx, Error *err);
typedef int (*NameFilter)(const char *);
int list_dir_filtered(const char *dir, NameFilter filter, Visitor cb, void *ctx, Error *err);
int canonical(const char *path, Path *out);
int user_root(Path *out, int local);
int mkdir_new(const char *path);
int mkdir_tree(const char *path);
int remove_file(const char *path);
int remove_dir(const char *path);
void restore_mode(const char *path, unsigned mode);
int move_file(const char *from, const char *to, int replace);
FILE *file_open(const char *path, int write);
int move_queue_exclusive(const char *from,const char *to);
FILE *file_open_append(const char *path);
FILE *file_open_new(const char *path);
int file_seek(FILE *f, uint64_t pos);
int file_flush(FILE *f);
int read_file(const char *path, size_t limit, Buf *out, Error *e);
int write_new_atomic(const char *path, const void *data, size_t size, Error *e);
int write_atomic(const char *path, const void *data, size_t size, Error *e);
int system_random(void *out, size_t size);
int acquire_instance(const char *root);
int pick_path(int folder, const char *start, Path *out);
int open_url(const char *url, int app_mode);
void alert_user(const char *msg);
int locate_exec(const char *value, const char *name, Path *path);
int self_executable(Path *path);
int worker_stdout(const char *data,size_t size);
int locate_codex_cli(const char *value, Path *path);
int native_codex_home(Path *path);
int windows_terminal_available(void);
typedef enum { CODEX_UNKNOWN, CODEX_INTERACTIVE, CODEX_SERVER, CODEX_DAEMON, CODEX_HOST, CODEX_BATCH, CODEX_MANAGED } CodexKind;
typedef struct { unsigned interactive, server, daemon, host, batch, managed, unknown, conflict; } CodexProcesses;
CodexKind classify_codex(const char *image, const char *const *args, int count, int managed);
void inspect_codex(const char *exe, const unsigned *managed, size_t count, const char *thread,
                   const char *workspace, CodexProcesses *result);
int launch_windows_terminal(const char *exe, const char *workspace, const char *home, const char *thread,
                            const char *lease, const char *done, const char *shell, Error *e);
int release_terminal_lease(const char *lease, const char *done, Error *e);
long long info_unix_time(const Info *info);
const char *terminal_program(void);
void sleep_ms(unsigned ms);
uint64_t monotonic_ms(void);

typedef struct {
    uintptr_t handle, job, input, output;
    unsigned pid;
    int captured, reaped, exit_code;
} Process;
int process_start(Process *p, const char *exe, const char *const *argv, const char *cwd,
                  const char *codex_home, int capture, int console, Error *e);
int process_write(Process *p, const char *s, size_t n);
void process_close_input(Process *p);
int process_read(Process *p, char *out, size_t cap);
int process_poll(Process *p, int *exit_code);
int process_stop(Process *p);
void process_dispose(Process *p);
int run_capture(const char *exe, const char *const *argv, const char *cwd, const char *home,
                Buf *out, size_t max, unsigned deadline_ms, int *exit_code, Error *e);

typedef uintptr_t Socket;
#define BAD_SOCKET ((Socket)-1)
Socket listen_local(unsigned short *port);
Socket accept_local(Socket server);
int socket_read(Socket fd, void *buffer, size_t size);
int socket_write(Socket fd, const void *buffer, size_t size);
void socket_close(Socket fd);

#endif
