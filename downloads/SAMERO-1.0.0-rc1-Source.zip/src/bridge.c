#include "manager.h"

/* User-mediated local editing. No external API, CORS, shell or browser credentials. */
#define BRIDGE_LIMIT (64u*1024u)
static struct {
    char ticket[33], project[33], rel[PATH_CAP], before[65], after[65];
    Path root;
    uint64_t expires;
} preview;

static void digest(const char *s,size_t n,char hex[65]) {
    Sha256 h={0}; sha_update(&h,s,n); sha_finish(&h,hex);
}
static int allowed_component(const char *s) {
    static const char *denied[]={"node_modules","vendor","target","dist","build","__pycache__","credentials","secrets","auth","TASK_QUEUE.json","PROJECT_STATUS.md","CODEX_HANDOVER.md","CODEX_HANDOVER.json","MANIFEST.json"};
    if (!path_valid_component(s) || s[0]=='.' || credential_path(s) || secret_text(s)) return 0;
    for (size_t i=0;i<ARRAY_LEN(denied);++i) if (ascii_equal(s,denied[i])) return 0;
    return 1;
}
static int allowed_file(const char *s) {
    static const char *ext[]={".c",".h",".cpp",".hpp",".cs",".rs",".slint",".js",".mjs",".cjs",".ts",".tsx",".jsx",".py",".go",".java",".kt",".lua",".gd",".html",".css",".scss",".json",".toml",".yaml",".yml",".md",".txt",".svg",".glsl",".wgsl"};
    for (size_t i=0;i<ARRAY_LEN(ext);++i) if (has_suffix(s,ext[i])) return 1;
    return 0;
}
static int locate(Manager *m,const char *id,const char *rel,Path *root,Path *file,Info *info,Error *e) {
    Document d={0}; Path *p=allocate(2*sizeof(*p)); int ok=0;
    if (!valid_id(id) || !get_doc(m,"projects",id,&d,e) || !FIELD(&d,"path",p[0].p) ||
        !open_directory(p[0].p,root) || strcmp(p[0].p,root->p) || !directory_allowed(m,root->p,1)) {
        errorf(e,"Dự án không hợp lệ hoặc đường dẫn đã đổi."); goto done;
    }
    if (!*rel || strlen(rel)>=PATH_CAP || strchr(rel,'\\') || rel[0]=='/' || rel[strlen(rel)-1]=='/' || !allowed_file(rel)) {
        errorf(e,"Chỉ chấp nhận đường dẫn tương đối của tệp mã nguồn/văn bản đã có (dùng /)."); goto done;
    }
    *file=*root;
    const char *s=rel;
    for (;;) {
        size_t n=strcspn(s,"/"); char component[256];
        if (!n || n>=sizeof(component)) { errorf(e,"Đường dẫn không hợp lệ."); goto done; }
        memcpy(component,s,n); component[n]=0;
        if (!allowed_component(component) || !path_join(&p[0],file->p,component) ||
            !file_info(p[0].p,info) || info->kind!=(s[n]?2:1)) {
            errorf(e,"Tệp/thư mục bị giới hạn, không tồn tại hoặc là liên kết."); goto done;
        }
        *file=p[0];
        if (!s[n]) break;
        s+=n+1;
    }
    if (info->links!=1 || !canonical(file->p,&p[1]) || !within(root->p,p[1].p) || !within(file->p,p[1].p) || !within(p[1].p,file->p)) {
        errorf(e,"Tệp nằm ngoài đường dẫn đã xác nhận."); goto done;
    }
    if (workspace_busy(m,root->p)) { errorf(e,"Workspace đang có phiên/runner ghi. Hãy dừng trước khi dùng Bridge."); goto done; }
    ok=1;
done:
    doc_free(&d); free(p); return ok;
}
static int read_text(const char *path,Buf *b,Error *e) {
    return (read_file(path,BRIDGE_LIMIT,b,e) && text_utf8(b->s,b->n) && !secret_text(b->s)) || errorf(e,"Chỉ hỗ trợ UTF-8 tối đa 64 KiB; tệp có dấu hiệu bí mật bị chặn.");
}
static int backup_path(Manager *m,const char *id,Path *p) { return docs_path(m,"bridge",id,p); }
static int same_root(const Path *a,const Path *b) { return within(a->p,b->p) && within(b->p,a->p); }
int bridge_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    if (!strcmp(action,"bridge-chat")) {
        if (!open_url("https://chatgpt.com/",0)) return errorf(e,"Không mở được trình duyệt.");
        buffer_text(out,"{}"); return 1;
    }
    if (!strcmp(action,"bridge-browser")) {
        Path *p=allocate(sizeof(*p)); Buf url={0};
        int ok=path_join(p,m->data.p,"ui.url") && read_file(p->p,200,&url,e) &&
            !strncmp(url.s,"http://127.0.0.1:",17) && strspn(url.s+17,"0123456789/#abcdef")==strlen(url.s+17) && open_url(url.s,0);
        free(p); buffer_free(&url); if (!ok) return errorf(e,"Không mở được Manager trong trình duyệt.");
        buffer_text(out,"{}"); return 1;
    }
    char project[33], rel[PATH_CAP], base[65], current[65], after[65], id[33], ticket[33];
    Path *p=allocate(4*sizeof(*p)); Buf old={0}, record={0}, check={0}; Document backup={0}; Info info={0};
    char *replacement=allocate(BRIDGE_LIMIT+1); int ok=0;
    ARG(in,"project",project); ARG(in,"path",rel); ARG(in,"baseSha256",base);
    if (!strcmp(action,"bridge-rollback")) {
        char selected[33]={0};
        if (json_get(in,0,"project")>=0 && (!ARG(in,"project",selected)||!valid_id(selected))) { errorf(e,"Dự án được chọn không hợp lệ."); goto done; }
        if (!YES(in,"confirm") || !ARG(in,"backup",id) || !get_doc(m,"bridge",id,&backup,e) ||
            !FIELD(&backup,"project",project) || !FIELD(&backup,"path",rel) || !FIELD(&backup,"root",p[3].p) ||
            !FIELD(&backup,"after",base) || !json_field(&backup.data,0,"original",replacement,BRIDGE_LIMIT+1)) {
            errorf(e,"Bản sao lưu không hợp lệ hoặc chưa xác nhận."); goto done;
        }
        if (*selected && strcmp(selected,project)) { errorf(e,"Bản sao lưu thuộc dự án khác. Chọn đúng dự án trước khi khôi phục."); goto done; }
    }
    if (!locate(m,project,rel,&p[0],&p[1],&info,e) || !read_text(p[1].p,&old,e)) goto done;
    digest(old.s,old.n,current);
    if (!strcmp(action,"bridge-read")) {
        buffer_char(out,'{'); json_pair(out,"path",rel); KEY(out,"sha256",current); KEY(out,"content",old.s); buffer_char(out,'}'); ok=1; goto done;
    }
    if (strcmp(base,current)) { errorf(e,"SHA-256 không khớp: tệp đã đổi. Đọc lại tệp trước khi sửa/khôi phục."); goto done; }
    if (!strcmp(action,"bridge-preview") || !strcmp(action,"bridge-apply")) {
        if (!json_field(in,0,"content",replacement,BRIDGE_LIMIT+1) || !text_utf8(replacement,strlen(replacement)) || secret_text(replacement)) {
            errorf(e,"Nội dung thay thế không hợp lệ hoặc có dấu hiệu bí mật."); goto done;
        }
        digest(replacement,strlen(replacement),after);
        if (!strcmp(current,after)) { errorf(e,"Không có thay đổi."); goto done; }
        if (!strcmp(action,"bridge-preview")) {
            new_id(preview.ticket); strcpy(preview.project,project); strcpy(preview.rel,rel);
            strcpy(preview.before,current); strcpy(preview.after,after); preview.root=p[0]; preview.expires=monotonic_ms()+300000;
            buffer_char(out,'{'); json_pair(out,"ticket",preview.ticket); KEY(out,"path",rel); KEY(out,"before",old.s);
            KEY(out,"after",replacement); KEY(out,"sha256",after); buffer_char(out,'}'); ok=1; goto done;
        }
        if (!YES(in,"confirm") || !ARG(in,"ticket",ticket) || !valid_id(ticket) || strcmp(ticket,preview.ticket) ||
            monotonic_ms()>preview.expires || strcmp(project,preview.project) || strcmp(rel,preview.rel) ||
            strcmp(current,preview.before) || strcmp(after,preview.after) || !same_root(&p[0],&preview.root)) {
            errorf(e,"Phải xem trước đúng thay đổi và xác nhận trong vòng 5 phút."); goto done;
        }
        memset(&preview,0,sizeof(preview));
        new_id(id);
        buffer_char(&record,'{'); json_pair(&record,"project",project); KEY(&record,"path",rel); KEY(&record,"root",p[0].p);
        KEY(&record,"before",current); KEY(&record,"after",after); KEY(&record,"original",old.s); NUM(&record,"mode",info.mode); NUM(&record,"created",timestamp()); buffer_char(&record,'}');
        if (!backup_path(m,id,&p[2]) || !write_new_atomic(p[2].p,record.s,record.n,e)) goto done;
    } else if (!strcmp(action,"bridge-rollback")) {
        digest(replacement,strlen(replacement),after);
        char expected[65]; FIELD(&backup,"before",expected);
        if (!same_root(&p[0],&p[3]) || strcmp(after,expected) || !text_utf8(replacement,strlen(replacement)) || secret_text(replacement)) {
            errorf(e,"Bản sao lưu hoặc thư mục dự án không còn khớp."); goto done;
        }
    } else { errorf(e,"Thao tác Bridge không tồn tại."); goto done; }
    /* Recheck immediately before atomic replace. External editors must be closed by user. */
    p[3]=p[0];
    if (!locate(m,project,rel,&p[0],&p[1],&info,e) || !same_root(&p[0],&p[3]) || !read_text(p[1].p,&check,e)) goto done;
    digest(check.s,check.n,base);
    if (strcmp(base,current)) { errorf(e,"Tệp thay đổi trong khi chuẩn bị ghi."); goto done; }
    if (!write_atomic(p[1].p,replacement,strlen(replacement),e)) goto done;
    restore_mode(p[1].p,!strcmp(action,"bridge-rollback")?(unsigned)NUMBER(&backup.data,"mode",info.mode):info.mode);
    buffer_char(out,'{'); json_pair(out,"backup",id); KEY(out,"path",rel); KEY(out,"sha256",after); buffer_char(out,'}'); ok=1;
done:
    free(replacement); free(p); buffer_free(&old); buffer_free(&record); buffer_free(&check); doc_free(&backup); return ok;
}
