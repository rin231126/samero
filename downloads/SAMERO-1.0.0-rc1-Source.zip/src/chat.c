#include "manager.h"
#include "verify_trace.h"

#define TEXT_CAP (64 * 1024)
#define PROMPT_CAP 3000
#define RUNNER_PROMPT_CAP 8192
#define HISTORY_BYTES (2 * MIB)
#define HISTORY_MESSAGES 160
#define MAX_APPROVALS 8

typedef struct {
    int present, acceptable;
    char key[33], rpc_id[256], title[80], detail[2048];
} Approval;

struct Chat {
    Buf incoming, draft, diff, tool_output, runner_result, access_policy;
    int access_request, access_checked, access_verified, windows_server, readiness_request, readiness_checked;
    int verifying;
    VerifyTrace verification;
    int final_result;
    Approval approvals[MAX_APPROVALS];
    char thread[160], turn[160], item[160], proposed_item[160];
    char proposed_detail[2048], resume[160], model[128], first[RUNNER_PROMPT_CAP+1], activity[160];
    char changed[33], history_revision[33], tool_id[160];
    const char *stage;
    int turn_complete, auto_review, legacy_reviewer, saw_review;
    int next, account_request, quota_request, probe_request, thread_request, thread_committed, turn_request, interrupt_request, limited, unauthorized, ended;
    int loaded, loaded_request, load_attempt, load_page, idle_in_reply, missing_history;
    int turn_accepted, history_request, disk_resume;
    char history_turn[160];
    uint64_t load_retry;
    Path rollout;
    uint64_t deadline, account_deadline, close_deadline, quota_timeout, quota_after_turn;
    int account_checked, quota_supported;
    unsigned quota_generation, requested_generation;
};

static void changed(Chat *c) { new_id(c->changed); }
static void stage(Chat *c, const char *status) { c->stage=status; changed(c); }
static const char *redacted(const char *s) {
    return secret_text(s) ? "[Nội dung có dấu hiệu chứa dữ liệu xác thực]" : s;
}
static void home_digest(const Live *l, char hex[65]) {
    Sha256 sha={0}; sha_update(&sha,l->home.p,strlen(l->home.p)); sha_finish(&sha,hex);
}
static void live_chat_key(const Live *l,char key[33]) {
    char home[65]; home_digest(l,home);
    chat_session_key(l->profile,home,l->chat->thread,key);
}
static Live *find_chat(Manager *m, const char *project) {
    for (Live *l=m->live;l;l=l->next) if (l->chat && !strcmp(l->project,project)) return l;
    return NULL;
}

static void history(Manager *m, const char *project, Document *d) {
    Error ignored={0};
    get_doc(m,"chatlogs",project,d,&ignored);
}
static int log_entry(Manager *m, Live *l, const char *role, const char *text, Error *e) {
    Document d;
    history(m,l->project,&d);
    Buf record={0}, line={0};
    char rev[33]; new_id(rev);
    if (role) {
        buffer_char(&line,'{'); json_pair(&line,"role",role);
        KEY(&line,"profile",l->profile); KEY(&line,"session",l->id);
        if (l->chat && *l->chat->thread) {
            char key[33]; live_chat_key(l,key); KEY(&line,"chatKey",key);
        }
        KEY(&line,"text",redacted(text)); NUM(&line,"at",timestamp()); buffer_char(&line,'}');
    }
    buffer_char(&record,'{'); json_pair(&record,"revision",rev);
    KEY(&record,"latestSession",l->id); KEY(&record,"latestProfile",l->profile);
    char resume_session[33], previous_profile[33];
    FIELD(&d,"latestProfile",previous_profile);
    if (l->chat && (l->chat->thread_committed || l->chat->turn_accepted)) strcpy(resume_session,l->id);
    else if (strcmp(previous_profile,l->profile)) resume_session[0]=0;
    else if (!FIELD(&d,"resumeSession",resume_session)) FIELD(&d,"latestSession",resume_session);
    KEY(&record,"resumeSession",resume_session);
    char unavailable[160]; FIELD(&d,"unavailableThread",unavailable);
    if (l->chat && l->chat->missing_history) {
        const char *id=l->chat->resume[0]?l->chat->resume:l->chat->thread;
        sam_format(unavailable,sizeof(unavailable),"%s",id);
    } else if (l->chat && l->chat->loaded && l->chat->thread_committed) unavailable[0]=0;
    if (*unavailable) { KEY(&record,"unavailableThread",unavailable); }
    if (l->chat && (!strcmp(l->chat->stage,"error") || !strcmp(l->chat->stage,"auth") ||
        !strcmp(l->chat->stage,"startup"))) KEY(&record,"startupFailure",l->chat->stage);
    buffer_text(&record,",\"messages\":[");
    int array=json_get(&d.data,0,"messages"), written=0;
    if (array>=0 && d.data.t[array].type=='[') {
        const JSON *j=&d.data;
        int start=array+1,end=j->t[array].after, skip=j->t[array].count+(line.n!=0)-HISTORY_MESSAGES;
        while (start<end &&
               (skip-- > 0 || line.n+j->t[end-1].last-j->t[start].first>HISTORY_BYTES))
            start=j->t[start].after;
        for (int i=start;i<end;i=j->t[i].after) {
            if (written++) buffer_char(&record,',');
            json_raw(&record,j,i);
        }
    }
    if (line.n) {
        if (written) buffer_char(&record,',');
        buffer_add(&record,line.s,line.n);
    }
    buffer_text(&record,"]}");
    int ok=put_doc(m,"chatlogs",l->project,&record,e);
    if (l->chat) {
        if (ok) strcpy(l->chat->history_revision,rev);
        changed(l->chat);
    }
    buffer_free(&record); buffer_free(&line); doc_free(&d);
    return ok;
}
static void log_system(Manager *m, Live *l, const char *text) {
    Error ignored={0};
    log_entry(m,l,"system",text,&ignored);
}
static void log_assistant(Manager *m, Live *l, const char *text) {
    Error ignored={0};
    if (!log_entry(m,l,"assistant",text,&ignored)) log_system(m,l,"Không lưu được tin nhắn Codex vào lịch sử.");
}
static void clear_draft(Chat *c) {
    if (c->draft.s) c->draft.s[0]=0;
    c->draft.n=0;
    c->item[0]=0;
}
static void flush_draft(Manager *m, Live *l) {
    Chat *c=l->chat;
    if (c->draft.n) log_assistant(m,l,c->draft.s);
    clear_draft(c);
}
int chat_review_pending(const Live *l,const char *turn) {
    return !l->stopping && l->chat && !strcmp(l->chat->stage,"running") && !strcmp(l->chat->turn,turn);
}
const char *chat_thread_id(const Live *l) { return l->chat ? l->chat->thread : ""; }
void chat_emit_session(Buf *record, const Live *l) {
    char hash[65];
    home_digest(l,hash);
    KEY(record,"reviewer",l->chat->auto_review?"auto_review":"user");
    KEY(record,"chatThread",l->chat->thread_committed?l->chat->thread:""); KEY(record,"chatHome",hash);
    if (l->chat->turn_accepted && !l->chat->thread_committed) {
        KEY(record,"chatCandidate",l->chat->thread);
    }
    char key[33]; live_chat_key(l,key);
    KEY(record,"chatKey",l->chat->thread_committed?key:""); KEY(record,"chatModel",l->chat->model);
}

static int post_turn(Manager *m, Live *l, const char *text, Error *e) {
    Chat *c=l->chat;
    if (!c->loaded || !*c->thread || c->close_deadline || l->stopping ||
        (strcmp(c->stage,"ready") && strcmp(c->stage,"limited")))
        return errorf(e,"Codex chưa nạp luồng trên kết nối này. Tin nhắn chưa được gửi.");
    if (l->read_only_turn && !c->access_policy.n)
        return errorf(e,"BLOCKED_PREFLIGHT: Chưa xác nhận sandbox chỉ đọc cho lượt Codex.");
    Buf params={0};
    buffer_char(&params,'{'); json_pair(&params,"threadId",c->thread);
    /* TurnStartParams accepts explicit policy overrides. Reassert only the exact
       server-confirmed read-only policy; do not change or relax approvals. */
    if (l->read_only_turn) {
        KEY(&params,"cwd",l->workspace.p);
        KEY(&params,"approvalPolicy","never");
        RAW(&params,"sandboxPolicy",c->access_policy.s);
    }
    buffer_text(&params,",\"input\":[{\"type\":\"text\",");
    json_pair(&params,"text",text); buffer_text(&params,",\"text_elements\":[]}]");
    if (l->autonomous) {
        static const char plan_schema[]="{\"type\":\"object\",\"properties\":{\"tasks\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"title\":{\"type\":\"string\"},\"accept\":{\"type\":\"string\"},\"after\":{\"type\":\"integer\"}},\"required\":[\"title\",\"accept\",\"after\"],\"additionalProperties\":false}}},\"required\":[\"tasks\"],\"additionalProperties\":false}";
        static const char result_schema[]="{\"type\":\"object\",\"properties\":{\"met\":{\"type\":\"boolean\"},\"needsReview\":{\"type\":\"boolean\"},\"evidence\":{\"type\":\"string\"}},\"required\":[\"met\",\"needsReview\",\"evidence\"],\"additionalProperties\":false}";
        RAW(&params,"outputSchema",!strncmp(text,"SAMERO PLAN.",12)?plan_schema:result_schema);
    }
    buffer_char(&params,'}');
    if (params.n>3970) {
        buffer_free(&params);
        return errorf(e,"Tin nhắn quá dài sau khi mã hoá. Hãy chia thành các đoạn ngắn hơn.");
    }
    if (!log_entry(m,l,"user",text,e)) { buffer_free(&params); return 0; }
    int id=c->next++;
    int ok=codex_send(&l->process,id,"turn/start",params.s);
    buffer_free(&params);
    if (!ok) {
        stage(c,"error");
        log_system(m,l,"Tin nhắn đã được lưu cục bộ. Không chuyển được đến Codex.");
        process_close_input(&l->process);
        return errorf(e,"Không gửi được tin nhắn tới Codex App Server.");
    }
    c->turn_request=id;
    c->turn[0]=0;
    c->activity[0]=0;
    c->limited=0;
    c->unauthorized=0;
    c->verifying=l->autonomous && l->read_only_turn && !strncmp(text,"SAMERO VERIFY.",14);
    memset(&c->verification,0,sizeof(c->verification));
    c->tool_id[0]=0;
    c->proposed_detail[0]=0;
    c->proposed_item[0]=0;
    buffer_free(&c->tool_output);
    buffer_free(&c->diff);
    c->deadline=monotonic_ms()+45000;
    c->turn_complete=0; c->saw_review=0;
    stage(c,"running");
    return 1;
}

static void connection_failed(Manager *m, Live *l, const char *failure,const char *message) {
    Chat *c=l->chat;
    c->loaded=0; c->loaded_request=0; c->load_retry=0; c->turn_request=0;
    c->deadline=0; c->account_deadline=0; c->account_request=0; c->probe_request=0; c->thread_request=0;
    stage(c,failure);
    log_system(m,l,message);
    if (c->first[0]) {
        Error ignored={0};
        log_entry(m,l,"user",c->first,&ignored);
        log_system(m,l,"Tin nhắn trên mới được lưu cục bộ. Hãy gửi lại sau khi kết nối được Codex.");
        c->first[0]=0;
    }
    c->close_deadline=monotonic_ms()+10000;
    process_close_input(&l->process);
}
static void connection_error(Manager *m, Live *l, const char *message) {
    connection_failed(m,l,"error",message);
}

void chat_begin(Manager *m, Live *l, const char *resume, const char *first, const char *model) {
    Chat *c=allocate(sizeof(*c));
    l->chat=c;
    c->next=2; c->auto_review=m->auto_approval && !l->read_only_turn;
    c->deadline=monotonic_ms()+45000;
    if (resume) sam_format(c->resume,sizeof(c->resume),"%s",resume);
    if (first) sam_format(c->first,sizeof(c->first),"%s",first);
    sam_format(c->model,sizeof(c->model),"%s",model);
    stage(c,"starting");
    Error e={0};
    const char *init=c->auto_review?
        "{\"clientInfo\":{\"name\":\"samero_codex_manager\",\"version\":\"" SAM_VERSION "\"},\"capabilities\":{\"experimentalApi\":true}}":codex_client_info;
    if (!log_entry(m,l,NULL,NULL,&e) || !codex_send(&l->process,1,"initialize",init))
        connection_error(m,l,"Không khởi tạo được kết nối Codex App Server.");
}

static void start_verified_thread(Manager *m, Live *l) {
    Chat *c=l->chat;
    Buf params={0};
    buffer_char(&params,'{'); json_pair(&params,"sandbox",l->read_only_turn?"read-only":"workspace-write");
    if (!c->disk_resume) { KEY(&params,"cwd",l->workspace.p); }
    if (!c->legacy_reviewer) { KEY(&params,"approvalsReviewer",c->auto_review?"auto_review":"user"); }
    if (c->auto_review) {
        RAW(&params,"approvalPolicy",review_policy); RAW(&params,"config",review_config);
    } else { KEY(&params,"approvalPolicy",l->read_only_turn?"never":"on-request"); }
    if (!*c->resume) { RAW(&params,"ephemeral","false"); }
    if (c->model[0]) { KEY(&params,"model",c->model); }
    if (c->resume[0]) {
        KEY(&params,"threadId",c->resume); RAW(&params,"excludeTurns","true");
    }
    buffer_char(&params,'}');
    c->thread_request=c->next++;
    int ok=codex_send(&l->process,c->thread_request,c->resume[0]?"thread/resume":"thread/start",params.s);
    buffer_free(&params);
    if (!ok) connection_error(m,l,"Codex App Server không mở được luồng dự án.");
}
static void chat_thread_open(Manager *m,Live *l) {
    Chat *c=l->chat;
    if (!*c->resume) { start_verified_thread(m,l); return; }
    Buf params={0};
    buffer_char(&params,'{'); json_pair(&params,"threadId",c->resume); buffer_char(&params,'}');
    c->probe_request=c->next++;
    if (!codex_send(&l->process,c->probe_request,"thread/read",params.s))
        connection_error(m,l,"Không gửi được yêu cầu kiểm tra lịch sử luồng.");
    buffer_free(&params);
}

static int matching_workspace(const Live *l,const JSON *j,int thread) {
    Path *paths=allocate(2*sizeof(*paths));
    int ok=json_field(j,thread,"cwd",paths[0].p,sizeof(paths[0].p)) && open_directory(paths[0].p,&paths[1]) &&
        within(l->workspace.p,paths[1].p) && within(paths[1].p,l->workspace.p);
    free(paths); return ok;
}

static int save_thread_link(Manager *m,Live *l) {
    Error e={0};
    if (write_session(m,l,0,0,&e) && log_entry(m,l,NULL,NULL,&e)) return 1;
    connection_error(m,l,"Không lưu được liên kết hội thoại. Kiểm tra lịch sử trước khi gửi tiếp.");
    return 0;
}
/* Probe fixed bookkeeping files and a bounded directory listing through the
 * server's confirmed read-only sandbox. No names, contents, host fallback or escalation. */
static void access_hold(Manager *m,Live *l,const char *reason) {
    l->chat->access_request=0;
    connection_failed(m,l,"startup",reason);
    runner_review_denied(m,l,reason);
}
static int access_probe(Manager *m,Live *l) {
    Chat *c=l->chat;
    if (!c->access_policy.n) { access_hold(m,l,"BLOCKED_PREFLIGHT: Codex chưa xác nhận chính sách chỉ đọc."); return 0; }
    Buf params={0};
    buffer_text(&params,"{\"command\":[");
    json_quote(&params,terminal_program());
#ifdef SAM_WINDOWS
    buffer_text(&params,",\"-NoLogo\",\"-NoProfile\",\"-NonInteractive\",\"-Command\",");
    json_quote(&params,"$ErrorActionPreference='Stop'; foreach($name in @('TASK_QUEUE.json','PROJECT_STATUS.md')) { try { $s=[IO.File]::OpenRead([IO.Path]::Combine((Get-Location).Path,$name)); try {$null=$s.ReadByte()} finally {$s.Dispose()} } catch { [Console]::Error.WriteLine('SAMERO_READ_FAILED '+$name+' '+$_.Exception.GetBaseException().GetType().Name); exit 13 } }; try { Get-ChildItem -Force -Name -ErrorAction Stop | Select-Object -First 1 | Out-Null } catch { [Console]::Error.WriteLine('SAMERO_LIST_FAILED '+$_.Exception.GetBaseException().GetType().Name); exit 14 }; [Console]::WriteLine('SAMERO_READ_OK')");
#else
    buffer_text(&params,",\"--noprofile\",\"--norc\",\"-c\",");
    json_quote(&params,"for name in TASK_QUEUE.json PROJECT_STATUS.md; do if ! head -c 1 -- \"$name\" >/dev/null; then printf 'SAMERO_READ_FAILED %s\\n' \"$name\" >&2; exit 13; fi; done; if ! ls -A -- . >/dev/null; then printf 'SAMERO_LIST_FAILED\\n' >&2; exit 14; fi; printf 'SAMERO_READ_OK\\n'");
#endif
    buffer_char(&params,']'); KEY(&params,"cwd",l->workspace.p);
    RAW(&params,"sandboxPolicy",c->access_policy.s);
    NUM(&params,"timeoutMs",10000);
#ifndef SAM_WINDOWS
    /* The Windows restricted-token backend only accepts its default output cap. */
    if (!c->windows_server) { NUM(&params,"outputBytesCap",2048); }
#endif
    buffer_char(&params,'}');
    c->access_request=c->next++;
    c->deadline=monotonic_ms()+15000;
    stage(c,"starting");
    int ok=codex_send(&l->process,c->access_request,"command/exec",params.s);
    buffer_free(&params);
    if (!ok) access_hold(m,l,"BLOCKED_PREFLIGHT: Không gửi được command/exec kiểm tra quyền đọc.");
    return ok;
}
static void thread_ready(Manager *m,Live *l) {
    Chat *c=l->chat;
    c->deadline=0; c->load_retry=0; c->loaded=1;
    if (l->read_only_turn && !c->access_checked && !strncmp(c->first,"SAMERO VERIFY.",14)) {
        if (c->windows_server && !c->readiness_checked) {
            c->readiness_request=c->next++;
            c->deadline=monotonic_ms()+15000;
            stage(c,"starting");
            if (!codex_send(&l->process,c->readiness_request,"windowsSandbox/readiness",NULL))
                access_hold(m,l,"BLOCKED_PREFLIGHT: Không gửi được yêu cầu kiểm tra sandbox Windows.");
            return;
        }
        access_probe(m,l); return;
    }
    c->thread_committed=*c->resume || (*c->rollout.p &&
        chat_rollout_matches(c->rollout.p,l->home.p,c->thread,l->workspace.p));
    stage(c,"ready");
    if (!save_thread_link(m,l)) return;
    if (c->first[0]) {
        Error e={0};
        if (l->autonomous && l->read_only_turn && !strncmp(c->first,"SAMERO VERIFY.",14)) {
            const char marker[]="Bookkeeping probe: PENDING_SERVER_CHECK.";
            char *p=strstr(c->first,marker);
            if (p) {
                const char *proof=c->access_verified?"Bookkeeping probe: READ_OK.":"Bookkeeping probe: NOT_VERIFIED.";
                size_t n=strlen(proof),old=sizeof(marker)-1;
                memmove(p+n,p+old,strlen(p+old)+1); memcpy(p,proof,n);
            }
        }
        if (!post_turn(m,l,c->first,&e)) log_system(m,l,e.msg);
        c->first[0]=0;
    }
}
static void verify_stored_turn(Manager *m,Live *l,const char *turn) {
    Chat *c=l->chat;
    if (c->thread_committed || c->history_request) return;
    if (*c->rollout.p && chat_rollout_matches(c->rollout.p,l->home.p,c->thread,l->workspace.p)) {
        c->thread_committed=1;
        save_thread_link(m,l);
        return;
    }
    Buf p={0};
    buffer_char(&p,'{'); json_pair(&p,"threadId",c->thread);
    buffer_text(&p,",\"limit\":1,\"sortDirection\":\"desc\",\"itemsView\":\"notLoaded\"}");
    c->history_request=c->next++;
    sam_format(c->history_turn,sizeof(c->history_turn),"%s",turn);
    if (!codex_send(&l->process,c->history_request,"thread/turns/list",p.s)) c->history_request=0;
    buffer_free(&p);
}
static void check_loaded(Manager *m,Live *l,const char *cursor) {
    Chat *c=l->chat; Buf p={0};
    buffer_text(&p,"{\"limit\":100");
    if (cursor) { KEY(&p,"cursor",cursor); }
    else { ++c->load_attempt; c->load_page=0; }
    ++c->load_page;
    buffer_char(&p,'}');
    c->load_retry=0; c->loaded_request=c->next++;
    if (!codex_send(&l->process,c->loaded_request,"thread/loaded/list",p.s))
        connection_failed(m,l,"startup","Không kiểm tra được luồng trên kết nối Codex hiện tại.");
    buffer_free(&p);
}
static void accept_turn(Manager *m,Live *l,const JSON *j,int turn) {
    Chat *c=l->chat;
    char id[160];
    if (!json_field(j,turn,"id",id,sizeof(id)) || !*id) {
        connection_error(m,l,"Codex chưa xác nhận ID của lượt. Kiểm tra lịch sử trước khi gửi lại.");
        return;
    }
    if (*c->turn && strcmp(c->turn,id)) {
        if (c->verifying) c->verification.partial=1;
        return;
    }
    strcpy(c->turn,id);
    c->deadline=0;
    changed(c);
    if (!c->thread_committed && !c->turn_accepted) {
        c->turn_accepted=1;
        save_thread_link(m,l);
    }
}
static void request_quota(Live *l) {
    Chat *c=l->chat;
    if (c->quota_request) return;
    c->requested_generation=c->quota_generation;
    c->quota_timeout=monotonic_ms()+15000;
    c->quota_request=c->next++;
    if (!codex_send(&l->process,c->quota_request,"account/rateLimits/read",NULL)) c->quota_request=0;
}
int chat_quota_refresh(Manager *m,const char *profile) {
    int owned=0;
    for (Live *l=m->live;l;l=l->next) {
        if (strcmp(l->profile,profile)) continue;
        if (!strcmp(l->kind,"login")) return -1;
        if (!l->chat) continue;
        Chat *c=l->chat; owned=-1;
        if (!c->quota_supported || l->stopping ||
            (strcmp(c->stage,"ready") && strcmp(c->stage,"running") && strcmp(c->stage,"limited"))) continue;
        request_quota(l);
        return 1;
    }
    return owned;
}
static int error_is(const JSON *j, int object,const char *code) {
    if (object<0) return 0;
    static const char *fields[]={"codexErrorInfo","data","type","error"};
    for (size_t i=0;i<ARRAY_LEN(fields);++i) {
        int token=json_get(j,object,fields[i]);
        char category[80];
        if (json_string(j,token,category,sizeof(category)) && !strcmp(category,code)) return 1;
        if (token>=0 && json_get(j,token,code)>=0) return 1;
    }
    int data=json_get(j,object,"data");
    char category[80];
    return json_field(j,data,"type",category,sizeof(category)) && !strcmp(category,code);
}
static int auth_error(const JSON *j,int object) {
    if (error_is(j,object,"unauthorized")) return 1;
    int info=json_get(j,object,"codexErrorInfo");
    const char *categories[]={"httpConnectionFailed","responseStreamConnectionFailed","responseTooManyFailedAttempts"};
    for (size_t i=0;i<ARRAY_LEN(categories);++i)
        if (json_int(j,json_get(j,json_get(j,info,categories[i]),"httpStatusCode"),-1)==401) return 1;
    return 0;
}
static int thread_error(const JSON *j,int err) {
    char msg[1200];
    if (error_is(j,err,"threadNotFound")) return 1;
    if (!json_field(j,err,"message",msg,sizeof(msg))) return 0;
    if (strstr(msg,"no rollout found for thread id")) return 2;
    return strstr(msg,"thread not loaded") || strstr(msg,"thread not found");
}
/* A server refusal is a stop condition, never permission to reroute. */
static int policy_refused(const char *text) {
    return contains_ci(text,"rejected: blocked by policy") || contains_ci(text,"denied by policy");
}
static int handle_review_error(Manager *m,Live *l,const JSON *j,int err,const char *turn) {
    char message[1200];
    int explicit_refusal=l->read_only_turn && json_field(j,err,"message",message,sizeof(message)) && policy_refused(message);
    if (!explicit_refusal && !error_is(j,err,"tooManyDenials") && !error_is(j,err,"inferenceHookDenied")) return 0;
    const char *why=explicit_refusal?"BLOCKED_ACCESS: App Server xác nhận chính sách từ chối thao tác. Không tự thử lại hoặc đổi quyền.":error_is(j,err,"tooManyDenials")?
        "Codex đã dừng sau nhiều lần từ chối quyền.":"Chính sách của Codex đã từ chối lượt này.";
    Error e={0};
    if (!review_record(m,l,turn,"policy-error","server","denied","policy",why,&e))
        why="Codex từ chối lượt này và SAMERO không ghi được nhật ký.";
    runner_review_denied(m,l,why);
    if (!l->stopping) connection_failed(m,l,"error",why);
    return 1;
}
static void report_error(Manager *m, Live *l, const JSON *j, int err, int final) {
    Chat *c=l->chat;
    if (handle_review_error(m,l,j,err,c->turn)) return;
    int lost=thread_error(j,err);
    if (lost) {
        c->missing_history=lost==2;
        connection_failed(m,l,"startup","Codex đã báo luồng không còn dùng được trên kết nối này. Hãy kiểm tra Phiên chat hoặc chọn Tạo luồng mới.");
        char msg[1200];
        if (json_field(j,err,"message",msg,sizeof(msg))) log_system(m,l,msg);
        return;
    }
    int was_limited=c->limited;
    if (error_is(j,err,"usageLimitExceeded") || error_is(j,err,"rateLimitExceeded")) c->limited=1;
    if (auth_error(j,err)) c->unauthorized=1;
    if (!final) return;
    char text[1200];
    if (c->unauthorized) {
        codex_rejected(m,l->profile);
        connection_failed(m,l,"auth","Codex đã từ chối xác thực. Kiểm tra đúng CODEX_HOME và đăng nhập lại khi cần.");
    } else if (c->limited) {
        stage(c,"limited");
        log_system(m,l,"Codex báo đã chạm hạn mức hồ sơ này. Bạn có thể xem giờ reset hoặc chủ động bàn giao dự án.");
    } else {
        stage(c,"ready");
        if (json_field(j,err,"message",text,sizeof(text)) && *text)
            log_system(m,l,redacted(text));
        else if (!was_limited) log_system(m,l,"Codex không hoàn thành lượt này. Hãy kiểm tra đăng nhập và cấu hình hồ sơ.");
    }
}
static void handle_response(Manager *m, Live *l, const JSON *j, long long id) {
    Chat *c=l->chat;
    int result=json_get(j,0,"result"), err=json_get(j,0,"error");
    if (id==1 && !strcmp(c->stage,"starting")) {
        if (result<0) connection_error(m,l,"Codex CLI từ chối kết nối. Hãy kiểm tra phiên bản CLI.");
        else if (!codex_send(&l->process,-1,"initialized",NULL)) connection_error(m,l,"Codex đã đóng kết nối khi khởi tạo.");
        else {
            char platform[24];
            c->windows_server=json_field(j,result,"platformOs",platform,sizeof(platform)) && !strcmp(platform,"windows");
#ifdef SAM_WINDOWS
            if (!*platform) c->windows_server=1;
#endif
            c->account_request=c->next++;
            if (codex_send(&l->process,c->account_request,"account/read","{\"refreshToken\":false}"))
                c->account_deadline=monotonic_ms()+2000;
            else chat_thread_open(m,l);
        }
        return;
    }
    if (id==c->account_request && c->account_request) {
        c->account_request=0; c->account_deadline=0;
        int auth=result>=0 ? codex_record_auth(m,l->profile,j,result) : 0;
        int opening=!c->account_checked && !c->thread_request && !c->probe_request && !c->thread[0];
        c->account_checked=1;
        c->quota_supported=auth>0;
        if (auth<0) connection_failed(m,l,"auth","Hồ sơ Codex này chưa đăng nhập. Chọn Đăng nhập rồi mở lại phiên.");
        else {
            if (opening) chat_thread_open(m,l);
            if (auth>0) request_quota(l);
        }
        return;
    }
    if (id==c->quota_request && c->quota_request) {
        c->quota_request=0;
        c->quota_timeout=0;
        if (c->requested_generation!=c->quota_generation) return;
        if (result>=0) codex_record_live_quota(m,l->profile,j,result);
        else if (json_int(j,json_get(j,err,"code"),0)==-32601) {
            c->quota_supported=0; quota_observed(m,l->profile,NULL,0);
        } else quota_observed(m,l->profile,NULL,1);
        return;
    }
    if (id==c->probe_request && c->probe_request) {
        c->probe_request=0;
        int thread=json_get(j,result,"thread");
        char stored[160],status[32],detail[900];
        json_field(j,json_get(j,thread,"status"),"type",status,sizeof(status));
        int failure=thread_error(j,err);
        int unsupported=json_int(j,json_get(j,err,"code"),0)==-32601;
        int matching=json_field(j,thread,"id",stored,sizeof(stored)) && !strcmp(stored,c->resume) &&
            !json_bool(j,json_get(j,thread,"ephemeral")) && strcmp(status,"active") && strcmp(status,"systemError") &&
            matching_workspace(l,j,thread);
        if (!matching && err>=0 && (failure==1 || unsupported)) {
            c->disk_resume=chat_find_rollout(l->home.p,c->resume,l->workspace.p,NULL);
            matching=c->disk_resume;
        }
        if (!matching && failure) c->missing_history=1;
        if (matching) start_verified_thread(m,l);
        else {
            const char *reason=unsupported ?
                "CLI chưa hỗ trợ kiểm tra lịch sử thread/read. Cập nhật CLI hoặc tiếp tục bằng Terminal." :
                "Không xác minh được luồng đã lưu trong đúng CODEX_HOME và thư mục dự án, hoặc luồng đang bận. Kiểm tra Phiên chat hoặc chọn Tạo luồng mới.";
            connection_failed(m,l,"startup",reason);
            if (json_field(j,err,"message",detail,sizeof(detail)) && *detail) log_system(m,l,detail);
        }
        return;
    }
    if (id==c->thread_request && c->thread_request) {
        c->thread_request=0;
        int thread=json_get(j,result,"thread");
        char reviewer[40];
        char detail[900];
        if (!c->auto_review && !c->legacy_reviewer && err>=0 && json_int(j,json_get(j,err,"code"),0)==-32602 &&
            json_field(j,err,"message",detail,sizeof(detail)) && strstr(detail,"unknown field") && strstr(detail,"approvalsReviewer")) {
            c->legacy_reviewer=1; start_verified_thread(m,l); return;
        }
        int box=json_get(j,result,"sandbox"),network=json_get(j,box,"networkAccess");
        char box_type[32],policy[32];
        int unsafe_read=l->read_only_turn && result>=0 &&
            (!json_field(j,box,"type",box_type,sizeof(box_type)) || strcmp(box_type,"readOnly") ||
             (network>=0 && j->t[network].type!='f') || !json_field(j,result,"approvalPolicy",policy,sizeof(policy)) ||
             strcmp(policy,"never") || !matching_workspace(l,j,result));
        if (unsafe_read || (c->auto_review && result>=0 && (!review_policy_matches(l,j,result) || !matching_workspace(l,j,result))) ||
            (!c->auto_review && json_field(j,result,"approvalsReviewer",reviewer,sizeof(reviewer)) && strcmp(reviewer,"user"))) {
            const char *reason="Codex chưa xác nhận reviewer và phạm vi quyền đã chọn. Kiểm tra phiên bản CLI hoặc chính sách quản trị.";
            connection_failed(m,l,"startup",reason); runner_review_denied(m,l,reason);
            return;
        }
        if (!json_field(j,thread,"id",c->thread,sizeof(c->thread)) || !c->thread[0] ||
            json_bool(j,json_get(j,thread,"ephemeral")) || secret_text(c->thread) || (c->resume[0] && strcmp(c->thread,c->resume))) {
            c->thread[0]=0;
            c->missing_history=*c->resume && thread_error(j,err)==2;
            connection_failed(m,l,"startup",c->resume[0] ?
                "Codex không mở được luồng cũ. Bạn có thể chọn Tạo luồng mới trong cùng hồ sơ." :
                "Không tạo được luồng Codex. Kiểm tra CLI, workspace và cấu hình hồ sơ.");
            char detail[900];
            if (json_field(j,err,"message",detail,sizeof(detail)) && *detail) {
                log_system(m,l,redacted(detail));
                if (c->auto_review) runner_review_denied(m,l,redacted(detail));
            }
            return;
        }
        char model[128];
        if (json_field(j,result,"model",model,sizeof(model)) && *model && !secret_text(model)) strcpy(c->model,model);
        char status[32];
        json_field(j,json_get(j,thread,"status"),"type",status,sizeof(status));
        if (((c->disk_resume || json_get(j,thread,"cwd")>=0) && !matching_workspace(l,j,thread)) ||
            !strcmp(status,"active") || !strcmp(status,"systemError")) {
            connection_failed(m,l,"startup","Codex trả về luồng bận, có lỗi hoặc thuộc thư mục dự án khác.");
            return;
        }
        if (l->read_only_turn) { buffer_free(&c->access_policy); json_raw(&c->access_policy,j,box); }
        c->idle_in_reply=!strcmp(status,"idle");
        json_field(j,thread,"path",c->rollout.p,sizeof(c->rollout.p));
        check_loaded(m,l,NULL);
        return;
    }
    if (id==c->readiness_request && c->readiness_request) {
        c->readiness_request=0; c->deadline=0;
        char readiness[32];
        json_field(j,result,"status",readiness,sizeof(readiness));
        if (!strcmp(readiness,"ready") && err<0) {
            c->readiness_checked=1; thread_ready(m,l); return;
        }
        if (json_int(j,json_get(j,err,"code"),0)==-32601) {
            /* Older servers still have to confirm policy and run the sandboxed read probe. */
            log_system(m,l,"CLI chưa hỗ trợ windowsSandbox/readiness. Trạng thái sandbox Windows chưa xác định.");
            c->readiness_checked=1; thread_ready(m,l); return;
        }
        const char *why=!strcmp(readiness,"notConfigured")?"BLOCKED_PREFLIGHT: App Server báo sandbox Windows chưa được cấu hình (notConfigured).":
            !strcmp(readiness,"updateRequired")?"BLOCKED_PREFLIGHT: App Server báo sandbox Windows cần cập nhật (updateRequired).":
            "BLOCKED_PREFLIGHT: App Server chưa xác nhận trạng thái sandbox Windows.";
        access_hold(m,l,why); return;
    }
    if (id==c->access_request && c->access_request) {
        c->access_request=0; c->deadline=0;
        long long code=json_int(j,json_get(j,result,"exitCode"),INT64_MIN);
        long long rpc_code=json_int(j,json_get(j,err,"code"),0);
        char output[2049],detail[2049],rpc_detail[1200]={0},message[520];
        json_field(j,result,"stdout",output,sizeof(output));
        json_field(j,result,"stderr",detail,sizeof(detail));
        json_field(j,err,"message",rpc_detail,sizeof(rpc_detail));
        if (err>=0 && rpc_code==-32601) {
            /* Legacy server: no preflight assertion; normal verifier still required. */
            log_system(m,l,"CLI không hỗ trợ command/exec; kiểm tra trước chưa xác minh. VERIFY vẫn phải đọc bằng chứng gốc.");
            c->access_checked=1; thread_ready(m,l); return;
        }
        if (err<0 && code!=INT64_MIN) runner_record_command(m,l,"command/exec: read-only bookkeeping and directory-list preflight (no file contents or names)",code);
        if (err<0 && result>=0 && code==0 && (!strcmp(output,"SAMERO_READ_OK\n") || !strcmp(output,"SAMERO_READ_OK\r\n"))) {
            log_system(m,l,"Kiểm tra trước: App Server đã đọc được hai tệp quản lý và liệt kê thư mục trong sandbox chỉ đọc. Không thay thế nghiệm thu Task.");
            c->access_verified=1; c->access_checked=1; thread_ready(m,l); return;
        }
        const char *file=strstr(detail,"SAMERO_LIST_FAILED")?"workspace directory listing":strstr(detail,"SAMERO_READ_FAILED TASK_QUEUE.json")?"TASK_QUEUE.json":
            strstr(detail,"SAMERO_READ_FAILED PROJECT_STATUS.md")?"PROJECT_STATUS.md":"TASK_QUEUE.json / PROJECT_STATUS.md";
        const char *kind=contains_ci(detail,"UnauthorizedAccessException") || contains_ci(detail,"Permission denied") || contains_ci(detail,"Access is denied") || policy_refused(detail) || policy_refused(rpc_detail)?"BLOCKED_ACCESS":"BLOCKED_PREFLIGHT";
        const char *cause=contains_ci(detail,"FileNotFoundException") || contains_ci(detail,"No such file")?"Không tìm thấy tệp.":
            !strcmp(kind,"BLOCKED_ACCESS")?"Quyền đọc bị từ chối.":"Chưa xác định được nguyên nhân; kiểm tra quyền, workspace và CLI.";
        char exit_label[32]="NOT RECORDED";
        if (err<0 && code!=INT64_MIN) sam_format(exit_label,sizeof(exit_label),"%lld",code);
        sam_format(message,sizeof(message),"%s: command/exec chỉ đọc: %s; exit %s, RPC %lld. %s Không gửi VERIFY.",kind,file,exit_label,rpc_code,cause);
        access_hold(m,l,message); return;
    }
    if (id==c->loaded_request && c->loaded_request) {
        c->loaded_request=0;
        int list=json_get(j,result,"data");
        if (list>=0 && j->t[list].type=='[') {
            for (int i=list+1;i<j->t[list].after;i=j->t[i].after) {
                char entry[160];
                if (json_string(j,i,entry,sizeof(entry)) && !strcmp(entry,c->thread)) {
                    thread_ready(m,l); return;
                }
            }
            char cursor[1400];
            if (json_field(j,result,"nextCursor",cursor,sizeof(cursor)) && *cursor) {
                if (c->load_page<16) { check_loaded(m,l,cursor); return; }
            } else if (c->load_attempt<3) { c->load_retry=monotonic_ms()+250; return; }
        } else if (json_int(j,json_get(j,err,"code"),0)==-32601 && c->idle_in_reply) {
            thread_ready(m,l); return;
        }
        connection_failed(m,l,"startup","Codex chưa xác nhận đã nạp đúng luồng. Tin nhắn chưa được gửi. Chọn Phiên chat hoặc Tạo luồng mới.");
        return;
    }
    if (id==c->history_request && c->history_request) {
        c->history_request=0;
        int list=json_get(j,result,"data");
        char turn[160];
        if (list>=0 && j->t[list].type=='[' && j->t[list].count &&
            json_field(j,list+1,"id",turn,sizeof(turn)) && !strcmp(turn,c->history_turn)) {
            c->thread_committed=1;
            save_thread_link(m,l);
        }
        return;
    }
    if (id==c->turn_request && c->turn_request) {
        c->turn_request=0;
        c->deadline=0;
        if (result<0) report_error(m,l,j,err,1);
        else {
            int turn=json_get(j,result,"turn");
            accept_turn(m,l,j,turn);
        }
    }
    if (id==c->interrupt_request && c->interrupt_request) {
        c->interrupt_request=0;
        if (err>=0) log_system(m,l,"Codex chưa dừng được lượt này.");
    }
}
static int same_thread(const Chat *c,const JSON *j,int params) {
    char thread[160];
    return c->thread[0] && json_field(j,params,"threadId",thread,sizeof(thread)) && !strcmp(thread,c->thread);
}
static int same_turn(const Chat *c,const JSON *j,int params) {
    char turn[160];
    return !c->turn[0] || (json_field(j,params,"turnId",turn,sizeof(turn)) && !strcmp(turn,c->turn));
}
static int reply(Live *l,const char *rpc_id,const char *decision) {
    Buf response={0};
    buffer_fmt(&response,"{\"id\":%s,",rpc_id);
    if (decision) buffer_fmt(&response,"\"result\":{\"decision\":\"%s\"}}\n",decision);
    else buffer_text(&response,"\"error\":{\"code\":-32601,\"message\":\"Request unsupported by SAMERO\"}}\n");
    int ok=process_write(&l->process,response.s,response.n);
    buffer_free(&response);
    return ok;
}
static int id_string(const JSON *j,int token,char out[256]) {
    if (token<0 || (j->t[token].type!='"' && j->t[token].type!='0')) return 0;
    size_t n=j->t[token].last-j->t[token].first;
    if (!n || n>=256) return 0;
    memcpy(out,j->raw+j->t[token].first,n); out[n]=0;
    return 1;
}
static int permits_accept(const JSON *j,int token) {
    if (token<0 || j->t[token].type!='[') return 1;
    for (int i=token+1;i<j->t[token].after;i=j->t[i].after) {
        char choice[64];
        if (json_string(j,i,choice,sizeof(choice)) && !strcmp(choice,"accept")) return 1;
    }
    return 0;
}
static void review_halt(Manager *m,Live *l,const char *msg) {
    runner_review_denied(m,l,msg);
    if (!l->stopping) connection_failed(m,l,"error",msg);
}
static int audit(Manager *m,Live *l,const char *turn,const char *id,const char *source,
                 const char *status,const char *kind,const char *reason) {
    Error e={0};
    if (review_record(m,l,turn,id,source,status,kind,reason,&e)) { l->chat->saw_review=1; changed(l->chat); return 1; }
    review_halt(m,l,"Đã dừng vì không ghi được nhật ký xét duyệt."); return 0;
}
static void auto_event(Manager *m,Live *l,const JSON *j,int p,int final) {
    Chat *c=l->chat;
    char turn[160],id[160],kind[64],status[32],reason[600];
    if (!json_field(j,p,"turnId",turn,sizeof(turn)) || !*turn || secret_text(turn)) {
        if (c->auto_review) review_halt(m,l,"Sự kiện xét duyệt thiếu ID lượt hợp lệ.");
        return;
    }
    if (strcmp(c->stage,"running") || (*c->turn && strcmp(turn,c->turn))) return;
    if (!*c->turn) { review_halt(m,l,"Codex gửi sự kiện xét duyệt trước khi xác nhận ID lượt."); return; }
    int review=json_get(j,p,"review");
    if (!json_field(j,p,"reviewId",id,sizeof(id)) || !*id || secret_text(id) ||
        !json_field(j,review,"status",status,sizeof(status)) ||
        (!final && strcmp(status,"inProgress")) ||
        (final && strcmp(status,"approved") && strcmp(status,"denied") && strcmp(status,"timedOut") && strcmp(status,"aborted"))) {
        review_halt(m,l,"Codex trả về sự kiện xét duyệt chưa được hỗ trợ."); return;
    }
    if (!json_field(j,json_get(j,p,"action"),"type",kind,sizeof(kind)) || secret_text(kind)) strcpy(kind,"action");
    int rt=json_get(j,review,"rationale");
    size_t cap=rt<0?1:j->t[rt].last-j->t[rt].first+1;
    char *full=allocate(cap);
    if (!json_string(j,rt,full,cap) || !*full) strcpy(reason,"Codex không cung cấp lý do.");
    else if (secret_text(full)) strcpy(reason,"[Đã ẩn thông tin nhạy cảm]");
    else {
        size_t n=strlen(full);
        if (n>=sizeof(reason)) { n=sizeof(reason)-1; while (((unsigned char)full[n]&0xc0)==0x80) --n; }
        memcpy(reason,full,n); reason[n]=0;
    }
    free(full);
    if (!audit(m,l,turn,id,"codex",status,kind,reason)) return;
    if (final && strcmp(status,"approved")) {
        char msg[760]; sam_format(msg,sizeof(msg),"Codex Auto-review (%s): %s",status,reason);
        log_system(m,l,msg); runner_review_denied(m,l,msg);
    }
}
static void approval_request(Manager *m,Live *l,const JSON *j,int params,int token,const char *method) {
    Chat *c=l->chat;
    char rpc_id[256];
    if (!id_string(j,token,rpc_id)) return;
    int command=!strcmp(method,"item/commandExecution/requestApproval");
    int file=!strcmp(method,"item/fileChange/requestApproval");
    if ((!command && !file) || !same_thread(c,j,params) || !same_turn(c,j,params)) {
        reply(l,rpc_id,NULL);
        if (same_thread(c,j,params) && same_turn(c,j,params)) {
            const char *why="Yêu cầu tương tác chưa được hỗ trợ. Kiểm tra quyền trước khi tiếp tục.";
            log_system(m,l,why);
            char key[33]; new_id(key);
            if (*c->turn && audit(m,l,c->turn,key,"manager","denied","unsupported",why)) runner_review_denied(m,l,why);
        }
        return;
    }
    if (l->read_only_turn) {
        reply(l,rpc_id,"decline");
        const char *why="BLOCKED_ACCESS: Codex yêu cầu phê duyệt thao tác ngoài quyền của phiên chỉ đọc. Kiểm tra cấu hình hợp lệ.";
        log_system(m,l,why); runner_review_denied(m,l,why); return;
    }
    Approval *a=NULL;
    for (size_t i=0;i<ARRAY_LEN(c->approvals);++i) {
        if (c->approvals[i].present && !strcmp(c->approvals[i].rpc_id,rpc_id)) return;
        if (!c->approvals[i].present && !a) a=&c->approvals[i];
    }
    if (!a) {
        reply(l,rpc_id,"decline");
        const char *why="Đã đạt số yêu cầu quyền đang chờ.";
        char key[33]; new_id(key);
        if (audit(m,l,c->turn,key,"manager","denied",command?"command":"fileChange",why)) runner_review_denied(m,l,why);
        return;
    }
    *a=(Approval){.present=1};
    new_id(a->key); strcpy(a->rpc_id,rpc_id);
    int network=json_get(j,params,"networkApprovalContext");
    int has_network=network>=0 && j->t[network].type=='{';
    char subject[1400], extra[400], item[160], reason[400];
    if (has_network) {
        strcpy(a->title,"Yêu cầu kết nối mạng");
        json_field(j,network,"host",subject,sizeof(subject));
        json_field(j,network,"protocol",extra,sizeof(extra));
    } else if (command) {
        strcpy(a->title,"Yêu cầu chạy lệnh");
        json_field(j,params,"command",subject,sizeof(subject));
        json_field(j,params,"cwd",extra,sizeof(extra));
    } else {
        strcpy(a->title,"Yêu cầu thay đổi tệp");
        json_field(j,params,"itemId",item,sizeof(item));
        sam_format(subject,sizeof(subject),"%s",item[0] && !strcmp(item,c->proposed_item)?c->proposed_detail:"");
        json_field(j,params,"grantRoot",extra,sizeof(extra));
    }
    json_field(j,params,"reason",reason,sizeof(reason));
    sam_format(a->detail,sizeof(a->detail),"%s%s%s%s%s",redacted(subject),
        *extra?"\n":"",redacted(extra),*reason?"\n":"",redacted(reason));
    a->acceptable=*subject && !secret_text(subject) && !secret_text(extra) &&
        permits_accept(j,json_get(j,params,"availableDecisions"));
    audit(m,l,c->turn,a->key,"user","inProgress",command?"command":"fileChange","Chờ người dùng xác nhận trong Workspace.");
}
static void capture_paths(Chat *c,const JSON *j,int item) {
    Buf paths={0};
    int list=json_get(j,item,"changes");
    if (list>=0 && j->t[list].type=='[') {
        for (int i=list+1;i<j->t[list].after;i=j->t[i].after) {
            char path[700];
            if (!json_field(j,i,"path",path,sizeof(path)) || secret_text(path) ||
                paths.n+strlen(path)+1>=sizeof(c->proposed_detail)) {
                buffer_free(&paths); c->proposed_item[0]=0; c->proposed_detail[0]=0; return;
            }
            if (paths.n) buffer_char(&paths,'\n');
            buffer_text(&paths,path);
        }
    }
    json_field(j,item,"id",c->proposed_item,sizeof(c->proposed_item));
    sam_format(c->proposed_detail,sizeof(c->proposed_detail),"%s",paths.s?paths.s:"");
    buffer_free(&paths);
}
static void capture_tool_output(Chat *c,const JSON *j,int object,const char *field,int append) {
    char *text=allocate(TEXT_CAP+1);
    if (!append) buffer_free(&c->tool_output);
    if (json_field(j,object,field,text,TEXT_CAP+1) && *text &&
        c->tool_output.n+strlen(text)<=TEXT_CAP) buffer_text(&c->tool_output,text);
    free(text);
    changed(c);
}
static void handle_notification(Manager *m,Live *l,const JSON *j,int p,const char *method) {
    Chat *c=l->chat;
    if (!strcmp(method,"account/rateLimits/updated")) {
        if (codex_record_live_quota(m,l->profile,j,p)) ++c->quota_generation;
        return;
    }
    if (!strcmp(method,"account/updated") && c->account_checked && !c->account_request && !c->close_deadline) {
        c->account_request=c->next++;
        if (codex_send(&l->process,c->account_request,"account/read","{\"refreshToken\":false}"))
            c->account_deadline=monotonic_ms()+4000;
        else c->account_request=0;
        return;
    }
    if (!same_thread(c,j,p)) return;
    if (l->autonomous && (!strncmp(method,"item/",5) || !strncmp(method,"turn/",5))) l->runner_activity=monotonic_ms();
    if (!strcmp(method,"thread/closed") || !strcmp(method,"thread/status/changed")) {
        char status[32]; json_field(j,json_get(j,p,"status"),"type",status,sizeof(status));
        if (!strcmp(method,"thread/closed") || !strcmp(status,"notLoaded") || !strcmp(status,"systemError") ||
            (!strcmp(status,"active") && strcmp(c->stage,"running"))) {
            connection_failed(m,l,"startup","Codex đã đóng luồng hoặc luồng không còn sẵn sàng. Mở lại phiên trước khi gửi tiếp.");
        }
        return;
    }
    if (!c->loaded) return;
    if (!strcmp(method,"autoApprovalReview/strictReviewRequired") && c->auto_review && *c->turn && same_turn(c,j,p)) {
        const char *why="Codex yêu cầu xét duyệt nghiêm ngặt. Kiểm tra nhiệm vụ trước khi tiếp tục.";
        if (audit(m,l,c->turn,"strict-review","codex","needsReview","policy",why)) runner_review_denied(m,l,why);
        return;
    }
    if (!strcmp(method,"item/autoApprovalReview/started") || !strcmp(method,"item/autoApprovalReview/completed")) {
        auto_event(m,l,j,p,!strcmp(method,"item/autoApprovalReview/completed")); return;
    }
    if (!strcmp(method,"turn/diff/updated") && same_turn(c,j,p)) {
        char *diff=allocate(TEXT_CAP+1);
        if (json_field(j,p,"diff",diff,TEXT_CAP+1)) {
            buffer_free(&c->diff); buffer_text(&c->diff,diff); changed(c);
        }
        free(diff);
        return;
    }
    if (!strcmp(method,"item/commandExecution/outputDelta") && same_turn(c,j,p)) {
        char item[160];
        if (json_field(j,p,"itemId",item,sizeof(item)) && !strcmp(c->tool_id,item))
            capture_tool_output(c,j,p,"delta",1);
        return;
    }
    if (!strcmp(method,"turn/started") && !strcmp(c->stage,"running")) {
        int turn=json_get(j,p,"turn");
        accept_turn(m,l,j,turn);
    } else if (!strcmp(method,"item/agentMessage/delta") && same_turn(c,j,p)) {
        char id[160], *delta=allocate(TEXT_CAP+1);
        if (json_field(j,p,"itemId",id,sizeof(id)) && json_field(j,p,"delta",delta,TEXT_CAP+1)) {
            if (strcmp(id,c->item)) { clear_draft(c); strcpy(c->item,id); }
            if (strlen(delta)+c->draft.n<=TEXT_CAP) {
                buffer_text(&c->draft,delta); changed(c);
            }
        }
        free(delta);
    } else if ((!strcmp(method,"item/completed") || !strcmp(method,"item/started")) && same_turn(c,j,p)) {
        int item=json_get(j,p,"item"); char type[40];
        if (!json_field(j,item,"type",type,sizeof(type))) return;
        if (c->verifying) {
            if (!*c->turn || strcmp(c->stage,"running")) return;
            if (!verify_item(&c->verification,j,item,!strcmp(method,"item/completed"))) return;
        }
        char item_status[32],item_id[160];
        if ((!strcmp(type,"commandExecution") || !strcmp(type,"fileChange")) && !strcmp(method,"item/completed") &&
            *c->turn && json_field(j,item,"status",item_status,sizeof(item_status)) && !strcmp(item_status,"declined")) {
            if (!json_field(j,item,"id",item_id,sizeof(item_id)) || secret_text(item_id)) new_id(item_id);
            const char *why=l->read_only_turn?"BLOCKED_ACCESS: App Server ghi nhận thao tác bị từ chối trong lượt chỉ đọc.":"Codex đã từ chối thao tác. Máy chủ không gửi thêm lý do.";
            if (audit(m,l,c->turn,item_id,"server","denied",type,why)) runner_review_denied(m,l,why);
            return;
        }
        if (!strcmp(type,"agentMessage") && !strcmp(method,"item/completed")) {
            char id[160], *text=allocate(TEXT_CAP+1);
            json_field(j,item,"id",id,sizeof(id));
            const char *received=json_field(j,item,"text",text,TEXT_CAP+1) && *text?text:
                !strcmp(id,c->item) && c->draft.n?c->draft.s:NULL;
            if (received) log_assistant(m,l,received);
            else log_system(m,l,"Phản hồi vượt giới hạn hoặc thiếu nội dung.");
            if (l->autonomous && *c->turn && !strcmp(c->stage,"running")) {
                char phase[32]; json_field(j,item,"phase",phase,sizeof(phase));
                if (!strcmp(phase,"final_answer") || (!*phase && !c->final_result)) {
                    buffer_free(&c->runner_result); c->final_result=!strcmp(phase,"final_answer");
                    if (received && !secret_text(received)) buffer_text(&c->runner_result,received);
                }
            }
            if (!strcmp(id,c->item)) clear_draft(c);
            changed(c);
            free(text);
        } else if (!strcmp(type,"commandExecution") && !strcmp(method,"item/completed")) {
            char id[160], status[48];
            if (l->autonomous) {
                char command[1801];
                int has_command=json_field(j,item,"command",command,sizeof(command));
                runner_record_command(m,l,has_command?command:NULL,json_int(j,json_get(j,item,"exitCode"),INT64_MIN));
            }
            if (json_field(j,item,"id",id,sizeof(id)) && !strcmp(id,c->tool_id)) {
                int output=json_get(j,item,"aggregatedOutput");
                if (output>=0 && j->t[output].type=='"') capture_tool_output(c,j,item,"aggregatedOutput",0);
                json_field(j,item,"status",status,sizeof(status));
                long long exit_code=json_int(j,json_get(j,item,"exitCode"),-1);
                sam_format(c->activity,sizeof(c->activity),"Lệnh: %s · mã thoát %lld",status,exit_code);
                changed(c);
            }
        } else if (!strcmp(type,"fileChange") && !strcmp(method,"item/completed")) {
            capture_paths(c,j,item);
            if (c->proposed_detail[0]) { strcpy(c->activity,"Codex đã báo thay đổi tệp."); changed(c); }
        } else if (!strcmp(method,"item/started")) {
            const char *activity=NULL;
            if (!strcmp(type,"fileChange")) { capture_paths(c,j,item); activity="Codex đang đề xuất thay đổi tệp."; }
            else if (!strcmp(type,"commandExecution")) {
                json_field(j,item,"id",c->tool_id,sizeof(c->tool_id));
                buffer_free(&c->tool_output);
                activity="Codex đang xử lý bằng lệnh trong workspace.";
            }
            else if (!strcmp(type,"mcpToolCall")) activity="Codex đang chờ kết quả công cụ.";
            if (activity) { strcpy(c->activity,activity); changed(c); }
        }
    } else if (!strcmp(method,"serverRequest/resolved")) {
        char rpc_id[256];
        if (id_string(j,json_get(j,p,"requestId"),rpc_id)) {
            for (size_t i=0;i<ARRAY_LEN(c->approvals);++i) {
                if (c->approvals[i].present && !strcmp(c->approvals[i].rpc_id,rpc_id)) {
                    c->approvals[i].present=0; changed(c);
                }
            }
        }
    } else if (!strcmp(method,"error") && same_turn(c,j,p) && !json_bool(j,json_get(j,p,"willRetry"))) {
        report_error(m,l,j,json_get(j,p,"error"),0);
    } else if (!strcmp(method,"turn/completed") && !strcmp(c->stage,"running")) {
        int turn=json_get(j,p,"turn");
        char id[160], status[40];
        if (!json_field(j,turn,"id",id,sizeof(id)) || (c->turn[0] && strcmp(id,c->turn))) return;
        if (!json_field(j,turn,"status",status,sizeof(status))) return;
        if (c->verifying && *c->turn) {
            /* A new thread may have no rollout path until its first turn. */
            if (!*c->rollout.p)
                chat_find_rollout(l->home.p,c->thread,l->workspace.p,&c->rollout);
            verify_rollout(&c->verification,c->rollout.p,l->home.p,c->thread,l->workspace.p,id);
        }
        if (!strcmp(status,"failed")) {
            if (handle_review_error(m,l,j,json_get(j,turn,"error"),id)) return;
            if (c->verifying && verify_has_denial(&c->verification)) {
                runner_review_denied(m,l,"BLOCKED_ACCESS: App Server ghi nhận công cụ bị từ chối quyền trước khi lượt VERIFY kết thúc.");
                return;
            }
        }
        if (c->saw_review && l->autonomous && !reviews_settled(m,l,id)) {
            review_halt(m,l,"Lượt đã kết thúc khi quyết định xét duyệt chưa được xác minh."); return;
        }
        flush_draft(m,l);
        c->deadline=0; c->turn[0]=0; c->turn_request=0; c->interrupt_request=0;
        memset(c->approvals,0,sizeof(c->approvals));
        if (c->quota_supported) c->quota_after_turn=monotonic_ms()+1500;
        if (c->turn_accepted && strcmp(status,"failed")) verify_stored_turn(m,l,id);
        if (c->close_deadline) return;
        if (!strcmp(status,"failed")) report_error(m,l,j,json_get(j,turn,"error"),1);
        else {
            c->turn_complete=!strcmp(status,"completed");
            stage(c,"ready");
            if (!strcmp(status,"interrupted")) log_system(m,l,"Đã dừng lượt Codex.");
        }
    }
}
static void receive_line(Manager *m,Live *l,const char *raw,size_t length) {
    if (l->stopping || l->chat->close_deadline || !strcmp(l->chat->stage,"closing")) return;
    JSON j;
    if (!json_parse(&j,raw,length)) {
        if (l->chat->verifying && !strcmp(l->chat->stage,"running")) {
            l->chat->verification.partial=1;
            log_system(m,l,"VERIFY: Phản hồi JSON App Server không hợp lệ; không đủ bằng chứng nghiệm thu.");
        }
        return;
    }
    char method[100];
    int id=json_get(&j,0,"id");
    if (!json_field(&j,0,"method",method,sizeof(method))) {
        if (id>=0) handle_response(m,l,&j,json_int(&j,id,-1));
    } else {
        int p=json_get(&j,0,"params");
        if (id>=0) approval_request(m,l,&j,p,id,method);
        else handle_notification(m,l,&j,p,method);
    }
    json_free(&j);
}
void chat_tick(Manager *m,Live *l) {
    Chat *c=l->chat;
    if (c->ended) return;
    if (c->close_deadline && monotonic_ms()>c->close_deadline) {
        c->close_deadline=0;
        log_system(m,l,"Codex không tự đóng sau khi ngắt kết nối. Manager dừng tiến trình của phiên này.");
        process_stop(&l->process);
        return;
    }
    if (l->stopping) return;
    if (c->load_retry && monotonic_ms()>=c->load_retry) check_loaded(m,l,NULL);
    if (c->account_deadline && monotonic_ms()>c->account_deadline) {
        c->account_deadline=0; c->account_request=0;
        if (!c->account_checked) { c->account_checked=1; chat_thread_open(m,l); }
    }
    if (c->quota_request && monotonic_ms()>=c->quota_timeout) {
        c->quota_request=0; quota_observed(m,l->profile,NULL,1);
    }
    if (c->quota_after_turn && monotonic_ms()>=c->quota_after_turn && !c->close_deadline) {
        c->quota_after_turn=0;
        request_quota(l);
    }
    if (c->deadline && monotonic_ms()>c->deadline) {
        if (c->readiness_request) { c->readiness_request=0; access_hold(m,l,"BLOCKED_PREFLIGHT: Hết thời gian kiểm tra sandbox Windows."); return; }
        if (c->access_request) { access_hold(m,l,"BLOCKED_PREFLIGHT: command/exec kiểm tra quyền đọc vượt thời gian chờ. Không gửi VERIFY."); return; }
        if (!strcmp(c->stage,"starting")) connection_error(m,l,"Codex App Server mất quá nhiều thời gian để mở chat.");
        else {
            connection_error(m,l,"Codex chưa xác nhận lượt. Kết nối đang được đóng. Kiểm tra lịch sử phiên trước khi gửi lại.");
        }
    }
    char chunk[4096];
    for (int i=0;i<32;++i) {
        int n=process_read(&l->process,chunk,sizeof(chunk));
        if (n<=0) break;
        if (c->incoming.n+(size_t)n>2*MIB) {
            connection_error(m,l,"Codex gửi một sự kiện vượt giới hạn đọc.");
            buffer_free(&c->incoming);
            break;
        }
        buffer_add(&c->incoming,chunk,(size_t)n);
        size_t used=0;
        while (used<c->incoming.n) {
            const char *end=memchr(c->incoming.s+used,'\n',c->incoming.n-used);
            if (!end) break;
            size_t next=(size_t)(end-c->incoming.s);
            receive_line(m,l,c->incoming.s+used,next-used);
            used=next+1;
        }
        if (used) {
            c->incoming.n-=used;
            memmove(c->incoming.s,c->incoming.s+used,c->incoming.n);
            c->incoming.s[c->incoming.n]=0;
        }
    }
}
const char *chat_runner_result(const Live *l) { return l->chat->runner_result.s; }
int chat_access_verified(const Live *l) { return l->chat && l->chat->access_verified; }
int chat_observed_access_denial(const Live *l) { return verify_has_denial(&l->chat->verification); }
int chat_verify_success(const Live *l) { return verify_has_success(&l->chat->verification); }
void chat_verify_summary(const Live *l,char *out,size_t cap) {
    verify_summary(&l->chat->verification,l->chat->access_verified,out,cap);
}
void chat_runner_close(Live *l) {
    Chat *c=l->chat; l->stopping=1; stage(c,"closing");
    c->close_deadline=monotonic_ms()+10000; process_close_input(&l->process);
}
const char *chat_runner_progress(const Live *l) {
    const Chat *c=l->chat;
    return c->turn_complete && !strcmp(c->stage,"ready") ? "completed" : c->stage;
}
int chat_reconnectable(const Live *l) {
    const Chat *c=l->chat;
    return c && !l->autonomous && !l->stopping && !l->reconnected && c->thread_committed && !strcmp(c->stage,"ready") &&
        !c->first[0] && !c->turn[0] && !c->turn_request && !c->close_deadline;
}
void chat_ended(Manager *m,Live *l,int code) {
    Chat *c=l->chat;
    if (c->ended) return;
    c->ended=1;
    int early_exit=!strcmp(c->stage,"starting");
    if (early_exit || (!l->stopping && (!strcmp(c->stage,"ready") || !strcmp(c->stage,"running")))) stage(c,"error");
    flush_draft(m,l);
    if (c->first[0]) {
        Error ignored={0};
        log_entry(m,l,"user",c->first,&ignored);
        c->first[0]=0;
    }
    if (early_exit) log_system(m,l,"Codex App Server thoát trước khi mở phiên. Kiểm tra đường dẫn CLI và cấu hình hồ sơ.");
    else if (!strcmp(c->stage,"error") && !c->close_deadline) log_system(m,l,"Mất kết nối với Codex. Kiểm tra lịch sử trước khi mở lại; ứng dụng không tự gửi lại prompt.");
    else if (strcmp(c->stage,"closing") && strcmp(c->stage,"error") && strcmp(c->stage,"auth") && strcmp(c->stage,"startup")) {
        log_system(m,l,l->stopping ? "Đã dừng phiên chat." : code ?
            "Tiến trình Codex kết thúc bất thường." : "Đã đóng kết nối Codex.");
    }
}
void chat_free(Chat *c) {
    if (!c) return;
    buffer_free(&c->access_policy); buffer_free(&c->runner_result); buffer_free(&c->incoming); buffer_free(&c->draft); buffer_free(&c->tool_output); buffer_free(&c->diff); free(c);
}

static int chat_state(Manager *m,const char *project,const JSON *in,Buf *out,Error *e) {
    if (!valid_id(project)) return errorf(e,"Chọn một dự án.");
    Live *l=find_chat(m,project);
    Chat *c=l?l->chat:NULL;
    char revision[33]; ARG(in,"revision",revision);
    int now_same=c && !strcmp(revision,c->changed);
    if (now_same) { buffer_text(out,"{\"unchanged\":true}"); return 1; }
    char history_revision[33]; ARG(in,"historyRevision",history_revision);
    int reuse=c && *history_revision && !strcmp(history_revision,c->history_revision);
    Document d={0};
    char saved[33]="", last_session[33]="", last_profile[33]="", failure[16]="";
    if (reuse) strcpy(saved,history_revision);
    else {
        history(m,project,&d);
        FIELD(&d,"revision",saved);
        FIELD(&d,"latestSession",last_session); FIELD(&d,"latestProfile",last_profile);
        FIELD(&d,"startupFailure",failure);
    }
    if (!c && *saved && !strcmp(saved,revision)) { buffer_text(out,"{\"unchanged\":true}"); doc_free(&d); return 1; }
    int messages=json_get(&d.data,0,"messages");
    buffer_char(out,'{'); json_pair(out,"revision",c?c->changed:saved);
    KEY(out,"historyRevision",saved);
    KEY(out,"session",l?l->id:last_session); KEY(out,"profile",l?l->profile:last_profile);
    KEY(out,"stage",c?l->stopping?"closing":c->stage:*failure?failure:"closed");
    KEY(out,"reviewer",c?(c->auto_review?"auto_review":"user"):"");
    KEY(out,"model",c?c->model:"");
    char active_key[33]="";
    if (c && c->thread_committed) live_chat_key(l,active_key);
    KEY(out,"chatKey",active_key);
    KEY(out,"toolOutput",c && c->tool_output.n?redacted(c->tool_output.s):"");
    KEY(out,"diff",c && c->diff.n?redacted(c->diff.s):"");
    KEY(out,"files",c?redacted(c->proposed_detail):"");
    KEY(out,"draft",c && c->draft.n?redacted(c->draft.s):"");
    KEY(out,"activity",c?c->activity:"");
    RAW(out,"canInterrupt",c && c->turn[0] && !c->interrupt_request ? "true":"false");
    RAW(out,"active",l?"true":"false");
    if (!reuse) {
        buffer_text(out,",\"messages\":");
        if (messages>=0) json_raw(out,&d.data,messages);
        else buffer_text(out,"[]");
    }
    buffer_text(out,",\"approvals\":[");
    int has=0;
    if (c) for (size_t i=0;i<ARRAY_LEN(c->approvals);++i) {
        Approval *a=&c->approvals[i];
        if (!a->present) continue;
        if (has++) buffer_char(out,',');
        buffer_char(out,'{'); json_pair(out,"id",a->key); KEY(out,"title",a->title); KEY(out,"detail",a->detail);
        RAW(out,"acceptable",a->acceptable?"true":"false"); buffer_char(out,'}');
    }
    buffer_text(out,"]}");
    doc_free(&d);
    return 1;
}
static int profile_exists(Manager *m,const char *id) {
    Document d; Error ignored={0};
    int ok=get_doc(m,"profiles",id,&d,&ignored);
    if (ok) doc_free(&d);
    return ok;
}
static int resume_chat(Manager *m,const char *project,const char *profile,const char *first,
                       int fresh,Buf *out,Error *e) {
    Document d;
    history(m,project,&d);
    char last[33], last_profile[33], unavailable[160], thread[160]="";
    FIELD(&d,"unavailableThread",unavailable);
    int known=FIELD(&d,"resumeSession",last) && *last;
    if (!known && !last[0] && json_get(&d.data,0,"resumeSession")<0) FIELD(&d,"latestSession",last);
    FIELD(&d,"latestProfile",last_profile);
    doc_free(&d);
    if (*last_profile && strcmp(last_profile,profile)) {
        if (profile_exists(m,last_profile)) return errorf(e,"Dùng Bàn giao để chuyển hồ sơ cho dự án này.");
        if (!fresh) return errorf(e,"Hồ sơ cũ đã được gỡ. Chọn Tạo luồng mới để chat bằng hồ sơ đang chọn.");
    }
    if (*last && !fresh) {
        Document session, account;
        if (get_doc(m,"sessions",last,&session,e)) {
            char older[65];
            char owner[33],scope[33]; FIELD(&session,"profile",owner); FIELD(&session,"project",scope);
            int home_found=FIELD(&session,"chatHome",older);
            FIELD(&session,"chatThread",thread);
            if (!*thread) FIELD(&session,"chatCandidate",thread);
            int has=home_found && *thread;
            int wrong_scope=strcmp(owner,profile) || strcmp(scope,project);
            doc_free(&session);
            if (wrong_scope) return errorf(e,"Phiên đã lưu thuộc hồ sơ hoặc dự án khác.");
            if (*thread && !strcmp(unavailable,thread))
                return errorf(e,"Không tìm thấy lịch sử cho luồng cũ. Chọn Tạo luồng mới hoặc khôi phục lịch sử rồi chọn lại trong Phiên chat.");
            if ((known || *thread) && !has) return errorf(e,"Thông tin luồng đã lưu bị thiếu. Kiểm tra Phiên chat hoặc chọn Tạo luồng mới.");
            if (has) {
                if (!get_doc(m,"profiles",profile,&account,e)) return 0;
                Path *home=allocate(sizeof(*home));
                FIELD(&account,"home",home->p);
                doc_free(&account);
                Sha256 sha={0}; char current[65];
                sha_update(&sha,home->p,strlen(home->p)); sha_finish(&sha,current); free(home);
                if (strcmp(older,current)) { return errorf(e,"CODEX_HOME đã đổi. Chọn Tạo luồng mới để bắt đầu trong hồ sơ này."); }
            }
        } else if (known) return errorf(e,"Không đọc được luồng đã lưu. Kiểm tra Phiên chat trước khi mở một luồng mới.");
    }
    e->msg[0]=0;
    return start_session(m,profile,project,thread,first,"chat",out,e);
}
int chat_resume_saved(Manager *m,const char *profile,const char *project,const char *thread,Buf *out,Error *e) {
    Document d;
    history(m,project,&d);
    char owner[33]; FIELD(&d,"latestProfile",owner);
    doc_free(&d);
    if (*owner && strcmp(owner,profile) && profile_exists(m,owner))
        return errorf(e,"Chat dự án đang thuộc hồ sơ khác. Bàn giao hồ sơ hoặc dùng Tiếp tục trong terminal.");
    return start_session(m,profile,project,thread,NULL,"chat",out,e);
}
static int project_draft(Manager *m,const char *project,const JSON *in,Buf *out,Error *e,int save) {
    Document d;
    if (save) {
        char text[PROMPT_CAP+1];
        if (!get_doc(m,"projects",project,&d,e)) return 0;
        doc_free(&d);
        if (!safe_field(text,sizeof(text),in,"text"))
            return errorf(e,"Bản nháp quá dài hoặc có dấu hiệu chứa dữ liệu xác thực.");
        Buf record={0};
        buffer_char(&record,'{'); json_pair(&record,"text",text); buffer_char(&record,'}');
        int ok=put_doc(m,"drafts",project,&record,e);
        buffer_free(&record);
        if (ok) buffer_text(out,"{}");
        return ok;
    }
    Error ignored={0};
    if (!get_doc(m,"drafts",project,&d,&ignored)) { buffer_text(out,"{\"text\":\"\"}"); return 1; }
    char text[PROMPT_CAP+1];
    FIELD(&d,"text",text);
    buffer_char(out,'{'); json_pair(out,"text",redacted(text)); buffer_char(out,'}');
    doc_free(&d);
    return 1;
}
static int send_chat(Manager *m,Live *l,const JSON *in,const char *project,const char *profile,Buf *out,Error *e) {
    char text[PROMPT_CAP+1],id[33],hash[65];
    if (!safe_field(text,sizeof(text),in,"text") || !text[strspn(text," \t\r\n")])
        return errorf(e,"Nhập tin nhắn tối đa 3.000 byte và bỏ dữ liệu xác thực trước khi gửi.");
    int tracked=json_get(in,0,"requestId")>=0;
    if (tracked) {
        if (!ARG(in,"requestId",id) || !valid_id(id) || !valid_id(profile)) return errorf(e,"Mã lượt gửi không hợp lệ.");
        Sha256 sha={0}; sha_update(&sha,project,strlen(project)+1); sha_update(&sha,profile,strlen(profile)+1);
        sha_update(&sha,text,strlen(text)); sha_finish(&sha,hash);
        Document receipt; Error ignored={0};
        if (get_doc(m,"chatreceipts",id,&receipt,&ignored)) {
            char prior[65]; FIELD(&receipt,"hash",prior);
            int accepted=YES(&receipt.data,"accepted"); doc_free(&receipt);
            if (strcmp(prior,hash)) return errorf(e,"Mã gửi này đã được dùng cho nội dung khác.");
            if (!accepted) return errorf(e,"Lượt gửi trước chưa rõ kết quả. Kiểm tra lịch sử trước khi tạo yêu cầu mới.");
            buffer_text(out,"{\"duplicate\":true}"); return 1;
        }
    }
    if (l && strcmp(l->profile,profile)) return errorf(e,"Phiên đang dùng hồ sơ khác. Chọn Bàn giao hồ sơ.");
    if (l && (l->stopping || (strcmp(l->chat->stage,"ready") && strcmp(l->chat->stage,"limited"))))
        return errorf(e,"Đợi Codex hoàn thành lượt đang chạy.");
    Path *path=NULL;
    if (tracked) {
        char record[128]; sam_format(record,sizeof(record),"{\"hash\":\"%s\",\"accepted\":false}",hash);
        path=allocate(sizeof(*path));
        if (!docs_path(m,"chatreceipts",id,path) || !write_new_atomic(path->p,record,strlen(record),e)) {
            free(path); return 0;
        }
    }
    int ok=l ? post_turn(m,l,text,e) : resume_chat(m,project,profile,text,YES(in,"fresh"),out,e);
    if (path) {
        if (ok) {
            char record[128]; sam_format(record,sizeof(record),"{\"hash\":\"%s\",\"accepted\":true}",hash);
            if (!write_atomic(path->p,record,strlen(record),e))
                ok=errorf(e,"Manager đã nhận tin nhưng chưa xác nhận được biên nhận. Kiểm tra lịch sử.");
        } else if (!l || strcmp(l->chat->stage,"error")) remove_file(path->p);
        free(path);
    }
    if (ok && l) buffer_text(out,"{}");
    return ok;
}
int chat_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    char project[33], profile[33]; ARG(in,"project",project); ARG(in,"profile",profile);
    if (!strcmp(action,"chat-state")) return chat_state(m,project,in,out,e);
    if (!valid_id(project)) return errorf(e,"Chọn một dự án.");
    if (!strcmp(action,"chat-draft-read")) return project_draft(m,project,in,out,e,0);
    if (!strcmp(action,"chat-draft-save")) return project_draft(m,project,in,out,e,1);
    Live *l=find_chat(m,project);
    if (!strcmp(action,"chat-open")) {
        if (l) return errorf(e,"Workspace đã có phiên chat.");
        return resume_chat(m,project,profile,NULL,YES(in,"fresh"),out,e);
    }
    if (l && l->autonomous && !m->runner_internal && (!strcmp(action,"chat-send") || !strcmp(action,"chat-close") || !strcmp(action,"chat-interrupt"))) return errorf(e,"Dùng điều khiển Autonomous Mode cho lượt này.");
    if (!strcmp(action,"chat-send")) return send_chat(m,l,in,project,profile,out,e);
    if (!l) return errorf(e,"Phiên chat đã đóng.");
    char session[33]; ARG(in,"session",session);
    if (strcmp(session,l->id)) return errorf(e,"Phiên chat đã thay đổi. Hãy làm mới.");
    Chat *c=l->chat;
    if (!strcmp(action,"chat-close")) {
        if (!strcmp(c->stage,"running") || !strcmp(c->stage,"starting"))
            return errorf(e,"Dừng hoặc đợi lượt hiện tại hoàn thành trước khi đóng.");
        stage(c,"closing"); c->close_deadline=monotonic_ms()+10000; process_close_input(&l->process);
    } else if (!strcmp(action,"chat-interrupt")) {
        if (!c->turn[0] || c->interrupt_request) return errorf(e,"Codex chưa xác nhận lượt đang chạy.");
        Buf params={0};
        buffer_char(&params,'{'); json_pair(&params,"threadId",c->thread); KEY(&params,"turnId",c->turn); buffer_char(&params,'}');
        int id=c->next++;
        int ok=codex_send(&l->process,id,"turn/interrupt",params.s);
        buffer_free(&params);
        if (!ok) return errorf(e,"Không gửi được yêu cầu dừng.");
        c->interrupt_request=id; changed(c);
    } else if (!strcmp(action,"chat-approval")) {
        char key[33], decision[20]; ARG(in,"id",key); ARG(in,"decision",decision);
        Approval *a=NULL;
        for (size_t i=0;i<ARRAY_LEN(c->approvals);++i)
            if (c->approvals[i].present && !strcmp(key,c->approvals[i].key)) a=&c->approvals[i];
        if (!a) return errorf(e,"Yêu cầu phê duyệt đã thay đổi.");
        if ((strcmp(decision,"decline") && (strcmp(decision,"accept") || !a->acceptable)) ||
            !reply(l,a->rpc_id,decision)) return errorf(e,"Không gửi được quyết định này.");
        const char *why=!strcmp(decision,"accept")?"Người dùng đã xác nhận một lần.":"Người dùng đã từ chối yêu cầu quyền.";
        a->present=0;
        if (!audit(m,l,c->turn,a->key,"user",!strcmp(decision,"accept")?"approved":"denied",a->title,why))
            return errorf(e,"Không ghi được quyết định xét duyệt.");
        if (!strcmp(decision,"decline")) runner_review_denied(m,l,why);
    } else return errorf(e,"Thao tác chat không tồn tại.");
    buffer_text(out,"{}"); return 1;
}
