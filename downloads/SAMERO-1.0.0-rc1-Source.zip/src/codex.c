#include "manager.h"

const char codex_client_info[] =
    "{\"clientInfo\":{\"name\":\"samero_codex_manager\",\"title\":\"SAMERO Codex Manager\",\"version\":\"" SAM_VERSION "\"}}";
static const char isolation[] = "cli_auth_credentials_store=\"file\"";
int use_file_credentials(const Document *profile, const char *home) {
    char store[12];
    FIELD(profile,"authStore",store);
    if (*store) return !strcmp(store,"file");
    return !strncmp(base_name(home),".codex-samero-",14);
}
static int current_profile(Manager *m, const char *id, Document *d, Path *exe, Path *home, Error *e) {
    if (!get_doc(m,"profiles",id,d,e)) return 0;
    Path *resolved = allocate(sizeof(*resolved));
    int ok = FIELD(d,"home",home->p) && open_directory(home->p,resolved) &&
        within(home->p,resolved->p) && within(resolved->p,home->p);
    free(resolved);
    if (ok) ok = find_codex(m,d,exe);
    if (ok) return 1;
    doc_free(d);
    return errorf(e,"CODEX_HOME không còn hợp lệ hoặc chưa tìm thấy Codex CLI. Kiểm tra Cài đặt.");
}
typedef struct { Process process; Buf pending; } RPC;
int codex_send(Process *process, int id, const char *method, const char *params) {
    Buf request = {0};
    buffer_fmt(&request,"{\"method\":\"%s\"",method);
    if (id >= 0) NUM(&request,"id",id);
    if (params) RAW(&request,"params",params);
    buffer_text(&request,"}\n");
    int ok = process_write(process,request.s,request.n);
    buffer_free(&request);
    return ok;
}
static int rpc_message(RPC *rpc, int id, const char *method, const char *params,
                       Buf *response, unsigned timeout, Error *e) {
    if (!codex_send(&rpc->process,id,method,params))
        return errorf(e,"Không gửi được yêu cầu tới Codex App Server.");
    if (id < 0) return 1;
    uint64_t end = monotonic_ms() + timeout;
    char data[4096];
    while (monotonic_ms() < end) {
        const char *newline = rpc->pending.s ? memchr(rpc->pending.s,'\n',rpc->pending.n) : NULL;
        if (newline) {
            size_t len = (size_t)(newline-rpc->pending.s);
            int found = 0;
            JSON j;
            if (json_parse(&j,rpc->pending.s,len)) {
                if (NUMBER(&j,"id",-1) == id && json_get(&j,0,"method") < 0) {
                    int r = json_get(&j,0,"result");
                    found = r >= 0 && j.t[r].type == '{' ? 1 : -1;
                    if (found > 0) json_raw(response,&j,r);
                }
                json_free(&j);
            }
            rpc->pending.n -= len + 1;
            memmove(rpc->pending.s,newline+1,rpc->pending.n);
            rpc->pending.s[rpc->pending.n] = 0;
            if (found > 0) return 1;
            if (found < 0) return errorf(e,"Codex App Server từ chối yêu cầu hoặc tài khoản chưa hỗ trợ dữ liệu này.");
            continue;
        }
        int n = process_read(&rpc->process,data,sizeof(data));
        if (n < 0) return errorf(e,"Codex App Server đóng kết nối trước khi trả lời.");
        if (!n) { sleep_ms(10); continue; }
        if (rpc->pending.n + (size_t)n > 2*MIB) return errorf(e,"Phản hồi Codex vượt giới hạn.");
        buffer_add(&rpc->pending,data,(size_t)n);
    }
    return errorf(e,"Codex App Server vượt thời gian chờ.");
}
/* Use the same child-only -c overrides for verification and the TUI. */
int codex_terminal_review(Manager *m,Live *l,const char *exe,const char **args,size_t cap,size_t *count,Error *e) {
    static const char *const config[]={
        "approvals_reviewer=\"auto_review\"",
        "approval_policy={granular={sandbox_approval=false,rules=true,mcp_elicitations=false,request_permissions=false,skill_approval=false}}",
        "sandbox_mode=\"workspace-write\"",
        "sandbox_workspace_write={writable_roots=[],network_access=false,exclude_tmpdir_env_var=true,exclude_slash_tmp=true}"
    };
    size_t n=m->auto_approval?ARRAY_LEN(config):1;
    if (*count+2*n+1>cap) return errorf(e,"Danh sách đối số CLI quá dài.");
    const char *probe[2*ARRAY_LEN(config)+2]={"app-server"}; size_t pc=1;
    for (size_t i=0;i<n;++i) {
        const char *value=m->auto_approval?config[i]:"approvals_reviewer=\"user\"";
        args[(*count)++]="-c"; args[(*count)++]=value;
        probe[pc++]="-c"; probe[pc++]=value;
    }
    if (!m->auto_approval) return 1;
    probe[pc]=NULL; RPC rpc={0}; Buf init={0},params={0},data={0};
    if (!process_start(&rpc.process,exe,probe,l->workspace.p,l->home.p,1,0,e)) return 0;
    buffer_char(&params,'{'); json_pair(&params,"cwd",l->workspace.p); buffer_char(&params,'}');
    JSON j={0};
    int ok=rpc_message(&rpc,1,"initialize",codex_client_info,&init,2500,e) && codex_send(&rpc.process,-1,"initialized",NULL) &&
        rpc_message(&rpc,2,"config/read",params.s,&data,3000,e) && json_parse(&j,data.s,data.n);
    if (ok) {
        int c=json_get(&j,0,"config"),sw=json_get(&j,c,"sandbox_workspace_write"),roots=json_get(&j,sw,"writable_roots");
        int net=json_get(&j,sw,"network_access"); char reviewer[40],mode[32];
        ok=json_field(&j,c,"approvals_reviewer",reviewer,sizeof(reviewer)) && !strcmp(reviewer,"auto_review") &&
           json_field(&j,c,"sandbox_mode",mode,sizeof(mode)) && !strcmp(mode,"workspace-write") &&
           review_granular_ok(&j,json_get(&j,json_get(&j,c,"approval_policy"),"granular")) &&
           roots>=0 && j.t[roots].type=='[' && !j.t[roots].count && net>=0 && j.t[net].type=='f' &&
           json_bool(&j,json_get(&j,sw,"exclude_tmpdir_env_var")) && json_bool(&j,json_get(&j,sw,"exclude_slash_tmp"));
    }
    json_free(&j); buffer_free(&init); buffer_free(&params); buffer_free(&data); buffer_free(&rpc.pending);
    process_stop(&rpc.process); process_dispose(&rpc.process); l->terminal_auto=ok;
    return ok || errorf(e,"CLI chưa xác nhận cấu hình Auto Approval giới hạn trong workspace cho Terminal.");
}
int codex_list_saved(const char *exe, const char *home, Buf *out, Error *e) {
    RPC rpc={0};
    const char *args[]={"app-server",NULL};
    if (!process_start(&rpc.process,exe,args,home,home,1,0,e)) return 0;
    Buf init={0};
    int ok=rpc_message(&rpc,1,"initialize",codex_client_info,&init,2500,e) &&
        codex_send(&rpc.process,-1,"initialized",NULL);
    buffer_free(&init);
    char cursor[1400]="";
    int rows=0;
    buffer_char(out,'[');
    for (int page=0;ok && page<3;++page) {
        Buf p={0}, result={0};
        buffer_text(&p,"{\"limit\":100,\"sortKey\":\"updated_at\",\"modelProviders\":[],"
                       "\"useStateDbOnly\":true,\"currentAccountOnly\":false,\"sourceKinds\":[\"cli\"]");
        if (*cursor) { KEY(&p,"cursor",cursor); }
        buffer_char(&p,'}');
        ok=rpc_message(&rpc,page+2,"thread/list",p.s,&result,2600,e);
        JSON j;
        if (ok) ok=json_parse(&j,result.s,result.n);
        if (ok) {
            int array=json_get(&j,0,"data");
            ok=array>=0 && j.t[array].type=='[';
            if (ok) for (int i=array+1;i<j.t[array].after;i=j.t[i].after) {
                char id[37];
                Path cwd;
                if (!json_field(&j,i,"id",id,sizeof(id)) || !uuid_valid(id)) continue;
                json_field(&j,i,"cwd",cwd.p,sizeof(cwd.p));
                if (secret_text(cwd.p)) cwd.p[0]=0;
                if (rows++) buffer_char(out,',');
                buffer_char(out,'{'); json_pair(out,"id",id); KEY(out,"cwd",cwd.p);
                NULLNUM(out,"created",json_int(&j,json_get(&j,i,"createdAt"),-1));
                NULLNUM(out,"updated",json_int(&j,json_get(&j,i,"updatedAt"),-1));
                buffer_char(out,'}');
            }
            json_field(&j,0,"nextCursor",cursor,sizeof(cursor));
            json_free(&j);
        }
        buffer_free(&p); buffer_free(&result);
        if (!*cursor) break;
    }
    buffer_char(out,']');
    process_close_input(&rpc.process);
    int status=0, waiting=1;
    uint64_t until=monotonic_ms()+350;
    do {
        waiting=process_poll(&rpc.process,&status);
        if (!waiting) break;
        sleep_ms(10);
    } while (monotonic_ms()<until);
    if (waiting) process_stop(&rpc.process);
    process_dispose(&rpc.process);
    buffer_free(&rpc.pending);
    return ok || rows>0;
}

static long long valid_number(long long v, long long max) { return v >= 0 && v <= max ? v : -1; }

static int codex_query(const char *exe,const char *home,int use_file,const char *method,const char *params,Buf *result,Error *e) {
    RPC rpc={0}; Buf init={0};
    const char *args[]={"app-server",use_file?"-c":NULL,isolation,NULL};
    if (!process_start(&rpc.process,exe,args,home,home,1,0,e)) return 0;
    int ok=rpc_message(&rpc,1,"initialize",codex_client_info,&init,5000,e) &&
        codex_send(&rpc.process,-1,"initialized",NULL) && rpc_message(&rpc,2,method,params,result,7000,e);
    process_close_input(&rpc.process);
    process_dispose(&rpc.process);
    buffer_free(&init); buffer_free(&rpc.pending);
    return ok;
}

static void export_chat_item(Buf *out,const JSON *j,int item,int *count) {
    char type[40];
    if (!json_field(j,item,"type",type,sizeof(type))) return;
    char *text=allocate(32769); Buf content={0};
    const char *role=NULL;
    if (!strcmp(type,"agentMessage") && json_field(j,item,"text",text,32769)) {
        role="assistant"; buffer_text(&content,text);
    } else if (!strcmp(type,"userMessage")) {
        role="user";
        int list=json_get(j,item,"content");
        if (list>=0 && j->t[list].type=='[') for (int i=list+1;i<j->t[list].after;i=j->t[i].after) {
            char kind[40];
            if (json_field(j,i,"type",kind,sizeof(kind)) && !strcmp(kind,"text") &&
                json_field(j,i,"text",text,32769) && content.n+strlen(text)<65536) {
                if (content.n) buffer_char(&content,'\n');
                buffer_text(&content,text);
            }
        }
    }
    if (role && content.n) {
        if ((*count)++) buffer_char(out,',');
        buffer_char(out,'{'); json_pair(out,"role",role);
        KEY(out,"text",secret_text(content.s)?"[Nội dung có dấu hiệu chứa dữ liệu xác thực]":content.s);
        buffer_char(out,'}');
    }
    buffer_free(&content); free(text);
}

int codex_read_turns(const char *exe,const char *home,int use_file,const char *thread,Buf *out,Error *e) {
    Buf params={0}, result={0};
    buffer_char(&params,'{'); json_pair(&params,"threadId",thread);
    NUM(&params,"limit",12); KEY(&params,"itemsView","full"); buffer_char(&params,'}');
    int ok=codex_query(exe,home,use_file,"thread/turns/list",params.s,&result,e);
    JSON j;
    if (ok) ok=json_parse(&j,result.s,result.n);
    if (ok) {
        int list=json_get(&j,0,"data");
        ok=list>=0 && j.t[list].type=='[';
        if (ok) {
            int turns[12], n=0, count=0;
            for (int i=list+1;i<j.t[list].after && n<12;i=j.t[i].after) turns[n++]=i;
            buffer_text(out,"{\"messages\":[");
            while (n && out->n<512*1024) {
                int items=json_get(&j,turns[--n],"items");
                if (items<0 || j.t[items].type!='[') continue;
                for (int i=items+1;i<j.t[items].after && count<100 && out->n<512*1024;i=j.t[i].after)
                    export_chat_item(out,&j,i,&count);
            }
            buffer_text(out,"]}");
        }
        json_free(&j);
    }
    buffer_free(&params); buffer_free(&result);
    return ok || errorf(e,"Codex chưa đọc được lịch sử luồng. Kiểm tra ID, CODEX_HOME và phiên bản CLI.");
}

int codex_models(Manager *m,const JSON *in,Buf *out,Error *e) {
    char profile[33]; ARG(in,"profile",profile);
    Path *p=allocate(2*sizeof(*p)); Document d;
    int ok=current_profile(m,profile,&d,&p[0],&p[1],e);
    Buf result={0};
    if (ok) {
        ok=codex_query(p[0].p,p[1].p,use_file_credentials(&d,p[1].p),"model/list","{\"limit\":60}",&result,e);
        doc_free(&d);
    }
    JSON j;
    if (ok) ok=json_parse(&j,result.s,result.n);
    if (ok) {
        int models=json_get(&j,0,"data"), count=0;
        ok=models>=0 && j.t[models].type=='[';
        if (ok) {
            buffer_text(out,"{\"models\":[");
            for (int i=models+1;i<j.t[models].after && count<60;i=j.t[i].after) {
                char name[128],label[160];
                if (json_bool(&j,json_get(&j,i,"hidden")) || !json_field(&j,i,"model",name,sizeof(name)) || secret_text(name)) continue;
                json_field(&j,i,"displayName",label,sizeof(label));
                if (count++) buffer_char(out,',');
                buffer_char(out,'{'); json_pair(out,"id",name); KEY(out,"name",secret_text(label)||!*label?name:label);
                buffer_text(out,",\"efforts\":[");
                int efforts=json_get(&j,i,"supportedReasoningEfforts"), values=0;
                if (efforts>=0 && j.t[efforts].type=='[') for (int k=efforts+1;k<j.t[efforts].after && values<20;k=j.t[k].after) {
                    char value[24];
                    if (!json_field(&j,k,"reasoningEffort",value,sizeof(value)) || secret_text(value)) continue;
                    if (values++) buffer_char(out,',');
                    json_quote(out,value);
                }
                buffer_text(out,"]}");
            }
            buffer_text(out,"]}");
        }
        json_free(&j);
    }
    buffer_free(&result); free(p);
    return ok || errorf(e,"Không lấy được danh mục model từ Codex CLI.");
}
static int amount_string(const char *input) {
    int dots = 0, digits = 0;
    if (strlen(input) > 24) return 0;
    for (const char *p = input; *p; ++p) {
        if (*p >= '0' && *p <= '9') ++digits;
        else if (*p == '.' && !dots++) {}
        else return 0;
    }
    return digits > 0 && input[strlen(input)-1] != '.' && input[0] != '.';
}
static int rate_values(Buf *out, const JSON *j, int object) {
    int top = json_get(j,object,"rateLimits"), buckets = json_get(j,object,"rateLimitsByLimitId");
    int codex = json_get(j,buckets,"codex");
    char id[80];
    if (codex < 0 && (!json_field(j,top,"limitId",id,sizeof(id)) || !strcmp(id,"codex"))) codex = top;
    long long h = -1, w = -1, hr = -1, wr = -1;
    const char *windows[] = {"primary","secondary"};
    for (size_t i = 0; i < ARRAY_LEN(windows); ++i) {
        int t = json_get(j,codex,windows[i]);
        long long duration = json_int(j,json_get(j,t,"windowDurationMins"),-1);
        long long used = json_int(j,json_get(j,t,"usedPercent"),-1);
        long long reset = valid_number(json_int(j,json_get(j,t,"resetsAt"),-1),253402300799LL);
        if (used < 0 || used > 100) continue;
        long long rem = used >= 100 ? 0 : 100 - used;
        if (duration == 300) { h = rem; hr = reset; }
        if (duration == 10080) { w = rem; wr = reset; }
    }
    NULLNUM(out,"h",h); NULLNUM(out,"w",w); NULLNUM(out,"hr",hr); NULLNUM(out,"wr",wr);
    int credits = json_get(j,codex,"credits");
    if (credits < 0 && codex != top && json_field(j,top,"limitId",id,sizeof(id)) && !strcmp(id,"codex"))
        credits = json_get(j,top,"credits");
    char balance[32];
    int has = json_field(j,credits,"balance",balance,sizeof(balance)) && amount_string(balance);
    int unlimited=json_bool(j,json_get(j,credits,"unlimited"));
    RAW(out,"creditsUnlimited",unlimited ? "true" : "false");
    if (has) { KEY(out,"credits",balance); } else { RAW(out,"credits","null"); }
    int resets = json_get(j,object,"rateLimitResetCredits");
    long long count = valid_number(json_int(j,json_get(j,resets,"availableCount"),-1),1000000);
    NULLNUM(out,"earnedResets",count);
    char reached[80];
    if (json_field(j,codex,"rateLimitReachedType",reached,sizeof(reached)) && !secret_text(reached)) KEY(out,"reached",reached);
    return h>=0 || w>=0 || has || unlimited || count>=0;
}
static int save_sample(Manager *m, const char *profile, Buf *sample, Error *e) {
    char id[33]; new_id(id);
    if (!put_doc(m,"samples",id,sample,e)) return 0;
    return put_doc(m,"quota",profile,sample,e);
}
void codex_rejected(Manager *m,const char *profile) {
    Buf auth={0}; Error ignored={0};
    buffer_char(&auth,'{'); json_pair(&auth,"profile",profile); KEY(&auth,"status","Rejected");
    NUM(&auth,"at",timestamp()); buffer_char(&auth,'}');
    put_doc(m,"auth",profile,&auth,&ignored); buffer_free(&auth);
    quota_observed(m,profile,NULL,0);
}
int codex_record_auth(Manager *m,const char *profile,const JSON *j,int result) {
    int account=json_get(j,result,"account");
    char type[32],email[320]="",plan[128]="";
    int signed_in=json_field(j,account,"type",type,sizeof(type)) && *type;
    int signed_out=account>=0 && j->t[account].type=='n' && json_bool(j,json_get(j,result,"requiresOpenaiAuth"));
    if (!signed_in && !signed_out) return 0;
    if (signed_in) {
        json_field(j,account,"email",email,sizeof(email));
        json_field(j,account,"planType",plan,sizeof(plan));
        if (!strchr(email,'@') || secret_text(email)) email[0]=0;
        if (secret_text(plan)) plan[0]=0;
    }
    Error ignored={0}; Buf auth={0};
    buffer_char(&auth,'{'); json_pair(&auth,"profile",profile); KEY(&auth,"status",signed_in?"Signed in":"Signed out");
    KEY(&auth,"email",email); KEY(&auth,"plan",plan); NUM(&auth,"at",timestamp()); buffer_char(&auth,'}');
    put_doc(m,"auth",profile,&auth,&ignored);
    buffer_free(&auth);
    return signed_out ? -1 : !strcmp(type,"chatgpt") ? 1 : 0;
}
int codex_record_live_quota(Manager *m,const char *profile,const JSON *j,int object) {
    Buf record={0}; Error ignored={0};
    buffer_char(&record,'{'); json_pair(&record,"profile",profile); KEY(&record,"source","official");
    KEY(&record,"status","Signed in"); NUM(&record,"at",timestamp());
    Document auth;
    if (get_doc(m,"auth",profile,&auth,&ignored)) {
        char email[320]; FIELD(&auth,"email",email); KEY(&record,"email",email); doc_free(&auth);
    }
    int valid=rate_values(&record,j,object);
    buffer_char(&record,'}');
    int ok=valid && put_doc(m,"quota",profile,&record,&ignored);
    JSON saved;
    if (ok && json_parse(&saved,record.s,record.n)) {
        quota_observed(m,profile,&saved,0); json_free(&saved);
    }
    buffer_free(&record);
    return ok;
}
int codex_account(Manager *m, const JSON *in, Buf *out, Error *e) {
    char profile[33]; ARG(in,"profile",profile);
    Document d;
    Path *paths = allocate(2*sizeof(*paths));
    int ok = current_profile(m,profile,&d,&paths[0],&paths[1],e);
    if (!ok) { free(paths); return 0; }
    RPC rpc = {0};
    int use_file=use_file_credentials(&d,paths[1].p);
    const char *argv[] = {"app-server",use_file?"-c":NULL,isolation,NULL};
    Buf initialize = {0}, account = {0}, quota = {0};
    int uses_rpc = process_start(&rpc.process,paths[0].p,argv,paths[1].p,paths[1].p,1,0,e) &&
        rpc_message(&rpc,1,"initialize",codex_client_info,&initialize,3500,e) &&
        rpc_message(&rpc,-1,"initialized",NULL,NULL,0,e) &&
        rpc_message(&rpc,2,"account/read","{\"refreshToken\":false}",&account,4000,e);
    char email[320] = "", plan[128] = "", type[32] = "";
    const char *status = "Unknown";
    if (uses_rpc) {
        JSON parsed;
        if (json_parse(&parsed,account.s,account.n)) {
            int a = json_get(&parsed,0,"account");
            if (json_field(&parsed,a,"type",type,sizeof(type))) {
                status = "Signed in";
                json_field(&parsed,a,"planType",plan,sizeof(plan));
                json_field(&parsed,a,"email",email,sizeof(email));
                if (!strchr(email,'@') || secret_text(email)) email[0] = 0;
                if (secret_text(plan)) plan[0] = 0;
            } else if (a >= 0 && parsed.t[a].type == 'n')
                status = json_bool(&parsed,json_get(&parsed,0,"requiresOpenaiAuth")) ? "Signed out" : "Unknown";
            json_free(&parsed);
        }
        if (!strcmp(type,"chatgpt")) rpc_message(&rpc,3,"account/rateLimits/read",NULL,&quota,11500,e);
    }
    if (rpc.process.handle) { process_close_input(&rpc.process); process_stop(&rpc.process); process_dispose(&rpc.process); }
    if (!uses_rpc) {
        const char *args[] = {"login","status",use_file?"-c":NULL,isolation,NULL};
        Buf result = {0};
        int rc = -1;
        Error ignored = {0};
        if (run_capture(paths[0].p,args,paths[1].p,paths[1].p,&result,128*1024,5000,&rc,&ignored)) {
            if (rc == 0) status = "Signed in";
            else if (strstr(result.s,"Not logged in")) status = "Signed out";
        }
        buffer_free(&result);
    }
    buffer_char(out,'{'); json_pair(out,"profile",profile);
    char identity[33]; new_id(identity);
    KEY(out,"sample",identity); KEY(out,"source",quota.n || uses_rpc ? "official" : "cli");
    KEY(out,"status",status); KEY(out,"email",email); KEY(out,"plan",plan);
    NUM(out,"at",timestamp());
    const char *note=quota.n ? "" : !strcmp(status,"Signed out") ? "Hồ sơ chưa đăng nhập. Hoàn tất đăng nhập Codex để xem hạn mức." :
        !strcmp(status,"Unknown") ? "CLI chưa xác minh được đăng nhập hoặc hạn mức. Kiểm tra đường dẫn và CODEX_HOME." :
        "Đã xác minh đăng nhập. CLI chưa cung cấp hạn mức cho hồ sơ này.";
    RAW(out,"ratesRead",quota.n?"true":"false");
    RAW(out,"rateError",!strcmp(type,"chatgpt") && !quota.n?"true":"false");
    KEY(out,"note",note);
    JSON rates;
    if (quota.n && json_parse(&rates,quota.s,quota.n)) { rate_values(out,&rates,0); json_free(&rates); }
    buffer_char(out,'}');
    e->msg[0] = 0;
    doc_free(&d); free(paths);
    buffer_free(&rpc.pending); buffer_free(&initialize); buffer_free(&account); buffer_free(&quota);
    return 1;
}

int codex_commit_account(Manager *m,const char *profile,const JSON *result,Buf *sample,long long started,Error *e) {
    char status[24],email[320],plan[128];
    ARG(result,"status",status); ARG(result,"email",email); ARG(result,"plan",plan);
    int credit=json_get(result,0,"credits");
    int has_limits=NUMBER(result,"h",-1)>=0 || NUMBER(result,"w",-1)>=0 || NUMBER(result,"earnedResets",-1)>=0 ||
        YES(result,"creditsUnlimited") || (credit>=0 && result->t[credit].type=='"');
    int keep=0, changed_limits=has_limits;
    Document previous; Error ignored={0};
    if (get_doc(m,"quota",profile,&previous,&ignored)) {
        char source[32],prior_email[320],prior_status[24];
        FIELD(&previous,"source",source); FIELD(&previous,"email",prior_email); FIELD(&previous,"status",prior_status);
        int same_owner=!*email || !*prior_email || !strcmp(email,prior_email);
        int old_limits=NUMBER(&previous.data,"h",-1)>=0 || NUMBER(&previous.data,"w",-1)>=0 ||
            NUMBER(&previous.data,"earnedResets",-1)>=0 || YES(&previous.data,"creditsUnlimited");
        int previous_credit=json_get(&previous.data,0,"credits");
        old_limits |= previous_credit>=0 && previous.data.t[previous_credit].type=='"';
        keep=NUMBER(&previous.data,"at",-1)>started || (!has_limits &&
            (!strcmp(source,"manual") || !strcmp(source,"estimate") ||
             (old_limits && same_owner && strcmp(status,"Signed out") && !strcmp(source,"official"))));
        if (has_limits && same_owner && !strcmp(source,"official") && !strcmp(status,prior_status)) {
            changed_limits=0;
            const char *fields[]={"h","w","hr","wr","credits","creditsUnlimited","earnedResets","reached"};
            for (size_t i=0;i<ARRAY_LEN(fields);++i) {
                Buf before={0},after={0};
                json_raw(&before,&previous.data,json_get(&previous.data,0,fields[i]));
                json_raw(&after,result,json_get(result,0,fields[i]));
                if (before.n!=after.n || (before.n && memcmp(before.s,after.s,before.n))) changed_limits=1;
                buffer_free(&before); buffer_free(&after);
            }
        }
        doc_free(&previous);
    }
    int ok=1;
    Document prior_auth;
    int rejected=0;
    if (get_doc(m,"auth",profile,&prior_auth,&ignored)) {
        char prior[24]; FIELD(&prior_auth,"status",prior); rejected=!strcmp(prior,"Rejected"); doc_free(&prior_auth);
    }
    if (*status && strcmp(status,"Unknown") && !(rejected && !has_limits && !strcmp(status,"Signed in"))) {
        Buf auth={0};
        buffer_char(&auth,'{'); json_pair(&auth,"profile",profile); KEY(&auth,"status",status);
        KEY(&auth,"email",email); KEY(&auth,"plan",plan); NUM(&auth,"at",timestamp()); buffer_char(&auth,'}');
        ok=put_doc(m,"auth",profile,&auth,e);
        buffer_free(&auth);
    }
    if (ok && !keep) ok=changed_limits ? save_sample(m,profile,sample,e) : put_doc(m,"quota",profile,sample,e);
    if (ok) quota_observed(m,profile,has_limits && !keep ? result : NULL,
        YES(result,"rateError") || !strcmp(status,"Unknown"));
    return ok;
}
int codex_version(Manager *m, const JSON *in, Buf *out, Error *e) {
    char id[33]; ARG(in,"profile",id);
    Document d = {0};
    if (*id && !get_doc(m,"profiles",id,&d,e)) return 0;
    Path *path = allocate(sizeof(*path)), *home = allocate(sizeof(*home));
    if (d.raw.s) FIELD(&d,"home",home->p);
    int ok = find_codex(m,d.raw.s ? &d : NULL,path);
    if (!ok) errorf(e,"Chưa tìm thấy Codex CLI. Chọn codex.exe trong Cài đặt.");
    Buf result = {0};
    int rc = -1;
    const char *argv[] = {"--version",NULL};
    if (ok) ok = run_capture(path->p,argv,m->data.p,*home->p ? home->p : m->data.p,&result,16384,5000,&rc,e) && !rc;
    if (ok && result.n && (!strncmp(result.s,"codex-cli ",10) || !strncmp(result.s,"codex ",6))) {
        result.s[strcspn(result.s,"\r\n")] = 0;
        if (secret_text(result.s)) ok = 0;
    } else ok = 0;
    if (ok) { buffer_char(out,'{'); json_pair(out,"version",result.s); buffer_char(out,'}'); }
    else if (!e->msg[0]) errorf(e,"Lệnh --version không trả về phiên bản Codex hợp lệ.");
    free(path); free(home); doc_free(&d); buffer_free(&result);
    return ok;
}
int refresh_manual(Manager *m, const JSON *in, Buf *out, Error *e) {
    char id[33], amount[32], unit[32], pool[128], source[20];
    ARG(in,"profile",id);
    Document profile;
    if (!get_doc(m,"profiles",id,&profile,e)) return 0;
    doc_free(&profile);
    if (!safe_field(amount,sizeof(amount),in,"credits") || (*amount && !amount_string(amount)) ||
        !safe_field(unit,sizeof(unit),in,"creditUnit") || !safe_field(pool,sizeof(pool),in,"creditPool") ||
        !safe_field(source,sizeof(source),in,"source") ||
        (strcmp(source,"manual") && strcmp(source,"estimate")))
        return errorf(e,"Dữ liệu hạn mức thủ công không hợp lệ.");
    const char *keys[] = {"h","w","hr","wr"};
    long long values[4];
    for (size_t i = 0; i < ARRAY_LEN(keys); ++i) {
        int tok = json_get(in,0,keys[i]);
        values[i] = json_int(in,tok,-1);
        if (tok >= 0 && in->t[tok].type != 'n' &&
            valid_number(values[i],i < 2 ? 100 : 253402300799LL) < 0)
            return errorf(e,"Phần trăm phải nằm trong 0–100 và thời điểm reset phải hợp lệ.");
    }
    buffer_char(out,'{'); json_pair(out,"profile",id);
    char sample[33]; new_id(sample);
    KEY(out,"sample",sample); KEY(out,"source",source); NUM(out,"at",timestamp());
    for (size_t i = 0; i < ARRAY_LEN(keys); ++i) { NULLNUM(out,keys[i],values[i]); }
    if (*amount) { KEY(out,"credits",amount); } else { RAW(out,"credits","null"); }
    KEY(out,"creditUnit",unit); KEY(out,"creditPool",pool);
    buffer_char(out,'}');
    return save_sample(m,id,out,e);
}

int write_session(Manager *m, Live *l, int code, long long end, Error *e) {
    Buf record = {0};
    buffer_char(&record,'{'); json_pair(&record,"id",l->id);
    KEY(&record,"profile",l->profile); KEY(&record,"project",l->project);
    KEY(&record,"workspace",l->workspace.p); KEY(&record,"kind",l->kind);
    KEY(&record,"status",l->status); NUM(&record,"started",l->started);
    if (l->process.pid) { NUM(&record,"pid",l->process.pid); } else { RAW(&record,"pid","null"); }
    if (end) { NUM(&record,"ended",end); NUM(&record,"exitCode",code); }
    else { RAW(&record,"ended","null"); RAW(&record,"exitCode","null"); }
    if (l->resumed_thread[0]) { KEY(&record,"resumedThread",l->resumed_thread); }
    if (l->chat) chat_emit_session(&record,l);
    else if (!strcmp(l->kind,"codex") || !strcmp(l->kind,"imported")) { KEY(&record,"reviewer",l->terminal_auto?"auto_review":"user"); }
    if (l->autonomous && end && l->check_log.n) {
        const char *log=l->check_log.s;
        while (((unsigned char)*log & 0xc0)==0x80) ++log;
        if (text_utf8(log,l->check_log.n-(size_t)(log-l->check_log.s)) && !secret_text(log)) { KEY(&record,"output",log); }
    }
    buffer_char(&record,'}');
    int ok = put_doc(m,"sessions",l->id,&record,e);
    buffer_free(&record);
    return ok;
}
static void drain_check(Live *l) {
    if (!l->autonomous || l->chat || !l->process.captured) return;
    char chunk[4096]; Buf *b=&l->check_log;
    for (int i=0;i<32;++i) {
        int n=process_read(&l->process,chunk,sizeof(chunk));
        if (n<=0) break;
        l->runner_activity=monotonic_ms();
        if (l->check_sensitive) continue;
        char window[64+sizeof(chunk)+1]; size_t tail=b->n<64?b->n:64;
        if (tail) memcpy(window,b->s+b->n-tail,tail);
        memcpy(window+tail,chunk,(size_t)n); window[tail+(size_t)n]=0;
        if (memchr(chunk,0,(size_t)n) || secret_text(window)) {
            l->check_sensitive=1; buffer_free(b); continue;
        }
        if (b->n+(size_t)n>8192) {
            size_t drop=b->n+(size_t)n-8192;
            memmove(b->s,b->s+drop,b->n-drop); b->n-=drop;
        }
        buffer_add(b,chunk,(size_t)n);
    }
}
void tick_sessions(Manager *m) {
    for (Live **link = &m->live; *link;) {
        Live *l = *link;
        if (l->chat) chat_tick(m,l); else drain_check(l);
        int code = 0, result = process_poll(&l->process,&code);
        Error ignored = {0};
        if (!result) {
            drain_check(l);
            int reopen=chat_reconnectable(l) && safe_idle_recovery(m,l);
            if (l->chat) chat_ended(m,l,code);
            strcpy(l->status,l->stopping ? "Stopped" : code ? "Failed" : "Completed");
            if (write_session(m,l,code,timestamp(),&ignored)) {
                if (!strcmp(l->kind,"login") || l->chat) quota_due(m,l->profile,1);
                *link = l->next;
                process_dispose(&l->process);
                if (reopen) {
                    Buf out={0};
                    if (start_session(m,l->profile,l->project,chat_thread_id(l),NULL,"chat",&out,&ignored))
                        m->live->reconnected=1;
                    buffer_free(&out);
                }
                buffer_free(&l->check_log); chat_free(l->chat); free(l);
                if (reopen) return;
                continue;
            }
        } else if (result < 0 && strcmp(l->status,"Unknown")) {
            strcpy(l->status,"Unknown");
            write_session(m,l,0,0,&ignored);
        }
        link = &l->next;
    }
}
int uuid_valid(const char *id) {
    if (strlen(id) != 36) return 0;
    for (int i = 0; i < 36; ++i) {
        if (i == 8 || i == 13 || i == 18 || i == 23) {
            if (id[i] != '-') return 0;
        } else if (!strchr("0123456789abcdefABCDEF",id[i])) return 0;
    }
    return 1;
}
int start_session(Manager *m, const char *profile, const char *project, const char *resume,
                  const char *handover, const char *kind, Buf *out, Error *e) {
    Document d, p = {0};
    Path *paths = allocate(2 * sizeof(*paths)), *exe = &paths[0], *resolved = &paths[1];
    Live *l = allocate(sizeof(*l));
    int ok = 0;
    if (!current_profile(m,profile,&d,exe,&l->home,e)) goto done;
    if (*project) {
        if (!get_doc(m,"projects",project,&p,e) || !FIELD(&p,"path",l->workspace.p) ||
            !open_directory(l->workspace.p,resolved) || !within(l->workspace.p,resolved->p) || !within(resolved->p,l->workspace.p)) {
            errorf(e,"Workspace không còn tồn tại hoặc đã đổi đường dẫn."); goto free_docs;
        }
        if (workspace_busy(m,l->workspace.p)) { errorf(e,"Workspace đang được khóa bởi một phiên khác."); goto free_docs; }
    }
    int is_chat = !strcmp(kind,"chat");
    if (!is_chat && resume && *resume && !uuid_valid(resume)) {
        errorf(e,"Nhập UUID phiên Codex thuộc hồ sơ đã chọn."); goto free_docs;
    }
    for (Live *existing = m->live; existing; existing = existing->next) {
        if (!strcmp(existing->profile,profile) && (!strcmp(existing->kind,"login") || !strcmp(kind,"login"))) {
            errorf(e,"Đóng các tiến trình của hồ sơ trước khi đăng nhập hoặc khởi chạy phiên."); goto free_docs;
        }
    }
    char model[128], effort[24], effort_config[96];
    FIELD(&d,"model",model); FIELD(&d,"effort",effort);
    const char *args[32];
    size_t count = 0;
    const char *program = exe->p;
    int use_file=use_file_credentials(&d,l->home.p);
    if (!strcmp(kind,"terminal")) {
        program = terminal_program();
#ifdef SAM_WINDOWS
        args[count++] = "-NoLogo"; args[count++] = "-NoProfile"; args[count++] = "-NoExit";
#else
        args[count++] = "--noprofile"; args[count++] = "--norc";
#endif
    } else if (is_chat) {
        args[count++] = "app-server";
        if (use_file) { args[count++] = "-c"; args[count++] = isolation; }
        if (*effort) {
            sam_format(effort_config,sizeof(effort_config),"model_reasoning_effort=\"%s\"",effort);
            args[count++] = "-c"; args[count++] = effort_config;
        }
    } else {
        if (!strcmp(kind,"login")) args[count++] = "login";
        else if (resume && *resume) args[count++] = "resume";
        if (use_file) { args[count++] = "-c"; args[count++] = isolation; }
        if (strcmp(kind,"login")) {
            if (!codex_terminal_review(m,l,exe->p,args,ARRAY_LEN(args),&count,e)) goto free_docs;
            if (*model) { args[count++] = "--model"; args[count++] = model; }
            if (*effort) {
                sam_format(effort_config,sizeof(effort_config),"model_reasoning_effort=\"%s\"",effort);
                args[count++] = "-c"; args[count++] = effort_config;
            }
            if ((resume && *resume) || (handover && *handover)) args[count++] = "--";
            if (resume && *resume) args[count++] = resume;
            if (handover && *handover) args[count++] = handover;
        }
    }
    args[count] = NULL;
    if (*project && strcmp(kind,"terminal") &&
        !guarded_resume(m,exe->p,l->home.p,resume?resume:"",l->workspace.p,e)) goto free_docs;
    if (!is_chat && resume && *resume) strcpy(l->resumed_thread,resume);
    strcpy(l->profile,profile); strcpy(l->project,project); strcpy(l->kind,kind);
    l->autonomous=m->runner_internal; l->read_only_turn=m->runner_readonly;
    Live *started=l;
    if (is_chat || !strcmp(kind,"login")) quota_yield_worker(profile);
    ok=launch_managed(m,&l,program,args,is_chat,out,e);
    if (ok && is_chat) chat_begin(m,started,resume,handover,model);
free_docs:
    doc_free(&d); doc_free(&p);
done:
    free(paths); free(l);
    return ok;
}
int launch_managed(Manager *m, Live **owner, const char *exe, const char *const *args, int capture,
                   Buf *out, Error *e) {
    Live *l=*owner;
    new_id(l->id); strcpy(l->status,"Ready"); l->started=timestamp();
    if (!write_session(m,l,0,0,e)) return 0;
    if (!process_start(&l->process,exe,args,*l->workspace.p ? l->workspace.p:l->home.p,l->home.p,capture,!capture,e)) {
        strcpy(l->status,"Failed");
        Error ignored={0}; write_session(m,l,125,timestamp(),&ignored);
        return 0;
    }
    strcpy(l->status,"Running");
    int ok=write_session(m,l,0,0,e);
    if (!ok) { process_stop(&l->process); strcpy(l->status,"Stopping"); l->stopping=1; }
    l->next=m->live; m->live=l; *owner=NULL;
    if (ok) {
        buffer_char(out,'{'); json_pair(out,"id",l->id); NUM(out,"pid",l->process.pid);
        if (!strcmp(l->kind,"chat")) { KEY(out,"project",l->project); }
        buffer_char(out,'}');
    }
    return ok;
}
static int start_check(Manager *m, const JSON *in, Buf *out, Error *e) {
    char project[33], kind[20];
    ARG(in,"project",project); ARG(in,"kind",kind);
    if ((strcmp(kind,"build") && strcmp(kind,"test")) || !YES(in,"confirmed"))
        return errorf(e,"Chọn build hoặc test và xác nhận chạy chương trình.");
    Document d;
    if (!get_doc(m,"projects",project,&d,e)) return 0;
    Path *p=allocate(3*sizeof(*p)), *configured=&p[0], *resolved=&p[1], *actual=&p[2];
    Live *l=allocate(sizeof(*l));
    char *arguments=allocate(8193);
    int ok=0;
    if (!FIELD(&d,"path",l->workspace.p) || !open_directory(l->workspace.p,actual) ||
        !within(l->workspace.p,actual->p) || !within(actual->p,l->workspace.p) || workspace_busy(m,l->workspace.p)) {
        errorf(e,"Workspace đang dùng hoặc đã đổi đường dẫn."); goto done;
    }
    if (!safe_field(configured->p,sizeof(configured->p),in,"exe") || !*configured->p ||
        !locate_exec(configured->p,"",resolved) || !safe_field(arguments,8193,in,"args")) {
        errorf(e,"Chọn đường dẫn tuyệt đối đến tệp thực thi và nhập mỗi đối số trên một dòng."); goto done;
    }
    const char *argv[25]={0};
    size_t n=0;
    for (char *a=arguments; *a;) {
        if (n+1>=ARRAY_LEN(argv)) { errorf(e,"Tối đa 24 đối số."); goto done; }
        size_t length=strcspn(a,"\r\n");
        char *next=a+length;
        int length_sep=*next ? 1 : 0;
        if (next[0]=='\r' && next[1]=='\n') length_sep=2;
        *next=0;
        if (length) argv[n++]=a;
        if (!length_sep) break;
        a=next+length_sep;
    }
    new_id(l->id); strcpy(l->project,project); strcpy(l->kind,kind); strcpy(l->status,"Ready"); l->started=timestamp();
    if (!write_session(m,l,0,0,e)) goto done;
    l->autonomous=m->runner_internal;
    if (!process_start(&l->process,resolved->p,argv,l->workspace.p,m->data.p,l->autonomous?2:0,!l->autonomous,e)) {
        Error ignored={0}; strcpy(l->status,"Failed"); write_session(m,l,125,timestamp(),&ignored); goto done;
    }
    if (l->autonomous) process_close_input(&l->process);
    strcpy(l->status,"Running");
    ok=write_session(m,l,0,0,e);
    if (!ok) { l->stopping=1; strcpy(l->status,"Stopping"); process_stop(&l->process); }
    l->next=m->live; m->live=l;
    if (ok) { buffer_char(out,'{'); json_pair(out,"id",l->id); NUM(out,"pid",l->process.pid); buffer_char(out,'}'); }
    l=NULL;
done:
    free(arguments); free(l); free(p); doc_free(&d); return ok;
}
int session_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e) {
    char id[33], profile[33], project[33], resume[64];
    ARG(in,"id",id); ARG(in,"profile",profile); ARG(in,"project",project); ARG(in,"resume",resume);
    if (!strcmp(action,"session-stop")) {
        if (!YES(in,"confirmed")) return errorf(e,"Cần xác nhận dừng cưỡng bức phiên.");
        for (Live *l = m->live; l; l=l->next) if (!strcmp(l->id,id)) {
            if (!process_stop(&l->process)) return errorf(e,"Không gửi được yêu cầu dừng. Hãy đóng terminal.");
            l->stopping=1; strcpy(l->status,"Stopping");
            if (!write_session(m,l,0,0,e)) return 0;
            buffer_text(out,"{}"); return 1;
        }
        return errorf(e,"Phiên đã đóng hoặc không do Manager quản lý.");
    }
    if (!strcmp(action,"session-check")) return start_check(m,in,out,e);
    if (!strcmp(action,"session-login")) return start_session(m,profile,"",NULL,NULL,"login",out,e);
    if (!strcmp(action,"session-terminal")) return start_session(m,profile,project,NULL,NULL,"terminal",out,e);
    if (!strcmp(action,"session-start") && *project) return start_session(m,profile,project,resume,NULL,"codex",out,e);
    return errorf(e,"Chọn hồ sơ và dự án hợp lệ.");
}
