#include "manager.h"

/* Durable user-mediated ChatGPT rounds. No web automation or AI credentials. */
#define GOAL_CAP 4097
#define NOTE_CAP 4097
#define HISTORY_LIMIT (4*MIB)
static int safe_text(const JSON *j,const char *key,char *s,size_t cap) {
    return json_field(j,0,key,s,cap) && text_utf8(s,strlen(s)) && !secret_text(s);
}
static int same_path(const char *a,const char *b) { return within(a,b)&&within(b,a); }
int continuous_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    char id[33], mode[24]="idle", goal[GOAL_CAP]={0}, task[NOTE_CAP]={0}, note[NOTE_CAP], next[NOTE_CAP], testid[33], owner[33], kind[24], status[24];
    Path *p=allocate(4*sizeof(*p)); Document project={0}, saved={0}, test={0}; Buf history={0}, record={0}; Info info={0};
    long long rev=0, rounds=0, flags=63, role=0, started=0, now=timestamp(), code=-1, testtime=0; int ok=0, exists=0;
    if (!ARG(in,"project",id)||!valid_id(id)||!get_doc(m,"projects",id,&project,e)||!FIELD(&project,"path",p[0].p)||!open_directory(p[0].p,&p[1])||!same_path(p[0].p,p[1].p)||!directory_allowed(m,p[1].p,1)) { errorf(e,"Dự án hoặc workspace không hợp lệ."); goto done; }
    if (!docs_path(m,"continuous",id,&p[2])) goto done;
    if (file_info(p[2].p,&info)) {
        exists=1;
        if (info.kind!=1 || !get_doc(m,"continuous",id,&saved,e) || !FIELD(&saved,"project",owner)||strcmp(owner,id)||!FIELD(&saved,"root",p[3].p)||!same_path(p[1].p,p[3].p)||!FIELD(&saved,"mode",mode)||!FIELD(&saved,"goal",goal)||!FIELD(&saved,"task",task)) { errorf(e,"Bộ nhớ bị lỗi hoặc workspace đã đổi; không ghi đè."); goto done; }
        rev=NUMBER(&saved.data,"revision",-1); rounds=NUMBER(&saved.data,"rounds",-1); flags=NUMBER(&saved.data,"flags",-1); started=NUMBER(&saved.data,"roundStarted",-1); role=NUMBER(&saved.data,"role",0);
        int h=json_get(&saved.data,0,"history");
        if (rev<1||rounds<0||flags<1||flags>63||role<0||role>7||started<0||h<0||saved.data.t[h].type!='['||saved.data.t[h].count!=rounds|| (strcmp(mode,"waiting_user")&&strcmp(mode,"paused")&&strcmp(mode,"stopped"))) { errorf(e,"Bộ nhớ không hợp lệ; không ghi đè."); goto done; }
        json_raw(&history,&saved.data,h);
    } else buffer_text(&history,"[]");
    if (!strcmp(action,"continuous-get")&&exists) { buffer_add(out,saved.raw.s,saved.raw.n); ok=1; goto done; }
    if (strcmp(action,"continuous-get")) {
        if (NUMBER(in,"revision",-1)!=rev) { errorf(e,"Revision đã đổi. Làm mới trước khi tiếp tục."); goto done; }
        if (!strcmp(action,"continuous-start")) {
            if (exists||!safe_text(in,"goal",goal,sizeof(goal))||!*goal||!safe_text(in,"task",task,sizeof(task))||!*task) { errorf(e,"Cần mục tiêu và nhiệm vụ đầu tiên; không tạo đè phiên đã có."); goto done; }
            role=NUMBER(in,"role",0); if(role<0||role>7){errorf(e,"Vai trò AI không hợp lệ.");goto done;}
            flags=NUMBER(in,"flags",-1); if (flags<1||flags>63) { errorf(e,"Chọn ít nhất một chế độ."); goto done; }
            if (workspace_busy(m,p[1].p)) { errorf(e,"Workspace đang bận. Dừng phiên ghi trước khi bắt đầu."); goto done; }
            strcpy(mode,"waiting_user"); started=now;
        } else if (!exists) { errorf(e,"Chưa có phiên phát triển."); goto done; }
        else if (!strcmp(action,"continuous-role")) {
            role=NUMBER(in,"role",-1); if(role<0||role>7){errorf(e,"Vai trò AI không hợp lệ.");goto done;}
        }
        else if (!strcmp(action,"continuous-pause")&&!strcmp(mode,"waiting_user")) strcpy(mode,"paused");
        else if (!strcmp(action,"continuous-stop")&&strcmp(mode,"stopped")) strcpy(mode,"stopped");
        else if (!strcmp(action,"continuous-resume")&&strcmp(mode,"waiting_user")) {
            if (workspace_busy(m,p[1].p)) { errorf(e,"Workspace đang bận."); goto done; } strcpy(mode,"waiting_user");
        } else if (!strcmp(action,"continuous-record")&&!strcmp(mode,"waiting_user")) {
            if (workspace_busy(m,p[1].p)) { errorf(e,"Đợi phiên ghi hoặc kiểm thử kết thúc."); goto done; }
            if (!safe_text(in,"note",note,sizeof(note))||!*note||!safe_text(in,"next",next,sizeof(next))||!*next||!safe_text(in,"testSession",testid,sizeof(testid))) { errorf(e,"Cần kết quả, bài học và nhiệm vụ tiếp theo; không lưu bí mật."); goto done; }
            if (*testid) {
                if (!valid_id(testid)||!get_doc(m,"sessions",testid,&test,e)||!FIELD(&test,"project",owner)||strcmp(owner,id)||!FIELD(&test,"workspace",p[3].p)||!same_path(p[1].p,p[3].p)||!FIELD(&test,"kind",kind)||strcmp(kind,"test")||!FIELD(&test,"status",status)||(strcmp(status,"Completed")&&strcmp(status,"Failed"))||NUMBER(&test.data,"started",-1)<started||(testtime=NUMBER(&test.data,"ended",-1))<started||(code=NUMBER(&test.data,"exitCode",-1))<0) { errorf(e,"Phiên test không hợp lệ, chưa kết thúc hoặc thuộc vòng cũ."); goto done; }
                int h=json_get(&saved.data,0,"history");
                for(int i=h+1;i<saved.data.t[h].after;i=saved.data.t[i].after) { char old[33]; if(json_field(&saved.data,i,"testSession",old,sizeof(old))&&!strcmp(old,testid)){errorf(e,"Phiên test đã dùng trong vòng trước.");goto done;} }
            }
            if (history.n>=HISTORY_LIMIT) { errorf(e,"Bộ nhớ đạt giới hạn 4 MiB. Xuất bộ nhớ; không xóa dữ liệu tự động."); goto done; }
            history.s[--history.n]=0; if(rounds)buffer_char(&history,',');
            buffer_char(&history,'{'); json_key(&history,"round"); buffer_fmt(&history,"%lld",rounds+1);
            KEY(&history,"task",task); KEY(&history,"note",note); KEY(&history,"next",next); KEY(&history,"testSession",testid); NUM(&history,"exitCode",code); NUM(&history,"testEnded",testtime); NUM(&history,"at",now); NUM(&history,"role",role); buffer_text(&history,"}]");
            if (history.n>HISTORY_LIMIT) { errorf(e,"Bộ nhớ đạt giới hạn 4 MiB. Xuất bộ nhớ; không xóa dữ liệu tự động."); goto done; }
            strcpy(task,next); ++rounds; started=now;
        } else { errorf(e,"Thao tác không phù hợp trạng thái hiện tại."); goto done; }
        ++rev;
    }
    buffer_char(&record,'{'); json_pair(&record,"project",id); KEY(&record,"root",p[1].p); KEY(&record,"mode",mode); KEY(&record,"goal",goal); KEY(&record,"task",task); NUM(&record,"revision",rev); NUM(&record,"rounds",rounds); NUM(&record,"flags",flags); NUM(&record,"role",role); NUM(&record,"roundStarted",started); RAW(&record,"history",history.s); buffer_char(&record,'}');
    if (strcmp(action,"continuous-get")&&!put_doc(m,"continuous",id,&record,e)) goto done;
    buffer_add(out,record.s,record.n); ok=1;
done:
    free(p); doc_free(&project); doc_free(&saved); doc_free(&test); buffer_free(&history); buffer_free(&record); return ok;
}
