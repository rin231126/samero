#include "manager.h"

static const char *tables[] = {"profiles", "projects", "sessions", "auth", "quota", "samples", "checkpoints", "settings", "chatlogs", "imports", "external", "threadprefs", "drafts", "chatreceipts","runs","reviews","runheads","runrecovery","bridge","continuous"};
int docs_path(Manager *m, const char *table, const char *id, Path *path) {
    Path *dir = allocate(sizeof(*dir));
    char basename[38];
    int ok = valid_id(id) && path_join(dir, m->data.p, table) &&
        sam_format(basename, sizeof(basename), "%s.json", id) == 37 && path_join(path, dir->p, basename);
    free(dir);
    return ok;
}
int get_doc(Manager *m, const char *table, const char *id, Document *doc, Error *e) {
    Path *path = allocate(sizeof(*path));
    *doc = (Document){0};
    int ok = docs_path(m, table, id, path) && read_file(path->p, 8*MIB, &doc->raw, e) &&
        json_parse(&doc->data, doc->raw.s, doc->raw.n) && doc->data.t[0].type == '{';
    free(path);
    if (ok) return 1;
    doc_free(doc);
    return errorf(e, "Không tìm thấy mục hoặc dữ liệu đã lưu bị lỗi.");
}
int put_doc(Manager *m, const char *table, const char *id, Buf *buf, Error *e) {
    Path *path = allocate(sizeof(*path));
    int ok = docs_path(m, table, id, path) && buf->n <= 8*MIB && write_atomic(path->p, buf->s, buf->n, e);
    free(path);
    if (!ok && !e->msg[0]) errorf(e, "Không lưu được mục.");
    return ok;
}
void doc_free(Document *doc) { json_free(&doc->data); buffer_free(&doc->raw); }
typedef struct { Manager *m; const char *table; DocVisitor fn; void *ctx; } Collection;
static int visit_doc(const char *name, const Info *info, void *context, Error *e) {
    Collection *c = context;
    if (info->kind != 1 || strlen(name) != 37 || strcmp(name + 32, ".json")) return 1;
    char id[33]; memcpy(id, name, 32); id[32] = 0;
    if (!valid_id(id)) return 1;
    Document doc;
    if (!get_doc(c->m, c->table, id, &doc, e)) return 0;
    int ok = c->fn(id, &doc, c->ctx, e);
    doc_free(&doc);
    return ok;
}
/* Metadata writers create short-lived .tmp/.saving entries. Filter those
   before stat/readdir processing; a disappearing temporary is not a corrupt
   committed document. Snapshot walks remain strict and unfiltered. */
static int committed_doc_name(const char *name) {
    if (strlen(name)!=37 || strcmp(name+32,".json")) return 0;
    char id[33]; memcpy(id,name,32); id[32]=0; return valid_id(id);
}
int each_doc(Manager *m, const char *table, DocVisitor visit, void *ctx, Error *e) {
    Path *path = allocate(sizeof(*path));
    Collection c = {m, table, visit, ctx};
    int ok = path_join(path, m->data.p, table) && list_dir_filtered(path->p, committed_doc_name, visit_doc, &c, e);
    free(path);
    return ok;
}
int open_directory(const char *input, Path *out) {
    Info info;
    return *input && canonical(input, out) && file_info(out->p, &info) && info.kind == 2;
}
static int overlaps(const char *a, const char *b) { return within(a,b) || within(b,a); }
int directory_allowed(Manager *m, const char *path, int project) {
    if (overlaps(m->data.p, path) || overlaps(m->backup.p, path)) return 0;
    if (project && (within(path, m->home.p) || credential_path(path))) return 0;
    return 1;
}
int workspace_busy(Manager *m, const char *path) {
    if (runner_reserved(m,path)) return 1;
    for (Live *l = m->live; l; l = l->next)
        if (l->workspace.p[0] && overlaps(l->workspace.p, path)) return 1;
    return external_workspace_busy(m,path);
}
int safe_field(char *out, size_t cap, const JSON *j, const char *key) {
    int t = json_get(j, 0, key);
    if (t < 0 || j->t[t].type == 'n') { out[0] = 0; return 1; }
    return json_string(j, t, out, cap) && !secret_text(out);
}
int find_codex(Manager *m, Document *profile, Path *out) {
    Path *override=allocate(sizeof(*override));
    if (profile) FIELD(profile,"cli",override->p);
    int ok=locate_codex_cli(override->p[0] ? override->p : m->codex.p,out);
    free(override);
    return ok;
}
int find_git(Manager *m, Path *out) {
#ifdef SAM_WINDOWS
    return locate_exec(m->git.p, "git.exe", out);
#else
    return locate_exec(m->git.p, "git", out);
#endif
}
static const char settings_id[] = "00000000000000000000000000000000";
static void load_settings(Manager *m, Document *d) {
    m->auto_approval=YES(&d->data,"autoApproval");
    Path *path = allocate(sizeof(*path));
    if (FIELD(d, "backup", path->p) && *path->p) m->backup = *path;
    if (FIELD(d, "projects", path->p) && *path->p) m->projects = *path;
    FIELD(d, "codex", m->codex.p); FIELD(d, "git", m->git.p);
    if (!FIELD(d, "theme", m->theme) || strcmp(m->theme, "light")) strcpy(m->theme, "dark");
    if (!FIELD(d, "caches", m->caches)) strcpy(m->caches, "node_modules,.cache,__pycache__,.venv");
    free(path);
}
static int open_manager(Manager *m, const char *root, int read_only, Error *e) {
    Path *path = allocate(sizeof(*path));
    int ok = user_root(&m->home, 0) && open_directory(m->home.p,path);
    if (ok) m->home = *path;
    ok = ok &&
        (root ? sam_format(m->data.p, sizeof(m->data.p), "%s", root) < PATH_CAP :
           user_root(path, 1) && path_join(&m->data, path->p, "SAMERO Codex Manager")) &&
        (read_only || mkdir_tree(m->data.p)) && open_directory(m->data.p, path);
    if (ok) m->data = *path;
    if (!ok) { free(path); return errorf(e, "Không tạo được thư mục dữ liệu người dùng."); }
    if (!read_only && !acquire_instance(m->data.p)) { free(path); return -1; }
    ok = path_join(&m->backup, m->data.p, "Backups") && path_join(&m->projects, m->home.p, "Documents");
    strcpy(m->theme, "dark");
    strcpy(m->caches, "node_modules,.cache,__pycache__,.venv");
    for (size_t i = 0; !read_only && i < ARRAY_LEN(tables) && ok; ++i)
        ok = path_join(path, m->data.p, tables[i]) && mkdir_tree(path->p);
    Info info;
    if (ok && docs_path(m, "settings", settings_id, path) && file_info(path->p, &info)) {
        Document d;
        ok = get_doc(m, "settings", settings_id, &d, e);
        if (ok) { load_settings(m, &d); doc_free(&d); }
    }
    free(path);
    return ok ? 1 : errorf(e, "Không mở được cấu hình hoặc thư mục dữ liệu.");
}

int manager_init(Manager *m,const char *root,Error *e) { return open_manager(m,root,0,e); }
int manager_readonly(Manager *m,const char *root,Error *e) { return open_manager(m,root,1,e); }

typedef struct { Buf *out; int comma; Manager *m; const char *table; } TableOutput;
static int emit_doc(const char *id, Document *d, void *context, Error *e) {
    TableOutput *ctx = context;
    Buf *b = ctx->out;
    if (ctx->comma++) buffer_char(b, ',');
    if (!strcmp(ctx->table,"external")) {
        buffer_text(b,"{\"record\":"); buffer_add(b,d->raw.s,d->raw.n);
        RAW(b,"closed",external_terminal_done(ctx->m,id)?"true":"false"); buffer_char(b,'}');
        return 1;
    }
    if (!strcmp(ctx->table, "sessions")) {
        char thread[160], digest[65], profile[33], key[33];
        int legacy=0, active=0;
        if (!FIELD(d,"chatKey",key) && FIELD(d,"chatThread",thread) && *thread &&
            FIELD(d,"chatHome",digest) && strlen(digest)==64 && FIELD(d,"profile",profile)) {
            chat_session_key(profile,digest,thread,key);
            legacy=1;
        }
        for (Live *l = ctx->m->live; l; l = l->next) {
            if (!strcmp(l->id,id)) { active=1; break; }
        }
        char state[24];
        int stale=!active && FIELD(d,"status",state) &&
            (!strcmp(state,"Running") || !strcmp(state,"Ready") || !strcmp(state,"Stopping"));
        if (stale || legacy) {
            buffer_char(b, '{');
            if (stale) json_pair(b,"status","Unknown");
            else json_pair(b,"chatKey",key);
            if (stale && legacy) { KEY(b,"chatKey",key); }
            JSON *j = &d->data;
            for (int i = 1; i < j->t[0].after; i = j->t[i+1].after) {
                char key[64];
                if (!json_string(j,i,key,sizeof(key)) || (stale && (!strcmp(key,"status") || !strcmp(key,"pid")))) continue;
                buffer_char(b,','); json_key(b,key); json_raw(b,j,i+1);
            }
            buffer_char(b,'}');
            return 1;
        }
    }
    buffer_add(b, d->raw.s, d->raw.n);
    (void)e;
    return 1;
}
static int emit_table(Manager *m, const char *table, Buf *out, Error *e) {
    json_key(out, table);
    buffer_char(out, '[');
    TableOutput ctx = {out, 0, m, table};
    if (!each_doc(m, table, emit_doc, &ctx, e)) return 0;
    buffer_char(out, ']');
    return 1;
}
static int state(Manager *m, Buf *out, Error *e) {
    Path *cli = allocate(sizeof(*cli));
    buffer_text(out, "{\"settings\":{");
    json_pair(out, "backup", m->backup.p);
    KEY(out,"projects",m->projects.p); KEY(out,"codex",m->codex.p); KEY(out,"git",m->git.p);
    KEY(out,"data",m->data.p); KEY(out,"theme",m->theme); KEY(out,"caches",m->caches);
    KEY(out,"detectedCodex",find_codex(m,NULL,cli) ? cli->p : "");
    KEY(out,"terminalHome",(native_codex_home(cli) || path_join(cli,m->home.p,".codex")) ? cli->p : "");
    RAW(out,"windowsTerminal",windows_terminal_available()?"true":"false");
    RAW(out,"autoApproval",m->auto_approval?"true":"false");
    KEY(out,"version",SAM_VERSION);
    KEY(out,"detectedGit",find_git(m,cli) ? cli->p : "");
    buffer_char(out, '}');
    free(cli);
    const char *publish[] = {"profiles","projects","sessions","auth","quota","samples","checkpoints","imports","external","threadprefs","runs"};
    for (size_t i = 0; i < ARRAY_LEN(publish); ++i) {
        buffer_char(out, ',');
        if (m->runner_fault && !strcmp(publish[i],"runs")) buffer_text(out,"\"runs\":[]");
        else if (!emit_table(m, publish[i], out, e)) return 0;
    }
    RAW(out,"runnerFault",m->runner_fault?"true":"false");
    quota_emit(m,out);
    buffer_char(out, '}');
    return 1;
}

typedef struct { const char *path, *except, *field; int conflict; } Collision;
static int check_overlap(const char *id, Document *d, void *context, Error *e) {
    Collision *c = context;
    Path *p = allocate(sizeof(*p));
    if ((!c->except || strcmp(c->except,id)) && json_field(&d->data,0,c->field,p->p,sizeof(p->p)) &&
        overlaps(c->path,p->p)) c->conflict = 1;
    free(p);
    (void)e;
    return 1;
}
static int has_collision(Manager *m, const char *table, const char *field, const char *path,
                         const char *except, Error *e) {
    Collision c = {path,except,field,0};
    return !each_doc(m,table,check_overlap,&c,e) || c.conflict;
}
static int profile_busy(Manager *m, const char *id) {
    for (Live *l = m->live; l; l = l->next) if (!strcmp(l->profile,id)) return 1;
    return 0;
}
static int simple_model(const char *s) {
    if (*s == '-') return 0;
    for (; *s; ++s) if (!strchr("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.:/", *s)) return 0;
    return 1;
}
static int valid_effort(const char *s) {
    const char *allowed[] = {"","none","minimal","low","medium","high","xhigh","max","ultra"};
    for (size_t i = 0; i < ARRAY_LEN(allowed); ++i) if (!strcmp(s,allowed[i])) return 1;
    return 0;
}
static int profile_edit(Manager *m, const JSON *in, Buf *out, Error *e) {
    char id[33], name[256], model[128], effort[24], auth_store[12], old_store[12]="";
    Path *p = allocate(4*sizeof(*p)), *home=&p[0], *canonical_home=&p[1], *cli=&p[2], *oldhome=&p[3];
    ARG(in,"id",id);
    int ok = 0, edited = *id != 0;
    if (edited) {
        Document old;
        if (!get_doc(m,"profiles",id,&old,e)) goto done;
        FIELD(&old,"home",oldhome->p);
        FIELD(&old,"authStore",old_store);
        doc_free(&old);
        if (profile_busy(m,id)) { errorf(e,"Đóng phiên và terminal của hồ sơ trước khi chỉnh sửa."); goto done; }
    } else new_id(id);
    if (!safe_field(name,sizeof(name),in,"name") || !*name ||
        !safe_field(model,sizeof(model),in,"model") || !simple_model(model) ||
        !safe_field(effort,sizeof(effort),in,"effort") || !valid_effort(effort) ||
        !safe_field(home->p,sizeof(home->p),in,"home") ||
        !safe_field(cli->p,sizeof(cli->p),in,"cli") ||
        !safe_field(auth_store,sizeof(auth_store),in,"authStore") ||
        (*auth_store && strcmp(auth_store,"file") && strcmp(auth_store,"config"))) {
        errorf(e,"Kiểm tra tên, đường dẫn, model và reasoning effort."); goto done;
    }
    if (!home->p[0]) {
        if (YES(in,"existing")) { errorf(e,"Chọn thư mục CODEX_HOME đang có."); goto done; }
        if (edited) *home = *oldhome;
        else {
            char folder[80];
            sam_format(folder,sizeof(folder),".codex-samero-%.12s",id);
            if (!path_join(home,m->home.p,folder)) { errorf(e,"Đường dẫn CODEX_HOME quá dài."); goto done; }
        }
    }
    if (!directory_allowed(m,home->p,0) ||
        has_collision(m,"profiles","home",home->p,id,e) ||
        has_collision(m,"projects","path",home->p,NULL,e) ||
        (!open_directory(home->p,canonical_home) && (YES(in,"existing") || !mkdir_tree(home->p) || !open_directory(home->p,canonical_home))) ||
        !directory_allowed(m,canonical_home->p,0) || within(canonical_home->p,m->home.p) ||
        has_collision(m,"profiles","home",canonical_home->p,id,e) ||
        has_collision(m,"projects","path",canonical_home->p,NULL,e)) {
        errorf(e,"CODEX_HOME phải là thư mục riêng, tách khỏi dự án, hồ sơ khác và dữ liệu ứng dụng.");
        goto done;
    }
    if (*cli->p && !locate_codex_cli(cli->p,home)) { errorf(e,"Đường dẫn Codex CLI phải trỏ tới tệp thực thi."); goto done; }
    if (json_get(in,0,"authStore")<0) strcpy(auth_store, old_store);
    Buf doc = {0};
    buffer_char(&doc,'{'); json_pair(&doc,"id",id);
    KEY(&doc,"name",name); KEY(&doc,"home",canonical_home->p); KEY(&doc,"cli",*cli->p ? home->p : "");
    KEY(&doc,"model",model); KEY(&doc,"effort",effort); NUM(&doc,"updated",timestamp());
    KEY(&doc,"authStore",auth_store);
    buffer_char(&doc,'}');
    ok = put_doc(m,"profiles",id,&doc,e);
    buffer_free(&doc);
    if (ok) quota_register(m,id);
    if (ok && edited && (strcmp(oldhome->p,canonical_home->p) || strcmp(old_store,auth_store))) {
        if (docs_path(m,"quota",id,home)) remove_file(home->p);
        if (docs_path(m,"auth",id,home)) remove_file(home->p);
    }
    if (ok) { buffer_char(out,'{'); json_pair(out,"id",id); buffer_char(out,'}'); }
done:
    free(p);
    return ok;
}
static int delete_profile(Manager *m, const JSON *in, Buf *out, Error *e) {
    char id[33]; ARG(in,"id",id);
    if (!YES(in,"confirmed") || !valid_id(id)) return errorf(e,"Cần xác nhận gỡ hồ sơ khỏi danh sách.");
    if (profile_busy(m,id)) return errorf(e,"Hồ sơ vẫn có tiến trình.");
    Path *p = allocate(sizeof(*p));
    int ok = docs_path(m,"profiles",id,p) && remove_file(p->p);
    if (ok && docs_path(m,"quota",id,p)) remove_file(p->p);
    if (ok && docs_path(m,"auth",id,p)) remove_file(p->p);
    free(p);
    if (!ok) return errorf(e,"Không gỡ được hồ sơ.");
    quota_forget(m,id);
    buffer_text(out,"{}");
    return 1;
}

typedef struct { Manager *m; Buf *out; unsigned count; } ProfileScan;
static int scan_profile_home(const char *name,const Info *info,void *ctx,Error *e) {
    ProfileScan *scan=ctx;
    if (scan->count>=80 || info->kind!=2 || (strcmp(name,".codex") && strncmp(name,".codex-",7))) return 1;
    Path *p=allocate(2*sizeof(*p));
    if (path_join(&p[0],scan->m->home.p,name) && open_directory(p[0].p,&p[1]) &&
        directory_allowed(scan->m,p[1].p,0) && !secret_text(p[1].p)) {
        if (scan->count++) buffer_char(scan->out,',');
        buffer_char(scan->out,'{'); json_pair(scan->out,"name",name);
        KEY(scan->out,"home",p[1].p); buffer_char(scan->out,'}');
    }
    free(p); (void)e; return 1;
}
static int discover_profiles(Manager *m,Buf *out,Error *e) {
    ProfileScan scan={m,out,0};
    buffer_text(out,"{\"homes\":[");
    if (!list_dir(m->home.p,scan_profile_home,&scan,e)) return 0;
    buffer_text(out,"]}");
    return 1;
}
int validate_project_path(Manager *m, const char *path, const char *id, Error *e) {
    return directory_allowed(m,path,1) && !has_collision(m,"profiles","home",path,NULL,e) &&
        !has_collision(m,"projects","path",path,id,e);
}
static int edit_settings(Manager *m, const JSON *in, Buf *out, Error *e) {
    int setting=json_get(in,0,"autoApproval");
    if (setting>=0 && in->t[setting].type!='t' && in->t[setting].type!='f') return errorf(e,"Auto Approval phải là bật hoặc tắt.");
    int auto_approval=setting<0?m->auto_approval:json_bool(in,setting);
    Path *p = allocate(5*sizeof(*p)), *backup=&p[0], *projects=&p[1], *codex=&p[2], *git=&p[3], *resolved=&p[4];
    char theme[12], caches[1024];
    int ok = 0;
    if (!safe_field(backup->p,sizeof(backup->p),in,"backup") ||
        !safe_field(projects->p,sizeof(projects->p),in,"projects") ||
        !safe_field(codex->p,sizeof(codex->p),in,"codex") ||
        !safe_field(git->p,sizeof(git->p),in,"git") ||
        !safe_field(theme,sizeof(theme),in,"theme") || (strcmp(theme,"dark") && strcmp(theme,"light")) ||
        !safe_field(caches,sizeof(caches),in,"caches")) {
        errorf(e,"Cấu hình không hợp lệ."); goto done;
    }
    if (!backup->p[0]) path_join(backup,m->data.p,"Backups");
#ifdef SAM_WINDOWS
    for (char *c=backup->p; *c; ++c) if (*c=='\\') *c='/';
#endif
    if (overlaps(backup->p,m->home.p) && within(backup->p,m->home.p)) {
        errorf(e,"Chọn thư mục sao lưu riêng."); goto done;
    }
    if (has_collision(m,"profiles","home",backup->p,NULL,e) || has_collision(m,"projects","path",backup->p,NULL,e) ||
        !mkdir_tree(backup->p) || !open_directory(backup->p,resolved) || within(resolved->p,m->data.p) ||
        has_collision(m,"profiles","home",resolved->p,NULL,e) || has_collision(m,"projects","path",resolved->p,NULL,e)) {
        errorf(e,"Thư mục sao lưu xung đột với dự án, hồ sơ hoặc thư mục dữ liệu."); goto done;
    }
    *backup = *resolved;
    if (*projects->p && strcmp(projects->p,m->projects.p) && !open_directory(projects->p,resolved)) {
        errorf(e,"Thư mục mặc định cho dự án chưa tồn tại."); goto done;
    } else if (*projects->p && strcmp(projects->p,m->projects.p)) *projects = *resolved;
    else *projects = m->projects;
    if (*codex->p && !locate_codex_cli(codex->p,resolved)) { errorf(e,"Không tìm thấy Codex CLI đã chọn."); goto done; }
    if (*codex->p) *codex = *resolved;
    if (*git->p && !locate_exec(git->p,"",resolved)) { errorf(e,"Không tìm thấy Git đã chọn."); goto done; }
    if (*git->p) *git = *resolved;
    Buf record = {0};
    buffer_char(&record,'{'); json_pair(&record,"backup",backup->p);
    KEY(&record,"projects",projects->p); KEY(&record,"codex",codex->p); KEY(&record,"git",git->p);
    RAW(&record,"autoApproval",auto_approval?"true":"false"); KEY(&record,"theme",theme); KEY(&record,"caches",caches); buffer_char(&record,'}');
    ok = put_doc(m,"settings",settings_id,&record,e);
    buffer_free(&record);
    if (ok) {
        m->auto_approval=auto_approval; m->backup=*backup; m->projects=*projects; m->codex=*codex; m->git=*git;
        strcpy(m->theme,theme); strcpy(m->caches,caches);
        buffer_text(out,"{}");
    }
done:
    free(p);
    return ok;
}
int dispatch(Manager *m, const char *action, const JSON *in, Buf *out, Error *e) {
    if (!strcmp(action,"review-history")) return review_history(m,in,out,e);
    if (!strncmp(action,"runner-",7)) return runner_action(m,action,in,out,e);
    if (!strcmp(action,"state")) return state(m,out,e);
    if (!strcmp(action,"quota-focus")) {
        char id[33]; ARG(in,"profile",id);
        quota_due(m,id,0); buffer_text(out,"{}"); return 1;
    }
    if (!strcmp(action,"quota-state")) {
        buffer_char(out,'{');
        if (!emit_table(m,"quota",out,e)) return 0;
        buffer_char(out,',');
        if (!emit_table(m,"auth",out,e)) return 0;
        quota_emit(m,out);
        buffer_char(out,'}');
        return 1;
    }
    if (!strcmp(action,"profile-save")) return profile_edit(m,in,out,e);
    if (!strcmp(action,"profile-discover")) return discover_profiles(m,out,e);
    if (!strcmp(action,"profile-delete")) return delete_profile(m,in,out,e);
    if (!strcmp(action,"account-refresh")) return codex_account(m,in,out,e);
    if (!strcmp(action,"cli-check")) return codex_version(m,in,out,e);
    if (!strcmp(action,"codex-models")) return codex_models(m,in,out,e);
    if (!strcmp(action,"quota-manual")) return refresh_manual(m,in,out,e);
    if (!strncmp(action,"thread-",7)) return chat_thread_action(m,action,in,out,e);
    if (!strncmp(action,"chat-",5)) return chat_action(m,action,in,out,e);
    if (!strncmp(action,"saved-",6)) return saved_action(m,action,in,out,e);
    if (!strncmp(action,"session-",8)) return session_action(m,action,in,out,e);
    if (!strncmp(action,"continuous-",11)) return continuous_action(m,action,in,out,e);
    if (!strncmp(action,"bridge-",7)) return bridge_action(m,action,in,out,e);
    if (!strncmp(action,"project-",8)) return projects_action(m,action,in,out,e);
    if (!strncmp(action,"checkpoint-",11)) return checkpoint_action(m,action,in,out,e);
    if (!strcmp(action,"settings-save")) return edit_settings(m,in,out,e);
    if (!strcmp(action,"pick")) {
        Path *p = allocate(2*sizeof(*p)), *start=&p[1];
        ARG(in,"start",start->p);
        int ok=pick_path(!YES(in,"file"),start->p,p);
        if (ok>=0) { buffer_char(out,'{'); json_pair(out,"path",ok?p->p:""); buffer_char(out,'}'); }
        free(p);
        return ok>=0 || errorf(e,"Không mở được trình chọn Windows. Bạn có thể dán đường dẫn vào ô nhập.");
    }
    if (!strcmp(action,"exit")) {
        if (runner_checkpoint_busy(m)) return errorf(e,"Đợi checkpoint đang ghi hoàn tất trước khi thoát.");
        if (m->live) return errorf(e,"Đóng hoặc dừng các phiên đang chạy trước khi thoát.");
        m->quit = 1;
        buffer_text(out,"{}");
        return 1;
    }
    return errorf(e,"Thao tác không tồn tại.");
}
