#ifndef SAM_MANAGER
#define SAM_MANAGER
#include "archive.h"
#define SAM_VERSION "1.0.0-rc1"
#ifndef SAM_BUILD_ID
#define SAM_BUILD_ID "unidentified"
#endif
int public_update_check(Buf *out,Error *e);
int public_update_parse(const char *body,size_t size,long long current,Buf *out,Error *e);
typedef struct Chat Chat;
typedef struct QuotaWatch QuotaWatch;
typedef struct { Buf raw; JSON data; } Document;
typedef struct Live {
    Process process;
    char id[33], profile[33], project[33];
    Path workspace, home;
    char kind[20], status[24], resumed_thread[37];
    long long started;
    int stopping, reconnected, autonomous, read_only_turn, terminal_auto, check_sensitive;
    uint64_t runner_activity;
    Buf check_log;
    Chat *chat;
    struct Live *next;
} Live;
typedef struct {
    Path data, home, backup, projects, codex, git;
    char theme[12], caches[1024];
    Live *live;
    QuotaWatch *watches;
    long long quota_tick;
    struct Run *runs;
    uint64_t runner_tick;
    int auto_approval, runner_internal, runner_readonly, runner_fault, quit;
} Manager;
#define FIELD(doc, key, target) json_field(&(doc)->data, 0, key, target, sizeof(target))
#define ARG(j, key, target) json_field(j, 0, key, target, sizeof(target))
#define NUMBER(j, k, fallback) json_int(j, json_get(j, 0, k), fallback)
#define YES(j, k) json_bool(j, json_get(j, 0, k))
#define KEY(b, k, s) do { buffer_char(b, ','); json_pair(b, k, s); } while (0)
#define NUM(b, k, n) do { buffer_char(b, ','); json_key(b, k); buffer_fmt(b, "%lld", (long long)(n)); } while (0)
#define RAW(b, k, raw) do { buffer_char(b, ','); json_key(b, k); buffer_text(b, raw); } while (0)
#define NULLNUM(b, k, n) do { if ((n) < 0) { RAW(b, k, "null"); } else { NUM(b, k, n); } } while (0)

int docs_path(Manager *m, const char *table, const char *id, Path *path);
int get_doc(Manager *m, const char *table, const char *id, Document *doc, Error *e);
int put_doc(Manager *m, const char *table, const char *id, Buf *buf, Error *e);
void doc_free(Document *doc);
typedef int (*DocVisitor)(const char *, Document *, void *, Error *);
int each_doc(Manager *m, const char *table, DocVisitor visit, void *ctx, Error *e);
int open_directory(const char *input, Path *out);
int directory_allowed(Manager *m, const char *path, int project);
int workspace_busy(Manager *m, const char *path);
int external_workspace_busy(Manager *m, const char *path);
int external_terminal_done(Manager *m, const char *id);
int guarded_resume(Manager *m, const char *exe, const char *home, const char *thread, const char *workspace, Error *e);
int chat_rollout_matches(const char *path,const char *home,const char *id,const char *workspace);
int chat_find_rollout(const char *home,const char *id,const char *workspace);
int saved_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
int uuid_valid(const char *id);
int validate_project_path(Manager *m, const char *path, const char *id, Error *e);
int safe_field(char *output, size_t cap, const JSON *j, const char *key);
int find_codex(Manager *m, Document *profile, Path *out);
int find_git(Manager *m, Path *out);
void quota_dispose(Manager *m);
void quota_init(Manager *m);
void quota_register(Manager *m,const char *profile);
void quota_forget(Manager *m,const char *profile);
void quota_due(Manager *m,const char *profile,int urgent);
void quota_observed(Manager *m,const char *profile,const JSON *sample,int offline);
void quota_emit(Manager *m,Buf *out);
void quota_tick(Manager *m);
unsigned quota_revision(Manager *m,const char *profile);
int quota_background_worker(Manager *m,const char *profile);
int chat_quota_refresh(Manager *m,const char *profile);
int codex_account(Manager *m, const JSON *in, Buf *out, Error *e);
int codex_commit_account(Manager *m,const char *profile,const JSON *result,Buf *sample,long long started,Error *e);
int use_file_credentials(const Document *profile,const char *home);
void quota_yield_worker(const char *profile);
int safe_idle_recovery(Manager *m,const Live *l);
void codex_rejected(Manager *m,const char *profile);
int codex_record_auth(Manager *m,const char *profile,const JSON *j,int result);
int codex_record_live_quota(Manager *m,const char *profile,const JSON *j,int object);
int codex_version(Manager *m, const JSON *in, Buf *out, Error *e);
int refresh_manual(Manager *m, const JSON *in, Buf *out, Error *e);
int write_session(Manager *m, Live *l, int code, long long end, Error *e);
void tick_sessions(Manager *m);
void chat_begin(Manager *m, Live *live, const char *resume, const char *first, const char *model);
void chat_tick(Manager *m, Live *live);
int chat_reconnectable(const Live *l);
void chat_ended(Manager *m, Live *live, int code);
void chat_free(Chat *chat);
void chat_emit_session(Buf *record, const Live *live);
const char *chat_thread_id(const Live *live);
int chat_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
void chat_session_key(const char *profile,const char *home_hash,const char *thread,char key[33]);
int chat_thread_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e);
int chat_resume_saved(Manager *m,const char *profile,const char *project,const char *thread,Buf *out,Error *e);
extern const char codex_client_info[];
int codex_send(Process *process, int id, const char *method, const char *params);
int codex_list_saved(const char *exe, const char *home, Buf *out, Error *e);
int codex_read_turns(const char *exe,const char *home,int use_file,const char *thread,Buf *out,Error *e);
int codex_models(Manager *m,const JSON *in,Buf *out,Error *e);
int launch_managed(Manager *m, Live **live, const char *exe, const char *const *args, int capture, Buf *out, Error *e);
int start_session(Manager *m, const char *profile, const char *project, const char *resume,
                  const char *handover, const char *kind, Buf *out, Error *e);
int session_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
int continuous_action(Manager *,const char *,const JSON *,Buf *,Error *);
int bridge_action(Manager *,const char *,const JSON *,Buf *,Error *);
int projects_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
int checkpoint_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
long long quota_verified(Manager *,const char *);
int runner_checkpoint_busy(Manager *);
int runner_pending_work(Manager *);
int runner_checkpoint_worker(const char *,const char *,const char *,const char *);
const char *chat_runner_result(const Live *);
void chat_runner_close(Live *);
void runner_review_denied(Manager *,Live *,const char *);
void runner_record_command(Manager *,Live *,const char *,long long);
int chat_review_pending(const Live *,const char *);
int reviews_settled(Manager *,const Live *,const char *);
int review_history(Manager *,const JSON *,Buf *,Error *);
int review_record(Manager *,Live *,const char *,const char *,const char *,const char *,const char *,const char *,Error *);
int codex_terminal_review(Manager *,Live *,const char *,const char **,size_t,size_t *,Error *);
int review_granular_ok(const JSON *,int);
int review_policy_matches(const Live *,const JSON *,int);
extern const char review_policy[];
extern const char review_config[];
int runner_action(Manager *,const char *,const JSON *,Buf *,Error *);
int runner_reserved(Manager *,const char *);
int run_store_init(Manager *,Error *);
void run_store_hash(const Document *,char [65]);
int run_store_write(Manager *,const char *,const Buf *,char [65],Error *);
int run_store_checkpoint(Manager *,const char *,const char *,char [65],Error *);
int run_store_recover(Manager *,const char *,Document *,char [65],Error *);
int runner_init(Manager *,Error *);
void runner_tick(Manager *);
void runner_free(Manager *);
const char *chat_runner_progress(const Live *);
int manager_init(Manager *m, const char *root, Error *e);
int manager_readonly(Manager *m, const char *root, Error *e);
int dispatch(Manager *m, const char *action, const JSON *in, Buf *out, Error *e);
#endif
