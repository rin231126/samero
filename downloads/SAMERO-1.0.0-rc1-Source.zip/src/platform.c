#include "base.h"

#ifdef SAM_WINDOWS
typedef unsigned short W;
typedef uint32_t DW;
typedef void *H;
#define INVALID ((H)(intptr_t)-1)
typedef struct { DW lo, hi; } FT;
typedef struct {
    DW attributes; FT created, accessed, modified; DW size_hi, size_lo, reserved1, reserved2;
    W name[260], alternate[14];
} FindData;
typedef struct {
    DW attributes; FT created, accessed, modified;
    DW volume, size_hi, size_lo, links, index_hi, index_lo;
} HandleInfo;
typedef struct { DW len; void *descriptor; int inherit; } Security;
typedef struct {
    DW cb; W *reserved, *desktop, *title; DW x, y, sx, sy, xc, yc, fill, flags;
    W show, extra; void *extra_p; H in, out, err;
} Startup;
typedef struct { H process, thread; DW pid, tid; } ProcInfo;
typedef struct {
    DW size, usage, pid; uintptr_t heap; DW module, threads, parent;
    int priority; DW flags; W exe[260];
} ProcessEntry;
typedef struct {
    int64_t proc_time, job_time; DW flags; size_t min_ws, max_ws; DW active_limit;
    uintptr_t affinity; DW priority, scheduling;
    uint64_t io[6]; size_t proc_mem, job_mem, peak_proc, peak_job;
} JobLimits;
typedef struct { uint64_t times[4]; DW faults, total, active, terminated; } JobCount;
typedef struct { uint32_t a; uint16_t b,c; unsigned char d[8]; } Guid;
typedef struct { void **methods; } Com;
typedef struct { const W *name,*pattern; } Filter;
typedef struct { unsigned short length,max; W *text; } UnicodeString;
typedef struct { unsigned short family, port; uint32_t addr; char zero[8]; } Addr;
extern int MultiByteToWideChar(DW, DW, const char *, int, W *, int);
extern int WideCharToMultiByte(DW, DW, const W *, int, char *, int, void *, void *);
extern DW GetLastError(void);
extern DW GetEnvironmentVariableW(const W *, W *, DW);
extern DW GetFileAttributesW(const W *);
extern DW ExpandEnvironmentStringsW(const W *, W *, DW);
extern int32_t RegGetValueW(H, const W *, const W *, DW, DW *, void *, DW *);
extern H CreateToolhelp32Snapshot(DW, DW);
extern int Process32FirstW(H, ProcessEntry *);
extern int Process32NextW(H, ProcessEntry *);
extern H OpenProcess(DW, int, DW);
extern int QueryFullProcessImageNameW(H, DW, W *, DW *);
extern W *GetEnvironmentStringsW(void);
extern int FreeEnvironmentStringsW(W *);
extern H FindFirstFileW(const W *, FindData *);
extern int FindNextFileW(H, FindData *);
extern int FindClose(H);
extern H CreateFileW(const W *, DW, DW, Security *, DW, DW, H);
extern int GetFileInformationByHandle(H, HandleInfo *);
extern DW GetFinalPathNameByHandleW(H, W *, DW, DW);
extern int CloseHandle(H);
extern int CreateDirectoryW(const W *, void *);
extern int RemoveDirectoryW(const W *);
extern int DeleteFileW(const W *);
extern int MoveFileExW(const W *, const W *, DW);
extern int _fseeki64(FILE *, long long, int);
extern int _fileno(FILE *);
extern int _commit(int);
extern int _open_osfhandle(intptr_t, int);
extern FILE *_fdopen(int, const char *);
extern int _close(int);
extern int BCryptGenRandom(H, void *, DW, DW);
extern void Sleep(DW);
extern uint64_t GetTickCount64(void);
extern int CreatePipe(H *, H *, Security *, DW);
extern int SetHandleInformation(H, DW, DW);
extern H CreateJobObjectW(void *, const W *);
extern int SetInformationJobObject(H, int, void *, DW);
extern int QueryInformationJobObject(H, int, void *, DW, DW *);
extern int AssignProcessToJobObject(H, H);
extern int TerminateJobObject(H, unsigned int);
extern int CreateProcessW(const W *, W *, void *, void *, int, DW, void *, const W *, Startup *, ProcInfo *);
extern DW ResumeThread(H);
extern int TerminateProcess(H, unsigned int);
extern int GetExitCodeProcess(H, DW *);
extern DW WaitForSingleObject(H, DW);
extern int PeekNamedPipe(H, void *, DW, DW *, DW *, DW *);
extern int ReadFile(H, void *, DW, DW *, void *);
extern int WriteFile(H, const void *, DW, DW *, void *);
extern int MessageBoxW(H, const W *, const W *, unsigned int);
extern intptr_t ShellExecuteW(H, const W *, const W *, const W *, const W *, int);
extern unsigned short **CommandLineToArgvW(const W *,int *);
extern void *LocalFree(void *);
extern H GetModuleHandleW(const W *);
extern DW GetModuleFileNameW(H,W *,DW);
extern H GetStdHandle(DW);
extern void *GetProcAddress(H,const char *);
extern int32_t SHCreateItemFromParsingName(const W *,void *,const Guid *,Com **);
extern int32_t CoCreateInstance(const Guid *,void *,DW,const Guid *,Com **);
extern int32_t CoInitializeEx(void *, DW);
extern void CoUninitialize(void);
extern void CoTaskMemFree(void *);
extern int WSAStartup(unsigned short, void *);
extern int WSAGetLastError(void);
extern Socket socket(int, int, int);
extern int bind(Socket, const void *, int);
extern int listen(Socket, int);
extern int getsockname(Socket, void *, int *);
extern Socket accept(Socket, void *, void *);
extern int setsockopt(Socket, int, int, const void *, int);
extern int ioctlsocket(Socket, uint32_t, DW *);
extern int recv(Socket, void *, int, int);
extern int send(Socket, const void *, int, int);
extern int closesocket(Socket);

_Static_assert(sizeof(W) == sizeof(wchar_t), "Windows UTF-16 compiler flag required");
#define WC(s) ((const W *)L##s)
static W *wide(const char *text) {
    if (!text) return NULL;
    int n = MultiByteToWideChar(65001, 8, text, -1, NULL, 0);
    if (!n) return NULL;
    W *result = allocate((size_t)n * sizeof(*result));
    if (!MultiByteToWideChar(65001, 8, text, -1, result, n)) { free(result); return NULL; }
    return result;
}
static int utf8(const W *text, char *out, size_t cap) {
    return WideCharToMultiByte(65001, 128, text, -1, out, (int)cap, NULL, NULL) > 0;
}
static W *file_wide(const char *text) {
    W *path = wide(text);
    if (!path) return NULL;
    size_t len = 0;
    for (; path[len]; ++len) if (path[len] == '/') path[len] = '\\';
    int drive = len > 2 && path[1] == ':' && path[2] == '\\';
    int unc = len > 2 && path[0] == '\\' && path[1] == '\\' && path[2] != '?';
    if (len < 248 || (!drive && !unc)) return path;
    const W *prefix = drive ? WC("\\\\?\\") : WC("\\\\?\\UNC\\");
    size_t n = drive ? 4 : 8, skip = drive ? 0 : 2;
    W *extended = allocate((len + n + 1) * sizeof(W));
    memcpy(extended, prefix, n * sizeof(W));
    memcpy(extended + n, path + skip, (len - skip + 1) * sizeof(W));
    free(path);
    return extended;
}
static int env_get(const W *name, Path *out) {
    W *value = allocate(PATH_CAP * sizeof(W));
    DW n = GetEnvironmentVariableW(name, value, PATH_CAP);
    int ok = n && n < PATH_CAP && utf8(value, out->p, sizeof(out->p));
    free(value);
    return ok;
}
static void translate_info(Info *info, DW attributes, FT modified, DW hi, DW lo) {
    *info = (Info){.kind = (attributes & 0x400) ? 3 : (attributes & 16) ? 2 : 1,
        .mode = (attributes & 1) ? 0444 : 0644,
        .mtime = ((uint64_t)modified.hi << 32) | modified.lo, .size = ((uint64_t)hi << 32) | lo};
}
int file_info(const char *path, Info *info) {
    W *name = file_wide(path);
    if (!name) return 0;
    H h = CreateFileW(name, 0, 7, NULL, 3, 0x02200000, NULL);
    free(name);
    *info = (Info){0};
    if (h == INVALID) return 0;
    HandleInfo d;
    int ok = GetFileInformationByHandle(h, &d);
    CloseHandle(h);
    if (ok) {
        translate_info(info, d.attributes, d.modified, d.size_hi, d.size_lo);
        info->device = d.volume;
        info->links = d.links;
        info->inode = ((uint64_t)d.index_hi << 32) | d.index_lo;
    }
    return ok;
}
/* Local OS access probe: no content returned, no reparse traversal. */
const char *probe_read_regular(const char *path, unsigned *code) {
    *code=0;
    W *name=file_wide(path);
    if (!name) return "INVALID_PATH";
    H h=CreateFileW(name,0x80000000,7,NULL,3,0x00200000,NULL);
    DW err=h==INVALID?GetLastError():0;
    free(name);
    if (h==INVALID) { *code=err; return err==2 || err==3?"MISSING":err==5?"DENIED":err==32 || err==33?"BUSY":"OPEN_FAILED"; }
    HandleInfo st;
    const char *status="OK";
    unsigned char b; DW n=0;
    if (!GetFileInformationByHandle(h,&st)) { *code=GetLastError(); status="STAT_FAILED"; }
    else if (st.attributes & 0x410) status="UNSAFE_TYPE";
    else if (!ReadFile(h,&b,1,&n,NULL)) { *code=GetLastError(); status="READ_FAILED"; }
    CloseHandle(h);
    return status;
}
int list_dir_filtered(const char *dir, NameFilter filter, Visitor cb, void *ctx, Error *e) {
    Path *glob = allocate(sizeof(*glob));
    int joined = path_join(glob, dir, "*");
    W *name = joined ? file_wide(glob->p) : NULL;
    free(glob);
    if (!name) return errorf(e, "Đường dẫn thư mục không hợp lệ.");
    FindData d;
    H h = FindFirstFileW(name, &d);
    DW find_error = h == INVALID ? GetLastError() : 0;
    free(name);
    if (h == INVALID) {
        if (find_error == 2) return 1;
        return errorf(e, "Không đọc được thư mục: %s", dir);
    }
    int ok = 1;
    do {
        char entry[1040];
        if (!utf8(d.name, entry, sizeof(entry))) { ok = errorf(e, "Tên tệp không hợp lệ."); break; }
        if (!strcmp(entry, ".") || !strcmp(entry, "..") || (filter && !filter(entry))) continue;
        Info info;
        translate_info(&info, d.attributes, d.modified, d.size_hi, d.size_lo);
        if (!cb(entry, &info, ctx, e)) { ok = 0; break; }
    } while (FindNextFileW(h, &d));
    if (ok && GetLastError() != 18) ok = errorf(e, "Không đọc hết thư mục: %s", dir);
    FindClose(h);
    return ok;
}
int canonical(const char *path, Path *out) {
    W *name = file_wide(path);
    if (!name) return 0;
    H h = CreateFileW(name, 0, 7, NULL, 3, 0x02000000, NULL);
    free(name);
    if (h == INVALID) return 0;
    W *result = allocate(PATH_CAP * sizeof(W));
    DW len = GetFinalPathNameByHandleW(h, result, PATH_CAP, 0);
    CloseHandle(h);
    int ok = 0;
    if (len && len < PATH_CAP) {
        W *begin = result;
        if (len >= 8 && !memcmp(result, WC("\\\\?\\UNC\\"), 8 * sizeof(W))) {
            begin += 6;
            begin[0] = begin[1] = '\\';
        } else if (len >= 4 && !memcmp(result, WC("\\\\?\\"), 4 * sizeof(W))) begin += 4;
        for (W *p = begin; *p; ++p) if (*p == '\\') *p = '/';
        ok = utf8(begin, out->p, sizeof(out->p));
    }
    free(result);
    return ok;
}
int user_root(Path *out, int local) { return env_get(local ? WC("LOCALAPPDATA") : WC("USERPROFILE"), out); }
int mkdir_new(const char *path) { W *p = file_wide(path); int ok = p && CreateDirectoryW(p, NULL); free(p); return ok; }
int remove_file(const char *path) { W *p = file_wide(path); int ok = p && DeleteFileW(p); free(p); return ok; }
int remove_dir(const char *path) { W *p = file_wide(path); int ok = p && RemoveDirectoryW(p); free(p); return ok; }
void restore_mode(const char *path, unsigned mode) { (void)path; (void)mode; }
int move_file(const char *from, const char *to, int replace) {
    W *a = file_wide(from), *b = file_wide(to);
    int ok = a && b && MoveFileExW(a, b, (replace ? 1 : 0) | 8);
    free(a); free(b);
    return ok;
}
static FILE *open_windows_file(const char *path, int write, DW disposition) {
    W *name = file_wide(path);
    if (!name) return NULL;
    H h=CreateFileW(name,write ? 0x40000000 : 0x80000000,1,NULL,disposition,0x00200000,NULL);
    free(name);
    if (h==INVALID) return NULL;
    HandleInfo info;
    if (!GetFileInformationByHandle(h,&info) || (info.attributes & 0x410)) {
        CloseHandle(h); return NULL;
    }
    int fd=_open_osfhandle((intptr_t)h,0x8000 | (write ? 1 : 0));
    if (fd<0) { CloseHandle(h); return NULL; }
    FILE *f=_fdopen(fd,write ? "wb" : "rb");
    if (!f) _close(fd);
    return f;
}
FILE *file_open(const char *path, int write) { return open_windows_file(path,write,write ? 2 : 3); }
int move_queue_exclusive(const char *from,const char *to) { return move_file(from,to,0); }
FILE *file_open_append(const char *path) {
    W *name=file_wide(path);
    if (!name) return NULL;
    H h=CreateFileW(name,0x40000000,1,NULL,4,0x00200000,NULL);
    free(name);
    if (h==INVALID) return NULL;
    HandleInfo i;
    if (!GetFileInformationByHandle(h,&i) || (i.attributes & 0x410) || i.links!=1) { CloseHandle(h); return NULL; }
    int fd=_open_osfhandle((intptr_t)h,0x8009);
    if (fd<0) { CloseHandle(h); return NULL; }
    FILE *f=_fdopen(fd,"ab");
    if (!f) _close(fd);
    return f;
}
FILE *file_open_new(const char *path) { return open_windows_file(path,1,1); }
int file_seek(FILE *f, uint64_t pos) { return pos <= INT64_MAX && !_fseeki64(f, (long long)pos, SEEK_SET); }
int file_flush(FILE *f) { return !fflush(f) && !_commit(_fileno(f)); }
int system_random(void *out, size_t size) { return size <= UINT32_MAX && BCryptGenRandom(NULL, out, (DW)size, 2) == 0; }
int acquire_instance(const char *root) {
    Path *lock = allocate(sizeof(*lock));
    W *name = path_join(lock, root, "manager.lock") ? file_wide(lock->p) : NULL;
    free(lock);
    H h = name ? CreateFileW(name, 0xc0000000, 0, NULL, 4, 0x00200000, NULL) : INVALID;
    free(name);
    return h != INVALID;
}
int self_executable(Path *out) {
    W *path=allocate(PATH_CAP*sizeof(W));
    DW length=GetModuleFileNameW(NULL,path,PATH_CAP);
    int ok=length>0 && length<PATH_CAP && utf8(path,out->p,sizeof(out->p));
    free(path); return ok;
}
int worker_stdout(const char *data,size_t size) {
    H pipe=GetStdHandle((DW)-11);
    while (size) {
        DW written=0;
        DW chunk=size>65536?65536:(DW)size;
        if (!WriteFile(pipe,data,chunk,&written,NULL) || !written) return 0;
        data+=written; size-=written;
    }
    return 1;
}
int pick_path(int folder, const char *start, Path *out) {
    static const Guid cls={0xdc1c5a9c,0xe88a,0x4dde,{0xa5,0xa1,0x60,0xf8,0x2a,0x20,0xae,0xf7}};
    static const Guid iid={0xd57c7288,0xd4ad,0x4768,{0xbe,0x02,0x9d,0x96,0x95,0x32,0xd9,0x60}};
    static const Guid item_id={0x43826d1e,0xe718,0x42ee,{0xbc,0x55,0xa1,0xe2,0x61,0xc3,0x7b,0xfe}};
    static const Guid client[]={ {0xbc835e20,0x7f99,0x4efd,{0x98,0xdc,0xc3,0xe6,0x37,0x57,0x93,0xb0}},
                                  {0xbc835e21,0x7f99,0x4efd,{0x98,0xdc,0xc3,0xe6,0x37,0x57,0x93,0xb0}} };
    typedef int32_t (*Result)(Com *, Com **);
    typedef int32_t (*OptionsGet)(Com *, DW *);
    typedef int32_t (*OptionsSet)(Com *, DW);
    typedef int32_t (*Show)(Com *, H);
    typedef int32_t (*SetGuid)(Com *,const Guid *);
    typedef int32_t (*SetTypes)(Com *,DW,const Filter *);
    typedef int32_t (*SetItem)(Com *,Com *);
    typedef int32_t (*Display)(Com *,DW,W **);
    typedef DW (*Release)(Com *);
    int32_t init=CoInitializeEx(NULL,2|4);
    if (init<0) return -1;
    Com *dialog=NULL, *item=NULL, *initial=NULL;
    int ok=-1;
    if (CoCreateInstance(&cls,NULL,1,&iid,&dialog)<0) goto done;
    DW flags=0;
    if (((OptionsGet)dialog->methods[10])(dialog,&flags)<0 ||
        ((OptionsSet)dialog->methods[9])(dialog,flags|0x40|0x800|(folder?0x20:0x1000))<0) goto done;
    ((SetGuid)dialog->methods[24])(dialog,&client[folder!=0]);
    if (!folder) {
        const Filter filter[]={ {WC("Codex CLI"),WC("*.exe;*.cmd;*.ps1")}, {WC("Tất cả tệp"),WC("*.*")} };
        ((SetTypes)dialog->methods[4])(dialog,2,filter);
    }
    if (start && *start) {
        W *path=file_wide(start);
        if (path && SHCreateItemFromParsingName(path,NULL,&item_id,&initial)>=0)
            ((SetItem)dialog->methods[11])(dialog,initial);
        free(path);
    }
    int32_t status=((Show)dialog->methods[3])(dialog,NULL);
    if (status==(int32_t)UINT32_C(0x800704c7)) { ok=0; goto done; }
    W *path=NULL;
    if (status>=0 && ((Result)dialog->methods[20])(dialog,&item)>=0 &&
        ((Display)item->methods[5])(item,0x80058000,&path)>=0) {
        ok=utf8(path,out->p,sizeof(out->p))?1:-1;
        CoTaskMemFree(path);
    }
done:
    if (initial) ((Release)initial->methods[2])(initial);
    if (item) ((Release)item->methods[2])(item);
    if (dialog) ((Release)dialog->methods[2])(dialog);
    CoUninitialize();
    return ok;
}
int open_url(const char *url, int app_mode) {
    W *target = wide(url);
    if (!target) return 0;
    intptr_t code = 0;
    if (app_mode) {
        Path *dir = allocate(sizeof(*dir)), *path = allocate(sizeof(*path));
        if ((env_get(WC("ProgramFiles(x86)"), dir) || env_get(WC("ProgramFiles"), dir)) &&
            path_join(path, dir->p, "Microsoft/Edge/Application/msedge.exe")) {
            W *program = file_wide(path->p);
            Buf args = {0};
            buffer_fmt(&args, "--app=\"%s\"", url);
            W *options = wide(args.s);
            if (program && options) code = ShellExecuteW(NULL, WC("open"), program, options, NULL, 1);
            free(program); free(options); buffer_free(&args);
        }
        free(path); free(dir);
    }
    if (code <= 32) code = ShellExecuteW(NULL, WC("open"), target, NULL, NULL, 1);
    free(target);
    return code > 32;
}
void alert_user(const char *msg) {
    W *text = wide(msg);
    if (text) MessageBoxW(NULL, text, WC("SAMERO Codex Manager"), 0x10);
    free(text);
}
void sleep_ms(unsigned ms) { Sleep(ms); }
uint64_t monotonic_ms(void) { return GetTickCount64(); }
const char *terminal_program(void) {
    static Path dir, program;
    if (env_get(WC("SystemRoot"), &dir) &&
        path_join(&program, dir.p, "System32/WindowsPowerShell/v1.0/powershell.exe")) return program.p;
    return "";
}
static size_t wlen(const W *s) { size_t n = 0; while (s[n]) ++n; return n; }
static int isolate_env(const char *name) {
    const char *prefixes[] = {"CODEX_", "OPENAI_", "CHATGPT_", "AWS_", "AZURE_OPENAI_"};
    for (size_t i=0;i<ARRAY_LEN(prefixes);++i) {
        size_t n=strlen(prefixes[i]);
        if (strlen(name)<n) continue;
        char prefix[16];
        memcpy(prefix,name,n); prefix[n]=0;
        if (ascii_equal(prefix,prefixes[i])) return 1;
    }
    return 0;
}
static int compare_env(const void *a, const void *b) {
    const W *x = *(W *const *)a, *y = *(W *const *)b;
    for (; *x && *y; ++x, ++y) {
        int c = *x >= 'a' && *x <= 'z' ? *x - 32 : *x;
        int d = *y >= 'a' && *y <= 'z' ? *y - 32 : *y;
        if (c != d) return c - d;
    }
    return *x - *y;
}
static void build_env(Buf *out, const char *home) {
    W *base = GetEnvironmentStringsW();
    if (!base) return;
    size_t count = 1;
    for (W *p = base; *p; p += wlen(p) + 1) ++count;
    W **entries = allocate(count * sizeof(*entries));
    size_t i = 0;
    for (W *p = base; *p; p += wlen(p) + 1) {
        char key[256];
        size_t n = 0;
        while (p[n] && p[n] != '=' && n < sizeof(key) - 1 && p[n] < 127) {
            key[n] = (char)p[n]; ++n;
        }
        key[n] = 0;
        if (!isolate_env(key)) entries[i++] = p;
    }
    Buf value = {0};
    buffer_fmt(&value, "CODEX_HOME=%s", home);
    W *entry = wide(value.s);
    if (!entry) { free(entries); FreeEnvironmentStringsW(base); buffer_free(&value); return; }
    entries[i++] = entry;
    qsort(entries, i, sizeof(*entries), compare_env);
    for (size_t j = 0; j < i; ++j) buffer_add(out, entries[j], (wlen(entries[j]) + 1) * sizeof(W));
    W zero = 0;
    buffer_add(out, &zero, sizeof(zero));
    free(entry); free(entries); FreeEnvironmentStringsW(base); buffer_free(&value);
}
static void quote_arg(Buf *cmd, const char *arg) {
    buffer_char(cmd, '"');
    for (;;) {
        size_t slashes = 0;
        while (*arg == '\\') { ++slashes; ++arg; }
        size_t n = (*arg == '"' || !*arg) ? slashes * 2 : slashes;
        while (n--) buffer_char(cmd, '\\');
        if (!*arg) break;
        if (*arg == '"') buffer_char(cmd, '\\');
        buffer_char(cmd, *arg++);
    }
    buffer_char(cmd, '"');
}
int process_start(Process *p, const char *exe, const char *const *argv, const char *cwd,
                  const char *home, int capture, int console, Error *e) {
    *p = (Process){0};
    Buf cmd = {0}, env = {0};
    quote_arg(&cmd, exe);
    for (size_t i = 0; argv && argv[i]; ++i) { buffer_char(&cmd, ' '); quote_arg(&cmd, argv[i]); }
    W *program = file_wide(exe), *arguments = wide(cmd.s), *dir = cwd ? file_wide(cwd) : NULL;
    if (home) build_env(&env, home);
    Startup start = {.cb = sizeof(start)};
    Security security = {.len = sizeof(security), .inherit = 1};
    H input = NULL, output = NULL, child_in = NULL, child_out = NULL, silence = INVALID;
    H job = CreateJobObjectW(NULL, NULL);
    JobLimits limits = {.flags = 0x2000};
    int ok = 0;
    DW err = 0;
    if (!program || !arguments || (cwd && !dir) || (home && !env.s) || !job ||
        !SetInformationJobObject(job, 9, &limits, sizeof(limits))) goto done;
    if (capture) {
        if (!CreatePipe(&child_in, &input, &security, 0) ||
            !CreatePipe(&output, &child_out, &security, 0) ||
            !SetHandleInformation(input, 1, 0) || !SetHandleInformation(output, 1, 0)) goto done;
        silence = CreateFileW(WC("NUL"), 0x40000000, 3, &security, 3, 0, NULL);
        if (silence == INVALID) goto done;
        start.flags = 0x100;
        start.in = child_in; start.out = child_out; start.err = capture==2?child_out:silence;
    }
    ProcInfo proc;
    DW flags = 4 | 0x400 | (console ? 0x10 : 0x08000000);
    if (!CreateProcessW(program, arguments, NULL, NULL, capture, flags, env.s, dir, &start, &proc)) goto done;
    if (!AssignProcessToJobObject(job, proc.process) || ResumeThread(proc.thread) == (DW)-1) {
        err = GetLastError();
        TerminateProcess(proc.process, 125);
        CloseHandle(proc.process);
    } else {
        *p = (Process){.handle=(uintptr_t)proc.process, .job=(uintptr_t)job, .input=(uintptr_t)input,
            .output=(uintptr_t)output, .pid=proc.pid, .captured=capture};
        ok = 1;
    }
    CloseHandle(proc.thread);
done:
    if (!err) err = GetLastError();
    if (child_in) CloseHandle(child_in);
    if (child_out) CloseHandle(child_out);
    if (silence != INVALID) CloseHandle(silence);
    if (!ok) {
        if (input) CloseHandle(input);
        if (output) CloseHandle(output);
        if (job) CloseHandle(job);
        errorf(e, "Không khởi chạy được tiến trình (Windows %u).", err);
    }
    free(program); free(arguments); free(dir); buffer_free(&cmd); buffer_free(&env);
    return ok;
}
int process_write(Process *p, const char *s, size_t n) {
    DW written = 0;
    return p->input && n <= 4096 && WriteFile((H)p->input, s, (DW)n, &written, NULL) && written == n;
}
void process_close_input(Process *p) { if (p->input) CloseHandle((H)p->input); p->input = 0; }
int process_read(Process *p, char *out, size_t cap) {
    DW available = 0, got = 0;
    if (!p->output || !PeekNamedPipe((H)p->output, NULL, 0, NULL, &available, NULL)) return -1;
    if (!available) return 0;
    if (available > cap) available = (DW)cap;
    return ReadFile((H)p->output, out, available, &got, NULL) ? (int)got : -1;
}
int process_poll(Process *p, int *code) {
    if (!p->handle) return -1;
    DW signal = WaitForSingleObject((H)p->handle, 0);
    if (signal == 258) return 1;
    DW status;
    JobCount count;
    if (signal || !GetExitCodeProcess((H)p->handle, &status) ||
        !QueryInformationJobObject((H)p->job, 1, &count, sizeof(count), NULL)) return -1;
    if (count.active) return 1;
    *code = (int)status;
    return 0;
}
int process_stop(Process *p) { return p->job && TerminateJobObject((H)p->job, 130); }
void process_dispose(Process *p) {
    process_close_input(p);
    if (p->output) CloseHandle((H)p->output);
    if (p->handle) CloseHandle((H)p->handle);
    if (p->job) CloseHandle((H)p->job);
    *p = (Process){0};
}

#else
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <signal.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>

typedef struct { unsigned short family, port; uint32_t addr; char zero[8]; } Addr;
int file_info(const char *path, Info *info) {
    struct stat s;
    *info = (Info){0};
    if (lstat(path, &s)) return 0;
    info->kind = S_ISREG(s.st_mode) ? 1 : S_ISDIR(s.st_mode) ? 2 : 3;
    info->mode = (unsigned)s.st_mode & 0777;
    info->size = (uint64_t)s.st_size;
    info->mtime = (uint64_t)s.st_mtim.tv_sec * UINT64_C(1000000000) + (uint64_t)s.st_mtim.tv_nsec;
    info->inode = s.st_ino;
    info->device = s.st_dev;
    info->links = s.st_nlink;
    return 1;
}
const char *probe_read_regular(const char *path, unsigned *code) {
    *code=0;
    int fd=open(path,O_RDONLY|O_NOFOLLOW|O_NONBLOCK|O_CLOEXEC);
    if (fd<0) { int err=errno; *code=(unsigned)err; return err==ENOENT || err==ENOTDIR?"MISSING":err==EACCES || err==EPERM?"DENIED":err==ELOOP?"UNSAFE_TYPE":"OPEN_FAILED"; }
    struct stat st; unsigned char b;
    const char *status="OK";
    if (fstat(fd,&st)) { *code=(unsigned)errno; status="STAT_FAILED"; }
    else if (!S_ISREG(st.st_mode)) status="UNSAFE_TYPE";
    else if (read(fd,&b,1)<0) { *code=(unsigned)errno; status="READ_FAILED"; }
    close(fd);
    return status;
}
int list_dir_filtered(const char *dir, NameFilter filter, Visitor cb, void *ctx, Error *e) {
    DIR *d = opendir(dir);
    if (!d) return errorf(e, "Không đọc được thư mục: %s", dir);
    int ok = 1;
    Path *path = allocate(sizeof(*path));
    for (;;) {
        errno = 0;
        struct dirent *entry = readdir(d);
        if (!entry) {
            if (errno) ok = errorf(e, "Không đọc hết thư mục: %s", dir);
            break;
        }
        if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..") || (filter && !filter(entry->d_name))) continue;
        Info info;
        if (!path_join(path, dir, entry->d_name) || !file_info(path->p, &info) ||
            !cb(entry->d_name, &info, ctx, e)) { ok = 0; break; }
    }
    free(path);
    closedir(d);
    return ok;
}
int canonical(const char *path, Path *out) { return realpath(path, out->p) != NULL; }
int user_root(Path *out, int local) {
    const char *home = getenv("HOME");
    if (!home) return 0;
    return local ? path_join(out, home, ".local/share") : sam_format(out->p, sizeof(out->p), "%s", home) < PATH_CAP;
}
int mkdir_new(const char *path) { return !mkdir(path, 0700); }
int remove_file(const char *path) { return !unlink(path); }
int remove_dir(const char *path) { return !rmdir(path); }
void restore_mode(const char *path, unsigned mode) { chmod(path, mode & 0777); }
int move_file(const char *from, const char *to, int replace) {
    if (replace) return !rename(from, to);
    if (link(from, to)) return 0;
    return !unlink(from);
}
FILE *file_open(const char *path, int write) {
    int fd = open(path, (write ? O_WRONLY | O_CREAT | O_TRUNC : O_RDONLY) | O_NOFOLLOW | O_CLOEXEC, 0600);
    return fd < 0 ? NULL : fdopen(fd, write ? "wb" : "rb");
}
int move_queue_exclusive(const char *from,const char *to) {
    return !renameat2(AT_FDCWD,from,AT_FDCWD,to,RENAME_NOREPLACE);
}
FILE *file_open_append(const char *path) {
    int fd=open(path,O_WRONLY|O_APPEND|O_CREAT|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK,0600);
    struct stat st;
    if (fd<0) return NULL;
    if (fstat(fd,&st) || !S_ISREG(st.st_mode) || st.st_nlink!=1) { close(fd); return NULL; }
    FILE *f=fdopen(fd,"ab");
    if (!f) close(fd);
    return f;
}
FILE *file_open_new(const char *path) {
    int fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0600);
    return fd < 0 ? NULL : fdopen(fd, "wb");
}
int file_seek(FILE *f, uint64_t pos) { return pos <= INT64_MAX && !fseeko(f, (off_t)pos, SEEK_SET); }
int file_flush(FILE *f) { return !fflush(f) && !fsync(fileno(f)); }
int system_random(void *out, size_t size) {
    FILE *f = fopen("/dev/urandom", "rb");
    if (!f) return 0;
    int ok = fread(out, 1, size, f) == size;
    fclose(f);
    return ok;
}
int acquire_instance(const char *root) {
    Path path;
    if (!path_join(&path, root, "manager.lock")) return 0;
    int fd = open(path.p, O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return 0;
    if (flock(fd, LOCK_EX | LOCK_NB)) { close(fd); return 0; }
    return 1;
}
int self_executable(Path *out) {
    ssize_t len=readlink("/proc/self/exe",out->p,sizeof(out->p)-1);
    if (len<=0 || len>=(ssize_t)sizeof(out->p)-1) return 0;
    out->p[len]=0; return 1;
}
int worker_stdout(const char *data,size_t size) {
    return fwrite(data,1,size,stdout)==size && !fflush(stdout);
}
int pick_path(int folder,const char *start,Path *out) { (void)folder; (void)start; (void)out; return -1; }
int open_url(const char *url, int app_mode) { (void)app_mode; printf("%s\n", url); fflush(stdout); return 1; }
void alert_user(const char *msg) { fprintf(stderr, "%s\n", msg); }
void sleep_ms(unsigned ms) {
    struct timespec t = {.tv_sec = ms / 1000, .tv_nsec = (long)(ms % 1000) * 1000000};
    nanosleep(&t, NULL);
}
uint64_t monotonic_ms(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (uint64_t)t.tv_sec * 1000 + (uint64_t)t.tv_nsec / 1000000;
}
const char *terminal_program(void) { return "/bin/bash"; }
extern char **environ;
int process_start(Process *p, const char *exe, const char *const *argv, const char *cwd,
                  const char *home, int capture, int console, Error *e) {
    (void)console;
    *p = (Process){0};
    int in[2] = {-1,-1}, out[2] = {-1,-1};
    if (capture) {
        if (pipe2(in,O_CLOEXEC)) return errorf(e,"Không tạo được pipe đầu vào.");
        if (pipe2(out,O_CLOEXEC)) { close(in[0]); close(in[1]); return errorf(e,"Không tạo được pipe đầu ra."); }
        if (fcntl(in[1],F_SETFL,O_NONBLOCK)<0 || fcntl(out[0],F_SETFL,O_NONBLOCK)<0) {
            close(in[0]); close(in[1]); close(out[0]); close(out[1]); return errorf(e,"Không thiết lập được pipe không chặn.");
        }
    }
    pid_t pid = fork();
    if (!pid) {
        setpgid(0, 0);
        if (capture) {
            if (dup2(in[0],STDIN_FILENO)<0 || dup2(out[1],STDOUT_FILENO)<0) _exit(126);
            int sink = capture==2?dup(out[1]):open("/dev/null", O_WRONLY);
            if (sink >= 0) { dup2(sink, STDERR_FILENO); if (sink > 2) close(sink); }
            close(in[0]); close(in[1]); close(out[0]); close(out[1]);
        }
        if (cwd && chdir(cwd)) _exit(126);
        if (home) {
            for (size_t i = 0; environ[i];) {
                const char *s = environ[i];
                if (!strncmp(s, "CODEX_", 6) || !strncmp(s, "OPENAI_", 7) ||
                    !strncmp(s, "CHATGPT_", 8) || !strncmp(s, "AWS_", 4) || !strncmp(s, "AZURE_OPENAI_", 13)) {
                    char *key = strndup(s, strcspn(s, "="));
                    if (!key || unsetenv(key)) _exit(126);
                    free(key);
                } else ++i;
            }
            if (setenv("CODEX_HOME",home,1)) _exit(126);
        }
        const char *args[32] = {exe};
        size_t i = 0;
        for (; argv && argv[i] && i < ARRAY_LEN(args) - 2; ++i) args[i+1] = argv[i];
        if (argv && argv[i]) _exit(126);
        execv(exe, (char *const *)args);
        _exit(127);
    }
    if (capture) { close(in[0]); close(out[1]); }
    if (pid < 0) {
        if (capture) { close(in[1]); close(out[0]); }
        return errorf(e, "Không khởi chạy được tiến trình.");
    }
    setpgid(pid, pid);
    *p = (Process){.handle=(uintptr_t)pid, .pid=(unsigned)pid, .input=capture ? (uintptr_t)(in[1] + 1) : 0,
        .output=capture ? (uintptr_t)(out[0] + 1) : 0, .captured=capture};
    return 1;
}
int process_write(Process *p, const char *s, size_t n) {
    return p->input && n <= 4096 && write((int)p->input - 1, s, n) == (ssize_t)n;
}
void process_close_input(Process *p) { if (p->input) close((int)p->input - 1); p->input = 0; }
int process_read(Process *p, char *out, size_t cap) {
    if (!p->output) return -1;
    ssize_t n = read((int)p->output - 1, out, cap);
    if (n < 0 && (errno == EAGAIN || errno == EINTR)) return 0;
    return n > 0 ? (int)n : -1;
}
int process_poll(Process *p, int *code) {
    if (!p->handle) return -1;
    if (!p->reaped) {
        int status;
        pid_t result = waitpid((pid_t)p->pid, &status, WNOHANG);
        if (!result) return 1;
        if (result < 0) return errno == EINTR ? 1 : -1;
        p->reaped = 1;
        p->exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : 128 + WTERMSIG(status);
    }
    if (kill(-(pid_t)p->pid, 0) == 0 || errno == EPERM) return 1;
    *code = p->exit_code;
    return 0;
}
int process_stop(Process *p) { return p->pid && !kill(-(pid_t)p->pid, SIGKILL); }
void process_dispose(Process *p) {
    process_close_input(p);
    if (p->output) close((int)p->output - 1);
    if (p->handle && !p->reaped) {
        process_stop(p);
        int status;
        while (waitpid((pid_t)p->pid, &status, 0) < 0 && errno == EINTR) {}
    }
    *p = (Process){0};
}
#endif

int list_dir(const char *dir, Visitor cb, void *ctx, Error *e) {
    return list_dir_filtered(dir,NULL,cb,ctx,e);
}
static int absolute_path(const char *s) {
#ifdef SAM_WINDOWS
    return (s[0] && s[1] == ':' && (s[2] == '/' || s[2] == '\\')) ||
        ((s[0] == '/' || s[0] == '\\') && (s[1] == '/' || s[1] == '\\'));
#else
    return s[0] == '/';
#endif
}
int mkdir_tree(const char *path) {
    if (!absolute_path(path)) return 0;
    for (const char *p=path; *p;) {
        size_t length=strcspn(p,"/\\");
        if ((length==1 && p[0]=='.') || (length==2 && p[0]=='.' && p[1]=='.')) return 0;
        p+=length+(p[length]!=0);
    }
    Path *partial = allocate(sizeof(*partial));
    int n = sam_format(partial->p, sizeof(partial->p), "%s", path);
    int ok = n > 0 && n < PATH_CAP;
#ifdef SAM_WINDOWS
    for (char *c = partial->p; *c; ++c) if (*c == '\\') *c = '/';
    char *start = partial->p + (partial->p[1] == ':' ? 3 : 2);
    if (ok && partial->p[0] == '/' && partial->p[1] == '/') {
        start = strchr(start, '/');
        if (start) start = strchr(start + 1, '/');
        start = start ? start + 1 : partial->p + n;
    }
#else
    char *start = partial->p + 1;
#endif
    for (char *c = start; ok && c <= partial->p + n; ++c) {
        if (*c && *c != '/') continue;
        if (c == partial->p || c[-1] == '/' || c[-1] == ':') continue;
        char reinsert = *c;
        *c = 0;
        Info info;
        if (!file_info(partial->p, &info)) {
            if (!mkdir_new(partial->p) && (!file_info(partial->p, &info) || info.kind != 2)) ok = 0;
        } else if (info.kind != 2) ok = 0;
        *c = reinsert;
    }
    free(partial);
    return ok;
}
int read_file(const char *path, size_t limit, Buf *out, Error *e) {
    Info info;
    if (!file_info(path, &info) || info.kind != 1 || info.size > limit)
        return errorf(e, "Không đọc được tệp hoặc tệp quá lớn: %s", path);
    FILE *f = file_open(path, 0);
    if (!f) return errorf(e, "Không mở được tệp: %s", path);
    char chunk[4096];
    int ok = 1;
    size_t n;
    while ((n = fread(chunk, 1, sizeof(chunk), f)) != 0) {
        if (limit - out->n < n) { ok = 0; break; }
        buffer_add(out, chunk, n);
    }
    if (ferror(f)) ok = 0;
    fclose(f);
    if (!out->s) buffer_text(out, "");
    return ok ? 1 : errorf(e, "Không đọc hết tệp: %s", path);
}
static int write_atomic_mode(const char *path, const void *data, size_t size, int replace, Error *e) {
    Path *tmp = allocate(sizeof(*tmp));
    char nonce[33]; new_id(nonce);
    int n = sam_format(tmp->p, sizeof(tmp->p), "%s.%s.tmp", path, nonce);
    FILE *f = n > 0 && n < PATH_CAP ? file_open_new(tmp->p) : NULL;
    if (!f) { free(tmp); return errorf(e, "Không thể tạo tệp: %s", path); }
    int ok = fwrite(data, 1, size, f) == size && file_flush(f);
    if (fclose(f)) ok = 0;
    if (ok) {
        Info info;
        if (file_info(path, &info) && info.kind != 1) ok = 0;
        else ok = move_file(tmp->p, path, replace);
    }
    if (!ok) { remove_file(tmp->p); errorf(e, "Không ghi được tệp: %s", path); }
    free(tmp);
    return ok;
}
int write_atomic(const char *path,const void *data,size_t size,Error *e) {
    return write_atomic_mode(path,data,size,1,e);
}
int write_new_atomic(const char *path,const void *data,size_t size,Error *e) {
    return write_atomic_mode(path,data,size,0,e);
}
static int executable(const char *p, Path *out) {
    if (!absolute_path(p) || !canonical(p, out)) return 0;
    Info info;
    if (!file_info(out->p, &info) || info.kind != 1) return 0;
#ifdef SAM_WINDOWS
    return has_suffix(out->p, ".exe");
#else
    return (info.mode & 0111) != 0;
#endif
}
int locate_exec(const char *value, const char *name, Path *out) {
    if (value && *value) return executable(value, out);
    Path *path = allocate(sizeof(*path)), *entry = allocate(sizeof(*entry));
    int found = 0;
#ifdef SAM_WINDOWS
    Path *env = allocate(sizeof(*env));
    const char *dirs = env_get(WC("Path"), env) ? env->p : "";
    const char *sep = ";";
#else
    const char *dirs = getenv("PATH"), *sep = ":";
#endif
    for (const char *p = dirs; !found && p && *p;) {
        size_t len = strcspn(p, sep);
        const char *end = p + len;
        if (len >= 2 && p[0] == '"' && p[len-1] == '"') { ++p; len -= 2; }
        if (len && len < sizeof(entry->p)) {
            memcpy(entry->p, p, len);
            entry->p[len] = 0;
            if (absolute_path(entry->p) && path_join(path, entry->p, name)) found = executable(path->p, out);
        }
        p = *end ? end + 1 : end;
    }
#ifdef SAM_WINDOWS
    free(env);
#endif
    free(path); free(entry);
    return found;
}
#ifdef SAM_WINDOWS
/* Read the current registry values as well as the environment inherited by this GUI. */
static char *long_env(const W *name) {
    DW n=GetEnvironmentVariableW(name,NULL,0);
    if (!n || n>32768) return NULL;
    W *raw=allocate((size_t)n*sizeof(W));
    DW actual=GetEnvironmentVariableW(name,raw,n);
    char *result=allocate((size_t)n*4);
    if (!actual || actual>=n || !utf8(raw,result,(size_t)n*4)) { free(result); result=NULL; }
    free(raw);
    return result;
}
static char *registry_env(int user,const W *name) {
    H hive=(H)(intptr_t)(int32_t)(user ? UINT32_C(0x80000001) : UINT32_C(0x80000002));
    const W *sub=user ? WC("Environment") : WC("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment");
    DW size=0;
    if (RegGetValueW(hive,sub,name,6,NULL,NULL,&size) || size<sizeof(W) || size>65536) return NULL;
    W *value=allocate((size_t)size+2*sizeof(W));
    if (RegGetValueW(hive,sub,name,6,NULL,value,&size)) { free(value); return NULL; }
    char *text=allocate((size_t)size*2+4);
    if (!utf8(value,text,(size_t)size*2+4) || !*text) { free(text); text=NULL; }
    free(value);
    return text;
}
int native_codex_home(Path *out) {
    char *value=long_env(WC("CODEX_HOME"));
    if (!value) value=registry_env(1,WC("CODEX_HOME"));
    if (!value) value=registry_env(0,WC("CODEX_HOME"));
    int ok=value && absolute_path(value) && sam_format(out->p,sizeof(out->p),"%s",value)<PATH_CAP;
    free(value);
    return ok;
}
static int named_codex(const char *name,const char *candidate) {
    return ascii_equal(name,"codex.exe") || ascii_equal(name,"codex-x86_64-pc-windows-msvc.exe") ||
           ascii_equal(name,"codex-aarch64-pc-windows-msvc.exe") ||
           (candidate && *candidate && ascii_equal(name,candidate));
}
static W *process_command(H process) {
    typedef int32_t (*Query)(H,DW,void *,DW,DW *);
    H module=GetModuleHandleW(WC("ntdll.dll"));
    Query query=module?(Query)GetProcAddress(module,"NtQueryInformationProcess"):NULL;
    if (!query) return NULL;
    DW need=0;
    query(process,60,NULL,0,&need);
    if (need<sizeof(UnicodeString) || need>131072) return NULL;
    unsigned char *raw=allocate(need);
    UnicodeString *str=(UnicodeString *)raw;
    W *cmd=NULL;
    if (query(process,60,raw,need,NULL)>=0 && str->length && !(str->length&1) &&
        (uintptr_t)str->text>=(uintptr_t)raw &&
        (uintptr_t)str->text-(uintptr_t)raw<=need &&
        str->length<=need-((uintptr_t)str->text-(uintptr_t)raw)) {
        cmd=allocate(str->length+sizeof(W)); memcpy(cmd,str->text,str->length);
    }
    memset(raw,0,need); free(raw); return cmd;
}
static int matching_scope(const char *const *args,int count,const char *thread,const char *workspace) {
    for (int i=1;i<count;++i) {
        const char *arg=args[i], *dir=NULL;
        if (!strcmp(arg,"--")) return thread && i+1<count && ascii_equal(args[i+1],thread);
        if (thread && *thread && ascii_equal(arg,thread)) return 1;
        if ((!strcmp(arg,"-C") || !strcmp(arg,"--cd")) && i+1<count) dir=args[++i];
        else if (!strncmp(arg,"--cd=",5)) dir=arg+5;
        if (dir && workspace && *workspace && absolute_path(dir)) {
            Path *resolved=allocate(sizeof(*resolved));
            int matches=canonical(dir,resolved) && (within(workspace,resolved->p) || within(resolved->p,workspace));
            free(resolved);
            if (matches) return 1;
        }
    }
    return 0;
}
void inspect_codex(const char *exe,const unsigned *known,size_t count,const char *thread,
                   const char *workspace,CodexProcesses *out) {
    memset(out,0,sizeof(*out));
    H snap=CreateToolhelp32Snapshot(2,0);
    if (snap==INVALID) { ++out->unknown; return; }
    ProcessEntry row={.size=sizeof(row)};
    if (!Process32FirstW(snap,&row)) ++out->unknown;
    else do {
        char name[1040];
        if (!utf8(row.exe,name,sizeof(name))) continue;
        if (ascii_equal(name,"codex-code-mode-host.exe")) { ++out->host; continue; }
        if (!named_codex(name,exe?base_name(exe):NULL)) continue;
        size_t i=0;
        while (i<count && known[i]!=row.pid) ++i;
        if (i<count) { ++out->managed; continue; }
        H process=OpenProcess(0x1000,0,row.pid);
        Path *image=allocate(sizeof(*image));
        W *wide_path=allocate(PATH_CAP*sizeof(W));
        DW n=PATH_CAP;
        if (process && QueryFullProcessImageNameW(process,0,wide_path,&n)) utf8(wide_path,image->p,sizeof(image->p));
        free(wide_path);
        W *cmd=process?process_command(process):NULL;
        if (process) CloseHandle(process);
        int argc=0;
        W **argv=cmd?CommandLineToArgvW(cmd,&argc):NULL;
        char **args=NULL;
        int parsed=argv && argc>0 && argc<=128;
        if (parsed) {
            args=allocate((size_t)argc*sizeof(*args));
            for (int k=0;k<argc;++k) {
                args[k]=allocate(PATH_CAP);
                if (!utf8(argv[k],args[k],PATH_CAP)) parsed=0;
            }
        }
        CodexKind kind=classify_codex(image->p,(const char *const *)args,parsed?argc:0,0);
        if (kind==CODEX_INTERACTIVE) {
            ++out->interactive;
            if (matching_scope((const char *const *)args,argc,thread,workspace)) ++out->conflict;
            else ++out->unknown;
        } else if (kind==CODEX_DAEMON) ++out->daemon;
        else if (kind==CODEX_SERVER) ++out->server;
        else if (kind==CODEX_BATCH) {
            ++out->batch;
            if (parsed && matching_scope((const char *const *)args,argc,thread,workspace)) ++out->conflict;
        } else ++out->unknown;
        if (args) { for (int k=0;k<argc;++k) { memset(args[k],0,PATH_CAP); free(args[k]); } free(args); }
        if (argv) {
            for (int k=0;k<argc;++k) memset(argv[k],0,wlen(argv[k])*sizeof(W));
            LocalFree(argv);
        }
        if (cmd) { memset(cmd,0,wlen(cmd)*sizeof(W)); free(cmd); }
        free(image);
    } while (Process32NextW(snap,&row));
    CloseHandle(snap);
}
static int live_codex_path(Path *out) {
    H snap=CreateToolhelp32Snapshot(2,0);
    if (snap==INVALID) return 0;
    ProcessEntry row={.size=sizeof(row)};
    int found=0, ambiguous=0;
    Path *candidate=allocate(sizeof(*candidate)), *resolved=allocate(sizeof(*resolved));
    if (Process32FirstW(snap,&row)) do {
        char name[1040];
        if (!utf8(row.exe,name,sizeof(name)) || !named_codex(name,NULL)) continue;
        H process=OpenProcess(0x1000,0,row.pid);
        if (!process) continue;
        W *image=allocate(PATH_CAP*sizeof(W));
        DW n=PATH_CAP;
        int ok=QueryFullProcessImageNameW(process,0,image,&n) && utf8(image,candidate->p,sizeof(candidate->p));
        free(image); CloseHandle(process);
        if (!ok || classify_codex(candidate->p,NULL,0,0)==CODEX_DAEMON || !executable(candidate->p,resolved)) continue;
        if (found && (!within(out->p,resolved->p) || !within(resolved->p,out->p))) { ambiguous=1; break; }
        *out=*resolved; found=1;
    } while (Process32NextW(snap,&row));
    free(candidate); free(resolved); CloseHandle(snap);
    return found && !ambiguous;
}
static int npm_codex(const char *folder,Path *out) {
    static const char *paths[]={
        "node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/bin/codex.exe",
        "node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/bin/codex.exe",
        "node_modules/@openai/codex/vendor/x86_64-pc-windows-msvc/bin/codex.exe",
        "node_modules/@openai/codex/node_modules/@openai/codex-win32-arm64/vendor/aarch64-pc-windows-msvc/bin/codex.exe",
        "node_modules/@openai/codex-win32-arm64/vendor/aarch64-pc-windows-msvc/bin/codex.exe",
        "node_modules/@openai/codex/node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/codex/codex.exe",
        "node_modules/@openai/codex-win32-x64/vendor/x86_64-pc-windows-msvc/codex/codex.exe",
        "node_modules/@openai/codex/vendor/x86_64-pc-windows-msvc/codex/codex.exe",
        "node_modules/@openai/codex/node_modules/@openai/codex-win32-arm64/vendor/aarch64-pc-windows-msvc/codex/codex.exe",
        "node_modules/@openai/codex-win32-arm64/vendor/aarch64-pc-windows-msvc/codex/codex.exe"
    };
    Path *p=allocate(sizeof(*p));
    int ok=0;
    for (size_t i=0;i<ARRAY_LEN(paths) && !ok;++i)
        ok=path_join(p,folder,paths[i]) && executable(p->p,out);
    free(p); return ok;
}
static int folder_codex(const char *folder,Path *out) {
    if (!absolute_path(folder)) return 0;
    Path *path=allocate(sizeof(*path));
    int found=path_join(path,folder,"codex.exe") && executable(path->p,out);
    if (!found) found=npm_codex(folder,out);
    free(path);
    return found;
}
static int windows_search(const char *paths,Path *out) {
    Path *entry=allocate(sizeof(*entry));
    int found=0;
    for (const char *p=paths;p && *p && !found;) {
        size_t n=strcspn(p,";");
        const char *tail=p+n;
        while (n && (*p==' ' || *p=='\t')) { ++p; --n; }
        while (n && (p[n-1]==' ' || p[n-1]=='\t')) --n;
        if (n>1 && *p=='"' && p[n-1]=='"') { ++p; n-=2; }
        if (n>0 && n<sizeof(entry->p)) {
            memcpy(entry->p,p,n); entry->p[n]=0;
            if (strchr(entry->p,'%')) {
                W *raw=wide(entry->p), *expanded=allocate(PATH_CAP*sizeof(W));
                DW count=raw ? ExpandEnvironmentStringsW(raw,expanded,PATH_CAP) : 0;
                if (!count || count>PATH_CAP || !utf8(expanded,entry->p,sizeof(entry->p))) entry->p[0]=0;
                free(raw); free(expanded);
            }
            found=folder_codex(entry->p,out);
        }
        p=*tail ? tail+1:tail;
    }
    free(entry); return found;
}
int locate_codex_cli(const char *value,Path *out) {
    if (value && *value) {
        if (executable(value,out)) return 1;
        if (!absolute_path(value)) return 0;
        if (!ascii_equal(base_name(value),"codex.cmd") && !ascii_equal(base_name(value),"codex.ps1")) return 0;
        Info info;
        if (!file_info(value,&info) || info.kind!=1) return 0;
        Path *dir=allocate(sizeof(*dir));
        size_t n=(size_t)(base_name(value)-value);
        if (!n || n>=sizeof(dir->p)) { free(dir); return 0; }
        memcpy(dir->p,value,n); dir->p[n]=0;
        int ok=npm_codex(dir->p,out);
        free(dir); return ok;
    }
    char *paths=long_env(WC("Path"));
    int found=windows_search(paths,out);
    free(paths);
    for (int user=0;user<=1 && !found;++user) {
        paths=registry_env(user,WC("Path"));
        found=windows_search(paths,out);
        free(paths);
    }
    if (!found) {
        paths=long_env(WC("CODEX_INSTALL_DIR"));
        if (paths) found=folder_codex(paths,out);
        free(paths);
    }
    static const struct { const W *env; const char *dir; } roots[]={
        {WC("LOCALAPPDATA"),"Programs/OpenAI/Codex/bin"},
        {WC("APPDATA"),"npm"},
        {WC("LOCALAPPDATA"),"Microsoft/WinGet/Links"},
        {WC("LOCALAPPDATA"),"Volta/bin"},
        {WC("USERPROFILE"),".local/bin"},
        {WC("USERPROFILE"),"scoop/shims"}
    };
    Path *root=allocate(sizeof(*root)), *folder=allocate(sizeof(*folder));
    for (size_t i=0; i<ARRAY_LEN(roots) && !found; ++i)
        found=env_get(roots[i].env,root) && path_join(folder,root->p,roots[i].dir) && folder_codex(folder->p,out);
    free(root); free(folder);
    return found || live_codex_path(out);
}
static int terminal_alias(Path *out) {
    Path *data=allocate(sizeof(*data));
    int ok=env_get(WC("LOCALAPPDATA"),data) && path_join(out,data->p,"Microsoft/WindowsApps/wt.exe");
    free(data);
    W *alias=ok?file_wide(out->p):NULL;
    DW attrs=alias?GetFileAttributesW(alias):UINT32_MAX;
    free(alias);
    if (attrs!=UINT32_MAX && !(attrs&16)) return 1;
    return locate_exec(NULL,"wt.exe",out);
}
int windows_terminal_available(void) {
    Path *path=allocate(sizeof(*path));
    int ok=terminal_alias(path);
    free(path); return ok;
}
static void powershell_string(Buf *script,const char *text) {
    buffer_char(script,'\'');
    for (;*text;++text) {
        if (*text=='\'') buffer_char(script,'\'');
        buffer_char(script,*text);
    }
    buffer_char(script,'\'');
}
static int encode_script(Buf *encoded,const char *script) {
    static const char alphabet[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    W *w=wide(script);
    if (!w) return 0;
    const unsigned char *p=(const unsigned char *)w;
    size_t bytes=wlen(w)*sizeof(W);
    for (size_t i=0;i<bytes;i+=3) {
        unsigned bits=(unsigned)p[i]<<16;
        if (i+1<bytes) bits|=(unsigned)p[i+1]<<8;
        if (i+2<bytes) bits|=p[i+2];
        buffer_char(encoded,alphabet[(bits>>18)&63]); buffer_char(encoded,alphabet[(bits>>12)&63]);
        buffer_char(encoded,i+1<bytes?alphabet[(bits>>6)&63]:'=');
        buffer_char(encoded,i+2<bytes?alphabet[bits&63]:'=');
    }
    free(w); return 1;
}
int launch_windows_terminal(const char *exe,const char *workspace,const char *home,const char *thread,
                            const char *lease,const char *done,const char *shell,Error *e) {
    Path *wt=allocate(sizeof(*wt));
    int is_wt=!strcmp(shell,"wt"), is_cmd=!strcmp(shell,"cmd");
    if (is_wt && !terminal_alias(wt)) { free(wt); return errorf(e,"Không tìm thấy Windows Terminal (wt.exe)."); }
    const char *ps=terminal_program();
    if (!*ps || strchr(ps,';')) { free(wt); return errorf(e,"Không tìm được Windows PowerShell."); }
    Buf script={0}, encoded={0}, cmd={0};
    buffer_text(&script,"$ErrorActionPreference='Stop'\n$lease=[IO.File]::Open(");
    powershell_string(&script,lease);
    buffer_text(&script,",[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)\n$done=");
    powershell_string(&script,done);
    buffer_text(&script,"\ntry { if ([IO.File]::Exists($done)) { return }; Set-Location -LiteralPath ");
    powershell_string(&script,workspace);
    buffer_text(&script,"; $env:CODEX_HOME=");
    powershell_string(&script,home);
    buffer_text(&script,"; & ");
    powershell_string(&script,exe);
    if (*thread) { buffer_text(&script," 'resume' '--' "); powershell_string(&script,thread); }
    buffer_text(&script,"\n} finally { try { [IO.File]::WriteAllText($done,'done') } finally { $lease.Dispose() } }\n");
    int ok=encode_script(&encoded,script.s) && encoded.n<24000;
    Path *system=allocate(sizeof(*system));
    if (is_cmd) {
        ok=ok && env_get(WC("SystemRoot"),system) && path_join(wt,system->p,"System32/cmd.exe");
        for (const char *c=ps;*c;++c) if (strchr("\"%&^!<>|",*c)) ok=0;
    }
    if (ok) {
        if (is_wt || is_cmd) {
            quote_arg(&cmd,wt->p);
            buffer_text(&cmd,is_wt?" -w new new-tab --title SAMERO-Codex ":" /d /s /k \"");
        }
        quote_arg(&cmd,ps);
        buffer_text(&cmd,is_cmd?" -NoLogo -NoProfile -EncodedCommand ":" -NoLogo -NoProfile -NoExit -EncodedCommand ");
        buffer_add(&cmd,encoded.s,encoded.n);
        if (is_cmd) buffer_char(&cmd,'"');
        W *app=(!is_cmd || cmd.n<8000)?file_wide(is_wt||is_cmd?wt->p:ps):NULL, *args=wide(cmd.s);
        W *cwd=is_wt?NULL:file_wide(workspace);
        Startup start={.cb=sizeof(start)};
        ProcInfo proc;
        ok=app && args && (is_wt || cwd) && CreateProcessW(app,args,NULL,NULL,0,is_wt?0:0x10,NULL,cwd,&start,&proc);
        if (ok) { CloseHandle(proc.thread); CloseHandle(proc.process); }
        free(app); free(args); free(cwd);
    }
    free(system);
    free(wt); buffer_free(&script); buffer_free(&encoded); buffer_free(&cmd);
    return ok ? 1 : errorf(e,"Không mở được terminal đã chọn.");
}
int release_terminal_lease(const char *lease,const char *done,Error *e) {
    W *path=file_wide(lease);
    H lock=path?CreateFileW(path,0xc0000000,0,NULL,4,0x00200000,NULL):INVALID;
    free(path);
    if (lock==INVALID) return errorf(e,"Cửa sổ ngoài vẫn đang giữ khóa. Hãy thoát Codex tại đó.");
    int ok=write_atomic(done,"released",8,e);
    CloseHandle(lock); return ok;
}
long long info_unix_time(const Info *info) {
    uint64_t seconds=info->mtime/10000000;
    return seconds>UINT64_C(11644473600) ? (long long)(seconds-UINT64_C(11644473600)) : -1;
}
#else
int native_codex_home(Path *out) {
    const char *value=getenv("CODEX_HOME");
    return value && absolute_path(value) && sam_format(out->p,sizeof(out->p),"%s",value)<PATH_CAP;
}
int locate_codex_cli(const char *value,Path *out) { return locate_exec(value,"codex",out); }
int windows_terminal_available(void) { return 0; }
void inspect_codex(const char *exe,const unsigned *known,size_t count,const char *thread,
                   const char *workspace,CodexProcesses *out) {
    (void)exe; (void)known; (void)count; (void)thread; (void)workspace;
    memset(out,0,sizeof(*out));
}
int launch_windows_terminal(const char *exe,const char *workspace,const char *home,const char *thread,
                            const char *lease,const char *done,const char *shell,Error *e) {
    (void)exe; (void)workspace; (void)home; (void)thread; (void)lease; (void)done; (void)shell;
    return errorf(e,"Chức năng này cần Windows.");
}
int release_terminal_lease(const char *lease,const char *done,Error *e) {
    (void)lease; (void)done; return errorf(e,"Chức năng này cần Windows Terminal trên Windows.");
}
long long info_unix_time(const Info *info) { return (long long)(info->mtime/1000000000); }
#endif

int run_capture(const char *exe, const char *const *argv, const char *cwd, const char *home,
                Buf *out, size_t max, unsigned deadline, int *exit_code, Error *e) {
    Process p;
    if (!process_start(&p, exe, argv, cwd, home, 1, 0, e)) return 0;
    process_close_input(&p);
    uint64_t until = monotonic_ms() + deadline;
    int ok = 0;
    char data[4096];
    while (monotonic_ms() < until) {
        int n = process_read(&p, data, sizeof(data));
        if (n > 0) {
            if (out->n + (size_t)n > max) { errorf(e, "Dữ liệu trả về vượt giới hạn đọc."); goto done; }
            buffer_add(out, data, (size_t)n);
            continue;
        }
        int running = process_poll(&p, exit_code);
        if (running < 0) { errorf(e, "Không kiểm tra được tiến trình."); goto done; }
        if (!running) {
            n = process_read(&p, data, sizeof(data));
            if (n > 0) {
                if (out->n + (size_t)n > max) { errorf(e, "Dữ liệu trả về vượt giới hạn đọc."); goto done; }
                buffer_add(out, data, (size_t)n);
                continue;
            }
            ok = 1;
            break;
        }
        sleep_ms(10);
    }
    if (!ok) errorf(e, "Tiến trình vượt thời gian chờ.");
done:
    if (!ok) process_stop(&p);
    process_dispose(&p);
    if (!out->s) buffer_text(out, "");
    return ok;
}
static unsigned short network16(unsigned short value) {
    return (unsigned short)((value << 8) | (value >> 8));
}
Socket listen_local(unsigned short *port) {
#ifdef SAM_WINDOWS
    void *init = allocate(512);
    int rc = WSAStartup(0x202, init);
    free(init);
    if (rc) return BAD_SOCKET;
#else
    signal(SIGPIPE, SIG_IGN);
#endif
    Socket fd = (Socket)socket(2, 1, 6);
    if (fd == BAD_SOCKET) return fd;
    Addr addr = {.family=2, .addr=0x0100007f, .port=network16(*port)};
    int len = sizeof(addr);
#ifdef SAM_WINDOWS
    SetHandleInformation((H)fd,1,0);
    int exclusive = 1;
    setsockopt(fd, 0xffff, ~4, &exclusive, sizeof(exclusive));
    int ok = !bind(fd, &addr, sizeof(addr)) && !listen(fd, 12) && !getsockname(fd, &addr, &len);
    DW nonblocking = 1;
    if (ok) ok = !ioctlsocket(fd, 0x8004667e, &nonblocking);
#else
    socklen_t addrlen = (socklen_t)len;
    int ok = !bind((int)fd, (void *)&addr, sizeof(addr)) && !listen((int)fd, 12) &&
        !getsockname((int)fd, (void *)&addr, &addrlen);
    if (ok) ok = !fcntl((int)fd, F_SETFL, O_NONBLOCK) && !fcntl((int)fd, F_SETFD, FD_CLOEXEC);
#endif
    if (!ok) { socket_close(fd); return BAD_SOCKET; }
    *port = network16(addr.port);
    return fd;
}
Socket accept_local(Socket server) {
#ifdef SAM_WINDOWS
    Socket fd = accept(server, NULL, NULL);
    if (fd != BAD_SOCKET) {
        SetHandleInformation((H)fd,1,0);
        DW zero = 0, timeout = 2500;
        ioctlsocket(fd, 0x8004667e, &zero);
        setsockopt(fd, 0xffff, 0x1006, &timeout, sizeof(timeout));
        setsockopt(fd, 0xffff, 0x1005, &timeout, sizeof(timeout));
    }
#else
    Socket fd = (Socket)accept4((int)server, NULL, NULL, SOCK_CLOEXEC);
    if (fd != BAD_SOCKET) {
        struct timeval timeout = {2,500000};
        setsockopt((int)fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
        setsockopt((int)fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    }
#endif
    return fd;
}
int socket_read(Socket fd, void *buffer, size_t size) {
#ifdef SAM_WINDOWS
    return recv(fd, buffer, (int)size, 0);
#else
    return (int)recv((int)fd, buffer, size, 0);
#endif
}
int socket_write(Socket fd, const void *buffer, size_t size) {
    const char *p = buffer;
    while (size) {
#ifdef SAM_WINDOWS
        int n = send(fd, p, (int)size, 0);
#else
        int n = (int)send((int)fd, p, size, MSG_NOSIGNAL);
#endif
        if (n <= 0) return 0;
        size -= (size_t)n;
        p += n;
    }
    return 1;
}
void socket_close(Socket fd) {
#ifdef SAM_WINDOWS
    closesocket(fd);
#else
    close((int)fd);
#endif
}
