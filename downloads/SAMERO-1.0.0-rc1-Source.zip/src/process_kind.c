#include "base.h"

static int daemon_path(const char *path) {
    const char *p=path;
    while (*p) {
        size_t n=strcspn(p,"/\\");
        if (n==17) {
            char name[18]; memcpy(name,p,n); name[n]=0;
            if (ascii_equal(name,"app-server-daemon")) return 1;
        }
        p+=n+(p[n]!=0);
    }
    return 0;
}
CodexKind classify_codex(const char *image,const char *const *argv,int argc,int managed) {
    if (managed) return CODEX_MANAGED;
    if (ascii_equal(base_name(image),"codex-code-mode-host.exe")) return CODEX_HOST;
    if (argc<1) return daemon_path(image)?CODEX_DAEMON:CODEX_UNKNOWN;
    for (int i=1;i<argc;++i) {
        const char *arg=argv[i];
        if (!strcmp(arg,"--")) break;
        if (!strcmp(arg,"app-server")) {
            for (int j=i+1;j<argc;++j)
                if (!strcmp(argv[j],"daemon")) return CODEX_DAEMON;
            return daemon_path(image)?CODEX_DAEMON:CODEX_SERVER;
        }
        if (!strcmp(arg,"app-server-daemon")) return CODEX_DAEMON;
        if (!strcmp(arg,"resume") || !strcmp(arg,"fork")) return CODEX_INTERACTIVE;
        if (!strcmp(arg,"exec") || !strcmp(arg,"e") || !strcmp(arg,"review")) return CODEX_BATCH;
        if (!strcmp(arg,"login") || !strcmp(arg,"logout") || !strcmp(arg,"mcp") ||
            !strcmp(arg,"completion") || !strcmp(arg,"--help") || !strcmp(arg,"--version")) return CODEX_UNKNOWN;
        if (!strcmp(arg,"-c") || !strcmp(arg,"-C") || !strcmp(arg,"--cd") ||
            !strcmp(arg,"--config") || !strcmp(arg,"--model") || !strcmp(arg,"-m") ||
            !strcmp(arg,"--profile") || !strcmp(arg,"-p") || !strcmp(arg,"--sandbox") ||
            !strcmp(arg,"-s") || !strcmp(arg,"--ask-for-approval") || !strcmp(arg,"-a")) { ++i; continue; }
        if (*arg!='-') break;
    }
    return CODEX_INTERACTIVE;
}
