#include "manager.h"

typedef struct {
    char branch[256], head[80], state[16];
    Buf changes, staged;
    size_t changes_count;
    Path binary;
} Git;
static void git_free(Git *g) { buffer_free(&g->changes); buffer_free(&g->staged); }
static int git_run(Git *git, const char *path, const char *const *command,
                   Buf *out, size_t max, int *code, Error *e) {
    const char *argv[24] = {"--no-optional-locks","-c","core.fsmonitor=false","-c","core.untrackedCache=false"};
    size_t i = 5;
    for (size_t j = 0; command[j] && i < ARRAY_LEN(argv)-1; ++j) argv[i++] = command[j];
    argv[i] = NULL;
    return run_capture(git->binary.p,argv,path,NULL,out,max,15000,code,e);
}
static void trim_eol(Buf *b) { if (b->s) b->s[b->n = strcspn(b->s,"\r\n")] = 0; }
static int git_status(Manager *m, const char *path, Git *g, Error *e) {
    Path *marker = allocate(sizeof(*marker));
    Info info;
    int marked = path_join(marker,path,".git") && file_info(marker->p,&info);
    free(marker);
    if (!find_git(m,&g->binary)) {
        strcpy(g->state,"Unknown");
        return marked ? errorf(e,"Dự án có Git. Hãy cài Git hoặc đặt đường dẫn git.exe.") : 1;
    }
    Buf raw = {0};
    int code = -1;
    const char *root_args[] = {"rev-parse","--show-toplevel",NULL};
    int ok = git_run(g,path,root_args,&raw,65536,&code,e);
    if (!ok) goto done;
    if (code) {
        strcpy(g->state,marked ? "Unknown" : "None");
        ok = !marked || errorf(e,"Git không đọc được repository. Kiểm tra quyền truy cập và cấu hình Git.");
        goto done;
    }
    trim_eol(&raw);
    Path *root = allocate(sizeof(*root));
    ok = canonical(raw.s,root) && within(root->p,path) && within(path,root->p);
    free(root); buffer_free(&raw);
    if (!ok) return errorf(e,"Chọn thư mục gốc repository hoặc gốc worktree Git.");
    strcpy(g->state,"Git");
    const char *branch[] = {"symbolic-ref","--quiet","--short","HEAD",NULL};
    ok = git_run(g,path,branch,&raw,16384,&code,e);
    if (!ok) goto done;
    trim_eol(&raw);
    sam_format(g->branch,sizeof(g->branch),"%s",code ? "(detached HEAD)" : secret_text(raw.s) ? "[redacted]" : raw.s);
    buffer_free(&raw);
    const char *head[] = {"rev-parse","--verify","HEAD",NULL};
    ok = git_run(g,path,head,&raw,16384,&code,e);
    if (!ok) goto done;
    trim_eol(&raw);
    if (!code && (raw.n == 40 || raw.n == 64) && strspn(raw.s,"abcdef0123456789") == raw.n)
        memcpy(g->head,raw.s,raw.n+1);
    buffer_free(&raw);
    const char *status[] = {"status","--porcelain=v1","-z","--untracked-files=all","--ignore-submodules=none","--",".",":(exclude).samero-handover",":(exclude).samero-staged",NULL};
    ok = git_run(g,path,status,&raw,16*MIB,&code,e) && !code;
    if (!ok) goto done;
    for (size_t pos = 0; pos < raw.n;) {
        char *line = raw.s + pos;
        size_t n = strlen(line);
        pos += n+1;
        if (n < 4 || line[2] != ' ') { ok = 0; break; }
        if (g->changes_count++) buffer_char(&g->changes,',');
        char status_code[3] = {line[0],line[1],0};
        buffer_char(&g->changes,'{'); json_pair(&g->changes,"status",status_code);
        KEY(&g->changes,"path",secret_text(line+3) ? "[redacted]" : line+3);
        if (strchr("RC",line[0]) || strchr("RC",line[1])) {
            if (pos >= raw.n) { ok = 0; break; }
            char *old = raw.s + pos;
            pos += strlen(old)+1;
            KEY(&g->changes,"from",secret_text(old) ? "[redacted]" : old);
        }
        buffer_char(&g->changes,'}');
        if (g->changes.n > MIB) { ok = 0; break; }
    }
    buffer_free(&raw);
    if (!ok) goto done;
    const char *cached[] = {"diff","--cached","--name-only","-z","--no-renames","--no-ext-diff",NULL};
    ok = git_run(g,path,cached,&g->staged,4*MIB,&code,e) && !code;
done:
    buffer_free(&raw);
    if (!ok && !e->msg[0]) errorf(e,"Không đọc được Git status hoặc dữ liệu quá lớn.");
    return ok;
}
static void git_json(Buf *b, const Git *g) {
    buffer_char(b,'{'); json_pair(b,"state",g->state);
    KEY(b,"branch",g->branch); KEY(b,"head",g->head); NUM(b,"count",g->changes_count);
    buffer_text(b,",\"changes\":[");
    if (g->changes.s) buffer_add(b,g->changes.s,g->changes.n);
    buffer_text(b,"]}");
}
static int protected_relative(const char *path) {
    for (const char *p=path; *p;) {
        size_t len=strcspn(p,"/");
        char name[256];
        if (!len || len >= sizeof(name)) return 1;
        memcpy(name,p,len); name[len]=0;
        if (credential_path(name) || secret_text(name) || !path_valid_component(name)) return 1;
        p+=len + (p[len]=='/');
    }
    return 0;
}
static int staged_files(Git *git, const char *path, Snapshot *s, Error *e) {
    size_t total = 0;
    for (size_t pos=0; pos < git->staged.n;) {
        const char *rel=git->staged.s+pos;
        pos+=strlen(rel)+1;
        if (protected_relative(rel)) { snapshot_exclude(s,rel,"protected staged path"); continue; }
        const char *list[]={"--literal-pathspecs","ls-files","--stage","-z","--",rel,NULL};
        Buf meta={0};
        int code=-1;
        int ok=git_run(git,path,list,&meta,65536,&code,e) && !code;
        if (!ok) { buffer_free(&meta); return 0; }
        for (size_t i=0; i<meta.n;) {
            const char *entry=meta.s+i;
            size_t size=strlen(entry);
            const char *first=strchr(entry,' '), *tab=strchr(entry,'\t');
            i+=size+1;
            if (!first || !tab || first>=tab || strcmp(tab+1,rel)) continue;
            const char *second=strchr(first+1,' ');
            if (!second || second+2!=tab || !strchr("0123",second[1])) continue;
            if ((size_t)(first-entry)!=6 || strncmp(entry,"100",3)) {
                snapshot_exclude(s,rel,"staged symlink or Git link"); continue;
            }
            char hash[65];
            size_t n=(size_t)(second-first-1);
            if (n!=40 && n!=64) { buffer_free(&meta); return errorf(e,"ID Git blob không hợp lệ."); }
            memcpy(hash,first+1,n); hash[n]=0;
            if (strspn(hash,"abcdef0123456789")!=n) { buffer_free(&meta); return errorf(e,"ID Git blob không hợp lệ."); }
            const char *blob[]={"cat-file","blob",hash,NULL};
            Buf bytes={0};
            ok=git_run(git,path,blob,&bytes,64*MIB,&code,e) && !code && total+bytes.n <= 128*MIB;
            total+=bytes.n;
            Path *name=allocate(sizeof(*name));
            int len=sam_format(name->p,sizeof(name->p),".samero-staged/%c/%s",second[1],rel);
            ok=ok && len>0 && len<PATH_CAP && snapshot_blob(s,name->p,&bytes,!strncmp(entry,"100755",6)?0755:0644,e);
            free(name); buffer_free(&bytes);
            if (!ok) { buffer_free(&meta); return e->msg[0] ? 0 : errorf(e,"Dữ liệu Git staged vượt giới hạn hoặc không đọc được."); }
        }
        buffer_free(&meta);
    }
    return 1;
}
static const char *note_keys[]={"goal","current","completed","pending","errors","architecture","next",
    "test","build","notes"};
static const char *note_labels[]={"Mục tiêu tổng thể","Mục tiêu hiện tại","Đã hoàn thành",
    "Chưa hoàn thành","Lỗi đang tồn tại","Quyết định kiến trúc","Công việc tiếp theo",
    "Kiểm thử","Build","Ghi chú bổ sung"};
static int project_save(Manager *m, const JSON *in, Buf *out, Error *e) {
    char id[33], name[256];
    ARG(in,"id",id);
    int editing=!!*id, ok=0;
    Document d={0};
    Path *paths=allocate(3*sizeof(*paths)), *input=&paths[0], *path=&paths[1], *old=&paths[2];
    if (editing) {
        if (!get_doc(m,"projects",id,&d,e)) goto done;
        FIELD(&d,"path",old->p);
    } else new_id(id);
    if (!safe_field(name,sizeof(name),in,"name") || !*name ||
        !safe_field(input->p,sizeof(input->p),in,"path") ||
        !open_directory(input->p,path) || !validate_project_path(m,path->p,id,e)) {
        errorf(e,"Chọn tên và một thư mục dự án hợp lệ, tách khỏi hồ sơ và dự án khác."); goto done;
    }
    if (editing && strcmp(old->p,path->p) && workspace_busy(m,old->p)) {
        errorf(e,"Đóng phiên trước khi thay đổi đường dẫn."); goto done;
    }
    ok=1;
    Buf record={0};
    buffer_char(&record,'{'); json_pair(&record,"id",id);
    KEY(&record,"name",name); KEY(&record,"path",path->p); NUM(&record,"updated",timestamp());
    char *note=allocate(16001);
    for (size_t i=0; i<ARRAY_LEN(note_keys) && ok; ++i) {
        if (editing && json_get(in,0,note_keys[i])<0) {
            int previous=json_get(&d.data,0,note_keys[i]);
            if (previous>=0) { buffer_char(&record,','); json_key(&record,note_keys[i]); json_raw(&record,&d.data,previous); }
            else { KEY(&record,note_keys[i],""); }
        } else {
            ok=safe_field(note,16001,in,note_keys[i]);
            if (ok) { KEY(&record,note_keys[i],note); }
        }
    }
    free(note);
    buffer_char(&record,'}');
    if (ok) ok=put_doc(m,"projects",id,&record,e);
    else errorf(e,"Ghi chú quá dài hoặc chứa dữ liệu xác thực. Hãy xóa phần nhạy cảm.");
    if (ok) { buffer_char(out,'{'); json_pair(out,"id",id); buffer_char(out,'}'); }
    buffer_free(&record);
done:
    doc_free(&d); free(paths);
    return ok;
}
static int project_data(Manager *m, const char *id, Document *d, Path *path, Error *e) {
    if (!get_doc(m,"projects",id,d,e)) return 0;
    Path *resolve=allocate(sizeof(*resolve));
    int ok=FIELD(d,"path",path->p) && open_directory(path->p,resolve) && within(path->p,resolve->p) && within(resolve->p,path->p);
    free(resolve);
    if (ok) return 1;
    doc_free(d);
    return errorf(e,"Workspace không còn tồn tại hoặc đã đổi đường dẫn.");
}
static int project_details(Manager *m,const JSON *in,Buf *out,Error *e);
static int create_status(Manager *m,const JSON *in,Buf *out,Error *e);
int projects_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e) {
    if (!strcmp(action,"project-details")) return project_details(m,in,out,e);
    if (!strcmp(action,"project-create-status")) return create_status(m,in,out,e);
    if (!strcmp(action,"project-save")) return project_save(m,in,out,e);
    if (!strcmp(action,"project-status")) {
        char id[33]; ARG(in,"project",id);
        Document d;
        Path *p=allocate(sizeof(*p));
        int ok=project_data(m,id,&d,p,e);
        if (ok) {
            Git *g=allocate(sizeof(*g));
            ok=git_status(m,p->p,g,e);
            if (ok) git_json(out,g);
            git_free(g); free(g); doc_free(&d);
        }
        free(p); return ok;
    }
    return errorf(e,"Thao tác dự án không tồn tại.");
}

typedef struct { char **entries; size_t size, cap; } Roots;
static void add_root(Roots *r, const char *path) {
    if (r->size==r->cap) {
        r->cap=r->cap ? r->cap*2 : 8;
        r->entries=realloc(r->entries,r->cap*sizeof(*r->entries));
        if (!r->entries) abort();
    }
    char *copy=allocate(strlen(path)+1); strcpy(copy,path);
    r->entries[r->size++]=copy;
}
static int add_home(const char *id, Document *d, void *ctx, Error *e) {
    Path *p=allocate(sizeof(*p));
    if (FIELD(d,"home",p->p)) add_root(ctx,p->p);
    free(p); (void)id; (void)e;
    return 1;
}
static void free_roots(Roots *r) {
    for(size_t i=0;i<r->size;++i) free(r->entries[i]);
    free(r->entries);
}
static int scan_project(Manager *m, const char *workspace, Git *git, Snapshot *s, char digest[65], Error *e) {
    Roots r={0};
    add_root(&r,m->data.p); add_root(&r,m->backup.p);
    int ok=each_doc(m,"profiles",add_home,&r,e);
    s->roots=(const char *const *)r.entries; s->root_count=r.size; s->cache_names=m->caches;
    ok=ok && git_status(m,workspace,git,e) && snapshot_walk(s,workspace,e) && staged_files(git,workspace,s,e);
    if (ok) {
        char files[65];
        snapshot_fingerprint(s,files);
        Sha256 sha={0};
        sha_update(&sha,files,sizeof(files));
        sha_update(&sha,git->head,strlen(git->head)+1);
        sha_update(&sha,git->branch,strlen(git->branch)+1);
        sha_update(&sha,git->changes.s,git->changes.n);
        sha_update(&sha,git->staged.s,git->staged.n);
        sha_update(&sha,s->excluded.s,s->excluded.n);
        sha_finish(&sha,digest);
    }
    s->roots=NULL; s->root_count=0;
    free_roots(&r);
    return ok;
}
static int snapshot_unchanged(Manager *m, const char *workspace, const char *fingerprint, Error *e) {
    Snapshot s={0};
    Git *git=allocate(sizeof(*git));
    char actual[65];
    int ok=scan_project(m,workspace,git,&s,actual,e);
    if (ok && strcmp(fingerprint,actual))
        ok=errorf(e,"Workspace hoặc Git index đã thay đổi. Hãy tạo checkpoint mới.");
    git_free(git); free(git); snapshot_free(&s);
    return ok;
}
static int write_named(const char *directory, const char *filename, const Buf *b, Error *e) {
    Path *p=allocate(sizeof(*p));
    int ok=path_join(p,directory,filename) && write_atomic(p->p,b->s,b->n,e);
    free(p); return ok;
}
static void named_digest(const Buf *data, char hex[65]) {
    Sha256 sha={0};
    sha_update(&sha,data->s,data->n); sha_finish(&sha,hex);
}
typedef struct {
    const char *project;
    long long timestamp[2], code[2];
    char status[2][24], id[2][33];
} CheckRuns;
static int find_check_run(const char *id, Document *d, void *ctx, Error *e) {
    CheckRuns *checks=ctx;
    char owner[33], kind[20], status[24];
    if (!FIELD(d,"project",owner) || strcmp(owner,checks->project) || !FIELD(d,"kind",kind) ||
        !FIELD(d,"status",status)) return 1;
    int i=!strcmp(kind,"build") ? 0 : !strcmp(kind,"test") ? 1 : -1;
    long long at=NUMBER(&d->data,"ended",-1), code=NUMBER(&d->data,"exitCode",-1);
    if (i>=0 && at>=0 && at>=checks->timestamp[i] && code>=0) {
        checks->timestamp[i]=at; checks->code[i]=code;
        strcpy(checks->id[i],id); strcpy(checks->status[i],status);
    }
    (void)e;
    return 1;
}
static int markdown_text(const char *workspace,const char *name,Buf *text,const char **state) {
    Path *path=allocate(sizeof(*path));
    Info info;
    int found=path_join(path,workspace,name) && file_info(path->p,&info);
    *state="missing";
    int ok=0;
    if (found) {
        Error e={0};
        *state="unavailable";
        if (info.kind==1 && read_file(path->p,96*1024,text,&e) &&
            text_utf8(text->s,text->n) && !secret_text(text->s)) {
            *state="available"; ok=1;
        }
    }
    free(path);
    return ok;
}

static void emit_checks(Buf *out,const CheckRuns *runs) {
    buffer_char(out,'{');
    for (int i=0;i<2;++i) {
        if (i) buffer_char(out,',');
        json_key(out,i?"test":"build");
        if (!runs->id[i][0]) { buffer_text(out,"null"); continue; }
        buffer_char(out,'{'); json_pair(out,"session",runs->id[i]); KEY(out,"status",runs->status[i]);
        NUM(out,"exitCode",runs->code[i]); NUM(out,"endedAt",runs->timestamp[i]); buffer_char(out,'}');
    }
    buffer_char(out,'}');
}
static int project_details(Manager *m,const JSON *in,Buf *out,Error *e) {
    char id[33]; ARG(in,"project",id);
    Document d;
    Path *p=allocate(2*sizeof(*p)), *path=&p[0], *config=&p[1];
    if (!project_data(m,id,&d,path,e)) { free(p); return 0; }
    CheckRuns runs={.project=id};
    if (!each_doc(m,"sessions",find_check_run,&runs,e)) { doc_free(&d); free(p); return 0; }
    Git *git=allocate(sizeof(*git));
    Error ge={0};
    int read_git=git_status(m,path->p,git,&ge);
    buffer_char(out,'{'); json_pair(out,"project",id);
    KEY(out,"gitError",read_git?"":ge.msg);
    RAW(out,"git",""); if (read_git) git_json(out,git); else buffer_text(out,"null");
    RAW(out,"checks",""); emit_checks(out,&runs);
    const char *docs[]={"PROJECT_STATUS.md","CODEX_HANDOVER.md","TASK_QUEUE.json"};
    buffer_text(out,",\"documents\":{");
    for (size_t i=0;i<ARRAY_LEN(docs);++i) {
        const char *state;
        Buf text={0};
        int loaded=markdown_text(path->p,docs[i],&text,&state);
        if (i) buffer_char(out,',');
        json_key(out,docs[i]); buffer_char(out,'{'); json_pair(out,"state",state);
        KEY(out,"content",loaded?text.s:""); buffer_char(out,'}');
        buffer_free(&text);
    }
    static const char *files[]={"AGENTS.md","README.md","package.json","pyproject.toml","requirements.txt","Cargo.toml",
        "go.mod","pom.xml","build.gradle","CMakeLists.txt","Makefile","Dockerfile","tsconfig.json","global.json"};
    buffer_text(out,"},\"configFiles\":[");
    int count=0;
    for (size_t i=0;i<ARRAY_LEN(files);++i) {
        Info info;
        if (path_join(config,path->p,files[i]) && file_info(config->p,&info) && info.kind==1) {
            if (count++) buffer_char(out,',');
            json_quote(out,files[i]);
        }
    }
    buffer_text(out,"]}");
    git_free(git); free(git); doc_free(&d); free(p);
    return 1;
}
static int create_status(Manager *m,const JSON *in,Buf *out,Error *e) {
    char id[33], name[256]; ARG(in,"project",id);
    Document d;
    Path *p=allocate(2*sizeof(*p));
    if (!project_data(m,id,&d,p,e)) { free(p); return 0; }
    int ok=0;
    if (workspace_busy(m,p[0].p)) errorf(e,"Hãy đóng phiên đang ghi vào workspace trước khi tạo tệp trạng thái.");
    else if (path_join(&p[1],p[0].p,"PROJECT_STATUS.md")) {
        FIELD(&d,"name",name);
        Buf markdown={0};
        buffer_fmt(&markdown,"# PROJECT_STATUS\n\n%s\n\n## Tiến độ\n\n## Công việc tiếp theo\n\n## Build / Test\n",name);
        ok=write_new_atomic(p[1].p,markdown.s,markdown.n,e);
        if (ok) { buffer_char(out,'{'); json_pair(out,"path",p[1].p); buffer_char(out,'}'); }
        else errorf(e,"Không tạo được PROJECT_STATUS.md. Tệp hiện có được giữ nguyên.");
        buffer_free(&markdown);
    }
    doc_free(&d); free(p); return ok;
}
static void generate_reports(Document *project, Document *source, const Git *git, const char *workspace,
                             const Snapshot *s, const char *id, const char *dest, const char *checksum,
                             const char *fingerprint, long long created, const CheckRuns *runs, Buf *status, Buf *md, Buf *json) {
    char title[256], source_id[33], source_profile[33], state[24];
    FIELD(project,"name",title); FIELD(source,"id",source_id);
    FIELD(source,"profile",source_profile); FIELD(source,"status",state);
    buffer_fmt(status,"# PROJECT_STATUS\n\n**%s**\n\nWorkspace `%s`\n\n",title,workspace);
    Buf current={0};
    const char *status_file;
    if (markdown_text(workspace,"PROJECT_STATUS.md",&current,&status_file)) {
        buffer_text(status,"## Nội dung từ PROJECT_STATUS.md trong dự án\n\n");
        buffer_add(status,current.s,current.n); buffer_text(status,"\n\n");
    }
    buffer_free(&current);
    buffer_char(json,'{'); json_key(json,"schemaVersion"); buffer_text(json,"1");
    KEY(json,"project",title); KEY(json,"workspace",workspace);
    KEY(json,"checkpoint",id); KEY(json,"sourceSession",source_id); KEY(json,"sourceProfile",source_profile);
    KEY(json,"destinationProfile",dest); KEY(json,"sourceStatus",state);
    NUM(json,"createdAt",created); NULLNUM(json,"sourceExitCode",NUMBER(&source->data,"exitCode",-1));
    KEY(json,"zipSha256",checksum); KEY(json,"workspaceFingerprint",fingerprint);
    NUM(json,"archivedEntries",s->n); NUM(json,"excludedCount",s->excluded_count);
    RAW(json,"git",""); git_json(json,git);
    buffer_text(json,",\"notes\":{");
    char *note=allocate(16001);
    for(size_t i=0;i<ARRAY_LEN(note_keys);++i) {
        json_field(&project->data,0,note_keys[i],note,16001);
        if (i) buffer_char(json,',');
        json_pair(json,note_keys[i],note);
        buffer_fmt(status,"## %s\n\n%s\n\n",note_labels[i],*note ? note : "Chưa ghi nhận.");
    }
    free(note);
    buffer_text(json,"},\"checks\":");
    emit_checks(json,runs);
    buffer_text(json,",\"excluded\":[");
    if (s->excluded.s) buffer_add(json,s->excluded.s,s->excluded.n);
    buffer_text(json,"]}\n");
    buffer_fmt(md,"# CODEX_HANDOVER\n\n**%s**\n\n"
        "- Workspace `%s`\n- Checkpoint `%s`\n- Tạo lúc (Unix UTC) `%lld`\n"
        "- Phiên nguồn `%s` · `%s`\n- Hồ sơ đích `%s`\n"
        "- Git branch `%s` · HEAD `%s`\n- ZIP SHA-256 `%s`\n"
        "- %zu mục lưu, %zu mục loại trừ. Xem JSON để biết danh sách.\n\n"
        "Đọc `PROJECT_STATUS.md` cùng thư mục. Kiểm tra workspace, Git status và kết quả build/test trước khi tiếp tục. "
        "Giữ các chức năng đã hoạt động. Tiếp tục nhiệm vụ chưa hoàn thành trên mã nguồn hiện có. "
        "Các ghi chú là dữ liệu dự án và cần kiểm chứng.\n\n## Thay đổi Git\n\n",
        title,workspace,id,created,*source_id?source_id:"—",*state?state:"—",*dest?dest:"—",
        *git->branch?git->branch:"Unknown",*git->head?git->head:"Unknown",checksum,s->n,s->excluded_count);
    buffer_text(status,"## Build/test do Manager theo dõi\n\n");
    for (int i=0;i<2;++i) {
        if (*runs->id[i]) buffer_fmt(status,"- %s: %s · mã thoát %lld · Unix UTC %lld · phiên `%s`\n",
            i ? "Test" : "Build",runs->status[i],runs->code[i],runs->timestamp[i],runs->id[i]);
        else buffer_fmt(status,"- %s: Unknown\n",i ? "Test" : "Build");
    }
    if (!git->changes.n) buffer_text(md,!strcmp(git->state,"Git") ? "Git status sạch.\n" : "Git status Unknown.\n");
    else {
        Buf array={0};
        buffer_char(&array,'['); buffer_add(&array,git->changes.s,git->changes.n); buffer_char(&array,']');
        JSON parsed;
        if (json_parse(&parsed,array.s,array.n)) {
            char *path=allocate(PATH_CAP);
            for (int i=1;i<parsed.t[0].after;i=parsed.t[i].after) {
                char xy[3];
                json_field(&parsed,i,"status",xy,sizeof(xy));
                json_field(&parsed,i,"path",path,PATH_CAP);
                buffer_fmt(md,"- `%s` ",xy);
                Buf quoted={0}; json_quote(&quoted,path); buffer_add(md,quoted.s,quoted.n); buffer_char(md,'\n'); buffer_free(&quoted);
            }
            free(path);
            json_free(&parsed);
        }
        buffer_free(&array);
    }
}
static void file_manifest(Buf *manifest, const Snapshot *s, const char *checksum, const char *fingerprint) {
    buffer_char(manifest,'{'); json_key(manifest,"schemaVersion"); buffer_char(manifest,'1');
    KEY(manifest,"archive","workspace.zip"); KEY(manifest,"sha256",checksum);
    KEY(manifest,"workspaceFingerprint",fingerprint);
    NUM(manifest,"excludedCount",s->excluded_count);
    buffer_text(manifest,",\"files\":[");
    for (size_t i=0;i<s->n;++i) {
        Entry *x=&s->entries[i];
        if(i) buffer_char(manifest,',');
        buffer_char(manifest,'{'); json_pair(manifest,"path",x->name);
        KEY(manifest,"kind",x->info.kind==2?"directory":"file");
        if (x->info.kind==1) { NUM(manifest,"size",x->info.size); KEY(manifest,"sha256",x->sha); }
        buffer_char(manifest,'}');
    }
    buffer_text(manifest,"],\"excluded\":[");
    if (s->excluded.s) buffer_add(manifest,s->excluded.s,s->excluded.n);
    buffer_text(manifest,"]}\n");
}
static int verify_named(const char *dir, const char *name, const char *expected, Error *e);
static int checkpoint_create(Manager *m, const JSON *in, Buf *out, int handover, Error *e) {
    char project_id[33], source_id[33], dest[33], session_project[33], source_profile[33], id[33], source_kind[20];
    ARG(in,"project",project_id); ARG(in,"source",source_id); ARG(in,"destination",dest);
    Document project={0}, source={0}, target={0};
    Path *p=allocate(7*sizeof(*p)), *workspace=&p[0], *dir=&p[1], *zip=&p[2], *root=&p[3],
        *handover_dir=&p[4], *handover_root=&p[5], *temp=&p[6];
    Buf report={0}, md={0}, json={0}, manifest={0}, record={0};
    Git *git=allocate(sizeof(*git));
    Snapshot snapshot={0};
    int ok=0, prepared_dir=0, published_dir=0;
    if (!YES(in,"quiet")) { errorf(e,"Xác nhận đã đóng tác vụ ghi trong và ngoài Manager."); goto done; }
    if (!project_data(m,project_id,&project,workspace,e)) goto done;
    if (workspace_busy(m,workspace->p)) { errorf(e,"Workspace vẫn có tiến trình. Thoát Codex và chờ cây tiến trình dừng."); goto done; }
    if (!guarded_resume(m,"","","",workspace->p,e)) goto done;
    if (handover) {
        if (!get_doc(m,"profiles",dest,&target,e)) goto done;
        if (*source_id && (!get_doc(m,"sessions",source_id,&source,e) ||
            !FIELD(&source,"kind",source_kind) || (strcmp(source_kind,"codex") && strcmp(source_kind,"chat") && strcmp(source_kind,"imported")) ||
            !FIELD(&source,"project",session_project) || strcmp(session_project,project_id) ||
            !FIELD(&source,"profile",source_profile) || !strcmp(source_profile,dest) ||
            !FIELD(&source,"workspace",temp->p) || !within(workspace->p,temp->p) || !within(temp->p,workspace->p))) {
            errorf(e,"Chọn phiên nguồn thuộc workspace này và một hồ sơ đích khác."); goto done;
        }
    } else { dest[0]=0; source_id[0]=0; }
    if (!mkdir_tree(m->backup.p) || !open_directory(m->backup.p,root) ||
        !within(m->backup.p,root->p) || !within(root->p,m->backup.p) ||
        within(workspace->p,root->p) || within(root->p,workspace->p)) {
        errorf(e,"Thư mục sao lưu không hợp lệ hoặc xung đột với workspace."); goto done;
    }
    char fingerprint[65], checksum[65], report_hash[65], md_hash[65], json_hash[65], manifest_hash[65];
    if (!scan_project(m,workspace->p,git,&snapshot,fingerprint,e)) goto done;
    if (!m->runner_internal || !ARG(in,"reservedId",id) || !valid_id(id)) new_id(id);
    char folder[80];
    long long created=timestamp();
    sam_format(folder,sizeof(folder),"%lld-%s",created,id);
    if (!path_join(dir,root->p,folder) || !mkdir_new(dir->p)) { errorf(e,"Không tạo được thư mục checkpoint."); goto done; }
    prepared_dir=1;
    if (!path_join(zip,dir->p,"workspace.zip") || !archive_write(&snapshot,workspace->p,zip->p,e) ||
        !archive_read(zip->p,NULL,e) || !digest_file(zip->p,checksum,e) ||
        !snapshot_unchanged(m,workspace->p,fingerprint,e)) goto done;
    CheckRuns runs={.project=project_id};
    if (!each_doc(m,"sessions",find_check_run,&runs,e)) goto done;
    generate_reports(&project,&source,git,workspace->p,&snapshot,id,dest,checksum,fingerprint,created,&runs,&report,&md,&json);
    file_manifest(&manifest,&snapshot,checksum,fingerprint);
    named_digest(&report,report_hash); named_digest(&md,md_hash); named_digest(&json,json_hash); named_digest(&manifest,manifest_hash);
    if (!write_named(dir->p,"MANIFEST.json",&manifest,e) ||
        !write_named(dir->p,"CODEX_HANDOVER.json",&json,e) ||
        !write_named(dir->p,"CODEX_HANDOVER.md",&md,e) ||
        !write_named(dir->p,"PROJECT_STATUS.md",&report,e) ||
        !verify_named(dir->p,"MANIFEST.json",manifest_hash,e) ||
        !verify_named(dir->p,"CODEX_HANDOVER.json",json_hash,e) ||
        !verify_named(dir->p,"CODEX_HANDOVER.md",md_hash,e) ||
        !verify_named(dir->p,"PROJECT_STATUS.md",report_hash,e)) goto done;
    if (handover) {
        if (!path_join(handover_root,workspace->p,".samero-handover") ||
            !mkdir_tree(handover_root->p) || !path_join(handover_dir,handover_root->p,id) || !mkdir_new(handover_dir->p)) {
            errorf(e,"Không tạo được thư mục bàn giao riêng trong workspace."); goto done;
        }
        published_dir=1;
        if (!write_named(handover_dir->p,"CODEX_HANDOVER.json",&json,e) ||
            !write_named(handover_dir->p,"CODEX_HANDOVER.md",&md,e) ||
            !write_named(handover_dir->p,"PROJECT_STATUS.md",&report,e) ||
            !verify_named(handover_dir->p,"CODEX_HANDOVER.json",json_hash,e) ||
            !verify_named(handover_dir->p,"CODEX_HANDOVER.md",md_hash,e) ||
            !verify_named(handover_dir->p,"PROJECT_STATUS.md",report_hash,e)) goto done;
    }
    buffer_char(&record,'{'); json_pair(&record,"id",id);
    KEY(&record,"project",project_id); KEY(&record,"workspace",workspace->p); KEY(&record,"directory",dir->p);
    KEY(&record,"handoverDir",handover_dir->p); KEY(&record,"source",source_id); KEY(&record,"destination",dest);
    /* scan_project sorted the entries and already hashed their bytes. Exclude
       manager-generated progress files so advancing a revision is not work. */
    Sha256 content={0}; char source_hash[65];
    for (size_t i=0;i<snapshot.n;++i) {
        Entry *x=&snapshot.entries[i];
        if (!strcmp(x->name,"TASK_QUEUE.json") || !strcmp(x->name,"PROJECT_STATUS.md") ||
            !strncmp(x->name,".samero-handover/",16) || !strcmp(x->name,".samero-handover")) continue;
        sha_update(&content,x->name,strlen(x->name)+1);
        sha_update(&content,x->sha,sizeof(x->sha)); sha_update(&content,&x->info.mode,sizeof(x->info.mode));
    }
    sha_finish(&content,source_hash); KEY(&record,"sourceHash",source_hash);
    KEY(&record,"sha256",checksum); KEY(&record,"fingerprint",fingerprint);
    KEY(&record,"statusHash",report_hash); KEY(&record,"mdHash",md_hash);
    KEY(&record,"jsonHash",json_hash); KEY(&record,"manifestHash",manifest_hash);
    NUM(&record,"at",created); NUM(&record,"files",snapshot.n); NUM(&record,"excluded",snapshot.excluded_count);
    RAW(&record,"handover",handover ? "true" : "false"); buffer_char(&record,'}');
    ok=put_doc(m,"checkpoints",id,&record,e);
    if (ok) buffer_add(out,record.s,record.n);
done:
    if (!ok) {
        const char *names[]={"workspace.zip","MANIFEST.json","CODEX_HANDOVER.json","CODEX_HANDOVER.md","PROJECT_STATUS.md"};
        for (size_t i=0;i<ARRAY_LEN(names);++i) {
            if (prepared_dir && path_join(temp,dir->p,names[i])) remove_file(temp->p);
            if (published_dir && i>=2 && path_join(temp,handover_dir->p,names[i])) remove_file(temp->p);
        }
        if (prepared_dir) remove_dir(dir->p);
        if (published_dir) remove_dir(handover_dir->p);
        if (!e->msg[0]) errorf(e,"Không tạo được checkpoint nhất quán.");
    }
    snapshot_free(&snapshot); git_free(git); free(git);
    doc_free(&project); doc_free(&source); doc_free(&target);
    buffer_free(&report); buffer_free(&md); buffer_free(&json); buffer_free(&manifest); buffer_free(&record); free(p);
    return ok;
}
static int verify_named(const char *dir, const char *name, const char *expected, Error *e) {
    Path *p=allocate(sizeof(*p));
    char current[65];
    int ok=path_join(p,dir,name) && digest_file(p->p,current,e) && !strcmp(expected,current);
    free(p);
    return ok || errorf(e,"SHA-256 không khớp hoặc thiếu tệp: %s",name);
}
static int secure_dir(const char *dir) {
    Path *p=allocate(sizeof(*p));
    int ok=open_directory(dir,p) && within(dir,p->p) && within(p->p,dir);
    free(p); return ok;
}
static int verify_reports(Document *d, const char *dir, int manifest, Error *e) {
    const char *keys[]={"statusHash","mdHash","jsonHash","manifestHash"};
    const char *files[]={"PROJECT_STATUS.md","CODEX_HANDOVER.md","CODEX_HANDOVER.json","MANIFEST.json"};
    if (!secure_dir(dir)) return errorf(e,"Thư mục checkpoint không còn hợp lệ.");
    for (size_t i=0;i<(manifest ? 4u : 3u);++i) {
        char hash[65];
        if (!json_field(&d->data,0,keys[i],hash,sizeof(hash)) || !verify_named(dir,files[i],hash,e)) return 0;
    }
    return 1;
}
static int load_preview(const char *dir, Buf *out, Error *e) {
    Path *p=allocate(sizeof(*p));
    Buf md={0}, status={0}, json={0};
    int ok=path_join(p,dir,"CODEX_HANDOVER.md") && read_file(p->p,4*MIB,&md,e) &&
        path_join(p,dir,"PROJECT_STATUS.md") && read_file(p->p,MIB,&status,e) &&
        path_join(p,dir,"CODEX_HANDOVER.json") && read_file(p->p,4*MIB,&json,e);
    if (ok) {
        buffer_char(out,'{'); json_pair(out,"markdown",md.s); KEY(out,"status",status.s);
        KEY(out,"json",json.s); buffer_char(out,'}');
    }
    free(p); buffer_free(&md); buffer_free(&status); buffer_free(&json);
    return ok;
}
int checkpoint_action(Manager *m, const char *action, const JSON *in, Buf *out, Error *e) {
    if (!strcmp(action,"checkpoint-backup")) return checkpoint_create(m,in,out,0,e);
    if (!strcmp(action,"checkpoint-prepare")) return checkpoint_create(m,in,out,1,e);
    char id[33], sum[65], project[33], dest[33];
    ARG(in,"id",id);
    Document check;
    if (!get_doc(m,"checkpoints",id,&check,e)) return 0;
    Path *p=allocate(6*sizeof(*p)), *dir=&p[0], *zip=&p[1], *input=&p[2], *restore=&p[3], *workspace=&p[4], *hand=&p[5];
    int ok=0;
    FIELD(&check,"directory",dir->p); FIELD(&check,"sha256",sum);
    FIELD(&check,"workspace",workspace->p); FIELD(&check,"handoverDir",hand->p);
    FIELD(&check,"project",project); FIELD(&check,"destination",dest);
    if (!verify_reports(&check,dir->p,1,e) || !path_join(zip,dir->p,"workspace.zip")) goto done;
    if (!strcmp(action,"checkpoint-preview")) { ok=load_preview(dir->p,out,e); goto done; }
    if (!verify_named(dir->p,"workspace.zip",sum,e) || !archive_read(zip->p,NULL,e)) goto done;
    if (!strcmp(action,"checkpoint-verify")) { buffer_text(out,"{\"verified\":true}"); ok=1; goto done; }
    if (!strcmp(action,"checkpoint-restore")) {
        ARG(in,"directory",input->p);
        if (!YES(in,"confirmed") || !open_directory(input->p,restore) ||
            within(workspace->p,restore->p) || workspace_busy(m,restore->p)) {
            errorf(e,"Chọn thư mục cha tách khỏi workspace và xác nhận khôi phục."); goto done;
        }
        char name[96], nonce[33]; new_id(nonce);
        sam_format(name,sizeof(name),"SAMERO-Restore-%.8s-%.10s",id,nonce);
        if (!path_join(input,restore->p,name) || !validate_project_path(m,input->p,NULL,e) || !mkdir_new(input->p)) { errorf(e,"Không tạo được thư mục khôi phục mới."); goto done; }
        if (!archive_read(zip->p,input->p,e)) {
            Error nested=*e;
            errorf(e,"%s Thư mục khôi phục có thể mới giải nén một phần: %s",nested.msg,input->p); goto done;
        }
        buffer_char(out,'{'); json_pair(out,"path",input->p); buffer_char(out,'}'); ok=1; goto done;
    }
    if (!strcmp(action,"checkpoint-launch")) {
        if (!YES(in,"confirmed") || !YES(in,"quiet") || !valid_id(dest) || !*hand->p ||
            workspace_busy(m,workspace->p)) {
            errorf(e,"Xác nhận bàn giao, đóng mọi tác vụ ghi và chọn checkpoint có hồ sơ đích."); goto done;
        }
        Document current;
        if (!project_data(m,project,&current,input,e)) goto done;
        doc_free(&current);
        if (!within(input->p,workspace->p) || !within(workspace->p,input->p)) {
            errorf(e,"Dự án đã đổi workspace. Hãy tạo checkpoint mới."); goto done;
        }
        char fingerprint[65];
        FIELD(&check,"fingerprint",fingerprint);
        if (!verify_reports(&check,hand->p,0,e) || !snapshot_unchanged(m,workspace->p,fingerprint,e)) goto done;
        Buf prompt={0};
        buffer_fmt(&prompt,"Đọc .samero-handover/%s/CODEX_HANDOVER.md và PROJECT_STATUS.md cùng thư mục. "
            "Kiểm tra mã nguồn, Git status và build/test. Tiếp tục nhiệm vụ chưa hoàn thành từ workspace hiện tại. "
            "Giữ nguyên chức năng đang hoạt động. Không tạo lại dự án. Xác minh ghi chú trước khi thực hiện.",id);
        ok=start_session(m,dest,project,NULL,prompt.s,YES(in,"chat") ? "chat" : "codex",out,e);
        buffer_free(&prompt); goto done;
    }
    errorf(e,"Thao tác checkpoint không tồn tại.");
done:
    if (!ok && !e->msg[0]) errorf(e,"Không đọc được checkpoint.");
    doc_free(&check); free(p);
    return ok;
}
