#include "manager.h"

/* Volatile observations. An old sample starts as cached on every launch. */
struct QuotaWatch {
    char profile[33];
    long long due, attempted, verified;
    unsigned failures, revision;
    int offline;
    struct QuotaWatch *next;
};

static QuotaWatch *find(Manager *m,const char *profile) {
    for (QuotaWatch *w=m->watches;w;w=w->next)
        if (!strcmp(w->profile,profile)) return w;
    return NULL;
}
void quota_forget(Manager *m,const char *profile) {
    for (QuotaWatch **link=&m->watches;*link;link=&(*link)->next) {
        QuotaWatch *w=*link;
        if (!strcmp(w->profile,profile)) { *link=w->next; free(w); return; }
    }
}
void quota_register(Manager *m,const char *profile) {
    quota_forget(m,profile);
    QuotaWatch *w=allocate(sizeof(*w));
    strcpy(w->profile,profile); w->next=m->watches; m->watches=w;
    w->due=timestamp()+2;
}
static int register_existing(const char *id,Document *doc,void *ctx,Error *e) {
    quota_register(ctx,id); (void)doc; (void)e; return 1;
}
void quota_dispose(Manager *m) {
    while (m->watches) quota_forget(m,m->watches->profile);
}
void quota_init(Manager *m) {
    Error ignored={0}; each_doc(m,"profiles",register_existing,m,&ignored);
}
long long quota_verified(Manager *m,const char *id) {
    QuotaWatch *w=find(m,id); return w && !w->offline?w->verified:0;
}
unsigned quota_revision(Manager *m,const char *id) {
    QuotaWatch *w=find(m,id); return w?w->revision:0;
}
void quota_due(Manager *m,const char *id,int urgent) {
    QuotaWatch *w=find(m,id);
    if (w && (urgent || timestamp()-w->attempted>=15)) w->due=0;
}
void quota_observed(Manager *m,const char *id,const JSON *sample,int offline) {
    QuotaWatch *w=find(m,id);
    if (!w) return;
    long long now=timestamp();
    w->revision++; w->attempted=now; w->offline=offline;
    if (offline) {
        if (w->failures<5) ++w->failures;
        w->due=now+(30LL<<(w->failures-1));
        return;
    }
    w->failures=0; w->due=now+300;
    w->verified=sample?NUMBER(sample,"at",now):0;
    if (sample) {
        const char *keys[]={"hr","wr"};
        for (size_t i=0;i<ARRAY_LEN(keys);++i) {
            long long reset=NUMBER(sample,keys[i],0);
            if (reset>now && reset<w->due) w->due=reset;
            if (reset>0 && reset<=now && w->due>now+30) w->due=now+30;
        }
    }
}
void quota_emit(Manager *m,Buf *out) {
    buffer_text(out,",\"quotaSync\":[");
    for (QuotaWatch *w=m->watches;w;w=w->next) {
        if (w!=m->watches) buffer_char(out,',');
        buffer_char(out,'{'); json_pair(out,"profile",w->profile);
        NUM(out,"verified",w->verified); NUM(out,"attempted",w->attempted);
        RAW(out,"offline",w->offline?"true":"false"); buffer_char(out,'}');
    }
    buffer_char(out,']');
}
void quota_tick(Manager *m) {
    long long now=timestamp(),last=m->quota_tick;
    if (now==last) return;
    m->quota_tick=now;
    for (QuotaWatch *w=m->watches;w;w=w->next) {
        if (last && (now-last>60 || now<last)) w->due=0;
        if (w->due>now) continue;
        int owned=chat_quota_refresh(m,w->profile);
        if (!owned && !quota_background_worker(m,w->profile)) continue;
        w->attempted=now;
        w->due=now+(owned<0?10:60);
    }
}
