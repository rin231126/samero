#include "manager.h"

/* The reviewer may review rule prompts. Requests for sandbox escapes, new
   permissions, network/tool prompts and skill escalation are not delegated. */
const char review_policy[]="{\"granular\":{\"sandbox_approval\":false,\"rules\":true,\"mcp_elicitations\":false,\"request_permissions\":false,\"skill_approval\":false}}";
const char review_config[]="{\"sandbox_workspace_write\":{\"writable_roots\":[],\"network_access\":false,\"exclude_tmpdir_env_var\":true,\"exclude_slash_tmp\":true}}";

static int bool_is(const JSON *j,int o,const char *key,int value,int optional) {
    int t=json_get(j,o,key);
    return t<0?optional:j->t[t].type==(value?'t':'f');
}
int review_granular_ok(const JSON *j,int g) {
    if (!bool_is(j,g,"rules",1,0)) return 0;
    /* Reject any newly introduced enabled granular category as well. */
    for (int t=g+1;t<j->t[g].after;t=j->t[t+1].after) {
        char key[80];
        if (!json_string(j,t,key,sizeof(key)) || (strcmp(key,"rules") && j->t[t+1].type!='f')) return 0;
    }
    if (!bool_is(j,g,"sandbox_approval",0,0) || !bool_is(j,g,"mcp_elicitations",0,0)) return 0;
    return 1;
}
int review_policy_matches(const Live *l,const JSON *j,int result) {
    int g=json_get(j,json_get(j,result,"approvalPolicy"),"granular");
    int s=json_get(j,result,"sandbox");
    char type[48],reviewer[40];
    if (!json_field(j,result,"approvalsReviewer",reviewer,sizeof(reviewer)) || strcmp(reviewer,"auto_review") ||
        !json_field(j,s,"type",type,sizeof(type)) || strcmp(type,"workspaceWrite") ||
        !bool_is(j,s,"networkAccess",0,1) || !bool_is(j,s,"excludeSlashTmp",1,0) ||
        !bool_is(j,s,"excludeTmpdirEnvVar",1,0) || !review_granular_ok(j,g)) return 0;
    int roots=json_get(j,s,"writableRoots");
    if (roots<0) return 1; /* schema default is [] */
    if (j->t[roots].type!='[') return 0;
    Path *p=allocate(2*sizeof(*p)); int ok=1;
    for (int t=roots+1;t<j->t[roots].after && ok;t=j->t[t].after)
        ok=json_string(j,t,p[0].p,sizeof(p[0].p)) && open_directory(p[0].p,&p[1]) && within(l->workspace.p,p[1].p);
    free(p); return ok;
}

#define REVIEW_LIMIT 200
static int history_doc(Manager *m,const char *project,Document *d,int *a,Error *e) {
    Path *path=allocate(sizeof(*path)); Info info;
    int valid=docs_path(m,"reviews",project,path);
    int exists=valid && file_info(path->p,&info); free(path);
    if (!valid) return errorf(e,"Chọn dự án hợp lệ.");
    *a=-1;
    if (!exists) return 1;
    if (info.kind!=1 || !get_doc(m,"reviews",project,d,e)) return 0;
    *a=json_get(&d->data,0,"events");
    return (*a>=0 && d->data.t[*a].type=='[') || errorf(e,"Nhật ký xét duyệt không hợp lệ.");
}
int review_history(Manager *m,const JSON *in,Buf *out,Error *e) {
    char p[33]; ARG(in,"project",p);
    Document d={0}; int a;
    int ok=history_doc(m,p,&d,&a,e);
    if (ok) {
        JSON *j=&d.data;
        buffer_text(out,"{\"events\":[");
        if (a>=0) for (int t=a+1;t<j->t[a].after;t=j->t[t].after) {
            if (t!=a+1) buffer_char(out,',');
            char status[32],session[33],turn[160];
            if (json_field(j,t,"status",status,sizeof(status)) && !strcmp(status,"inProgress") &&
                json_field(j,t,"session",session,sizeof(session)) && json_field(j,t,"turn",turn,sizeof(turn))) {
                Live *l=m->live;
                while (l && strcmp(l->id,session)) l=l->next;
                if (!l || !chat_review_pending(l,turn)) {
                    buffer_char(out,'{');
                    for (int k=t+1;k<j->t[t].after;k=j->t[k+1].after) {
                        char key[48]; json_string(j,k,key,sizeof(key));
                        if (!strcmp(key,"status") || !strcmp(key,"reason")) continue;
                        json_raw(out,j,k); buffer_char(out,':'); json_raw(out,j,k+1); buffer_char(out,',');
                    }
                    json_pair(out,"status","unconfirmed");
                    KEY(out,"reason","Phiên đã kết thúc trước khi nhận được kết quả xét duyệt.");
                    buffer_char(out,'}');
                    continue;
                }
            }
            json_raw(out,j,t);
        }
        buffer_text(out,"]}");
    }
    doc_free(&d); return ok;
}
int reviews_settled(Manager *m,const Live *l,const char *turn) {
    Document d={0}; Error e={0}; int a;
    int ok=history_doc(m,l->project,&d,&a,&e) && a>=0;
    if (ok) for (int i=a+1;i<d.data.t[a].after;i=d.data.t[i].after) {
        char sid[33],tid[160],status[32];
        if (json_field(&d.data,i,"session",sid,sizeof(sid)) && !strcmp(sid,l->id) &&
            json_field(&d.data,i,"turn",tid,sizeof(tid)) && !strcmp(tid,turn) &&
            (!json_field(&d.data,i,"status",status,sizeof(status)) || strcmp(status,"approved"))) { ok=0; break; }
    }
    doc_free(&d); return ok;
}
int review_record(Manager *m,Live *l,const char *turn,const char *id,const char *source,
                  const char *status,const char *kind,const char *reason,Error *e) {
    Document d={0}; int a,ok=history_doc(m,l->project,&d,&a,e);
    if (!ok) { doc_free(&d); return 0; }
    JSON *j=&d.data; int match=-1,count=0;
    if (a>=0) for (int t=a+1;t<j->t[a].after;t=j->t[t].after) {
        char sid[33],tid[160],rid[260],src[20],prior[32]; ++count;
        if (json_field(j,t,"session",sid,sizeof(sid)) && !strcmp(sid,l->id) &&
            json_field(j,t,"turn",tid,sizeof(tid)) && !strcmp(tid,turn) &&
            json_field(j,t,"review",rid,sizeof(rid)) && !strcmp(rid,id) &&
            json_field(j,t,"source",src,sizeof(src)) && !strcmp(src,source)) {
            match=t; json_field(j,t,"status",prior,sizeof(prior));
            if (!strcmp(prior,status) || (strcmp(prior,"inProgress") && !strcmp(status,"inProgress"))) {
                doc_free(&d); return 1;
            }
        }
    }
    Buf b={0}; buffer_text(&b,"{\"events\":["); int drop=count-(match>=0)+1-REVIEW_LIMIT;
    if (a>=0) for (int t=a+1;t<j->t[a].after;t=j->t[t].after) {
        if (t==match) continue;
        if (drop>0) {
            char sid[33],tid[160],prior[32];
            if (json_field(j,t,"session",sid,sizeof(sid)) && !strcmp(sid,l->id) &&
                json_field(j,t,"turn",tid,sizeof(tid)) && !strcmp(tid,turn) &&
                json_field(j,t,"status",prior,sizeof(prior)) && !strcmp(prior,"inProgress")) {
                buffer_free(&b); doc_free(&d); return errorf(e,"Nhật ký còn yêu cầu chưa có kết quả.");
            }
            --drop; continue;
        }
        json_raw(&b,j,t); buffer_char(&b,',');
    }
    buffer_char(&b,'{'); json_pair(&b,"session",l->id); KEY(&b,"profile",l->profile);
    KEY(&b,"turn",turn); KEY(&b,"review",id); KEY(&b,"source",source);
    KEY(&b,"status",status); KEY(&b,"action",kind);
    KEY(&b,"reason",secret_text(reason)?"[Đã ẩn thông tin nhạy cảm]":reason);
    NUM(&b,"at",timestamp()); buffer_text(&b,"}]}");
    ok=put_doc(m,"reviews",l->project,&b,e); buffer_free(&b); doc_free(&d); return ok;
}
