#include "manager.h"

/* Each managed record has at most one predecessor during publication. A crash
   before installation restores that predecessor; after installation the new
   document names the exact parent it replaced. */
static void hash_bytes(const Buf *b,char out[65]) {
    Sha256 sha={0}; sha_update(&sha,b->s,b->n); sha_finish(&sha,out);
}
static int parked_path(const char *path,Path *park) {
    return sam_format(park->p,sizeof(park->p),"%s.saving",path)<(int)sizeof(park->p);
}
static int guarded_write(Manager *m,const char *table,const char *id,const Buf *b,char expected[65],Error *e) {
    Path *p=allocate(2*sizeof(*p)); Info st; char hash[65]; int ok=0,parked=0;
    if (!docs_path(m,table,id,p) || !parked_path(p->p,p+1)) goto end;
    if (*expected) {
        if (!file_info(p->p,&st) || st.kind!=1 || st.size>8*MIB ||
            !digest_file(p->p,hash,e) || strcmp(hash,expected) || !move_queue_exclusive(p->p,p[1].p)) goto end;
        parked=1;
        if (!file_info(p[1].p,&st) || st.kind!=1 || st.size>8*MIB ||
            !digest_file(p[1].p,hash,e) || strcmp(hash,expected)) goto end;
    }
    if (!write_new_atomic(p->p,b->s,b->n,e)) goto end;
    if (parked && !remove_file(p[1].p)) goto end;
    hash_bytes(b,expected); ok=1;
end:
    if (!ok && parked && !file_info(p->p,&st)) move_queue_exclusive(p[1].p,p->p);
    free(p); return ok || errorf(e,"Nhật ký đã thay đổi hoặc không thể ghi an toàn. Đã giữ bản trên đĩa.");
}
int run_store_write(Manager *m,const char *id,const Buf *b,char expected[65],Error *e) {
    return guarded_write(m,"runs",id,b,expected,e);
}
typedef struct { Manager *m; Path dir; const char *table; } Recovery;
static int recover_one(const char *name,const Info *info,void *ctx,Error *e) {
    if (strlen(name)!=44 || strcmp(name+32,".json.saving")) return 1;
    Recovery *r=ctx; char id[33],hash[65],parent[65]; memcpy(id,name,32); id[32]=0;
    if (!valid_id(id)) return 1;
    Path *p=allocate(2*sizeof(*p)); Document d={0}; Info current; int ok=0;
    if (info->kind!=1 || info->size>8*MIB || !docs_path(r->m,r->table,id,p) || !path_join(p+1,r->dir.p,name)) goto end;
    if (!file_info(p->p,&current)) ok=move_queue_exclusive(p[1].p,p->p);
    else ok=current.kind==1 && get_doc(r->m,r->table,id,&d,e) && json_field(&d.data,0,!strcmp(r->table,"runs")?"parentHash":"headParent",parent,sizeof(parent)) &&
        digest_file(p[1].p,hash,e) && !strcmp(parent,hash) && remove_file(p[1].p);
end:
    free(p); doc_free(&d); return ok || errorf(e,"Có hai bản journal cần đối chiếu. Đã giữ cả hai.");
}
int run_store_init(Manager *m,Error *e) {
    Recovery *r=allocate(sizeof(*r)); r->m=m;
    const char *tables[]={"runs","runheads"}; int ok=1;
    for (size_t i=0;i<ARRAY_LEN(tables) && ok;++i) {
        r->table=tables[i]; ok=path_join(&r->dir,m->data.p,r->table) && list_dir(r->dir.p,recover_one,r,e);
    }
    free(r); return ok;
}
void run_store_hash(const Document *d,char out[65]) { hash_bytes(&d->raw,out); }

/* Only the manager records this private mirror, after the archive worker has
   finished and the public queue for that checkpoint has been published. */
int run_store_checkpoint(Manager *m,const char *id,const char *journal_hash,char expected[65],Error *e) {
    Document d={0}; int ok=get_doc(m,"runs",id,&d,e);
    if (ok) {
        char hash[65]; run_store_hash(&d,hash);
        if (strcmp(hash,journal_hash)) { doc_free(&d); return errorf(e,"Journal đã đổi trước khi ghi mốc phục hồi."); }
        d.raw.n--; d.raw.s[d.raw.n]=0; KEY(&d.raw,"headParent",expected); buffer_char(&d.raw,'}');
        ok=guarded_write(m,"runheads",id,&d.raw,expected,e);
    }
    doc_free(&d); return ok;
}
static int same_field(const Document *a,const Document *b,const char *key) {
    int x=json_get(&a->data,0,key),y=json_get(&b->data,0,key);
    if (x<0 || y<0) return 0;
    Token t=a->data.t[x],u=b->data.t[y]; size_t len=t.last-t.first;
    return u.last-u.first==len && !memcmp(a->raw.s+t.first,b->raw.s+u.first,len);
}
int run_store_recover(Manager *m,const char *id,Document *journal,char head_hash[65],Error *e) {
    Document head={0},ck={0}; Path *p=allocate(2*sizeof(*p)); Info st;
    int ok=0; Buf args={0},result={0}; JSON j={0}; char rid[33],qid[33],ckid[33],expected[65],hash[65];
    if (!docs_path(m,"runheads",id,p)) goto end;
    if (!file_info(p->p,&st)) { ok=1; goto end; }
    if (st.kind!=1 || !get_doc(m,"runheads",id,&head,e)) goto end;
    run_store_hash(&head,head_hash);
    long long hr=NUMBER(&head.data,"revision",-1),jr=NUMBER(&journal->data,"revision",-1);
    if (hr<jr || (hr==jr && NUMBER(&head.data,"generation",0)<=NUMBER(&journal->data,"generation",0))) { ok=1; goto end; }
    if (!FIELD(&head,"id",rid) || strcmp(rid,id) || !same_field(&head,journal,"project") ||
        !same_field(&head,journal,"workspace") || !same_field(&head,journal,"goal") ||
        !FIELD(&head,"workspace",p[0].p) || !FIELD(&head,"checkpoint",ckid) ||
        !get_doc(m,"checkpoints",ckid,&ck,e) || !same_field(&ck,&head,"workspace") || !same_field(&ck,&head,"project") ||
        !FIELD(&head,"queueHash",expected) || !path_join(p+1,p->p,"TASK_QUEUE.json") ||
        !file_info(p[1].p,&st) || st.kind!=1 || st.size>2*MIB || !digest_file(p[1].p,hash,e) || strcmp(expected,hash)) goto end;
    buffer_char(&args,'{'); json_pair(&args,"id",ckid); buffer_char(&args,'}');
    if (!json_parse(&j,args.s,args.n) || !checkpoint_action(m,"checkpoint-verify",&j,&result,e)) goto end;
    /* Keep the old journal for diagnosis and install a child of those bytes. */
    if (secret_text(journal->raw.s)) goto end;
    new_id(qid); if (!docs_path(m,"runrecovery",qid,p) || !write_new_atomic(p->p,journal->raw.s,journal->raw.n,e)) goto end;
    run_store_hash(journal,hash);
    Buf b={0}; buffer_char(&b,'{'); json_pair(&b,"parentHash",hash);
    for (int i=1;i<head.data.t[0].after;i=head.data.t[i+1].after) {
        char key[80]; if (!json_string(&head.data,i,key,sizeof(key)) || !strcmp(key,"parentHash") || !strcmp(key,"headParent")) continue;
        buffer_char(&b,','); json_raw(&b,&head.data,i); buffer_char(&b,':'); json_raw(&b,&head.data,i+1);
    }
    buffer_char(&b,'}'); ok=run_store_write(m,id,&b,hash,e); buffer_free(&b);
    if (ok) { doc_free(journal); ok=get_doc(m,"runs",id,journal,e); }
end:
    free(p); doc_free(&head); doc_free(&ck); json_free(&j); buffer_free(&args); buffer_free(&result);
    return ok || errorf(e,"Journal và checkpoint không khớp. Đã giữ nguyên dữ liệu để đối chiếu.");
}
