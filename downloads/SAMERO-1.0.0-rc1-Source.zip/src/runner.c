#include "manager.h"

#define TASK_LIMIT 16
#define RETRY_LIMIT 2
#ifndef SAM_RUNNER_IDLE_MS
#define SAM_RUNNER_IDLE_MS (15u * 60u * 1000u)
#endif
typedef enum { PLAN, WORK, VERIFY, TEST, FINAL_TEST, RELEASE, FINISH } Phase;
typedef enum { ACTIVE, PAUSED, STOPPED, LIMITED, REVIEW, BLOCKED, DONE } Mode;
static const char *const phases[]={"plan","work","verify","test","final-test","release","finish"};
static const char *const modes[]={"active","paused","stopped","quota","review","blocked","done"};
/* The journal is authoritative; these receipts never import PASS from a public queue.
   A bounded file-delta preview points at two hashed manifests for complete evidence. */
typedef struct {
    char title[256],accept[680],evidence[680],test_session[33],verify_session[33];
    char baseline[33],checkpoint[33],recovery_checkpoint[33],accepted_hash[65],test_signature[65];
    char changes[4096],change_status[24],errors[2048],error_status[24];
    char commands[4096];
    int command_count,command_partial,review_probe;
    int after,receipt_version,change_count,error_count,work_recoveries,baseline_recovery,historical_checkpoint;
} Task;
typedef struct { Path exe; char args[1536]; } Command;
typedef struct Run {
    char previous_run[33],pending_hash[65],limit_owner[320],destination[33],archive_id[33];
    Process archiver; int archived_revision; uint64_t archive_since,started_tick;
    char id[33],project[33],profile[33],home[PATH_CAP],goal[1250],session[33],checkpoint[33],queue_hash[65];
    Path workspace;
    Task tasks[TASK_LIMIT];
    Command checks[2];
    int count,index,attempt,auto_resume,inflight,snapshot,revision,retired;
    char source_hash[65],failure_hash[65],failure_gate[24],journal_hash[65],head_hash[65];
    int recovery_scan,final_repair,catchup_index,resume_verify; char catchup_hash[65],accept_hash[65]; long long generation;
    int reconnects; long long retry_at;
    int test,build; /* 0 unverified, 1 pass, -1 fail */
    long long at,limited_at,limited_since;
    Mode mode; Phase phase;
    char reason[700],log[12][740];
    uint64_t last_activity;
    struct Run *next;
} Run;

static const char *result(int n) { return n==1?"PASS":n==-1?"FAIL":"NOT VERIFIED"; }
static int enum_value(const char *s,const char *const *values,size_t n) {
    for (size_t i=0;i<n;++i) if (!strcmp(s,values[i])) return (int)i;
    return -1;
}
static void note(Run *r,const char *msg) {
    if (!msg || !*msg) return;
    memmove(r->log,r->log+1,sizeof(r->log)-sizeof(r->log[0]));
    size_t len=strlen(msg);
    if (len>690) { len=690; while (((unsigned char)msg[len]&0xc0)==0x80) --len; }
    sam_format(r->log[11],sizeof(r->log[11]),"%lld · %.*s",timestamp(),(int)len,msg);
    sam_format(r->reason,sizeof(r->reason),"%s",msg);
    ++r->revision; r->at=timestamp();
}
/* A reported blocker is not an independently verified failure or a PASS. */
static const char *review_blocker(const char *s) {
    if (!strncmp(s,"BLOCKED_ACCESS:",15) || !strncmp(s,"Chính sách chặn đọc repo.",strlen("Chính sách chặn đọc repo.")) ||
        !strncmp(s,"Môi trường chặn lệnh đọc repo.",strlen("Môi trường chặn lệnh đọc repo."))) return "BLOCKED_ACCESS";
    if (!strncmp(s,"BLOCKED_RESOURCE:",17)) return "BLOCKED_RESOURCE";
    return "";
}
static void queue_json(const Run *r,Buf *b) {
    buffer_char(b,'{'); json_pair(b,"id",r->id); KEY(b,"project",r->project); KEY(b,"profile",r->profile);
    KEY(b,"goal",r->goal); KEY(b,"mode",modes[r->mode]); KEY(b,"phase",phases[r->phase]);
    KEY(b,"reason",r->reason);
    KEY(b,"blocker",r->mode==REVIEW && r->phase==VERIFY && r->index<r->count?review_blocker(r->tasks[r->index].evidence):"");
    KEY(b,"test",result(r->test)); KEY(b,"build",result(r->build));
    NUM(b,"index",r->index); NUM(b,"attempt",r->attempt); NUM(b,"revision",r->revision); NUM(b,"at",r->at);
    buffer_text(b,",\"tasks\":[");
    for (int i=0;i<r->count;++i) {
        if (i) buffer_char(b,',');
        buffer_char(b,'{'); json_pair(b,"title",r->tasks[i].title);
        KEY(b,"accept",r->tasks[i].accept); NUM(b,"after",r->tasks[i].after);
        KEY(b,"evidence",r->tasks[i].evidence); KEY(b,"testSession",r->tasks[i].test_session); KEY(b,"verifySession",r->tasks[i].verify_session);
        const Task *t=&r->tasks[i];
        NUM(b,"receiptVersion",t->receipt_version);
        KEY(b,"baselineCheckpoint",t->baseline); KEY(b,"checkpoint",t->checkpoint);
        KEY(b,"recoveryCheckpoint",t->recovery_checkpoint); KEY(b,"acceptedSourceHash",t->accepted_hash); KEY(b,"testSignature",t->test_signature);
        KEY(b,"checkpointKind",*t->checkpoint?(t->historical_checkpoint?"HISTORICAL OBSERVATION":"ACCEPTANCE"):"NOT RECORDED");
        KEY(b,"changedFiles",t->changes); KEY(b,"changedFilesStatus",*t->change_status?t->change_status:"NOT RECORDED");
        NUM(b,"changedFileCount",t->change_count); NUM(b,"baselineFromRecovery",t->baseline_recovery);
        KEY(b,"errors",t->errors); KEY(b,"errorsStatus",*t->error_status?t->error_status:"NOT RECORDED");
        NUM(b,"errorCount",t->error_count); NUM(b,"workRecoveries",t->work_recoveries);
        KEY(b,"commands",t->commands); NUM(b,"commandCount",t->command_count); NUM(b,"commandPartial",t->command_partial); NUM(b,"reviewProbe",t->review_probe);
        KEY(b,"commandsStatus",t->command_count?(t->command_partial?"PARTIAL":"OBSERVED"):"NOT RECORDED");
        KEY(b,"status",i<r->index?"PASS":"NOT VERIFIED"); buffer_char(b,'}');
    }
    buffer_text(b,"]}");
}
static int save(Manager *m,Run *r,Error *e) {
    Buf b={0}; queue_json(r,&b); --b.n; b.s[b.n]=0;
    KEY(&b,"acceptHash",r->accept_hash);
    NUM(&b,"catchupIndex",r->catchup_index); KEY(&b,"catchupHash",r->catchup_hash);
    NUM(&b,"generation",r->generation+1); KEY(&b,"parentHash",r->journal_hash);
    KEY(&b,"workspace",r->workspace.p); KEY(&b,"home",r->home); KEY(&b,"session",r->session);
    KEY(&b,"checkpoint",r->checkpoint); KEY(&b,"queueHash",r->queue_hash);
    KEY(&b,"sourceHash",r->source_hash); KEY(&b,"failureHash",r->failure_hash); KEY(&b,"failureGate",r->failure_gate);
    NUM(&b,"resumeVerify",r->resume_verify); NUM(&b,"recoveryScan",r->recovery_scan); NUM(&b,"finalRepair",r->final_repair);
    NUM(&b,"reconnects",r->reconnects); NUM(&b,"retryAt",r->retry_at);
    NUM(&b,"inflight",r->inflight); NUM(&b,"snapshot",r->snapshot); NUM(&b,"autoResume",r->auto_resume);
    KEY(&b,"previousRun",r->previous_run); KEY(&b,"pendingHash",r->pending_hash); KEY(&b,"limitOwner",r->limit_owner);
    KEY(&b,"destination",r->destination); KEY(&b,"archiveId",r->archive_id); NUM(&b,"limitedSince",r->limited_since);
    NUM(&b,"limitedAt",r->limited_at); NUM(&b,"retired",r->retired);
    for (int i=0;i<2;++i) {
        KEY(&b,i?"buildExe":"testExe",r->checks[i].exe.p); KEY(&b,i?"buildArgs":"testArgs",r->checks[i].args);
    }
    buffer_text(&b,",\"log\":[");
    for (int i=0;i<12;++i) { if (i) buffer_char(&b,','); json_quote(&b,r->log[i]); }
    buffer_text(&b,"]}");
    int ok=run_store_write(m,r->id,&b,r->journal_hash,e);
    if (ok) ++r->generation;
    buffer_free(&b);
    if (!ok) { m->runner_fault=1; r->mode=BLOCKED; }
    return ok;
}
/* Only completed, observed operations. Never claim all commands were captured.
   Preserve bounded evidence across restart; do not log output or credentials. */
static void command_observed(Task *t,const char *phase,const char *sid,const char *command,long long exit_code) {
    if (t->command_count<1000000) ++t->command_count;
    if (!command || !*command || secret_text(command) || contains_ci(command,"--token") || contains_ci(command,"--password") || contains_ci(command,"--api-key") || contains_ci(command,"<!-- SAMERO") || strlen(command)>1800 || !text_utf8(command,strlen(command))) {
        command="[NOT RECORDED: missing, sensitive or too long]"; t->command_partial=1;
    }
    char line[2000]; int n=sam_format(line,sizeof(line),"%s session %s | exit %lld | %s\n",phase,sid,exit_code,command);
    size_t used=strlen(t->commands);
    if (n<0 || (size_t)n>=sizeof(line) || used+(size_t)n>=sizeof(t->commands)) {t->command_partial=1; return;}
    memcpy(t->commands+used,line,(size_t)n+1);
}
void runner_record_command(Manager *m,Live *l,const char *command,long long exit_code) {
    if (!l->autonomous) return;
    for (Run *r=m->runs;r;r=r->next) {
        if (r->retired || !r->inflight || r->index>=r->count || strcmp(r->session,l->id) ||
            strcmp(r->project,l->project) || (r->phase!=WORK && r->phase!=VERIFY)) continue;
        command_observed(&r->tasks[r->index],phases[r->phase],l->id,command,exit_code);
        Error e={0}; save(m,r,&e); return;
    }
}
static int read_tasks(Run *r,const JSON *j,int require) {
    int a=json_get(j,0,"tasks");
    if (a<0 || j->t[a].type!='[' || j->t[a].count>TASK_LIMIT || (require && !j->t[a].count)) return 0;
    int n=0;
    for (int t=a+1;t<j->t[a].after;t=j->t[t].after,++n) {
        Task *k=&r->tasks[n];
        long long dep=json_int(j,json_get(j,t,"after"),-2);
        if (dep< -1 || dep>=n || !json_field(j,t,"title",k->title,sizeof(k->title)) || !*k->title ||
            !json_field(j,t,"accept",k->accept,sizeof(k->accept)) || !*k->accept ||
            secret_text(k->title) || secret_text(k->accept)) return 0;
        k->after=(int)dep;
        if (!require) {
            json_field(j,t,"evidence",k->evidence,sizeof(k->evidence));
            json_field(j,t,"testSession",k->test_session,sizeof(k->test_session));
            json_field(j,t,"verifySession",k->verify_session,sizeof(k->verify_session));
            json_field(j,t,"baselineCheckpoint",k->baseline,sizeof(k->baseline));
            json_field(j,t,"checkpoint",k->checkpoint,sizeof(k->checkpoint));
            json_field(j,t,"recoveryCheckpoint",k->recovery_checkpoint,sizeof(k->recovery_checkpoint));
            json_field(j,t,"acceptedSourceHash",k->accepted_hash,sizeof(k->accepted_hash));
            if (json_get(j,t,"testSignature")>=0 && !json_field(j,t,"testSignature",k->test_signature,sizeof(k->test_signature))) return 0;
            if (*k->test_signature && (strlen(k->test_signature)!=64 || strspn(k->test_signature,"0123456789abcdef")!=64)) return 0;
            json_field(j,t,"changedFiles",k->changes,sizeof(k->changes));
            json_field(j,t,"changedFilesStatus",k->change_status,sizeof(k->change_status));
            json_field(j,t,"errors",k->errors,sizeof(k->errors));
            json_field(j,t,"errorsStatus",k->error_status,sizeof(k->error_status));
            if (json_get(j,t,"commands")>=0 && !json_field(j,t,"commands",k->commands,sizeof(k->commands))) return 0;
            long long command_count=json_int(j,json_get(j,t,"commandCount"),0);
            if (command_count<0 || command_count>1000000 || secret_text(k->commands)) return 0;
            k->command_count=(int)command_count;
            k->command_partial=json_int(j,json_get(j,t,"commandPartial"),0)==1;
            k->review_probe=json_int(j,json_get(j,t,"reviewProbe"),0)==1;
            long long version=json_int(j,json_get(j,t,"receiptVersion"),0),
                nc=json_int(j,json_get(j,t,"changedFileCount"),0), ne=json_int(j,json_get(j,t,"errorCount"),0),
                wr=json_int(j,json_get(j,t,"workRecoveries"),0);
            if (version<0 || version>2 || nc<0 || nc>131068 || ne<0 || ne>1000000 || wr<0 || wr>1) return 0;
            k->receipt_version=(int)version; k->change_count=(int)nc; k->error_count=(int)ne; k->work_recoveries=(int)wr;
            k->baseline_recovery=json_int(j,json_get(j,t,"baselineFromRecovery"),0)==1;
            char kind[32]; k->historical_checkpoint=json_field(j,t,"checkpointKind",kind,sizeof(kind)) && !strcmp(kind,"HISTORICAL OBSERVATION");
            if (secret_text(k->evidence) || secret_text(k->changes) || secret_text(k->errors) ||
                (*k->test_session && !valid_id(k->test_session)) || (*k->verify_session && !valid_id(k->verify_session)) ||
                (*k->baseline && !valid_id(k->baseline)) || (*k->checkpoint && !valid_id(k->checkpoint)) ||
                (*k->recovery_checkpoint && !valid_id(k->recovery_checkpoint))) return 0;
        }
    }
    r->count=n; return 1;
}
static void reconcile(Run *r) {
    if (r->phase==WORK) r->phase=r->final_repair?FINAL_TEST:VERIFY;
    r->inflight=0; r->session[0]=0;
}
static int load_run(const char *id,Document *d,void *ctx,Error *e) {
    Manager *m=ctx; Run *r=allocate(sizeof(*r));
    if (!run_store_recover(m,id,d,r->head_hash,e)) { free(r); return 0; }
    char mode[24],phase[24],test[20],build[20];
    run_store_hash(d,r->journal_hash);
    JSON *j=&d->data; r->generation=NUMBER(j,"generation",0);
    if (r->generation<0 || r->generation>9007199254740990LL) { free(r); return errorf(e,"Generation không hợp lệ."); }
    FIELD(d,"mode",mode); FIELD(d,"phase",phase);
    int mv=enum_value(mode,modes,ARRAY_LEN(modes)),pv=enum_value(phase,phases,ARRAY_LEN(phases));
    long long index=NUMBER(j,"index",-1);
    if (!FIELD(d,"id",r->id) || strcmp(id,r->id) || !FIELD(d,"project",r->project) || !valid_id(r->project) ||
        !FIELD(d,"profile",r->profile) || !valid_id(r->profile) || !FIELD(d,"workspace",r->workspace.p) ||
        !FIELD(d,"home",r->home) || !FIELD(d,"goal",r->goal) || mv<0 || pv<0 || !read_tasks(r,j,0) ||
        index<0 || index>r->count || ((pv==WORK || pv==VERIFY || pv==TEST) && index>=r->count && !(pv==WORK && index>0 && NUMBER(j,"finalRepair",0)==1))) {
        free(r); return errorf(e,"Nhật ký Autonomous không hợp lệ. Hãy kiểm tra bản sao lưu.");
    }
    long long revision=NUMBER(j,"revision",-1),attempt=NUMBER(j,"attempt",-1);
    if (revision<0 || revision>=2147483646 || attempt<0 || attempt>RETRY_LIMIT) { free(r); return errorf(e,"Revision hoặc số lần sửa không hợp lệ."); }
    FIELD(d,"sourceHash",r->source_hash); FIELD(d,"failureHash",r->failure_hash); FIELD(d,"failureGate",r->failure_gate);
    if ((pv==PLAN && r->count) || (pv>=FINAL_TEST && (!r->count || index!=r->count)) ||
        (mv==DONE && (pv!=FINISH || !FIELD(d,"test",test) || strcmp(test,"PASS") ||
                                     !FIELD(d,"build",build) || strcmp(build,"PASS")))) {
        free(r); return errorf(e,"Trạng thái giai đoạn không khớp tiến độ hoặc kết quả cuối.");
    }
    int tasks=json_get(j,0,"tasks"),n_task=0;
    for (int i=tasks+1;i<j->t[tasks].after;i=j->t[i].after,++n_task) {
        char status[24];
        if (!json_field(j,i,"status",status,sizeof(status)) || strcmp(status,n_task<index?"PASS":"NOT VERIFIED") ||
            (n_task<index && !*r->tasks[n_task].evidence)) {
            free(r); return errorf(e,"Trạng thái nhiệm vụ không khớp chỉ mục nghiệm thu.");
        }
    }
    /* Pending acceptance is reverified after a restart. */
    r->catchup_index=(int)NUMBER(j,"catchupIndex",0); FIELD(d,"catchupHash",r->catchup_hash);
    if (r->catchup_index<0 || r->catchup_index>r->count || (r->catchup_index && strlen(r->catchup_hash)!=64)) {
        free(r); return errorf(e,"Mốc đối chiếu hàng đợi không hợp lệ.");
    }
    r->resume_verify=NUMBER(j,"resumeVerify",0)==1; r->recovery_scan=NUMBER(j,"recoveryScan",0)==1; r->final_repair=NUMBER(j,"finalRepair",0)==1;
    r->mode=(Mode)mv; r->phase=(Phase)pv; r->index=(int)index;
    if (r->final_repair && (!r->count || index!=r->count)) { free(r); return errorf(e,"Mốc sửa kiểm thử cuối không hợp lệ."); }
    r->reconnects=(int)NUMBER(j,"reconnects",0); r->retry_at=NUMBER(j,"retryAt",0);
    r->attempt=(int)NUMBER(j,"attempt",0); r->auto_resume=NUMBER(j,"autoResume",0)==1;
    r->inflight=NUMBER(j,"inflight",0)==1; r->snapshot=NUMBER(j,"snapshot",0)==1;
    r->revision=(int)NUMBER(j,"revision",0); r->at=NUMBER(j,"at",0);
    FIELD(d,"previousRun",r->previous_run); FIELD(d,"pendingHash",r->pending_hash); FIELD(d,"limitOwner",r->limit_owner);
    FIELD(d,"destination",r->destination); FIELD(d,"archiveId",r->archive_id); r->limited_since=NUMBER(j,"limitedSince",0);
    r->limited_at=NUMBER(j,"limitedAt",0); r->retired=NUMBER(j,"retired",0)==1;
    FIELD(d,"test",test); FIELD(d,"build",build);
    r->test=!strcmp(test,"PASS")?1:!strcmp(test,"FAIL")?-1:0;
    r->build=!strcmp(build,"PASS")?1:!strcmp(build,"FAIL")?-1:0;
    FIELD(d,"reason",r->reason); FIELD(d,"session",r->session); FIELD(d,"checkpoint",r->checkpoint);
    FIELD(d,"queueHash",r->queue_hash); FIELD(d,"testExe",r->checks[0].exe.p); FIELD(d,"testArgs",r->checks[0].args);
    FIELD(d,"buildExe",r->checks[1].exe.p); FIELD(d,"buildArgs",r->checks[1].args);
    int log=json_get(j,0,"log"),n=0;
    if (log>=0 && j->t[log].type=='[') for (int t=log+1;t<j->t[log].after && n<12;t=j->t[t].after) json_string(j,t,r->log[n++],sizeof(r->log[0]));
    r->next=m->runs; m->runs=r;
    if (!r->retired && (r->inflight || r->mode==ACTIVE || *r->archive_id)) {
        Document archived={0}; Error ignored={0};
        if (*r->archive_id && get_doc(m,"checkpoints",r->archive_id,&archived,&ignored)) strcpy(r->checkpoint,r->archive_id);
        doc_free(&archived); r->archive_id[0]=0; r->destination[0]=0;
        int uncertain=r->inflight; reconcile(r); r->mode=uncertain?REVIEW:PAUSED; r->snapshot=1;
        note(r,uncertain?"Manager đã khởi động lại giữa một thao tác. Kiểm tra workspace trước khi tiếp tục.":"Đã phục hồi hàng đợi tại ranh giới giai đoạn.");
        return save(m,r,e);
    }
    return 1;
}
int runner_init(Manager *m,Error *e) {
    if (!run_store_init(m,e) || !each_doc(m,"runs",load_run,m,e)) return 0;
    for (Run *r=m->runs;r;r=r->next) if (valid_id(r->previous_run))
        for (Run *old=m->runs;old;old=old->next) if (!old->retired && !strcmp(old->id,r->previous_run) && !strcmp(r->project,old->project)) {
            old->retired=1; if (!save(m,old,e)) return 0;
        }
    return 1;
}
int runner_checkpoint_busy(Manager *m) {
    for (Run *r=m->runs;r;r=r->next) if (r->archiver.handle) return 1;
    return 0;
}
void runner_free(Manager *m) {
    while (m->runs) { Run *r=m->runs; m->runs=r->next; if (r->archiver.handle) { process_stop(&r->archiver); process_dispose(&r->archiver); } free(r); }
}
int runner_reserved(Manager *m,const char *path) {
    if (!m->runner_internal) for (Run *r=m->runs;r;r=r->next)
        if (!r->retired && (r->mode==ACTIVE || r->session[0] || r->snapshot) &&
            (within(path,r->workspace.p) || within(r->workspace.p,path))) return 1;
    return 0;
}
static Live *owned(Manager *m,const Run *r) {
    for (Live *l=m->live;l;l=l->next) if (!strcmp(l->id,r->session)) return l;
    return NULL;
}
static int bound(Manager *m,const Run *r,Error *e) {
    Document d={0}; Path *p=allocate(3*sizeof(*p));
    int ok=get_doc(m,"projects",r->project,&d,e) && FIELD(&d,"path",p[0].p) &&
        !strcmp(p[0].p,r->workspace.p) && open_directory(p[0].p,&p[1]) && !strcmp(p[0].p,p[1].p) &&
        directory_allowed(m,p[0].p,1);
    doc_free(&d);
    ok=ok && get_doc(m,"profiles",r->profile,&d,e) && FIELD(&d,"home",p[2].p) && !strcmp(p[2].p,r->home) &&
        open_directory(r->home,&p[1]) && !strcmp(p[1].p,r->home);
    doc_free(&d); free(p);
    return ok || errorf(e,"Đường dẫn dự án hoặc CODEX_HOME đã thay đổi.");
}
/* Hash the exact bytes parsed, and check their binding to the project and workspace.
   A missing/tampered manifest is not replaced by a guessed file list. */
static int receipt_manifest(Manager *m,const Run *r,const char *id,Buf *raw,JSON *j) {
    Document d={0}; Error e={0}; Path *p=allocate(3*sizeof(*p)); char project[33],hash[65],actual[65]; Info st;
    int ok=valid_id(id) && get_doc(m,"checkpoints",id,&d,&e) && FIELD(&d,"project",project) && !strcmp(project,r->project) &&
        FIELD(&d,"workspace",p[0].p) && !strcmp(p[0].p,r->workspace.p) && FIELD(&d,"directory",p[0].p) &&
        open_directory(p[0].p,p+1) && !strcmp(p[0].p,p[1].p) && FIELD(&d,"manifestHash",hash) &&
        path_join(p+2,p[0].p,"MANIFEST.json") && file_info(p[2].p,&st) && st.kind==1 && read_file(p[2].p,16*MIB,raw,&e);
    if (ok) {
        Sha256 sha={0}; sha_update(&sha,raw->s,raw->n); sha_finish(&sha,actual);
        ok=!strcmp(hash,actual) && json_parse(j,raw->s,raw->n) && j->t[0].type=='{';
    }
    doc_free(&d); free(p); return ok;
}
/* Entries are sorted by path by the archive code. Filter generated receipts,
   directories and credentials, and compare actual file hashes, not mtimes. */
static int next_manifest_file(const JSON *j,int *i,int end,char *path,char hash[65]) {
    while (*i<end) {
        int token=*i; *i=j->t[token].after; char kind[24];
        if (!json_field(j,token,"path",path,PATH_CAP) || !json_field(j,token,"kind",kind,sizeof(kind))) return -1;
        if (strcmp(kind,"file") || !strcmp(path,"TASK_QUEUE.json") || !strcmp(path,"PROJECT_STATUS.md") ||
            !strncmp(path,".samero-handover/",16) || credential_path(path) || secret_text(path)) continue;
        if (!json_field(j,token,"sha256",hash,65) || strlen(hash)!=64) return -1;
        return 1;
    }
    return 0;
}
static void task_delta(Manager *m,Run *r,Task *t) {
    Buf old={0},now={0},preview={0}; JSON a={0},b={0};
    char *x=allocate(PATH_CAP),*y=allocate(PATH_CAP),xh[65],yh[65]; int count=0,truncated=0,ok=0;
    t->changes[0]=0; t->change_count=0; strcpy(t->change_status,"NOT RECORDED");
    if (!receipt_manifest(m,r,t->baseline,&old,&a) || !receipt_manifest(m,r,t->checkpoint,&now,&b)) goto end;
    int ai=json_get(&a,0,"files"),bi=json_get(&b,0,"files");
    if (ai<0 || bi<0 || a.t[ai].type!='[' || b.t[bi].type!='[') goto end;
    int i=ai+1,j=bi+1,na=next_manifest_file(&a,&i,a.t[ai].after,x,xh),nb=next_manifest_file(&b,&j,b.t[bi].after,y,yh);
    while (na>0 || nb>0) {
        if (na<0 || nb<0) goto end;
        int cmp=!na?1:!nb?-1:strcmp(x,y); const char *kind=NULL,*path=NULL;
        if (cmp<0) {kind="deleted"; path=x;}
        else if (cmp>0) {kind="added"; path=y;}
        else if (strcmp(xh,yh)) {kind="modified"; path=x;}
        if (kind) {
            ++count;
            if (!truncated && preview.n+strlen(path)+strlen(kind)+3<sizeof(t->changes)) buffer_fmt(&preview,"%s: %s\n",kind,path);
            else truncated=1;
        }
        if (cmp<=0) na=next_manifest_file(&a,&i,a.t[ai].after,x,xh);
        if (cmp>=0) nb=next_manifest_file(&b,&j,b.t[bi].after,y,yh);
    }
    if (na<0 || nb<0 || count>131068) goto end;
    ok=1; t->change_count=count; strcpy(t->change_status,truncated?"TRUNCATED":"RECORDED");
    if (preview.n) memcpy(t->changes,preview.s,preview.n+1);
end:
    if (!ok) {t->changes[0]=0; t->change_count=0; strcpy(t->change_status,"NOT RECORDED");}
    free(x); free(y); json_free(&a); json_free(&b); buffer_free(&old); buffer_free(&now); buffer_free(&preview);
}
#define HISTORY_LIMIT 64
/* Keep the most recent bounded set of candidate checkpoint records. Their
   archived queue bytes must match a hashed MANIFEST entry before use. */
typedef struct {const Run *r; int n; struct {char id[33]; long long at;} item[HISTORY_LIMIT];} History;
static int history_candidate(const char *id,Document *d,void *ctx,Error *e) {
    (void)e; History *h=ctx; char project[33]; Path *p=allocate(sizeof(*p));
    int match=FIELD(d,"project",project) && !strcmp(project,h->r->project) && FIELD(d,"workspace",p->p) && !strcmp(p->p,h->r->workspace.p);
    free(p); if (!match) return 1;
    long long at=NUMBER(&d->data,"at",0); int i=h->n;
    if (i>=HISTORY_LIMIT) {i=0; for (int j=1;j<h->n;++j) if (h->item[j].at<h->item[i].at) i=j; if (at<h->item[i].at) return 1;}
    else ++h->n;
    strcpy(h->item[i].id,id); h->item[i].at=at; return 1;
}
static int archived_queue(Manager *m,const Run *r,const char *id,Buf *raw,JSON *q) {
    Buf manifest={0}; JSON j={0}; Document d={0}; Error e={0}; Path *p=allocate(2*sizeof(*p));
    char hash[65]={0},actual[65],rid[33],project[33],goal[1250]; int ok=0;
    if (!receipt_manifest(m,r,id,&manifest,&j)) goto end;
    int files=json_get(&j,0,"files"); if (files<0 || j.t[files].type!='[') goto end;
    for (int i=files+1;i<j.t[files].after;i=j.t[i].after) {
        char path[PATH_CAP];
        if (json_field(&j,i,"path",path,sizeof(path)) && !strcmp(path,"TASK_QUEUE.json")) {
            json_field(&j,i,"sha256",hash,sizeof(hash)); break;
        }
    }
    if (strlen(hash)!=64 || !get_doc(m,"checkpoints",id,&d,&e) || !FIELD(&d,"directory",p[0].p) ||
        !path_join(p+1,p[0].p,"workspace.zip") || !archive_member(p[1].p,"TASK_QUEUE.json",2*MIB,raw,&e)) goto end;
    Sha256 sha={0}; sha_update(&sha,raw->s,raw->n); sha_finish(&sha,actual);
    ok=!strcmp(hash,actual) && !secret_text(raw->s) && json_parse(q,raw->s,raw->n) && ARG(q,"id",rid) && !strcmp(rid,r->id) &&
        ARG(q,"project",project) && !strcmp(project,r->project) && ARG(q,"goal",goal) && !strcmp(goal,r->goal);
end:
    free(p); doc_free(&d); json_free(&j); buffer_free(&manifest); return ok;
}
static void historical_receipts(Manager *m,Run *r) {
    History h={.r=r}; Error e={0}; long long before[TASK_LIMIT],after[TASK_LIMIT];
    for (int i=0;i<TASK_LIMIT;++i) before[i]=after[i]=2147483647;
    if (!each_doc(m,"checkpoints",history_candidate,&h,&e)) return;
    for (int c=0;c<h.n;++c) {
        Buf raw={0}; JSON j={0};
        if (!archived_queue(m,r,h.item[c].id,&raw,&j)) goto next;
        long long index=NUMBER(&j,"index",-1),rev=NUMBER(&j,"revision",-1),attempt=NUMBER(&j,"attempt",0);
        int a=json_get(&j,0,"tasks"); char phase[24],mode[24],test[24],reason[700];
        if (index<0 || index>r->count || rev<0 || rev>r->revision || a<0 || j.t[a].type!='[' || j.t[a].count!=r->count ||
            !ARG(&j,"phase",phase) || !ARG(&j,"mode",mode)) goto next;
        int i=0;
        for (int k=a+1;k<j.t[a].after && i<r->index;k=j.t[k].after,++i) {
            Task *t=&r->tasks[i]; char title[256],status[24],evidence[680];
            if (t->receipt_version>=2 || !json_field(&j,k,"title",title,sizeof(title)) || strcmp(title,t->title) ||
                json_int(&j,json_get(&j,k,"after"),-2)!=t->after) continue;
            if (index==i && rev<before[i] && (!strcmp(phase,"work") || !strcmp(phase,"test") || !strcmp(phase,"verify"))) {
                strcpy(t->baseline,h.item[c].id); t->baseline_recovery=1; before[i]=rev;
            }
            if (index==i+1 && rev<after[i] && json_field(&j,k,"status",status,sizeof(status)) && !strcmp(status,"PASS") &&
                json_field(&j,k,"evidence",evidence,sizeof(evidence)) && !strcmp(evidence,t->evidence)) {
                strcpy(t->checkpoint,h.item[c].id); t->historical_checkpoint=1; after[i]=rev;
            }
            if (index==i && (!strcmp(mode,"review") || !strcmp(mode,"blocked") || (attempt>0 && !strcmp(phase,"work")) ||
                (ARG(&j,"test",test) && !strcmp(test,"FAIL"))) && ARG(&j,"reason",reason) && *reason && !secret_text(reason) && !strstr(t->errors,reason)) {
                size_t n=strlen(t->errors); if (t->error_count<1000000) ++t->error_count;
                if (n+strlen(reason)+48<sizeof(t->errors)) sam_format(t->errors+n,sizeof(t->errors)-n,"revision %lld: %s\n",rev,reason);
                else strcpy(t->error_status,"TRUNCATED");
                if (strcmp(t->error_status,"TRUNCATED")) strcpy(t->error_status,"PARTIAL");
            }
        }
next:
        json_free(&j); buffer_free(&raw);
    }
    for (int i=0;i<r->index;++i) {
        Task *t=&r->tasks[i]; if (t->receipt_version>=2) continue;
        if (*t->baseline && *t->checkpoint && before[i]<after[i]) task_delta(m,r,t);
        else t->baseline[0]=0;
    }
}
static void task_error(Run *r,const char *reason) {
    if (r->index>=r->count || r->phase==PLAN || !reason || !*reason) return;
    Task *t=&r->tasks[r->index];
    if (t->error_count<1000000) ++t->error_count;
    if (strcmp(t->error_status,"TRUNCATED")) strcpy(t->error_status,t->baseline_recovery?"PARTIAL":"RECORDED");
    const char *msg=secret_text(reason)?"[redacted]":reason;
    size_t n=strlen(t->errors),len=strlen(msg);
    if (n+len+3>=sizeof(t->errors)) {strcpy(t->error_status,"TRUNCATED"); return;}
    sam_format(t->errors+n,sizeof(t->errors)-n,"%s%s\n",n?"- ":"",msg);
}
static int invoke(Manager *m,int checkpoint,Buf *args,Buf *out,Error *e) {
    JSON j; buffer_char(args,'}');
    if (!json_parse(&j,args->s,args->n)) return errorf(e,"Lỗi dữ liệu điều khiển.");
    int ok=checkpoint?checkpoint_action(m,checkpoint==2?"checkpoint-prepare":"checkpoint-backup",&j,out,e):
        session_action(m,"session-check",&j,out,e);
    json_free(&j); return ok;
}
static void project_args(const Run *r,Buf *b) {
    buffer_char(b,'{'); json_pair(b,"project",r->project);
}
/* Publish exclusively. A concurrent editor that installs a new pathname wins.
   A parked file survives interruption until its hash is reconciled. */
static int publish_queue(Manager *m,Run *r,const char *path,const Buf *q,const char *hex,Path *park,Error *e) {
    Info st; char old[65],saved[65],name[84]; int parked=0;
    sam_format(name,sizeof(name),".samero-queue-%s.previous",r->id);
    if (!path_join(park,r->workspace.p,name)) return 0;
    if (file_info(park->p,&st)) {
        if (st.kind!=1 || st.size>2*MIB || !*r->pending_hash || !digest_file(park->p,saved,e) ||
            strcmp(saved,r->queue_hash)) return errorf(e,"Đã giữ bản hàng đợi để đối chiếu tại %s.",name);
        if (!file_info(path,&st)) {
            if (!move_queue_exclusive(park->p,path)) return errorf(e,"Không thể phục hồi bản hàng đợi đã giữ.");
        } else {
            if (st.kind!=1 || st.size>2*MIB || !digest_file(path,old,e) || strcmp(old,r->pending_hash))
                return errorf(e,"Hai bản TASK_QUEUE.json khác nhau. Đã giữ cả hai, gồm %s.",name);
            strcpy(r->queue_hash,old);
            if (!remove_file(park->p) || !save(m,r,e)) return 0;
        }
    }
    if (file_info(path,&st)) {
        if (st.kind!=1 || st.size>2*MIB || !digest_file(path,old,e) ||
            (strcmp(old,r->queue_hash) && strcmp(old,r->pending_hash) && strcmp(old,hex)))
            return errorf(e,"TASK_QUEUE.json đã có dữ liệu khác. Manager giữ nguyên tệp để đối chiếu.");
        if (!strcmp(old,hex)) goto commit;
        strcpy(r->queue_hash,old); strcpy(r->pending_hash,hex);
        if (!save(m,r,e) || !move_queue_exclusive(path,park->p)) return errorf(e,"Không thể giữ phiên bản TASK_QUEUE.json trước khi cập nhật.");
        parked=1;
        if (!file_info(park->p,&st) || st.kind!=1 || st.size>2*MIB || !digest_file(park->p,saved,e) || strcmp(saved,old)) {
            move_queue_exclusive(park->p,path); return errorf(e,"TASK_QUEUE.json vừa thay đổi. Kiểm tra cả bản %s nếu có.",name);
        }
    } else {
        if (*r->queue_hash) return errorf(e,"TASK_QUEUE.json đã bị di chuyển.");
        strcpy(r->pending_hash,hex); if (!save(m,r,e)) return 0;
    }
    if (!write_new_atomic(path,q->s,q->n,e)) {
        if (parked) move_queue_exclusive(park->p,path);
        return 0;
    }
    if (parked && !remove_file(park->p)) return errorf(e,"Không thể hoàn tất cập nhật hàng đợi. Bản trước còn tại %s.",name);
commit:
    strcpy(r->queue_hash,hex); r->pending_hash[0]=0; return save(m,r,e);
}
static int snapshot(Manager *m,Run *r,const char *destination,Error *e) {
    if (!bound(m,r,e) || workspace_busy(m,r->workspace.p) || !guarded_resume(m,"","","",r->workspace.p,e))
        return errorf(e,"Không thể chụp checkpoint khi đường dẫn thay đổi hoặc workspace đang được sử dụng.");
    Path *p=allocate(3*sizeof(*p)); Buf q={0},status={0},line={0};
    int ok=0; Info st; char hex[65],marker[110];
    if (!path_join(&p[0],r->workspace.p,"TASK_QUEUE.json") || !path_join(&p[1],r->workspace.p,"PROJECT_STATUS.md")) goto end;
    queue_json(r,&q); buffer_char(&q,'\n'); Sha256 sha={0}; sha_update(&sha,q.s,q.n); sha_finish(&sha,hex);
    if (*r->catchup_hash) {
        char live[65];
        if (!file_info(p[0].p,&st) || st.kind!=1 || st.size>2*MIB ||
            !digest_file(p[0].p,live,e) || strcmp(live,r->catchup_hash)) {
            errorf(e,"Hàng đợi thay đổi trong khi đối chiếu. Đã giữ nguyên cả hai bản."); goto end;
        }
        if (r->index<r->catchup_index) goto archive_only;
        strcpy(r->queue_hash,r->catchup_hash); r->catchup_index=0; r->catchup_hash[0]=0;
    }
    if (!publish_queue(m,r,p[0].p,&q,hex,&p[2],e)) goto end;
    sam_format(marker,sizeof(marker),"<!-- SAMERO %s %d -->",r->id,r->revision);
    if (file_info(p[1].p,&st) && (st.kind!=1 || st.size>4*MIB || !read_file(p[1].p,4*MIB,&status,e) ||
        !text_utf8(status.s,status.n))) { errorf(e,"PROJECT_STATUS.md không phải tài liệu văn bản an toàn."); goto end; }
    /* Journal is the authority for already accepted work. Backfill missing
       human-readable receipts before starting another stage, including runs
       migrated from older releases. Never promote a workspace claim to PASS. */
    for (int i=0;i<r->index;++i) {
        const Task *t=&r->tasks[i]; char receipt[100];
        sam_format(receipt,sizeof(receipt),"<!-- SAMERO TASK %s %d -->",r->id,i+1);
        if (!status.s || !strstr(status.s,receipt)) buffer_fmt(&line,"\n%s\n- Task %d: %s — PASS (Manager journal)\n  - Evidence: %s\n  - Test session: %s\n  - Verify session: %s\n",
            receipt,i+1,t->title,t->evidence,*t->test_session?t->test_session:"not recorded in legacy journal",
            *t->verify_session?t->verify_session:"not recorded in legacy journal");
        if (t->command_count || t->receipt_version==2) {
            char cmdmarker[100]; sam_format(cmdmarker,sizeof(cmdmarker),"<!-- SAMERO COMMANDS V1 %s %d -->",r->id,i+1);
            if (!status.s || !strstr(status.s,cmdmarker)) buffer_fmt(&line,
                "\n%s\n- Task %d command observations: %s (%d). This is not a complete historical transcript.\n%s\n",
                cmdmarker,i+1,t->command_count?(t->command_partial?"PARTIAL":"OBSERVED"):"NOT RECORDED",
                t->command_count,t->commands);
        }
        if (t->receipt_version==2) {
            char v2[100]; sam_format(v2,sizeof(v2),"<!-- SAMERO RECEIPT V2 %s %d -->",r->id,i+1);
            if (!status.s || !strstr(status.s,v2)) buffer_fmt(&line,
                "\n- Task %d receipt (Manager journal):\n  - Checkpoint (%s): %s\n  - Recovery checkpoint (not historical acceptance): %s\n  - Baseline checkpoint: %s%s\n  - Changed files: %s (%d recorded; compare referenced manifests for complete recorded delta)\n%s\n  - Errors: %s (%d recorded)\n%s\n%s\n",
                i+1,t->historical_checkpoint?"historical observation after PASS":"acceptance",*t->checkpoint?t->checkpoint:"not recorded in legacy journal",
                *t->recovery_checkpoint?t->recovery_checkpoint:"not needed",
                *t->baseline?t->baseline:"not recorded in legacy journal",t->baseline_recovery?" (recorded interval only, not full task history)":"",
                t->change_status,t->change_count,t->changes,t->error_status,t->error_count,t->errors,v2);
        }
    }
    if (!status.s || !strstr(status.s,marker)) {
        buffer_fmt(&line,"\n%s\n- Autonomous %s · %s · %d/%d · test %s · build %s\n",marker,modes[r->mode],phases[r->phase],r->index,r->count,result(r->test),result(r->build));
    }
    if (line.n) {
        if (status.n+line.n>4*MIB) { errorf(e,"PROJECT_STATUS.md vượt giới hạn 4 MiB; hãy lưu trữ nhật ký cũ."); goto end; }
        FILE *f=file_open_append(p[1].p);
        if (!f) { errorf(e,"Không mở được PROJECT_STATUS.md để ghi nối tiếp."); goto end; }
        int wrote=fwrite(line.s,1,line.n,f)==line.n && file_flush(f);
        if (fclose(f) || !wrote) { errorf(e,"Không lưu được PROJECT_STATUS.md."); goto end; }
    }
archive_only:
    new_id(r->archive_id); r->archived_revision=r->revision; r->archive_since=monotonic_ms();
    if (!save(m,r,e)) goto end;
    const char *argv[]={"--runner-checkpoint",m->data.p,r->project,r->archive_id,destination?destination:"-",NULL};
    ok=self_executable(&p[0]) && process_start(&r->archiver,p[0].p,argv,NULL,m->data.p,1,0,e);
    if (ok) process_close_input(&r->archiver);
    else r->archive_id[0]=0;
end:
    free(p); buffer_free(&q); buffer_free(&status); buffer_free(&line);
    return ok;
}
int runner_checkpoint_worker(const char *root,const char *project,const char *id,const char *dest) {
    if (!valid_id(project) || !valid_id(id) || (strcmp(dest,"-") && !valid_id(dest))) return 2;
    Manager *m=allocate(sizeof(*m)); Error e={0}; Buf args={0},out={0}; int ok=manager_readonly(m,root,&e);
    if (ok) {
        m->runner_internal=1;
        buffer_char(&args,'{'); json_pair(&args,"project",project); KEY(&args,"reservedId",id); RAW(&args,"quiet","true");
        if (strcmp(dest,"-")) { KEY(&args,"destination",dest); }
        ok=invoke(m,strcmp(dest,"-")?2:1,&args,&out,&e);
    }
    if (!ok && *e.msg) worker_stdout(e.msg,strlen(e.msg));
    buffer_free(&args); buffer_free(&out); free(m); return ok?0:1;
}
static int poll_snapshot(Manager *m,Run *r,Error *e) {
    int code=0;
    if (monotonic_ms()-r->archive_since>30u*60u*1000u) process_stop(&r->archiver);
    int running=process_poll(&r->archiver,&code);
    if (running>0) return 1;
    char why[ERROR_CAP]={0}; int bytes=process_read(&r->archiver,why,sizeof(why)-1); if (bytes>0) why[bytes]=0;
    process_dispose(&r->archiver); r->archiver=(Process){0};
    Document d={0}; char project[33],dest[33]; int ok=running==0 && code==0 && get_doc(m,"checkpoints",r->archive_id,&d,e) &&
        FIELD(&d,"project",project) && !strcmp(project,r->project);
    if (ok) {
        FIELD(&d,"sourceHash",r->source_hash);
        strcpy(r->checkpoint,r->archive_id); r->snapshot=r->revision!=r->archived_revision;
        if (*r->accept_hash && !r->snapshot) {
            Task *t=&r->tasks[r->index];
            if (!strcmp(r->accept_hash,r->source_hash)) {
                strcpy(t->checkpoint,r->archive_id); strcpy(t->accepted_hash,r->source_hash);
                t->receipt_version=2; task_delta(m,r,t);
                if (!*t->error_status) strcpy(t->error_status,t->baseline_recovery?"PARTIAL":"RECORDED");
                ++r->index; r->attempt=0; r->failure_hash[0]=0; r->failure_gate[0]=0;
                r->phase=r->index==r->count?FINAL_TEST:r->recovery_scan?TEST:WORK;
                note(r,t->evidence);
            } else {
                t->test_session[0]=0; t->verify_session[0]=0; r->mode=REVIEW; r->phase=TEST;
                note(r,"Workspace thay đổi trong lúc nghiệm thu. Cần chạy lại test trước khi xác nhận.");
            }
            r->accept_hash[0]=0; r->snapshot=1;
        }
        /* Complete old receipts before the next task starts. A new recovery
           checkpoint records today's state, not a fabricated historical one. */
        int migrated=0;
        for (int i=0;i<r->index;++i) if (r->tasks[i].receipt_version<2) { migrated=1; break; }
        if (migrated) historical_receipts(m,r);
        for (int i=0;i<r->index;++i) if (r->tasks[i].receipt_version<2) {
            Task *t=&r->tasks[i]; t->receipt_version=2;
            strcpy(t->recovery_checkpoint,r->archive_id);
            if (!*t->change_status) strcpy(t->change_status,"NOT RECORDED");
            if (!*t->error_status || !strcmp(t->error_status,"NOT RECORDED")) strcpy(t->error_status,"NOT RECORDED");
        }
        if (migrated) {r->snapshot=1; note(r,"Đã bổ sung hồ sơ nghiệm thu cũ từ journal và checkpoint đã lưu. Dữ liệu lịch sử không tìm được ghi NOT RECORDED, không tự cấp PASS.");}
        if (*r->destination && FIELD(&d,"destination",dest) && !strcmp(dest,r->destination)) {
            Document profile={0};
            ok=get_doc(m,"profiles",dest,&profile,e) && FIELD(&profile,"home",r->home);
            if (ok) { r->resume_verify=r->phase==VERIFY; strcpy(r->profile,dest); r->limited_at=0; r->limit_owner[0]=0; r->mode=ACTIVE; r->snapshot=1;
                note(r,"Đã bàn giao theo xác nhận. Hồ sơ đích tiếp tục từ hàng đợi."); }
            doc_free(&profile);
        }
    }
    r->destination[0]=0; r->archive_id[0]=0; doc_free(&d);
    if (!ok) { r->mode=BLOCKED; r->snapshot=0; note(r,*why?why:"Không xác minh được checkpoint. Kiểm tra ổ đĩa hoặc tiến trình ngoài."); }
    if (!save(m,r,e)) return 0;
    if (ok && !r->snapshot && !*r->catchup_hash && !run_store_checkpoint(m,r->id,r->journal_hash,r->head_hash,e)) { m->runner_fault=1; return 0; }
    return 1;
}
static int marker(const char *dir,const char *name) {
    Path *p=allocate(sizeof(*p)); Info i;
    int ok=path_join(p,dir,name) && file_info(p->p,&i) && i.kind==1;
    free(p); return ok;
}
static int npm_scripts(const char *dir) {
    Path *p=allocate(sizeof(*p)); Error e={0}; Buf b={0}; JSON j={0};
    int ok=path_join(p,dir,"package.json") && read_file(p->p,512*1024,&b,&e) && json_parse(&j,b.s,b.n);
    if (ok) {
        int scripts=json_get(&j,0,"scripts");
        int test=json_get(&j,scripts,"test"),build=json_get(&j,scripts,"build");
        ok=test>=0 && j.t[test].type=='"' && build>=0 && j.t[build].type=='"';
    }
    json_free(&j); buffer_free(&b); free(p); return ok;
}
static int choose_commands(Run *r,const JSON *in,Error *e) {
    const char *tool="",*test="",*build="";
    if (marker(r->workspace.p,"Cargo.toml")) { tool="cargo"; test="test"; build="build\n--release"; }
    else if (marker(r->workspace.p,"go.mod")) { tool="go"; test="test\n./..."; build="build\n-trimpath\n./..."; }
    else if (marker(r->workspace.p,"pyproject.toml")) {
#ifdef SAM_WINDOWS
        tool="python";
#else
        tool="python3";
#endif
        test="-m\npytest"; build="-m\nbuild";
    } else if (npm_scripts(r->workspace.p)) { tool="npm"; test="test"; build="run\nbuild"; }
    Path *tmp=allocate(sizeof(*tmp)); int ok=1;
    for (int i=0;i<2 && ok;++i) {
        Command *c=&r->checks[i];
        ok=safe_field(tmp->p,sizeof(tmp->p),in,i?"buildExe":"testExe") &&
            safe_field(c->args,sizeof(c->args),in,i?"buildArgs":"testArgs");
        if (!ok) break;
        if (*tmp->p) ok=locate_exec(tmp->p,"",&c->exe);
        else if (*tool && !*c->args) {
            char name[32]; sam_format(name,sizeof(name),"%s%s",tool,
#ifdef SAM_WINDOWS
            ".exe"
#else
            ""
#endif
            );
#ifdef SAM_WINDOWS
            if (!strcmp(tool,"npm")) {
                ok=locate_exec(NULL,"node.exe",&c->exe);
                if (ok) {
                    strcpy(tmp->p,c->exe.p);
                    size_t cut=(size_t)(base_name(tmp->p)-tmp->p);
                    tmp->p[cut]=0; Path *script=allocate(sizeof(*script)); Info info;
                    ok=path_join(script,tmp->p,"node_modules/npm/bin/npm-cli.js") && file_info(script->p,&info) &&
                        info.kind==1 && sam_format(c->args,sizeof(c->args),"%s\n%s",script->p,i?build:test)<(int)sizeof(c->args);
                    free(script);
                }
                continue;
            }
#endif
            ok=locate_exec(NULL,name,&c->exe);
            sam_format(c->args,sizeof(c->args),"%s",i?build:test);
        } else ok=0;
    }
    free(tmp);
    return ok || errorf(e,"Cần hai lệnh tin cậy cho test và build Release. Nhập tệp thực thi và đối số trong Tùy chọn kiểm thử.");
}
static int limit_data(Manager *m,Run *r,int fresh) {
    Document d={0},auth={0}; Error e={0}; char source[20],a[32],owner[320],sample[320];
    int ok=get_doc(m,"auth",r->profile,&auth,&e) && get_doc(m,"quota",r->profile,&d,&e) &&
        FIELD(&d,"source",source) && !strcmp(source,"official") && FIELD(&auth,"status",a) && !strcmp(a,"Signed in") &&
        FIELD(&d,"email",sample) && FIELD(&auth,"email",owner) && *owner && !strcmp(owner,sample);
    if (!fresh && !*r->limit_owner && FIELD(&auth,"status",a) && !strcmp(a,"Signed in") && FIELD(&auth,"email",owner))
        sam_format(r->limit_owner,sizeof(r->limit_owner),"%s",owner);
    if (ok) {
        long long h=NUMBER(&d.data,"h",-1),w=NUMBER(&d.data,"w",-1),at=NUMBER(&d.data,"at",0);
        if (fresh) ok=*r->limit_owner && !strcmp(r->limit_owner,owner) && at>r->limited_since && at>=r->limited_at &&
            at<=timestamp() && timestamp()-at<=300 && quota_verified(m,r->profile)>=at && h>0 && w>0 &&
            NUMBER(&d.data,"hr",0)>timestamp() && NUMBER(&d.data,"wr",0)>timestamp();
        else {
            strcpy(r->limit_owner,owner); long long due=0;
            if (!h) due=NUMBER(&d.data,"hr",0);
            if (!w && NUMBER(&d.data,"wr",0)>due) due=NUMBER(&d.data,"wr",0);
            r->limited_at=due>timestamp()?due:0;
        }
    }
    doc_free(&d); doc_free(&auth); return ok;
}
static void close_owned(Live *l) {
    if (!l || l->stopping) return;
    l->stopping=1; strcpy(l->status,"Stopping"); process_stop(&l->process);
}
static void hold(Manager *m,Run *r,Mode mode,const char *reason) {
    Live *l=owned(m,r); close_owned(l); r->accept_hash[0]=0;
    if (mode==REVIEW || mode==BLOCKED) task_error(r,reason);
    if (r->inflight && r->phase==WORK) r->phase=r->final_repair?FINAL_TEST:VERIFY;
    r->inflight=0; r->mode=mode; r->snapshot=1; r->destination[0]=0;
    note(r,reason); Error ignored={0}; save(m,r,&ignored);
}
void runner_review_denied(Manager *m,Live *l,const char *reason) {
    if (!l->autonomous) return;
    for (Run *r=m->runs;r;r=r->next) {
        if (r->inflight && !r->retired && !strcmp(r->project,l->project) && !strcmp(r->session,l->id)) {
            hold(m,r,REVIEW,reason);
            return;
        }
    }
}
static int backup_amendment(Manager *m,Run *r,char backup[33],Error *e) {
    char hash[65];
    Path *p=allocate(sizeof(*p)); Document old={0}; Info st;
    int ok=path_join(p,r->workspace.p,"TASK_QUEUE.json") && file_info(p->p,&st) && st.kind==1 && st.size<=2*MIB &&
        digest_file(p->p,hash,e) && *r->queue_hash && !strcmp(hash,r->queue_hash) && get_doc(m,"runs",r->id,&old,e);
    if (ok) {
        run_store_hash(&old,hash); new_id(backup);
        ok=!strcmp(hash,r->journal_hash) && !secret_text(old.raw.s) && docs_path(m,"runrecovery",backup,p) &&
            write_new_atomic(p->p,old.raw.s,old.raw.n,e);
    }
    doc_free(&old); free(p);
    return ok || errorf(e,"Không xác minh được journal/hàng đợi gốc để sao lưu. Giữ nguyên dữ liệu, cần đối chiếu.");
}
/* User-authorized compatibility migration for the exact legacy Animation AI
   Task 2 criterion. The functional acceptance remains intact. Missing historic
   command strings are an explicit observation gap, never invented. */
static int migrate_legacy_task2(Manager *m,Run *r,Error *e) {
    static const char before[] = "Trước lần sửa đầu, có snapshot hai cây và thử khôi phục khớp SHA-256. Dùng 0.4.1-dev làm nền, đối chiếu từng tệp khác biệt, giữ đặc tả, queue, bàn giao, dữ liệu và sửa đổi riêng của workspace. Sau mỗi tác vụ, PROJECT_STATUS.md và TASK_QUEUE.json ghi tệp sửa, quyết định, lệnh, kết quả, lỗi và checkpoint khôi phục được. Chỉ tự chuyển bước khi mọi bước trước PASS. STOP giữ nguyên điểm tiếp tục.";
    static const char after[] = "Xác minh snapshot hai cây trước sửa và khôi phục khớp SHA-256. Dùng 0.4.1-dev làm nền; đối chiếu từng tệp khác biệt, giữ đặc tả, queue, bàn giao, dữ liệu và sửa đổi riêng. TASK_QUEUE.json và PROJECT_STATUS.md ghi tệp, quyết định, lệnh, kết quả, lỗi, checkpoint mỗi task. Lịch sử cũ: dùng bằng chứng còn lưu, ghi NOT RECORDED cho lệnh gốc mất; không gán toàn bộ delta cho Task 1. Kiểm tra bằng chứng thay thế, chạy lại phép kiểm cần thiết; không bỏ yêu cầu thực chất. Mọi bước trước PASS; STOP giữ điểm tiếp tục.";
    if (r->index!=1 || r->count!=16 || r->phase==PLAN || r->inflight || r->snapshot || owned(m,r) ||
        r->archiver.handle || *r->catchup_hash || *r->pending_hash || *r->accept_hash ||
        strcmp(r->tasks[0].title,"Chốt mốc tiếp quản từ hai cây mã nguồn") ||
        strcmp(r->tasks[1].title,"Sao lưu và đưa phần mã mới nhất vào workspace an toàn") ||
        r->tasks[1].after!=0 || strcmp(r->tasks[1].accept,before)) return 1;
    if (!bound(m,r,e) || workspace_busy(m,r->workspace.p) || !guarded_resume(m,"","","",r->workspace.p,e)) return 0;
    char backup[33],msg[300];
    if (!backup_amendment(m,r,backup,e)) return 0;
    Task *t=&r->tasks[1]; strcpy(t->accept,after); t->review_probe=0;
    t->test_session[0]=0; t->verify_session[0]=0;
    r->attempt=0; r->failure_hash[0]=0; r->failure_gate[0]=0;
    r->test=0; r->recovery_scan=1; r->phase=TEST; r->snapshot=1;
    sam_format(msg,sizeof(msg),"Chuyển tiêu chí lịch sử Task 2 sang bằng chứng còn lưu, giữ yêu cầu thực chất. Journal gốc runrecovery/%s.json; chưa cấp PASS.",backup);
    note(r,msg); return 2;
}
/* Keep the full criterion and response contract within the existing 4 KiB
   synchronous RPC transport. Only old diagnostic text may be shortened. */
#define RUNNER_ENCODED_PROMPT_LIMIT 3300
static size_t encoded_prompt_size(const Buf *b) {
    Buf encoded={0}; json_quote(&encoded,b->s); size_t n=encoded.n; buffer_free(&encoded); return n;
}
static void append_previous(Buf *b,const char *previous) {
    const char *suffix="\nReturn ONLY JSON with met (boolean), needsReview (boolean), and evidence (specific explanation, max 600 UTF-8 bytes).";
    size_t base=b->n,n=strlen(previous),total=n;
    for (;;) {
        b->n=base; b->s[base]=0;
        buffer_fmt(b,"\nPrevious result%s: %.*s%s",n<total?" (excerpt; full in TASK_QUEUE.json)":"",(int)n,previous,suffix);
        if (encoded_prompt_size(b)<=RUNNER_ENCODED_PROMPT_LIMIT || !n) break;
        n=n>32?n-32:0;
        while (n && ((unsigned char)previous[n]&0xc0)==0x80) --n;
    }
}
/* Bind an observed test to the archived workspace and configured command.
   External dependencies and environment are not fully fingerprinted; VERIFY
   must still inspect actual evidence and may require a fresh test. */
static int test_signature(const Run *r,char out[65]) {
    char executable[65]; Error ignored={0}; out[0]=0;
    if (strlen(r->source_hash)!=64 || !digest_file(r->checks[0].exe.p,executable,&ignored)) return 0;
    Sha256 sha={0};
    sha_update(&sha,r->source_hash,65);
    sha_update(&sha,r->checks[0].exe.p,strlen(r->checks[0].exe.p)+1);
    sha_update(&sha,r->checks[0].args,strlen(r->checks[0].args)+1);
    sha_update(&sha,executable,65); sha_finish(&sha,out); return 1;
}
static int launch_stage(Manager *m,Run *r,Error *e) {
    if (!bound(m,r,e) || workspace_busy(m,r->workspace.p) || !guarded_resume(m,"","","",r->workspace.p,e)) return 0;
    int migrated=migrate_legacy_task2(m,r,e);
    if (migrated!=1) return migrated==2 && save(m,r,e);
    Buf b={0},out={0}; int ok;
    if (r->index<r->count && r->phase!=PLAN && !*r->tasks[r->index].baseline && valid_id(r->checkpoint)) {
        Task *t=&r->tasks[r->index]; strcpy(t->baseline,r->checkpoint);
        t->baseline_recovery=r->phase!=WORK || r->recovery_scan || r->attempt>0;
        strcpy(t->error_status,t->baseline_recovery?"PARTIAL":"RECORDED");
    }
    if (r->phase==TEST && r->index<r->count) {
        Task *t=&r->tasks[r->index]; t->test_session[0]=0;
        test_signature(r,t->test_signature);
    }
    r->inflight=1; r->started_tick=r->last_activity=monotonic_ms();
    char previous[sizeof(r->reason)]; strcpy(previous,r->reason);
    note(r,"Đã ghi nhận thao tác trước khi khởi chạy.");
    if (!save(m,r,e)) return 0;
    if (r->phase==PLAN || r->phase==WORK || r->phase==VERIFY) {
        if (r->phase==PLAN) buffer_fmt(&b,
            "SAMERO PLAN. Inspect read-only. Goal: %s\nReturn ONLY JSON tasks in order (1-16). Each task: title (max 200 UTF-8 bytes), accept (objective check, max 600 bytes), after (zero-based earlier dependency or -1). All prior tasks must pass. Cover full goal. Criteria must be verifiable after task test and before its PASS. Never require current queue counters, transient phase, future receipt or final Release build. Historical claims need historical evidence; document gaps and reproducible substitute checks, not invented logs. State external prerequisites explicitly.",r->goal);
        else {
            Task *t=&r->tasks[r->final_repair?r->count-1:r->index];
            buffer_fmt(&b,"SAMERO %s. TASK_QUEUE.json is bookkeeping, not an acceptance criterion. Task %d: %s\nAcceptance: %s\n",
                r->phase==WORK?"WORK":"VERIFY",r->final_repair?r->count:r->index+1,t->title,t->accept);
            if (r->final_repair) buffer_text(&b,"Repair the failed final check only. All planned tasks have already been accepted. ");
            if (r->phase==WORK) buffer_text(&b,"Inspect existing work; implement only missing deliverables. Preserve user files. Manager owns TASK_QUEUE.json and PROJECT_STATUS.md; never edit them. For incomplete history write a separate recovery report with files, decisions, commands/results and NOT RECORDED gaps; rerun checks as needed. Manager records observed completed commands. Never invent history, publish, deploy or use credentials. ");
            else buffer_fmt(&b,"Independent read-only verification. Manager observed test exit 0, session %s (possibly reused for matching tracked files and command; not proof of changed external inputs). First use allowed read-only tools to inspect TASK_QUEUE.json, PROJECT_STATUS.md and required artifacts. If access is denied, return met:false, needsReview:true, evidence beginning BLOCKED_ACCESS: with denied path/tool. For unavailable mandatory external resources use BLOCKED_RESOURCE:. Distinguish unreadable from missing. Check all current criteria; no pending PASS, transient counters, current receipt or future Release build required. Historical deltas cover recorded intervals; NOT RECORDED is unknown. Verify permitted substitutes, never invent evidence or waive requirements. Repairable gaps: met:false, needsReview:false; genuine blockers: needsReview:true. Manager writes receipt after acceptance. ",t->test_session);
            if (r->phase==VERIFY && t->review_probe) buffer_text(&b,"Reassess previous review independently; do not waive any criterion or permission. Distinguish safe repairable gaps from real blockers. PASS needs evidence for every required deliverable. ");
            append_previous(&b,previous);
        }
        if (encoded_prompt_size(&b)>RUNNER_ENCODED_PROMPT_LIMIT) {buffer_free(&b); return errorf(e,"Prompt nội bộ vượt giới hạn truyền JSON; tiêu chí không bị cắt.");}
        m->runner_readonly=r->phase!=WORK;
        ok=start_session(m,r->profile,r->project,NULL,b.s,"chat",&out,e);
        m->runner_readonly=0;
    } else {
        int build=r->phase==RELEASE;
        project_args(r,&b); KEY(&b,"kind",build?"build":"test"); KEY(&b,"exe",r->checks[build].exe.p);
        KEY(&b,"args",r->checks[build].args); RAW(&b,"confirmed","true"); ok=invoke(m,0,&b,&out,e);
    }
    if (ok) {
        JSON j;
        ok=json_parse(&j,out.s,out.n) && ARG(&j,"id",r->session) && valid_id(r->session);
        json_free(&j);
        if (ok) ok=save(m,r,e);
    }
    buffer_free(&b); buffer_free(&out); return ok;
}
static void step(Run *r,Phase phase,const char *msg) {
    r->phase=phase; r->reconnects=0; r->retry_at=0; r->inflight=0; r->snapshot=1; note(r,msg);
}
static void repair(Run *r,const char *reason) {
    task_error(r,reason);
    const char *gate=phases[r->phase];
    int unchanged=*r->source_hash && !strcmp(r->failure_hash,r->source_hash) && !strcmp(r->failure_gate,gate);
    if (r->index<r->catchup_index) { r->mode=REVIEW; step(r,r->phase,reason); return; }
    if (unchanged || r->attempt>=RETRY_LIMIT) {
        char detail[700];
        size_t len=strlen(reason); if (len>545) { len=545; while (((unsigned char)reason[len]&0xc0)==0x80) --len; }
        sam_format(detail,sizeof(detail),"%s %.*s",unchanged?"Không có tiến triển sau lần sửa.":"Đã hết hai lần sửa tự động.",(int)len,reason);
        r->mode=BLOCKED; step(r,r->phase,detail); return;
    }
    ++r->attempt; strcpy(r->failure_hash,r->source_hash); strcpy(r->failure_gate,gate);
    if (r->index==r->count) r->final_repair=1;
    else r->tasks[r->index].test_session[0]=0;
    step(r,WORK,reason);
}
static int valid_test(Manager *m,Run *r,const char *sid,int *code,Buf *output,Error *e) {
    Document d={0}; char project[33],kind[24],status[24]; Path *path=allocate(sizeof(*path));
    int build=r->phase==RELEASE;
    int ok=valid_id(sid) && get_doc(m,"sessions",sid,&d,e) &&
        FIELD(&d,"project",project) && !strcmp(project,r->project) &&
        FIELD(&d,"workspace",path->p) && !strcmp(path->p,r->workspace.p) &&
        FIELD(&d,"kind",kind) && !strcmp(kind,build?"build":"test") &&
        FIELD(&d,"status",status) && NUMBER(&d.data,"ended",0)>0;
    if (ok) {
        int t=json_get(&d.data,0,"exitCode");
        ok=t>=0 && d.data.t[t].type=='0';
        *code=(int)NUMBER(&d.data,"exitCode",-1);
        ok=ok && !strcmp(status,*code?"Failed":"Completed");
        if (ok && output) {
            char *log=allocate(8193);
            if (json_field(&d.data,0,"output",log,8193) && !secret_text(log)) buffer_text(output,log);
            free(log);
        }
    }
    free(path); doc_free(&d); return ok;
}
static int answer(Manager *m,Run *r,Live *l,Error *e) {
    const char *msg=chat_runner_result(l); JSON reply={0}; int ok=0;
    if (!msg || !json_parse(&reply,msg,strlen(msg))) goto end;
    if (r->phase==PLAN) {
        ok=read_tasks(r,&reply,1);
        if (ok) { r->attempt=0; step(r,WORK,"Đã kiểm tra thứ tự phụ thuộc và tiêu chí nghiệm thu."); }
    } else {
        int met=json_get(&reply,0,"met"),review=json_get(&reply,0,"needsReview"); char evidence[680];
        ok=(review<0 || reply.t[review].type=='t' || reply.t[review].type=='f') && met>=0 && (reply.t[met].type=='t' || reply.t[met].type=='f') &&
            json_field(&reply,0,"evidence",evidence,sizeof(evidence)) && *evidence && !secret_text(evidence);
        if (!ok) goto end;
        if (r->final_repair) { r->final_repair=0; if (YES(&reply,"needsReview")) r->mode=REVIEW; step(r,FINAL_TEST,evidence); }
        else {
            Task *t=&r->tasks[r->index]; strcpy(t->evidence,evidence);
            if (r->phase==WORK) { if (YES(&reply,"needsReview")) {r->mode=REVIEW; task_error(r,evidence);} step(r,TEST,evidence); }
            else if (*review_blocker(evidence)) {
                /* No automatic probe or repair when the verifier explicitly reports
                   an access/resource blocker. Even contradictory met:true cannot PASS. */
                task_error(r,evidence); r->mode=REVIEW; step(r,VERIFY,evidence);
            }
            else if (YES(&reply,"needsReview")) {
                task_error(r,evidence);
                if (r->mode==ACTIVE && r->phase==VERIFY && r->index>=r->catchup_index && !t->review_probe) {
                    /* One independent read-only diagnosis, not another write attempt.
                       Permission denials go through runner_review_denied, never here. */
                    t->review_probe=1;
                    step(r,VERIFY,evidence);
                } else { r->mode=REVIEW; step(r,VERIFY,evidence); }
            }
            else if (!json_bool(&reply,met)) repair(r,evidence);
            else {
                int code=-1;
                if (!valid_test(m,r,t->test_session,&code,NULL,e) || code!=0) {
                    json_free(&reply); return errorf(e,"Chưa xác minh được kết quả test của nhiệm vụ hiện tại.");
                }
                if (!*r->source_hash) { json_free(&reply); return errorf(e,"Thiếu dấu kiểm tra nội dung checkpoint."); }
                strcpy(t->verify_session,r->session); strcpy(r->accept_hash,r->source_hash);
                step(r,VERIFY,"Đang xác minh workspace của lượt nghiệm thu trước khi ghi PASS.");
            }
        }
    }
end:
    json_free(&reply);
    return ok || errorf(e,"Thiếu phản hồi cuối có cấu trúc hoặc bằng chứng nghiệm thu cho lượt này.");
}
static void check_finished(Run *r,int code,const char *log) {
    if (r->phase==RELEASE) r->build=code?-1:1;
    else r->test=code?-1:1;
    if (code) {
        char why[590]; size_t n=strlen(log);
        if (n>400) { log+=n-400; while (((unsigned char)*log&0xc0)==0x80) ++log; }
        sam_format(why,sizeof(why),"Lệnh %s trả mã thoát %d. %s",phases[r->phase],code,log);
        repair(r,why);
    } else if (r->phase==TEST) {
        strcpy(r->tasks[r->index].test_session,r->session);
        step(r,VERIFY,r->tasks[r->index].evidence[0]?r->tasks[r->index].evidence:"Đã lưu kết quả test cho nhiệm vụ.");
    } else if (r->phase==FINAL_TEST) { r->final_repair=0; step(r,RELEASE,"Kiểm thử hồi quy cuối trả mã 0."); }
    else { r->final_repair=0; step(r,FINISH,"Build Release trả mã 0."); }
}
static void tick_one(Manager *m,Run *r) {
    if (r->retired) return;
    Error e={0}; Live *l=owned(m,r);
    if (r->archiver.handle) { poll_snapshot(m,r,&e); return; }
    if (!r->inflight && l) { close_owned(l); return; }
    if (!r->inflight) r->session[0]=0;
    if (r->snapshot && !r->inflight) {
        if (!snapshot(m,r,*r->destination?r->destination:NULL,&e)) {
            r->snapshot=0; r->mode=BLOCKED; note(r,*e.msg?e.msg:"Tạo checkpoint thất bại."); save(m,r,&e);
        }
        return;
    }
    if (r->mode==LIMITED && r->auto_resume && *r->limit_owner && timestamp()>=r->limited_at) {
        if (!limit_data(m,r,1)) { quota_due(m,r->profile,0); return; }
        r->mode=ACTIVE; note(r,"Codex xác nhận hạn mức đã khả dụng trên cùng hồ sơ."); save(m,r,&e); return;
    }
    if (r->mode!=ACTIVE && !(r->inflight && r->mode==PAUSED)) return;
    if (!r->inflight) {
        if (r->retry_at>timestamp()) return;
        if (r->resume_verify) {
            r->resume_verify=0;
            if (r->phase==VERIFY && r->index<r->count) {
                Task *t=&r->tasks[r->index]; char signature[65]; int code=-1; Error check={0};
                if (!*t->test_signature || !test_signature(r,signature) || strcmp(t->test_signature,signature) ||
                    !valid_test(m,r,t->test_session,&code,NULL,&check) || code!=0) {
                    t->test_session[0]=0; t->test_signature[0]=0; r->test=0;
                    step(r,TEST,"Biên nhận test thiếu hoặc fingerprint đã đổi. Cần test lại trước khi nghiệm thu."); save(m,r,&e); return;
                }
                r->test=1;
                note(r,"Giữ biên nhận test exit 0 theo fingerprint checkpoint và lệnh đã ghi. Vẫn cần nghiệm thu thực tế.");
            }
            if (!save(m,r,&e)) return;
        }
        if (r->phase==VERIFY && !valid_id(r->tasks[r->index].test_session)) {
            step(r,TEST,"Cần kết quả test cho nhiệm vụ này trước khi nghiệm thu."); save(m,r,&e); return;
        }
        if (r->phase==FINISH) {
            r->mode=DONE; r->snapshot=1; note(r,"Đã đạt tiêu chí, kiểm thử cuối và build Release."); save(m,r,&e);
        } else if (!launch_stage(m,r,&e)) hold(m,r,REVIEW,*e.msg?e.msg:"Không khởi chạy được giai đoạn.");
        return;
    }
    if (!l) {
        if (r->phase==TEST || r->phase==FINAL_TEST || r->phase==RELEASE) {
            Buf output={0}; int code=-1;
            if (valid_test(m,r,r->session,&code,&output,&e)) {
                if (r->phase==TEST && r->index<r->count) {
                    Command *c=&r->checks[0]; char cmd[1801];
                    int n=sam_format(cmd,sizeof(cmd),"%s | args (one per line): %s",c->exe.p,c->args);
                    command_observed(&r->tasks[r->index],"test",r->session,n>=0 && n<(int)sizeof(cmd)?cmd:NULL,code);
                }
                check_finished(r,code,output.s?output.s:""); r->session[0]=0; save(m,r,&e);
            } else hold(m,r,REVIEW,"Tiến trình đã ngừng. Chưa xác nhận kết quả test/build.");
            buffer_free(&output);
        } else if (r->mode==ACTIVE && (r->phase==PLAN || r->phase==VERIFY) && r->reconnects<2) {
            ++r->reconnects; r->retry_at=timestamp()+3*r->reconnects; r->inflight=0; r->session[0]=0; r->snapshot=1;
            note(r,"Mất kết nối ở lượt chỉ đọc. Đang lưu checkpoint trước khi thử lại."); save(m,r,&e);
        } else if (r->mode==ACTIVE && r->phase==WORK && !r->final_repair && r->index<r->count && !r->tasks[r->index].work_recoveries) {
            r->tasks[r->index].work_recoveries=1;
            task_error(r,"Mất kết nối lượt ghi; không phát lại lệnh cũ.");
            step(r,TEST,"Tự phục hồi sau mất kết nối: lưu phần đã ghi, chạy test và nghiệm thu trước khi sửa tiếp."); save(m,r,&e);
        } else hold(m,r,REVIEW,"Mất kết nối Codex. Hãy kiểm tra công việc đã ghi trước khi tiếp tục.");
        return;
    }
    if (l->chat) {
        const char *stage=chat_runner_progress(l);
        if (l->runner_activity>r->last_activity) r->last_activity=l->runner_activity;
        if (!strcmp(stage,"completed")) {
            if (!answer(m,r,l,&e)) {
                if (r->mode==ACTIVE && (r->phase==PLAN || r->phase==VERIFY) && r->reconnects<2 && !*r->accept_hash) {
                    ++r->reconnects; r->retry_at=timestamp()+3*r->reconnects; r->inflight=0; r->snapshot=1;
                    note(r,"Phản hồi chỉ đọc không hợp lệ. Lưu checkpoint và thử lại có giới hạn.");
                    chat_runner_close(l); save(m,r,&e); return;
                }
                hold(m,r,REVIEW,e.msg); return;
            }
            chat_runner_close(l); save(m,r,&e); return;
        }
        if (!strcmp(stage,"limited")) {
            r->limited_since=timestamp(); r->limited_at=0; r->limit_owner[0]=0; limit_data(m,r,0); quota_due(m,r->profile,1);
            hold(m,r,LIMITED,"Codex báo hết hạn mức. Đã dừng trên hồ sơ hiện tại."); return;
        }
        if (strcmp(stage,"starting") && strcmp(stage,"running")) { hold(m,r,REVIEW,"Lượt Codex chưa hoàn tất. Kiểm tra log trong Workspace."); return; }
    }
    if (l->runner_activity>r->last_activity) r->last_activity=l->runner_activity;
    if (monotonic_ms()-r->last_activity>=SAM_RUNNER_IDLE_MS || monotonic_ms()-r->started_tick>=4u*SAM_RUNNER_IDLE_MS) hold(m,r,REVIEW,"Watchdog đã dừng tiến trình khi vượt thời hạn cho giai đoạn.");
}
void runner_tick(Manager *m) {
    uint64_t now=monotonic_ms();
    if (m->runner_fault) {
        for (Live *l=m->live;l;l=l->next) if (l->autonomous) close_owned(l);
        return;
    }
    if (now<m->runner_tick) return;
    m->runner_tick=now+300; m->runner_internal=1;
    for (Run *r=m->runs;r && !m->runner_fault;r=r->next) tick_one(m,r);
    m->runner_internal=0;
}
static Run *current(Manager *m,const char *project) {
    for (Run *r=m->runs;r;r=r->next) if (!r->retired && !strcmp(project,r->project)) return r;
    return NULL;
}
static int new_run(Manager *m,const JSON *in,Buf *out,Error *e) {
    Run *r=allocate(sizeof(*r)); Document p={0},account={0}; int ok=0;
    if (!ARG(in,"project",r->project) || !ARG(in,"profile",r->profile) || !YES(in,"confirmed") ||
        !get_doc(m,"projects",r->project,&p,e) || !get_doc(m,"profiles",r->profile,&account,e) ||
        !FIELD(&p,"path",r->workspace.p) || !FIELD(&account,"home",r->home)) goto end;
    Run *prior=current(m,r->project);
    if (prior && ((prior->mode!=STOPPED && prior->mode!=DONE) || prior->inflight || prior->snapshot || owned(m,prior))) {
        errorf(e,"Dự án đã có hàng đợi. Sử dụng Tiếp tục hoặc Dừng."); goto end;
    }
    if (!safe_field(r->goal,sizeof(r->goal),in,"goal") ||
        (!*r->goal && (!FIELD(&p,"goal",r->goal) || !*r->goal))) { errorf(e,"Nhập mục tiêu (tối đa 1.249 byte UTF-8)."); goto end; }
    if (!bound(m,r,e) || workspace_busy(m,r->workspace.p) || !guarded_resume(m,"","","",r->workspace.p,e) ||
        !choose_commands(r,in,e)) goto end;
    new_id(r->id); r->auto_resume=YES(in,"autoResume"); r->snapshot=1;
    if (prior) strcpy(r->queue_hash,prior->queue_hash);
    note(r,"Đã nhận mục tiêu. Đang lưu checkpoint ban đầu.");
    if (prior) strcpy(r->previous_run,prior->id);
    if (!save(m,r,e)) goto end;
    if (prior) { prior->retired=1; if (!save(m,prior,e)) goto end; }
    r->next=m->runs; m->runs=r; buffer_char(out,'{'); json_pair(out,"id",r->id); buffer_char(out,'}'); r=NULL; ok=1;
end:
    doc_free(&p); doc_free(&account); free(r);
    return ok || (*e->msg?0:errorf(e,"Chọn dự án, hồ sơ và xác nhận chạy."));
}
/* An edited workspace queue can describe work to inspect. It cannot grant
   PASS or change the plan, profile, goal, commands or test receipts. */
static int reconcile_queue(Manager *m,Run *r,Error *e) {
    Path *p=allocate(2*sizeof(*p)); Buf raw={0}; JSON j={0}; Info st; int ok=0;
    char hash[65],id[33],project[33],profile[33],name[33],goal[1250];
    if (!path_join(p,r->workspace.p,"TASK_QUEUE.json")) goto end;
    if (!file_info(p->p,&st)) { ok=!*r->queue_hash; goto end; }
    if (st.kind!=1 || st.size>2*MIB || !read_file(p->p,2*MIB,&raw,e)) goto end;
    Sha256 sha={0}; sha_update(&sha,raw.s,raw.n); sha_finish(&sha,hash);
    if (!strcmp(hash,r->queue_hash) || !strcmp(hash,r->pending_hash) || !strcmp(hash,r->catchup_hash)) { ok=1; goto end; }
    if (secret_text(raw.s) || !json_parse(&j,raw.s,raw.n) || !ARG(&j,"id",id) || strcmp(id,r->id) ||
        !ARG(&j,"project",project) || strcmp(project,r->project) || !ARG(&j,"profile",profile) || strcmp(profile,r->profile) ||
        !ARG(&j,"goal",goal) || strcmp(goal,r->goal)) goto end;
    long long rev=NUMBER(&j,"revision",-1),index=NUMBER(&j,"index",-1); int a=json_get(&j,0,"tasks");
    if (rev<r->revision || rev>=2147483600 || index<r->index || index>r->count || !r->count ||
        a<0 || j.t[a].type!='[' || j.t[a].count!=r->count) goto end;
    int n=0;
    for (int i=a+1;i<j.t[a].after;i=j.t[i].after,++n) {
        char title[256],accept[680],status[24]; Task *t=&r->tasks[n];
        if (!json_field(&j,i,"title",title,sizeof(title)) || strcmp(title,t->title) ||
            !json_field(&j,i,"accept",accept,sizeof(accept)) || strcmp(accept,t->accept) ||
            json_int(&j,json_get(&j,i,"after"),-2)!=t->after ||
            !json_field(&j,i,"status",status,sizeof(status)) || strcmp(status,n<index?"PASS":"NOT VERIFIED")) goto end;
    }
    new_id(name);
    if (!docs_path(m,"runrecovery",name,p+1) || !write_new_atomic(p[1].p,raw.s,raw.n,e)) goto end;
    r->revision=(int)rev; r->catchup_index=(int)index; strcpy(r->catchup_hash,hash); ok=1;
end:
    free(p); buffer_free(&raw); json_free(&j);
    return ok || errorf(e,"TASK_QUEUE.json khác journal hoặc kế hoạch không khớp. Đã giữ nguyên tệp.");
}
/* Explicit user amendment of a pending criterion. Preserve the exact old journal. */
static int amend_acceptance(Manager *m,Run *r,const JSON *in,Error *e) {
    char proposed[680],backup[33];
    if (!(r->mode==BLOCKED || r->mode==REVIEW || r->mode==PAUSED || r->mode==STOPPED) ||
        r->index>=r->count || r->phase==PLAN || r->snapshot || r->inflight || owned(m,r) ||
        r->archiver.handle || *r->catchup_hash || *r->pending_hash || *r->accept_hash ||
        !YES(in,"confirmed") || NUMBER(in,"revision",-1)!=r->revision || NUMBER(in,"taskIndex",-1)!=r->index)
        return errorf(e,"Chỉ sửa tiêu chí nhiệm vụ chưa đạt khi hàng đợi đã dừng và checkpoint đã ổn định.");
    Task *t=&r->tasks[r->index];
    if (!safe_field(proposed,sizeof(proposed),in,"accept") || !proposed[strspn(proposed," \t\r\n")] || !strcmp(proposed,t->accept))
        return errorf(e,"Nhập tiêu chí mới khác bản cũ, tối đa 679 byte UTF-8, không chứa bí mật.");
    if (!bound(m,r,e) || workspace_busy(m,r->workspace.p) || !guarded_resume(m,"","","",r->workspace.p,e))
        return errorf(e,"Workspace hoặc hồ sơ chưa sẵn sàng để sửa tiêu chí.");
    if (!backup_amendment(m,r,backup,e)) return 0;
    strcpy(t->accept,proposed); r->resume_verify=0; t->test_signature[0]=0; t->review_probe=0; t->evidence[0]=0; t->test_session[0]=0; t->verify_session[0]=0;
    r->attempt=0; r->failure_hash[0]=0; r->failure_gate[0]=0; r->test=0; r->build=0;
    r->recovery_scan=1; r->mode=YES(in,"resumeAfter")?ACTIVE:REVIEW; r->phase=TEST; r->snapshot=1; r->session[0]=0;
    char msg[220]; sam_format(msg,sizeof(msg),"Người dùng sửa tiêu chí Task %d; journal gốc: runrecovery/%s.json. Cần test và nghiệm thu lại, chưa cấp PASS.",r->index+1,backup);
    note(r,msg); if (r->mode==ACTIVE) note(r,"Đã xác nhận sửa tiêu chí và tiếp tục; chờ checkpoint rồi chạy test và nghiệm thu lại."); return 1;
}
int runner_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    if (m->runner_fault) return errorf(e,"Không lưu được nhật ký. Để phục hồi an toàn, kiểm tra ổ đĩa và mở lại Manager.");
    if (!strcmp(action,"runner-start")) return new_run(m,in,out,e);
    char project[33],id[33]; ARG(in,"project",project); ARG(in,"id",id);
    Run *r=current(m,project);
    if (!r || strcmp(id,r->id)) return errorf(e,"Hàng đợi đã thay đổi. Hãy làm mới.");
    int rev=json_get(in,0,"revision");
    if ((!strcmp(action,"runner-resume") || !strcmp(action,"runner-handover")) && rev>=0 && json_int(in,rev,-1)!=r->revision) return errorf(e,"Tiến độ đã thay đổi. Làm mới trước khi điều khiển nhiệm vụ.");
    if (!strcmp(action,"runner-amend")) {
        if (!amend_acceptance(m,r,in,e)) return 0;
    } else if (!strcmp(action,"runner-stop") && r->mode==STOPPED) { buffer_text(out,"{}"); return 1; }
    else if (!strcmp(action,"runner-stop") && r->mode!=DONE) {
        hold(m,r,STOPPED,"Người dùng đã dừng. Kiểm tra phần việc đã ghi trước khi tiếp tục.");
    } else if (!strcmp(action,"runner-pause") && r->mode==ACTIVE) {
        r->mode=PAUSED; if (!r->inflight) r->snapshot=1;
        note(r,"Đã yêu cầu tạm dừng tại ranh giới giai đoạn.");
    } else if (!strcmp(action,"runner-resume") && r->mode!=DONE && r->mode!=ACTIVE && YES(in,"confirmed")) {
        if (r->snapshot || r->inflight || owned(m,r) || workspace_busy(m,r->workspace.p)) return errorf(e,"Đợi checkpoint và tiến trình hiện tại kết thúc.");
        if (r->mode==LIMITED && !limit_data(m,r,1)) return errorf(e,"Chưa xác minh được hạn mức mới. Hãy làm mới hồ sơ.");
        if (!bound(m,r,e) || !reconcile_queue(m,r,e)) return 0;
        int migrated=migrate_legacy_task2(m,r,e);
        if (!migrated) return 0;
        if (r->index<r->count && r->phase!=PLAN) {
            r->recovery_scan=1;
            Task *t=&r->tasks[r->index];
            r->resume_verify=r->phase==VERIFY && *review_blocker(t->evidence) && valid_id(t->test_session);
            if (!r->resume_verify) { t->test_session[0]=0; t->test_signature[0]=0; r->test=0; r->phase=TEST; }
        }
        r->mode=ACTIVE; r->snapshot=1; note(r,"Người dùng đã kiểm tra workspace và yêu cầu tiếp tục.");
    } else if (!strcmp(action,"runner-handover") && YES(in,"confirmed")) {
        char dest[33]; ARG(in,"destination",dest);
        if (r->mode==ACTIVE || r->mode==DONE || r->inflight || r->snapshot || owned(m,r) ||
            !valid_id(dest) || !strcmp(dest,r->profile)) return errorf(e,"Tạm dừng trước, đợi checkpoint rồi chọn hồ sơ đích khác.");
        Document p={0}; Path *home=allocate(sizeof(*home));
        int ok=get_doc(m,"profiles",dest,&p,e) && FIELD(&p,"home",home->p) && strcmp(home->p,r->home);
        if (ok) {
            strcpy(r->destination,dest); r->snapshot=1;
            note(r,"Đang chuẩn bị checkpoint bàn giao cho hồ sơ đã chọn.");
        }
        doc_free(&p); free(home);
        if (!ok) return *e->msg?0:errorf(e,"Hồ sơ đích phải có CODEX_HOME độc lập.");
    } else return errorf(e,"Thao tác không hợp lệ với trạng thái hiện tại.");
    if (!save(m,r,e)) return 0;
    buffer_text(out,"{}"); return 1;
}
