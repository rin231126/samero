#include "manager.h"

#define ROW_LIMIT 2000
#define SCAN_LIMIT 3500
#define DISPLAY_LIMIT 400
#define HEADER_LIMIT (128 * 1024)

typedef struct {
    char id[37], iso[64];
    Path cwd;
    long long created, updated;
    int indexed;
} Saved;
typedef struct {
    Saved *rows;
    size_t count, capacity, files, scanned;
    int truncated;
} Inventory;

static void normalize_uuid(char *id) {
    for (;*id;++id) if (*id>='A' && *id<='F') *id=(char)(*id+('a'-'A'));
}
static void import_id(const char *home,const char *id,char out[33]) {
    Sha256 sha={0}; char hex[65];
    sha_update(&sha,home,strlen(home)+1); sha_update(&sha,id,strlen(id));
    sha_finish(&sha,hex); memcpy(out,hex,32); out[32]=0;
}
static void collect(Inventory *items,Saved *row) {
    for (size_t i=0;i<items->count;++i) {
        Saved *prior=&items->rows[i];
        if (!strcmp(prior->id,row->id)) {
            if (!*prior->cwd.p && *row->cwd.p) prior->cwd=row->cwd;
            if (prior->created<0 && row->created>=0) prior->created=row->created;
            if (row->updated>prior->updated) prior->updated=row->updated;
            if (!prior->iso[0] && row->iso[0]) strcpy(prior->iso,row->iso);
            prior->indexed |= row->indexed;
            return;
        }
    }
    if (items->count>=ROW_LIMIT) { items->truncated=1; return; }
    if (items->count==items->capacity) {
        items->capacity=items->capacity ? items->capacity*2 : 64;
        Saved *expanded=realloc(items->rows,items->capacity*sizeof(*expanded));
        if (!expanded) abort();
        items->rows=expanded;
    }
    items->rows[items->count++]=*row;
}
static int prefix(const char *str,const char *begin) { return !strncmp(str,begin,strlen(begin)); }
static int read_header(const char *path,JSON *j,Buf *line) {
    FILE *f=file_open(path,0);
    if (!f) return 0;
    int ch;
    while (line->n<HEADER_LIMIT && (ch=fgetc(f))!=EOF && ch!='\n') buffer_char(line,(char)ch);
    fclose(f);
    return line->n && line->n<HEADER_LIMIT && json_parse(j,line->s,line->n);
}
static int header_matches(const char *path,const char *id,const char *workspace) {
    Buf line={0}; JSON j; int match=0;
    if (read_header(path,&j,&line)) {
        char kind[24], stored[160];
        int p=json_get(&j,0,"payload");
        Path *paths=allocate(2*sizeof(*paths));
        match=ARG(&j,"type",kind) && !strcmp(kind,"session_meta") &&
            json_field(&j,p,"id",stored,sizeof(stored)) && !strcmp(stored,id) &&
            json_field(&j,p,"cwd",paths[0].p,sizeof(paths[0].p)) && open_directory(paths[0].p,&paths[1]) &&
            within(workspace,paths[1].p) && within(paths[1].p,workspace);
        free(paths); json_free(&j);
    }
    buffer_free(&line); return match;
}
int chat_rollout_matches(const char *path,const char *home,const char *id,const char *workspace) {
    Path *p=allocate(2*sizeof(*p)); Info info;
    int ok=path_join(&p[0],home,"sessions") && canonical(path,&p[1]) && within(p[0].p,p[1].p) &&
        file_info(p[1].p,&info) && info.kind==1 && has_suffix(p[1].p,".jsonl") &&
        header_matches(p[1].p,id,workspace);
    free(p); return ok;
}
static void read_rollout(const char *path,const Info *info,Inventory *items) {
    Buf first={0}; JSON j;
    if (read_header(path,&j,&first)) {
        char type[24], source[40];
        int payload=json_get(&j,0,"payload");
        Saved *row=allocate(sizeof(*row));
        if (ARG(&j,"type",type) && !strcmp(type,"session_meta") &&
            json_field(&j,payload,"id",row->id,sizeof(row->id)) && uuid_valid(row->id)) {
            int has_source=json_field(&j,payload,"source",source,sizeof(source));
            int source_token=json_get(&j,payload,"source");
            int interactive=!has_source ? source_token<0 || j.t[source_token].type=='n':
                !strcmp(source,"cli") || !strcmp(source,"terminal");
            if (interactive) {
                normalize_uuid(row->id);
                if (json_field(&j,payload,"cwd",row->cwd.p,sizeof(row->cwd.p)) && secret_text(row->cwd.p))
                    row->cwd.p[0]=0;
                json_field(&j,payload,"timestamp",row->iso,sizeof(row->iso));
                if (secret_text(row->iso)) row->iso[0]=0;
                row->created=-1; row->updated=info_unix_time(info);
                collect(items,row);
            }
        }
        free(row); json_free(&j);
    }
    buffer_free(&first);
}
typedef struct {
    Inventory *items;
    const char *dir;
    unsigned depth;
    const char *id, *workspace;
    int *matched;
    Path *match_path;
} Scan;
static int visit_rollout(const char *name,const Info *info,void *ptr,Error *e) {
    Scan *scan=ptr;
    if (scan->matched && *scan->matched) return 0;
    if (++scan->items->scanned>SCAN_LIMIT) { scan->items->truncated=1; return 0; }
    if (info->kind==3 || !path_valid_component(name)) return 1;
    int is_dir=info->kind==2 && scan->depth<5 && strlen(name)<=4 &&
        strspn(name,"0123456789")==strlen(name);
    int is_file=info->kind==1 && prefix(name,"rollout-") && has_suffix(name,".jsonl");
    if (is_file && scan->id) {
        char suffix[50];
        sam_format(suffix,sizeof(suffix),"-%s.jsonl",scan->id);
        is_file=has_suffix(name,suffix);
    }
    if (!is_dir && !is_file) return 1;
    Path *p=allocate(2*sizeof(*p)), *resolved=&p[1];
    int exact=path_join(p,scan->dir,name) && canonical(p->p,resolved) &&
        within(p->p,resolved->p) && within(resolved->p,p->p);
    if (exact && is_dir) {
        Scan sub=*scan; sub.dir=resolved->p; ++sub.depth;
        Error child={0};
        if (!list_dir(resolved->p,visit_rollout,&sub,&child)) scan->items->truncated=1;
    } else if (exact && is_file) {
        ++scan->items->files;
        if (scan->id) {
            *scan->matched=header_matches(resolved->p,scan->id,scan->workspace);
            if (*scan->matched && scan->match_path) *scan->match_path=*resolved;
        } else read_rollout(resolved->p,info,scan->items);
    }
    free(p); (void)e;
    return scan->items->scanned<=SCAN_LIMIT;
}
int chat_find_rollout(const char *home,const char *thread,const char *workspace,Path *match_path) {
    if (!uuid_valid(thread)) return 0;
    Path *p=allocate(2*sizeof(*p)); int matched=0;
    if (path_join(&p[0],home,"sessions") && open_directory(p[0].p,&p[1]) &&
        within(p[0].p,p[1].p) && within(p[1].p,p[0].p)) {
        Inventory inventory={0};
        Scan scan={.items=&inventory,.dir=p[1].p,.id=thread,.workspace=workspace,.matched=&matched,.match_path=match_path};
        Error ignored={0}; list_dir(p[1].p,visit_rollout,&scan,&ignored);
    }
    free(p); return matched;
}
static int updated_order(const void *a,const void *b) {
    long long x=((const Saved *)a)->updated,y=((const Saved *)b)->updated;
    return y>x ? 1 : y<x ? -1 : strcmp(((const Saved *)a)->id,((const Saved *)b)->id);
}
static int explicit_profile(Manager *m,const char *profile,Path *home,Path *cli,Error *e) {
    Document d;
    if (!get_doc(m,"profiles",profile,&d,e)) return 0;
    Path *raw=allocate(sizeof(*raw));
    int ok=FIELD(&d,"home",raw->p) && open_directory(raw->p,home);
    if (ok && !find_codex(m,&d,cli)) cli->p[0]=0;
    doc_free(&d); free(raw);
    return ok ? 1 : errorf(e,"CODEX_HOME của hồ sơ không còn tồn tại.");
}
static int get_source(Manager *m,const JSON *j,Path *home,Path *cli,char profile[33],Error *e) {
    json_field(j,0,"profile",profile,33);
    if (*profile) return explicit_profile(m,profile,home,cli,e);
    Path *p=allocate(sizeof(*p));
    int ok=safe_field(p->p,sizeof(p->p),j,"home");
    if (ok && !p->p[0]) ok=native_codex_home(p) || path_join(p,m->home.p,".codex");
    ok=ok && open_directory(p->p,home);
    free(p);
    if (!ok) return errorf(e,"Chọn thư mục CODEX_HOME đang tồn tại. Mặc định thường là thư mục .codex trong tài khoản Windows.");
    if (!find_codex(m,NULL,cli)) cli->p[0]=0;
    return 1;
}
static int fetch_inventory(const Path *home,const Path *cli,Inventory *inventory,int *indexed) {
    Path *root=allocate(2*sizeof(*root)), *actual=&root[1];
    Info info;
    int can_scan=path_join(root,home->p,"sessions") && file_info(root->p,&info) && info.kind==2 &&
        open_directory(root->p,actual) && within(root->p,actual->p) && within(actual->p,root->p);
    if (can_scan) {
        Error err={0};
        Scan scan={.items=inventory,.dir=actual->p};
        if (!list_dir(actual->p,visit_rollout,&scan,&err)) inventory->truncated=1;
    }
    *indexed=0;
    if (cli->p[0]) {
        Buf result={0}; Error err={0}; JSON j;
        if (codex_list_saved(cli->p,home->p,&result,&err) && json_parse(&j,result.s,result.n)) {
            *indexed=1;
            if (j.n>0 && j.t[0].type=='[') {
                Saved *row=allocate(sizeof(*row));
                for (int i=1;i<j.t[0].after;i=j.t[i].after) {
                    memset(row,0,sizeof(*row));
                    if (!json_field(&j,i,"id",row->id,sizeof(row->id)) || !uuid_valid(row->id)) continue;
                    normalize_uuid(row->id);
                    json_field(&j,i,"cwd",row->cwd.p,sizeof(row->cwd.p));
                    row->created=json_int(&j,json_get(&j,i,"created"),-1);
                    row->updated=json_int(&j,json_get(&j,i,"updated"),-1);
                    row->indexed=1;
                    collect(inventory,row);
                }
                free(row);
            }
            json_free(&j);
        }
        buffer_free(&result);
    }
    free(root);
    return can_scan || *indexed;
}
static void describe_saved(Buf *b,const Saved *row,const char *home,const char *profile) {
    char key[33];
    import_id(home,row->id,key);
    buffer_char(b,'{'); json_pair(b,"id",key); KEY(b,"thread",row->id); KEY(b,"workspace",row->cwd.p);
    KEY(b,"home",home); KEY(b,"profile",profile); KEY(b,"iso",row->iso);
    NULLNUM(b,"created",row->created); NULLNUM(b,"updated",row->updated);
    KEY(b,"source",row->indexed<0?"manual":row->indexed?"index":"rollout");
    buffer_char(b,'}');
}
static void inspect_manager_codex(Manager *m,const char *exe,const char *thread,const char *workspace,CodexProcesses *stats) {
    size_t count=0;
    for (Live *l=m->live;l;l=l->next) ++count;
    if (!count) { inspect_codex(exe,NULL,0,thread,workspace,stats); return; }
    unsigned *pids=allocate(count*sizeof(*pids));
    size_t i=0;
    for (Live *l=m->live;l;l=l->next) pids[i++]=l->process.pid;
    inspect_codex(exe,pids,count,thread,workspace,stats);
    free(pids);
}
static int saved_list(Manager *m,const JSON *j,Buf *out,Error *e,int importing) {
    Path *p=allocate(2*sizeof(*p)), *home=&p[0], *cli=&p[1];
    char profile[33], requested[37];
    if (importing && (!ARG(j,"thread",requested) || !uuid_valid(requested))) {
        free(p); return errorf(e,"Chọn phiên Codex hợp lệ để nhập.");
    }
    if (importing) normalize_uuid(requested);
    if (!get_source(m,j,home,cli,profile,e)) { free(p); return 0; }
    Inventory items={0};
    int indexed=0;
    int available=fetch_inventory(home,cli,&items,&indexed);
    int ok=1;
    if (importing) {
        Saved *chosen=NULL;
        for (size_t i=0;i<items.count;++i) if (!strcmp(items.rows[i].id,requested)) { chosen=&items.rows[i]; break; }
        Saved *manual=NULL;
        if (!chosen && YES(j,"manual")) {
            manual=allocate(sizeof(*manual));
            Path *path=allocate(sizeof(*path));
            if (safe_field(path->p,sizeof(path->p),j,"workspace") && open_directory(path->p,&manual->cwd) &&
                directory_allowed(m,manual->cwd.p,1) && !within(home->p,manual->cwd.p) && !within(manual->cwd.p,home->p)) {
                strcpy(manual->id,requested); manual->created=manual->updated=-1; manual->indexed=-1; chosen=manual;
            }
            free(path);
        }
        if (!chosen) ok=errorf(e,"Không tìm thấy ID trong nguồn này. Với ID thủ công, hãy chọn thư mục workspace gốc.");
        else {
            char key[33];
            import_id(home->p,chosen->id,key);
            describe_saved(out,chosen,home->p,profile);
            ok=put_doc(m,"imports",key,out,e);
        }
        free(manual);
    } else {
        if (items.count) qsort(items.rows,items.count,sizeof(*items.rows),updated_order);
        buffer_char(out,'{'); json_pair(out,"home",home->p); KEY(out,"cli",cli->p);
        RAW(out,"indexed",indexed?"true":"false");
        KEY(out,"note",available?"":cli->p[0] ?
            "CLI chưa trả về chỉ mục và thư mục sessions không đọc được. Kiểm tra CODEX_HOME hoặc nhập ID thủ công." :
            "Chưa tìm thấy CLI hoặc thư mục sessions. Kiểm tra lại cài đặt Codex và CODEX_HOME.");
        CodexProcesses stats;
        inspect_manager_codex(m,cli->p,NULL,NULL,&stats);
        buffer_text(out,",\"processes\":{"); json_key(out,"daemon"); buffer_fmt(out,"%u",stats.daemon);
        NUM(out,"host",stats.host); NUM(out,"server",stats.server); NUM(out,"interactive",stats.interactive);
        NUM(out,"batch",stats.batch); NUM(out,"managed",stats.managed); NUM(out,"unknown",stats.unknown); buffer_char(out,'}');
        RAW(out,"truncated",(items.truncated || items.count>DISPLAY_LIMIT)?"true":"false");
        buffer_text(out,",\"sessions\":[");
        for (size_t i=0;i<items.count && i<DISPLAY_LIMIT;++i) {
            if (i) buffer_char(out,',');
            describe_saved(out,&items.rows[i],home->p,profile);
        }
        buffer_text(out,"]}");
    }
    free(items.rows); free(p);
    return ok;
}

static int markers(Manager *m,const char *id,Path *lease,Path *done) {
    if (!valid_id(id)) return 0;
    Path *dir=allocate(sizeof(*dir));
    char name[40];
    int ok=path_join(dir,m->data.p,"external");
    if (ok && lease) {
        sam_format(name,sizeof(name),"%s.lease",id);
        ok=path_join(lease,dir->p,name);
    }
    if (ok && done) {
        sam_format(name,sizeof(name),"%s.done",id);
        ok=path_join(done,dir->p,name);
    }
    free(dir);
    return ok;
}
int external_terminal_done(Manager *m,const char *id) {
    Path *done=allocate(sizeof(*done));
    Info info;
    int ok=markers(m,id,NULL,done) && file_info(done->p,&info) && info.kind==1;
    free(done); return ok;
}
typedef struct { Manager *m; const char *workspace,*home,*thread; int busy; } ExternalSearch;
static int check_external(const char *id,Document *d,void *ctx,Error *e) {
    ExternalSearch *s=ctx;
    if (s->busy || external_terminal_done(s->m,id)) return 1;
    Path *p=allocate(sizeof(*p));
    char thread[37];
    if (s->workspace && FIELD(d,"workspace",p->p) &&
        (within(s->workspace,p->p) || within(p->p,s->workspace))) s->busy=1;
    if (s->thread && FIELD(d,"thread",thread) && ascii_equal(s->thread,thread) &&
        FIELD(d,"home",p->p) && within(s->home,p->p) && within(p->p,s->home)) s->busy=1;
    free(p); (void)e; return 1;
}
int external_workspace_busy(Manager *m,const char *path) {
    ExternalSearch scan={.m=m,.workspace=path};
    Error ignored={0};
    return !each_doc(m,"external",check_external,&scan,&ignored) || scan.busy;
}
int safe_idle_recovery(Manager *m,const Live *l) {
    Document profile; Error ignored={0};
    if (!get_doc(m,"profiles",l->profile,&profile,&ignored)) return 0;
    Path *exe=allocate(sizeof(*exe)); CodexProcesses stats={0};
    int found=find_codex(m,&profile,exe);
    if (found) inspect_manager_codex(m,exe->p,chat_thread_id(l),l->workspace.p,&stats);
    doc_free(&profile); free(exe);
    return found && !stats.unknown && !stats.conflict && !stats.interactive && !stats.server && !stats.batch;
}
int guarded_resume(Manager *m,const char *exe,const char *home,const char *thread,const char *workspace,Error *e) {
    ExternalSearch scan={.m=m,.home=home,.thread=*thread?thread:NULL};
    if (*thread && (!each_doc(m,"external",check_external,&scan,e) || scan.busy))
        return errorf(e,"Phiên này đang có khóa Windows Terminal.");
    for (Live *l=m->live;l;l=l->next) {
        if (*thread && *l->home.p && within(home,l->home.p) && within(l->home.p,home) &&
            (ascii_equal(thread,l->resumed_thread) || ascii_equal(thread,chat_thread_id(l))))
            return errorf(e,"Phiên này đang được Manager sử dụng.");
    }
    CodexProcesses stats;
    inspect_manager_codex(m,exe,thread,workspace,&stats);
    if (stats.conflict) return errorf(e,"Tiến trình Codex ngoài Manager đang dùng đúng ID hoặc workspace này. Hãy thoát tiến trình đó rồi thử lại.");
    return 1;
}
static int external_start(Manager *m,const Live *l,const char *exe,const char *shell,Buf *out,Error *e) {
    if (strcmp(shell,"cmd") && strcmp(shell,"powershell") && strcmp(shell,"wt"))
        return errorf(e,"Chọn CMD, PowerShell hoặc Windows Terminal.");
    if (!strcmp(shell,"wt") && !windows_terminal_available()) return errorf(e,"Không tìm thấy Windows Terminal (wt.exe). Chọn CMD hoặc PowerShell.");
    Path *p=allocate(2*sizeof(*p)), *lease=&p[0], *done=&p[1];
    char id[33]; new_id(id);
    if (!markers(m,id,lease,done)) { free(p); return errorf(e,"Không tạo được đường dẫn khóa phiên ngoài."); }
    Buf rec={0};
    buffer_char(&rec,'{'); json_pair(&rec,"id",id); KEY(&rec,"workspace",l->workspace.p); KEY(&rec,"home",l->home.p);
    KEY(&rec,"profile",l->profile); KEY(&rec,"thread",l->resumed_thread); KEY(&rec,"shell",shell); NUM(&rec,"started",timestamp()); buffer_char(&rec,'}');
    int saved=put_doc(m,"external",id,&rec,e);
    int ok=saved && launch_windows_terminal(exe,l->workspace.p,l->home.p,l->resumed_thread,lease->p,done->p,shell,e);
    if (ok) { buffer_char(out,'{'); json_pair(out,"id",id); buffer_char(out,'}'); }
    else if (saved) {
        Error ignored={0};
        release_terminal_lease(lease->p,done->p,&ignored);
    }
    buffer_free(&rec); free(p);
    return ok;
}
static int match_project(const char *id,Document *d,void *ptr,Error *e) {
    Live *l=ptr;
    Path *p=allocate(sizeof(*p));
    if (FIELD(d,"path",p->p) && within(p->p,l->workspace.p) && within(l->workspace.p,p->p)) strcpy(l->project,id);
    free(p); (void)e; return 1;
}
static int resume_or_open(Manager *m,const JSON *j,Buf *out,Error *e,int new_tab) {
    if (!YES(j,"confirmed")) return errorf(e,"Xác nhận phiên Codex cũ và các tác vụ ghi ngoài Manager đã đóng.");
    Path *p=allocate(4*sizeof(*p)), *stored=&p[0], *workspace=&p[1], *cli=&p[2], *profile_home=&p[3];
    Live *l=allocate(sizeof(*l));
    int ok=0;
    if (new_tab) {
        char project[33]; ARG(j,"project",project);
        Document d;
        if (!get_doc(m,"projects",project,&d,e)) goto done;
        FIELD(&d,"path",workspace->p); doc_free(&d);
        strcpy(l->project,project);
        if (!get_source(m,j,&l->home,cli,l->profile,e)) goto done;
    } else {
        char id[33]; ARG(j,"id",id);
        Document d;
        if (!get_doc(m,"imports",id,&d,e)) goto done;
        FIELD(&d,"home",stored->p); FIELD(&d,"workspace",workspace->p);
        FIELD(&d,"profile",l->profile); FIELD(&d,"thread",l->resumed_thread);
        doc_free(&d);
        if (!uuid_valid(l->resumed_thread) || !open_directory(stored->p,&l->home) ||
            !within(stored->p,l->home.p) || !within(l->home.p,stored->p)) {
            errorf(e,"CODEX_HOME đã thay đổi hoặc phiên nhập không hợp lệ. Hãy nhập lại từ nguồn cũ."); goto done;
        }
        if (YES(j,"chat") && !*l->profile) { ARG(j,"profile",l->profile); }
        if (*l->profile) {
            if (!explicit_profile(m,l->profile,profile_home,cli,e)) goto done;
            if (!within(l->home.p,profile_home->p) || !within(profile_home->p,l->home.p)) {
                errorf(e,"Hồ sơ đã đổi CODEX_HOME. Hãy chọn lại nguồn của phiên."); goto done;
            }
        } else if (!find_codex(m,NULL,cli)) cli->p[0]=0;
    }
    if (!cli->p[0]) { errorf(e,"Không tìm thấy Codex CLI. Chọn tệp codex.exe hoặc shim npm Codex trong Cài đặt."); goto done; }
    if (!open_directory(workspace->p,&l->workspace) || within(l->home.p,l->workspace.p) ||
        within(l->workspace.p,l->home.p) || !directory_allowed(m,l->workspace.p,1)) {
        errorf(e,"Phiên chưa có đường dẫn workspace hợp lệ hoặc thư mục gốc đã được di chuyển."); goto done;
    }
    if (!new_tab && !each_doc(m,"projects",match_project,l,e)) goto done;
    if (!new_tab && YES(j,"chat")) {
        if (!*l->profile || !*l->project) {
            errorf(e,"Thêm một hồ sơ dùng đúng CODEX_HOME và một dự án dùng đúng workspace của phiên trước khi mở trong chat."); goto done;
        }
        ok=chat_resume_saved(m,l->profile,l->project,l->resumed_thread,out,e);
        goto done;
    }
    if (workspace_busy(m,l->workspace.p)) { errorf(e,"Workspace đang có phiên khác hoặc đang được Windows Terminal giữ khóa."); goto done; }
    if (!guarded_resume(m,cli->p,l->home.p,l->resumed_thread,l->workspace.p,e)) goto done;
    if (new_tab || YES(j,"external")) {
        char shell[16]; ARG(j,"shell",shell);
        ok=external_start(m,l,cli->p,*shell?shell:"wt",out,e);
    }
    else {
        const char *args[16]={"resume"}; size_t count=1;
        if (!codex_terminal_review(m,l,cli->p,args,ARRAY_LEN(args),&count,e)) goto done;
        args[count++]="--"; args[count++]=l->resumed_thread; args[count]=NULL;
        strcpy(l->kind,"imported");
        ok=launch_managed(m,&l,cli->p,args,0,out,e);
    }
done:
    free(p); free(l);
    return ok;
}
int saved_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    if (!strcmp(action,"saved-list")) return saved_list(m,in,out,e,0);
    if (!strcmp(action,"saved-import")) return saved_list(m,in,out,e,1);
    if (!strcmp(action,"saved-resume")) return resume_or_open(m,in,out,e,0);
    if (!strcmp(action,"saved-new-external")) return resume_or_open(m,in,out,e,1);
    if (!strcmp(action,"saved-release")) {
        if (!YES(in,"confirmed")) return errorf(e,"Xác nhận phiên Codex trong Windows Terminal đã thoát.");
        char id[33]; ARG(in,"id",id);
        Document d;
        if (!get_doc(m,"external",id,&d,e)) return 0;
        doc_free(&d);
        if (!external_terminal_done(m,id)) {
            Path *p=allocate(2*sizeof(*p));
            int ok=markers(m,id,&p[0],&p[1]) && release_terminal_lease(p[0].p,p[1].p,e);
            free(p);
            if (!ok) return 0;
        }
        buffer_text(out,"{}"); return 1;
    }
    return errorf(e,"Chức năng nhập phiên không tồn tại.");
}
