#include "manager.h"

void chat_session_key(const char *profile,const char *home_hash,const char *thread,char key[33]) {
    Sha256 hash={0}; char digest[65];
    sha_update(&hash,profile,strlen(profile));
    sha_update(&hash,home_hash,strlen(home_hash));
    sha_update(&hash,thread,strlen(thread));
    sha_finish(&hash,digest);
    memcpy(key,digest,32); key[32]=0;
}

static int update_thread(Manager *m,const JSON *in,const char *key,Buf *out,Error *e) {
    char title[256];
    if (!safe_field(title,sizeof(title),in,"title")) return errorf(e,"Tên phiên không hợp lệ.");
    Buf record={0};
    buffer_char(&record,'{'); json_pair(&record,"id",key); KEY(&record,"title",title);
    RAW(&record,"pinned",YES(in,"pinned")?"true":"false"); RAW(&record,"archived",YES(in,"archived")?"true":"false");
    buffer_char(&record,'}');
    int ok=put_doc(m,"threadprefs",key,&record,e);
    if (ok) buffer_text(out,"{}");
    buffer_free(&record);
    return ok;
}

int chat_thread_action(Manager *m,const char *action,const JSON *in,Buf *out,Error *e) {
    char id[33],profile[33],project[33],thread[160],digest[65],key[33];
    ARG(in,"id",id);
    Document session;
    if (!get_doc(m,"sessions",id,&session,e)) return 0;
    FIELD(&session,"chatThread",thread);
    if (!*thread && !strcmp(action,"thread-resume")) FIELD(&session,"chatCandidate",thread);
    int ok=FIELD(&session,"profile",profile) && valid_id(profile) &&
        FIELD(&session,"project",project) && valid_id(project) &&
        *thread && !secret_text(thread) &&
        FIELD(&session,"chatHome",digest) && strlen(digest)==64;
    doc_free(&session);
    if (!ok) return errorf(e,"Phiên chưa có luồng đã lưu.");
    chat_session_key(profile,digest,thread,key);
    if (!strcmp(action,"thread-edit")) return update_thread(m,in,key,out,e);
    int reading=!strcmp(action,"thread-read");
    if (!reading && strcmp(action,"thread-resume")) return errorf(e,"Thao tác phiên không tồn tại.");
    Document account;
    if (!get_doc(m,"profiles",profile,&account,e)) return errorf(e,"Hồ sơ của luồng đã bị gỡ.");
    Path *paths=allocate(2*sizeof(*paths)), *home=&paths[0], *exe=&paths[1];
    FIELD(&account,"home",home->p);
    int use_file=use_file_credentials(&account,home->p);
    int found=!reading || find_codex(m,&account,exe);
    doc_free(&account);
    Sha256 hash={0}; char current[65];
    sha_update(&hash,home->p,strlen(home->p)); sha_finish(&hash,current);
    if (strcmp(digest,current)) ok=errorf(e,"CODEX_HOME của hồ sơ đã đổi. Khôi phục đường dẫn cũ trước khi tiếp tục.");
    else if (!found) ok=errorf(e,"Chưa tìm thấy Codex CLI của hồ sơ này.");
    else if (reading) ok=codex_read_turns(exe->p,home->p,use_file,thread,out,e);
    else ok=chat_resume_saved(m,profile,project,thread,out,e);
    free(paths);
    return ok;
}
