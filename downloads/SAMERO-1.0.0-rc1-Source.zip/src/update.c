#include "manager.h"

/* The public channel is deliberately fixed. No project data or credentials
 * are sent and server-provided URLs are never followed. */
#define PUBLIC_UPDATE_URL "https://rin231126.github.io/samero/downloads/SAMERO-1.0.0-rc1.exe"
#ifndef SAM_RELEASE_SEQUENCE
#define SAM_RELEASE_SEQUENCE 0
#endif
static int hash_valid(const char *s) { return strlen(s)==64 && strspn(s,"0123456789abcdef")==64; }
int public_update_parse(const char *body,size_t size,long long current,Buf *out,Error *e) {
    JSON j;
    if (!size || size>4096 || !json_parse(&j,body,size)) return errorf(e,"Thông tin cập nhật không hợp lệ.");
    char channel[24],version[32],digest[65];
    int fields=ARG(&j,"channel",channel) && ARG(&j,"version",version) && ARG(&j,"sha256",digest);
    long long seq=NUMBER(&j,"sequence",-1), bytes=NUMBER(&j,"bytes",-1);
    int ok=fields && j.t[0].type=='{' && NUMBER(&j,"schema",-1)==1 && !strcmp(channel,"public") && !strcmp(version,SAM_VERSION) && hash_valid(digest) && seq>0 && seq<2147483648LL && bytes>0 && bytes<=64*MIB;
    json_free(&j);
    if (!ok) return errorf(e,"Thông tin cập nhật không đúng kênh Public 1.0.");
    buffer_char(out,'{'); json_pair(out,"status",seq>current?"available":"current");
    NUM(out,"currentSequence",current); NUM(out,"sequence",seq); NUM(out,"bytes",bytes); KEY(out,"sha256",digest); KEY(out,"url",PUBLIC_UPDATE_URL); buffer_char(out,'}');
    return 1;
}
/* Publish a separate file only after exact length and digest match. Never
 * overwrite or execute the installed binary here. */
int public_update_stage(const char *root, long long expected, const char *digest,
                        UpdateReader reader, void *ctx, UpdateProgress progress,
                        Buf *out, Error *e) {
    if (expected<=0 || expected>64*MIB || !hash_valid(digest)) return errorf(e,"Thông tin tải không hợp lệ.");
    Path *paths=allocate(2*sizeof(*paths)); char id[33],name[80]; new_id(id);
    sam_format(name,sizeof(name),"SAMERO-update-%s.part",id);
    int ok=path_join(paths,root,name);
    sam_format(name,sizeof(name),"SAMERO-update-%s.exe",id);
    ok=ok && path_join(paths+1,root,name);
    FILE *f=ok?file_open_new(paths[0].p):NULL;
    if (!f) { free(paths); return errorf(e,"Không tạo được tệp tải mới."); }
    Sha256 sha={0}; unsigned char chunk[16384]; long long total=0; int last=-1;
    if (progress) progress(0,expected,ctx);
    for (;;) {
        int n=reader(ctx,chunk,sizeof(chunk));
        if (n<0 || n>(int)sizeof(chunk) || total+n>expected) { ok=0; break; }
        if (!n) break;
        if (fwrite(chunk,1,(size_t)n,f)!=(size_t)n) { ok=0; break; }
        sha_update(&sha,chunk,(size_t)n); total+=n;
        int percent=(int)(total*100/expected);
        if (progress && percent!=last) { progress(total,expected,ctx); last=percent; }
    }
    char actual[65]; sha_finish(&sha,actual);
    if (total!=expected || strcmp(actual,digest)) ok=0;
    if (ok && !file_flush(f)) ok=0;
    if (fclose(f)) ok=0;
    if (ok) ok=move_file(paths[0].p,paths[1].p,0);
    if (ok) {
        buffer_char(out,'{'); json_pair(out,"status","verified-download"); KEY(out,"path",paths[1].p); KEY(out,"sha256",actual); NUM(out,"bytes",total); buffer_char(out,'}');
    } else { remove_file(paths[0].p); errorf(e,"Tải thất bại hoặc SHA-256/kích thước không khớp. Không thay đổi EXE hiện tại."); }
    free(paths); return ok;
}
/* Re-open only a previously staged, single-link regular file under the
 * manager root. Keep this handle open through the approved Windows launch. */
FILE *public_update_verified_file(const char *root,const char *path,long long size,const char *digest,Error *e) {
    const char *name=base_name(path), *prefix="SAMERO-update-";
    char id[33], actual[65];
    if (strlen(name)!=strlen(prefix)+32+4 || strncmp(name,prefix,strlen(prefix)) || !has_suffix(name,".exe") || size<128 || size>64*MIB || !hash_valid(digest)) {errorf(e,"Tệp cập nhật không hợp lệ.");return NULL;}
    memcpy(id,name+strlen(prefix),32);id[32]=0;
    Path *p=allocate(2*sizeof(*p));Info before,after;
    int ok=valid_id(id) && path_join(p,root,name) && within(p[0].p,path) && within(path,p[0].p) &&
        canonical(path,p+1) && within(p[0].p,p[1].p) && within(p[1].p,p[0].p) &&
        file_info(path,&before) && before.kind==1 && before.links==1 && before.size==(uint64_t)size;
    FILE *f=ok?file_open(path,0):NULL;
    free(p);
    if (!f) {errorf(e,"Không mở được đúng tệp cập nhật đã tải.");return NULL;}
    unsigned char header[64],pe[26],buf[16384];
    ok=fread(header,1,sizeof(header),f)==sizeof(header) && header[0]=='M' && header[1]=='Z';
    uint32_t offset=ok?(uint32_t)header[60]|((uint32_t)header[61]<<8)|((uint32_t)header[62]<<16)|((uint32_t)header[63]<<24):0;
    ok=ok && offset>=64 && offset<=(uint64_t)size-sizeof(pe) && file_seek(f,offset) && fread(pe,1,sizeof(pe),f)==sizeof(pe) &&
        !memcmp(pe,"PE\0\0",4) && pe[4]==0x64 && pe[5]==0x86 && (pe[22]&2) && !(pe[23]&0x20) && pe[24]==0x0b && pe[25]==2 && file_seek(f,0);
    Sha256 sha={0};long long count=0;size_t n=0;
    while (ok && (n=fread(buf,1,sizeof(buf),f))!=0) {count+=(long long)n;if(count>size){ok=0;break;}sha_update(&sha,buf,n);}
    sha_finish(&sha,actual);
    ok=ok && !ferror(f) && count==size && !strcmp(actual,digest) && file_info(path,&after) && after.kind==1 && after.links==1 &&
        before.inode==after.inode && before.device==after.device && before.size==after.size && before.mtime==after.mtime;
    if (!ok) {fclose(f);errorf(e,"Tệp cập nhật đã đổi, không đúng SHA-256 hoặc không phải PE Windows x64.");return NULL;}
    return f;
}
#ifdef SAM_WINDOWS
typedef void *Http;
typedef unsigned short W;
typedef uint32_t DW;
extern Http WinHttpOpen(const W *,DW,const W *,const W *,DW);
extern Http WinHttpConnect(Http,const W *,unsigned short,DW);
extern Http WinHttpOpenRequest(Http,const W *,const W *,const W *,const W *,const W *const *,DW);
extern int WinHttpSetTimeouts(Http,int,int,int,int);
extern int WinHttpSetOption(Http,DW,void *,DW);
extern int WinHttpSendRequest(Http,const W *,DW,void *,DW,DW,uintptr_t);
extern int WinHttpReceiveResponse(Http,void *);
extern int WinHttpQueryHeaders(Http,DW,const W *,void *,DW *,DW *);
extern int WinHttpReadData(Http,void *,DW,DW *);
extern int WinHttpCloseHandle(Http);
static int update_http_read(void *ctx,void *data,size_t cap) {
    DW n=0;
    return WinHttpReadData(ctx,data,(DW)cap,&n)?(int)n:-1;
}
static void update_report_progress(long long done,long long total,void *ctx) {
    (void)ctx; char line[128];
    int n=sam_format(line,sizeof(line),"@{\"done\":%lld,\"total\":%lld}\n",done,total);
    if (n>0 && n<(int)sizeof(line)) worker_stdout(line,(size_t)n);
}
#endif
int public_update_check(Buf *out,Error *e) {
#ifdef SAM_WINDOWS
    Http session=WinHttpOpen((const W *)L"SAMERO Public 1.0",0,NULL,NULL,0),connect=NULL,request=NULL;
    Buf body={0}; int ok=0;
    DW redirect=0,status=0,len=sizeof(status),n=0;
    char chunk[512];
    if (!session || !WinHttpSetTimeouts(session,5000,5000,5000,5000)) goto done;
    connect=WinHttpConnect(session,(const W *)L"rin231126.github.io",443,0);
    if (!connect) goto done;
    request=WinHttpOpenRequest(connect,(const W *)L"GET",(const W *)L"/samero/downloads/public-update.json",NULL,NULL,NULL,0x00800000);
    /* WINHTTP_OPTION_REDIRECT_POLICY=88, NEVER=0; never turn off TLS verification. */
    if (!request || !WinHttpSetOption(request,88,&redirect,sizeof(redirect))) goto done;
    if (!WinHttpSendRequest(request,NULL,0,NULL,0,0,0) || !WinHttpReceiveResponse(request,NULL)) goto done;
    if (!WinHttpQueryHeaders(request,19|0x20000000,NULL,&status,&len,NULL) || status!=200) goto done;
    do {
        if (!WinHttpReadData(request,chunk,sizeof(chunk),&n) || n>sizeof(chunk) || body.n+n>4096) goto done;
        if (n) buffer_add(&body,chunk,n);
    } while (n);
    ok=public_update_parse(body.s,body.n,SAM_RELEASE_SEQUENCE,out,e);
done:
    if (request) WinHttpCloseHandle(request);
    if (connect) WinHttpCloseHandle(connect);
    if (session) WinHttpCloseHandle(session);
    buffer_free(&body);
    if (!ok && !e->msg[0]) errorf(e,"Không kiểm tra được bản cập nhật qua HTTPS.");
    return ok;
#else
    (void)out;
    return errorf(e,"Kiểm tra cập nhật Public chỉ hỗ trợ Windows.");
#endif
}

int public_update_download(const char *root,const char *sequence,Buf *out,Error *e) {
#ifdef SAM_WINDOWS
    Buf meta={0}; JSON j; char digest[65],status[24],seq[32];
    if (!public_update_check(&meta,e)) return 0;
    if (!json_parse(&j,meta.s,meta.n)) { buffer_free(&meta); return errorf(e,"Manifest cập nhật bị lỗi."); }
    long long expected=NUMBER(&j,"bytes",-1), latest=NUMBER(&j,"sequence",-1);
    sam_format(seq,sizeof(seq),"%lld",latest);
    int ok=ARG(&j,"status",status) && ARG(&j,"sha256",digest) && !strcmp(status,"available") && !strcmp(seq,sequence);
    json_free(&j); buffer_free(&meta);
    if (!ok) return errorf(e,"Bản phát hành đã thay đổi; kiểm tra lại trước khi tải.");
    Http session=WinHttpOpen((const W *)L"SAMERO Public 1.0",0,NULL,NULL,0),connect=NULL,request=NULL;
    DW redirect=0,http_status=0,len=sizeof(http_status);
    ok=0;
    if (!session || !WinHttpSetTimeouts(session,5000,5000,10000,10000)) goto done;
    connect=WinHttpConnect(session,(const W *)L"rin231126.github.io",443,0);
    if (!connect) goto done;
    request=WinHttpOpenRequest(connect,(const W *)L"GET",(const W *)L"/samero/downloads/SAMERO-1.0.0-rc1.exe",NULL,NULL,NULL,0x00800000);
    if (!request || !WinHttpSetOption(request,88,&redirect,sizeof(redirect))) goto done;
    if (!WinHttpSendRequest(request,NULL,0,NULL,0,0,0) || !WinHttpReceiveResponse(request,NULL)) goto done;
    if (!WinHttpQueryHeaders(request,19|0x20000000,NULL,&http_status,&len,NULL) || http_status!=200) goto done;
    ok=public_update_stage(root,expected,digest,update_http_read,request,update_report_progress,out,e);
    if (ok) {
        JSON staged; Path path; int marked=0;
        if (json_parse(&staged,out->s,out->n)) { if (ARG(&staged,"path",path.p)) { marked=mark_internet_download(path.p); if (!marked) remove_file(path.p); } json_free(&staged); }
        if (!marked) {buffer_free(out);ok=errorf(e,"Không lưu được dấu vùng Internet của Windows. Chỉ tải thủ công từ website chính thức.");}
    }
done:
    if (request) WinHttpCloseHandle(request);
    if (connect) WinHttpCloseHandle(connect);
    if (session) WinHttpCloseHandle(session);
    if (!ok && !e->msg[0]) errorf(e,"Không tải được bản cập nhật qua HTTPS.");
    return ok;
#else
    (void)root; (void)sequence; (void)out;
    return errorf(e,"Tải cập nhật chỉ hỗ trợ Windows.");
#endif
}
