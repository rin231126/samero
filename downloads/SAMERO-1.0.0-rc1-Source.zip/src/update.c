#include "manager.h"

/* The public channel is deliberately fixed. No project data or credentials
 * are sent and server-provided URLs are never followed. */
#define PUBLIC_UPDATE_URL "https://rin231126.github.io/samero/downloads/SAMERO-1.0.0-rc1.exe"
#ifndef SAM_RELEASE_SEQUENCE
#define SAM_RELEASE_SEQUENCE 0
#endif
static int hash_valid(const char *s) { return strlen(s)==64 && strspn(s,"0123456789abcdef")==64; }
int public_update_parse(const char *body,size_t size,long long current,Buf *out,Error *e) {
    JSON j;
    if (!size || size>4096 || !json_parse(&j,body,size)) return errorf(e,"Thông tin cập nhật không hợp lệ.");
    char channel[24],version[32],digest[65];
    int fields=ARG(&j,"channel",channel) && ARG(&j,"version",version) && ARG(&j,"sha256",digest);
    long long seq=NUMBER(&j,"sequence",-1), bytes=NUMBER(&j,"bytes",-1);
    int ok=fields && j.t[0].type=='{' && NUMBER(&j,"schema",-1)==1 && !strcmp(channel,"public") && !strcmp(version,SAM_VERSION) && hash_valid(digest) && seq>0 && seq<2147483648LL && bytes>0 && bytes<=64*MIB;
    json_free(&j);
    if (!ok) return errorf(e,"Thông tin cập nhật không đúng kênh Public 1.0.");
    buffer_char(out,'{'); json_pair(out,"status",seq>current?"available":"current");
    NUM(out,"currentSequence",current); NUM(out,"sequence",seq); NUM(out,"bytes",bytes); KEY(out,"sha256",digest); KEY(out,"url",PUBLIC_UPDATE_URL); buffer_char(out,'}');
    return 1;
}
#ifdef SAM_WINDOWS
typedef void *Http;
typedef unsigned short W;
typedef uint32_t DW;
extern Http WinHttpOpen(const W *,DW,const W *,const W *,DW);
extern Http WinHttpConnect(Http,const W *,unsigned short,DW);
extern Http WinHttpOpenRequest(Http,const W *,const W *,const W *,const W *,const W *const *,DW);
extern int WinHttpSetTimeouts(Http,int,int,int,int);
extern int WinHttpSetOption(Http,DW,void *,DW);
extern int WinHttpSendRequest(Http,const W *,DW,void *,DW,DW,uintptr_t);
extern int WinHttpReceiveResponse(Http,void *);
extern int WinHttpQueryHeaders(Http,DW,const W *,void *,DW *,DW *);
extern int WinHttpReadData(Http,void *,DW,DW *);
extern int WinHttpCloseHandle(Http);
#endif
int public_update_check(Buf *out,Error *e) {
#ifdef SAM_WINDOWS
    Http session=WinHttpOpen((const W *)L"SAMERO Public 1.0",0,NULL,NULL,0),connect=NULL,request=NULL;
    Buf body={0}; int ok=0;
    DW redirect=0,status=0,len=sizeof(status),n=0;
    char chunk[512];
    if (!session || !WinHttpSetTimeouts(session,5000,5000,5000,5000)) goto done;
    connect=WinHttpConnect(session,(const W *)L"rin231126.github.io",443,0);
    if (!connect) goto done;
    request=WinHttpOpenRequest(connect,(const W *)L"GET",(const W *)L"/samero/downloads/public-update.json",NULL,NULL,NULL,0x00800000);
    /* WINHTTP_OPTION_REDIRECT_POLICY=88, NEVER=0; never turn off TLS verification. */
    if (!request || !WinHttpSetOption(request,88,&redirect,sizeof(redirect))) goto done;
    if (!WinHttpSendRequest(request,NULL,0,NULL,0,0,0) || !WinHttpReceiveResponse(request,NULL)) goto done;
    if (!WinHttpQueryHeaders(request,19|0x20000000,NULL,&status,&len,NULL) || status!=200) goto done;
    do {
        if (!WinHttpReadData(request,chunk,sizeof(chunk),&n) || n>sizeof(chunk) || body.n+n>4096) goto done;
        if (n) buffer_add(&body,chunk,n);
    } while (n);
    ok=public_update_parse(body.s,body.n,SAM_RELEASE_SEQUENCE,out,e);
done:
    if (request) WinHttpCloseHandle(request);
    if (connect) WinHttpCloseHandle(connect);
    if (session) WinHttpCloseHandle(session);
    buffer_free(&body);
    if (!ok && !e->msg[0]) errorf(e,"Không kiểm tra được bản cập nhật qua HTTPS.");
    return ok;
#else
    (void)out;
    return errorf(e,"Kiểm tra cập nhật Public chỉ hỗ trợ Windows.");
#endif
}
