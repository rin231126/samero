#include "manager.h"
#include "verify_trace.h"

static int same_field(const JSON *j,int object,const char *field,const char *expected) {
    char value[160];
    return json_field(j,object,field,value,sizeof(value)) && !strcmp(value,expected);
}

static VerifyItem *by_id(VerifyTrace *v,const JSON *j,int object,const char *field,int create) {
    char id[160];
    if (!json_field(j,object,field,id,sizeof(id)) || !*id) { v->partial=1; return NULL; }
    for (size_t i=0;i<v->count;++i)
        if (!strcmp(v->items[i].id,id)) return &v->items[i];
    if (!create) return NULL;
    if (v->count==ARRAY_LEN(v->items)) { v->partial=1; return NULL; }
    VerifyItem *item=&v->items[v->count++];
    strcpy(item->id,id);
    return item;
}

static int denial_message(const char *s) {
    return contains_ci(s,"permission denied") || contains_ci(s,"access is denied") ||
        contains_ci(s,"UnauthorizedAccessException") || contains_ci(s,"rejected: blocked by policy") ||
        contains_ci(s,"denied by policy") || contains_ci(s,"rejected: policy forbids commands starting with");
}

/* A shell's stdout may quote error messages. Only consult a typed failed result.
   Early errors have the tool's outer diagnostic and no child exit status. */
static void early_output(VerifyItem *v,const char *s) {
    if (!strncmp(s,"exec_command failed:",20)) {
        v->early_failure=1;
        if (!strncmp(s,"exec_command failed: CreateProcess {",sizeof("exec_command failed: CreateProcess {")-1) && denial_message(s))
            v->early_denial=1;
    } else if (!strncmp(s,"approval policy is Never; reject command",40)) {
        v->early_failure=v->early_denial=1;
    }
}

static void inspect_text(VerifyTrace *trace,VerifyItem *item,const JSON *j,int token,int early) {
    if (token<0 || j->t[token].type!='"') return;
    size_t bytes=j->t[token].last-j->t[token].first;
    if (bytes>65536) { trace->partial=1; return; }
    char *text=allocate(bytes+1);
    if (json_string(j,token,text,bytes+1)) {
        if (early) early_output(item,text);
        else if (denial_message(text)) item->denied=1;
    } else trace->partial=1;
    free(text);
}

int verify_item(VerifyTrace *v,const JSON *j,int object,int completed) {
    int command=same_field(j,object,"type","commandExecution");
    int mcp=same_field(j,object,"type","mcpToolCall");
    int dynamic=same_field(j,object,"type","dynamicToolCall");
    int view=same_field(j,object,"type","imageView");
    if (!command && !mcp && !dynamic && !view) return 1;
    VerifyItem *item=by_id(v,j,object,"id",1);
    if (!item) return 0;
    if (!completed) { item->started=1; return 1; }
    if (item->command || item->other) return 0;
    item->command=command; item->other=!command;
    int result=json_get(j,object,"result"), error=json_get(j,object,"error");
    int success=json_get(j,object,"success");
    int exit_token=json_get(j,object,"exitCode");
    long long code=json_int(j,exit_token,-1);
    if (view) {
        /* The wire schema reports a path, not whether the image was read. */
        item->success=0;
    } else if (same_field(j,object,"status","declined")) {
        item->denied=item->failed=1;
    } else if (same_field(j,object,"status","failed") ||
            (command && exit_token>=0 && j->t[exit_token].type=='0' && code!=0) ||
            (mcp && ((error>=0 && j->t[error].type=='{') || json_bool(j,json_get(j,result,"isError")))) ||
            (dynamic && success>=0 && j->t[success].type=='f')) {
        item->failed=1;
        if (command) inspect_text(v,item,j,json_get(j,object,"aggregatedOutput"),0);
        if (mcp) inspect_text(v,item,j,json_get(j,error,"message"),0);
    } else if (same_field(j,object,"status","completed")) {
        /* Remote tools can acknowledge success without returning any evidence. */
        int content=mcp?json_get(j,result,"content"):json_get(j,object,"contentItems");
        int structured=mcp?json_get(j,result,"structuredContent"):-1;
        int has_content=(content>=0 && j->t[content].type=='[' && j->t[content].count>0) ||
            (structured>=0 && j->t[structured].type!='n');
        item->success=command ? code==0 : has_content && (!dynamic || json_bool(j,success));
    }
    return 1;
}

static void rollout_item(VerifyTrace *v,const JSON *j,int p) {
    int call=same_field(j,p,"type","function_call");
    if (!call && !same_field(j,p,"type","function_call_output")) return;
    if (call && !same_field(j,p,"name","exec_command")) return;
    int ns=json_get(j,p,"namespace");
    if (ns>=0 && j->t[ns].type!='n' && !same_field(j,p,"namespace","functions")) return;
    VerifyItem *item=by_id(v,j,p,"call_id",call);
    if (!item) return;
    if (call) { item->call=1; return; }
    if (!item->call || item->output) return;
    item->output=1;
    int out=json_get(j,p,"output");
    if (out>=0 && j->t[out].type=='[') {
        for (int i=out+1;i<j->t[out].after;i=j->t[i].after)
            if (same_field(j,i,"type","input_text")) inspect_text(v,item,j,json_get(j,i,"text"),1);
    } else inspect_text(v,item,j,out,1);
}

/* Read the server's own verified session journal solely to identify early tool
   failures. It cannot supply acceptance evidence. Other turns are never joined. */
void verify_rollout(VerifyTrace *v,const char *path,const char *home,const char *thread,
                    const char *workspace,const char *turn) {
    v->rollout="unavailable";
    if (!*path || !*turn || !chat_rollout_matches(path,home,thread,workspace)) return;
    Buf data={0}; Error err={0};
    if (!read_file(path,8*MIB,&data,&err)) { buffer_free(&data); return; }
    int active=0,seen=0,done=0;
    for (size_t pos=0;pos<data.n;) {
        const char *line=data.s+pos,*end=memchr(line,'\n',data.n-pos);
        if (!end) { v->partial=1; break; }
        size_t length=(size_t)(end-line);
        pos+=length+1;
        JSON j;
        if (!json_parse(&j,line,length)) { v->partial=1; active=0; continue; }
        int p=json_get(&j,0,"payload");
        if (pos==length+1 && (!same_field(&j,0,"type","session_meta") || !same_field(&j,p,"id",thread))) {
            json_free(&j); break;
        }
        if (same_field(&j,0,"type","turn_context") ||
            (same_field(&j,0,"type","event_msg") &&
             (same_field(&j,p,"type","task_started") || same_field(&j,p,"type","turn_started")))) {
            active=same_field(&j,p,"turn_id",turn);
            if (active) seen=1;
        } else if (active && same_field(&j,0,"type","event_msg") &&
                (same_field(&j,p,"type","task_complete") || same_field(&j,p,"type","turn_complete") ||
                 same_field(&j,p,"type","turn_aborted"))) {
            done=same_field(&j,p,"turn_id",turn); active=0;
        } else if (active && same_field(&j,0,"type","response_item")) rollout_item(v,&j,p);
        json_free(&j);
        if (done) break;
    }
    if (seen && !done) v->partial=1;
    v->rollout=done?"complete":seen?"partial":"turn-not-found";
    buffer_free(&data);
}

int verify_has_success(const VerifyTrace *v) {
    if (v->partial) return 0;
    for (size_t i=0;i<v->count;++i) if (v->items[i].success) return 1;
    return 0;
}
int verify_has_denial(const VerifyTrace *v) {
    for (size_t i=0;i<v->count;++i) if (v->items[i].denied || v->items[i].early_denial) return 1;
    return 0;
}
void verify_summary(const VerifyTrace *v,int preflight,char *out,size_t cap) {
    unsigned starts=0,commands=0,others=0,calls=0,outputs=0,early=0,failures=0,success=0,denials=0;
    for (size_t i=0;i<v->count;++i) {
        const VerifyItem *it=&v->items[i];
        starts+=it->started; commands+=it->command; others+=it->other; calls+=it->call; outputs+=it->output;
        early+=it->early_failure && !it->command;
        failures+=it->failed || it->early_failure; denials+=it->denied || it->early_denial; success+=it->success;
    }
    sam_format(out,cap,"preflight=%s; started=%u; commandResults=%u; otherToolResults=%u; execCalls=%u; execOutputs=%u; earlyErrors=%u; errors=%u; denials=%u; successfulResults=%u; rollout=%s; partial=%d",
        preflight?"READ_OK":"NOT_VERIFIED",starts,commands,others,calls,outputs,early,failures,denials,success,
        v->rollout?v->rollout:"not-read",v->partial);
}
