#ifndef SAM_VERIFY_TRACE_H
#define SAM_VERIFY_TRACE_H
#include "base.h"

/* Store only identifiers and observations. Never retain arguments, output or credentials. */
typedef struct {
    char id[160];
    unsigned started, command, other, success, failed, denied, call, output, early_failure, early_denial;
} VerifyItem;
typedef struct {
    VerifyItem items[128];
    size_t count;
    int partial;
    const char *rollout;
} VerifyTrace;

int verify_item(VerifyTrace *v, const JSON *j, int item, int completed);
void verify_rollout(VerifyTrace *v, const char *path, const char *home, const char *thread,
                    const char *workspace, const char *turn);
int verify_has_success(const VerifyTrace *v);
int verify_has_denial(const VerifyTrace *v);
void verify_summary(const VerifyTrace *v, int preflight, char *out, size_t cap);
#endif
