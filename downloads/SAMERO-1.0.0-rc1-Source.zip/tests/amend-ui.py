#!/usr/bin/env python3
"""Browser smoke for the pending-criterion editor; real Manager, fixture Codex."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
import integration as t

t.APP=Path(sys.argv[1]).resolve(); t.REAL_CODEX=None
case=t.ManagerTest('test_legacy_stale_criterion_amendment_preserves_evidence_and_reverifies')
case.setUp()
try:
    rid,ctl,_=case.seed_legacy_run(0,2,stale=True)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1380,'height':900})
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(case.url+'/#'+case.key)
        page.get_by_role('button',name='Hạn mức',exact=True).click()
        page.get_by_role('button',name='Sửa tiêu chí',exact=True).click()
        assert 'Queue hien co 0 tac vu' in page.get_by_label('Tiêu chí cũ').input_value()
        page.get_by_label('Tiêu chí mới (tối đa 679 byte UTF-8)').fill('File exists and configured check passes.')
        page.get_by_role('checkbox',name='Tôi xác nhận thay đổi tiêu chí nhưng giữ nguyên yêu cầu thực chất.').check()
        page.get_by_role('button',name='Lưu và tiếp tục',exact=True).click()
        r=case.run_state(rid,lambda r:r['index']==2 and r['phase']=='work' and r['inflight'])
        assert r['tasks'][0]['status']=='PASS' and r['tasks'][0]['testSession'] and r['tasks'][0]['verifySession']
        assert r['tasks'][0]['accept']=='File exists and configured check passes.'
        assert not errors,errors
        browser.close()
    print('PASS: Chromium actual button, old criterion display, confirmation, persisted amendment, no automatic PASS')
finally:
    case.tearDown()
