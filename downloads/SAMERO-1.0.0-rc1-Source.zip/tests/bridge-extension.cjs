const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');
const root=path.join(__dirname,'..','extension');
(async()=>{
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json')));
 assert.equal(manifest.manifest_version,3);assert(!manifest.host_permissions);assert(!manifest.content_scripts);
 let click,installed;const state={};let badge='';let menu;let targetURL='https://chatgpt.com/c/example';let sends=0;
 const chrome={runtime:{onInstalled:{addListener:f=>installed=f}},contextMenus:{removeAll:f=>f(),create:o=>menu=o,onClicked:{addListener:f=>click=f}},storage:{session:{set:async o=>Object.assign(state,o),get:async k=>({[k]:state[k]}),remove:async k=>delete state[k]}},action:{setBadgeText:async o=>badge=o.text},tabs:{query:async()=>[{id:1,url:targetURL}]},scripting:{executeScript:async o=>{sends++;assert.equal(o.args[0],'{"test":1}');return [{result:true}];}}};
 vm.runInNewContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),{chrome});installed();assert.deepEqual([...menu.documentUrlPatterns],['https://chatgpt.com/*']);
 await click({menuItemId:'samero-select',pageUrl:'https://example.com/',selectionText:'bad'});assert.equal(state.patch,undefined);
 await click({menuItemId:'samero-select',pageUrl:'https://chatgpt.com/c/a',selectionText:'x'.repeat(250001)});assert.equal(badge,'ERR');assert.equal(state.patch,undefined);
 await click({menuItemId:'samero-select',pageUrl:'https://chatgpt.com/c/a',selectionText:'{"test":1}'});assert.equal(badge,'1');
 const elements=Object.fromEntries(['text','status','clear','send'].map(k=>[k,{value:'',textContent:''}]));
 vm.runInNewContext(fs.readFileSync(path.join(root,'popup.js'),'utf8'),{chrome,document:{getElementById:k=>elements[k]}});await new Promise(setImmediate);
 await elements.send.onclick();assert.equal(sends,0);assert.match(elements.status.textContent,/Manager/);
 targetURL='http://127.0.0.1:5555/';await elements.send.onclick();assert.equal(sends,1);assert.equal(state.patch,undefined);assert.equal(badge,'');
 console.log('PASS: extension mocked API: explicit selected text, allowed origin, size bound, loopback only, clears buffer after transfer. Not a real Chrome integration test.');
})().catch(e=>{console.error(e);process.exit(1);});
