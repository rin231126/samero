#!/usr/bin/env python3
import sys,json
from pathlib import Path
from playwright.sync_api import sync_playwright
import integration as t

t.APP=Path(sys.argv[1]).resolve();t.REAL_CODEX=None
case=t.ManagerTest('test_process_exit_and_unsafe_paths');case.setUp()
try:
    pid=case.req('project-save',{'name':'Bridge UI','path':str(case.workspace)})['id']
    original=case.example.read_bytes()
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1380,'height':900})
        errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto(case.url+'/#'+case.key)
        page.get_by_role('button',name='ChatGPT Web',exact=True).click()
        page.locator('#bridge-project').select_option(pid)
        page.locator('#bridge-path').fill(case.example.name)
        page.locator('#bridge-read').click()
        page.locator('#bridge-source').wait_for()
        assert page.locator('#bridge-source').input_value()==original.decode()
        body={'path':case.example.name,'baseSha256':case.req('bridge-read',{'project':pid,'path':case.example.name})['sha256'],'content':'\nnew\n'}
        page.locator('#bridge-patch').fill(json.dumps(body))
        page.locator('#bridge-preview').click()
        page.locator('#bridge-confirm').wait_for()
        assert page.locator('#bridge-after').input_value()==body['content']
        assert case.example.read_bytes()==original
        page.locator('#bridge-confirm').check();page.locator('#bridge-apply').click()
        page.wait_for_function("document.querySelector('#bridge-backup').value.length === 32")
        assert case.example.read_bytes()==body['content'].encode()
        page.on('dialog',lambda d:d.accept())
        page.locator('#bridge-rollback').click()
        page.get_by_text('Đã khôi phục '+case.example.name,exact=True).last.wait_for()
        assert case.example.read_bytes()==original
        assert not errors,errors
        browser.close()
    print('PASS: real Chromium + real Manager UI; read, preview, confirmation, write, rollback')
finally:
    case.tearDown()
