#!/usr/bin/env python3
"""Linux real HTTP server integration with isolated fixture workspace."""
import hashlib,json,os,sys,unittest
from pathlib import Path
import integration as t

t.APP=Path(sys.argv[1]).resolve();t.REAL_CODEX=None
class BridgeTest(t.ManagerTest):
    def project(self):
        return self.req('project-save',{'name':'Bridge','path':str(self.workspace)})['id']
    def payload(self,p,content='new content\n'):
        r=self.req('bridge-read',{'project':p,'path':self.example.name})
        return {'project':p,'path':r['path'],'baseSha256':r['sha256'],'content':content}
    def test_bridge_review_apply_rollback_restart(self):
        p=self.project(); body=self.payload(p,'\nTiếng Việt\r\n'); old=self.example.read_bytes()
        self.req('bridge-apply',{**body,'confirm':True},expected=409)
        v=self.req('bridge-preview',body)
        self.assertEqual(v['before'],old.decode());self.assertEqual(v['after'],body['content']);self.assertEqual(self.example.read_bytes(),old)
        self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':False},expected=409)
        self.req('bridge-apply',{**body,'content':'tampered','ticket':v['ticket'],'confirm':True},expected=409)
        r=self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':True})
        self.assertEqual(self.example.read_bytes(),body['content'].encode());self.assertEqual(r['sha256'],hashlib.sha256(self.example.read_bytes()).hexdigest())
        self.assertEqual(json.loads((self.data/'bridge'/(r['backup']+'.json')).read_text())['original'],old.decode())
        self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':True},expected=409)
        self.req('exit');self.proc.wait();self.launch()
        self.req('bridge-rollback',{'backup':r['backup'],'confirm':False},expected=409)
        self.req('bridge-rollback',{'backup':r['backup'],'confirm':True})
        self.assertEqual(self.example.read_bytes(),old)
    def test_bridge_conflict_and_rollback_guard(self):
        p=self.project();body=self.payload(p);v=self.req('bridge-preview',body)
        self.example.write_text('outside change')
        self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':True},expected=409)
        self.assertEqual(self.example.read_text(),'outside change')
        body=self.payload(p);v=self.req('bridge-preview',body);r=self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':True})
        self.example.write_text('outside after')
        self.req('bridge-rollback',{'backup':r['backup'],'confirm':True},expected=409)
        self.assertEqual(self.example.read_text(),'outside after')
    def test_bridge_rollback_project_scope(self):
        p=self.project(); body=self.payload(p); v=self.req('bridge-preview',body)
        r=self.req('bridge-apply',{**body,'ticket':v['ticket'],'confirm':True})
        other=self.root/'OtherProject'; other.mkdir()
        q=self.req('project-save',{'name':'Other','path':str(other)})['id']
        self.req('bridge-rollback',{'project':q,'backup':r['backup'],'confirm':True},expected=409)
        self.assertEqual(self.example.read_text(),body['content'])
        self.req('bridge-rollback',{'project':p,'backup':r['backup'],'confirm':True})
        self.assertEqual(self.example.read_text(),'unstaged state\n')

    def test_bridge_paths_secrets_links_and_auth(self):
        p=self.project();(self.workspace/'binary.txt').write_bytes(b'\x00\xff');(self.workspace/'big.txt').write_bytes(b'x'*65537)
        (self.workspace/'link.txt').symlink_to(self.example);(self.workspace/'dirlink').symlink_to(self.root,target_is_directory=True)
        os.link(self.example,self.workspace/'hard.txt')
        for path in ('../else.txt','/etc/passwd','C:/file.txt','a\\b.txt','.env','.git/config','notes.txt','binary.txt','big.txt','link.txt','dirlink/file.txt','hard.txt','missing.py','node_modules/ignored.txt','PROJECT_STATUS.md'):
            self.req('bridge-read',{'project':p,'path':path},expected=409)
        (self.workspace/'hard.txt').unlink()
        self.req('bridge-read',{'project':p,'path':self.example.name},key='bad',expected=403)
        self.req('bridge-read',{'project':p,'path':self.example.name},origin='https://chatgpt.com',expected=403)
        body=self.payload(p,'sk-proj-example-secret');self.req('bridge-preview',body,expected=409)
    def test_bridge_busy_runner(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        self.req('runner-resume',ctl)
        self.req('bridge-read',{'project':ctl['project'],'path':self.example.name},expected=409)
        self.req('runner-stop',ctl)
        self.run_state(rid,lambda r:r['mode']=='stopped' and not r['snapshot'])
        self.req('bridge-read',{'project':ctl['project'],'path':self.example.name})

if __name__=='__main__':
    names=[n for n in dir(BridgeTest) if n.startswith('test_bridge_')]
    suite=unittest.TestSuite(BridgeTest(n) for n in names)
    sys.exit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
