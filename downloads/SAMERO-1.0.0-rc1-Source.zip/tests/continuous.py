#!/usr/bin/env python3
"""Actual local HTTP integration tests for user-mediated continuous rounds."""
import sys,unittest,json
from pathlib import Path
import integration as t

t.APP=Path(sys.argv[1]).resolve(); t.REAL_CODEX=None
class ContinuousTest(t.ManagerTest):
    def project(self): return self.req('project-save',{'name':'Continuous','path':str(self.workspace)})['id']
    def start(self,p): return self.req('continuous-start',{'project':p,'revision':0,'goal':'Hoàn thiện dự án','task':'Kiểm tra parser','flags':63})
    def op(self,p,s,a,**body): return self.req('continuous-'+a,{'project':p,'revision':s['revision'],**body})
    def test_continuous_lifecycle_restart(self):
        p=self.project(); self.assertEqual(self.req('continuous-get',{'project':p})['mode'],'idle'); s=self.start(p)
        self.assertEqual(s['mode'],'waiting_user'); self.assertEqual(s['revision'],1)
        s=self.op(p,s,'record',note='Chưa test; cần sửa lỗi',next='Kiểm tra Unicode',testSession='')
        self.assertEqual(s['rounds'],1); self.assertEqual(s['history'][0]['exitCode'],-1)
        self.assertEqual(s['history'][0]['task'],'Kiểm tra parser'); self.assertEqual(s['task'],'Kiểm tra Unicode')
        s=self.op(p,s,'pause'); self.req('continuous-record',{'project':p,'revision':s['revision'],'note':'x','next':'y','testSession':''},expected=409)
        self.req('exit'); self.proc.wait(); self.launch(); self.assertEqual(self.req('continuous-get',{'project':p}),s)
        s=self.op(p,s,'resume'); s=self.op(p,s,'stop'); self.assertEqual(s['mode'],'stopped')
        self.req('continuous-start',{'project':p,'revision':s['revision'],'goal':'new','task':'new','flags':63},expected=409)
        s=self.op(p,s,'resume'); s=self.op(p,s,'record',note='Đã rà soát',next='Kiểm tra lỗi',testSession=''); self.assertEqual(s['rounds'],2); self.assertEqual(len(s['history']),2)
    def test_continuous_reject_stale_and_secrets(self):
        p=self.project(); s=self.start(p)
        for body in ({'revision':0,'note':'ok','next':'next','testSession':''},{'revision':1,'note':'sk-proj-fixture-secret','next':'next','testSession':''},{'revision':1,'note':'ok','next':'next','testSession':'f'*32}):
            self.req('continuous-record',{'project':p,**body},expected=409)
        self.req('continuous-get',{'project':p},key='bad',expected=403)
        self.assertEqual(self.req('continuous-get',{'project':p}),s)
        path=self.data/'continuous'/(p+'.json'); path.write_text('{bad')
        self.req('continuous-get',{'project':p},expected=409); self.req('continuous-start',{'project':p,'revision':0,'goal':'new','task':'new','flags':63},expected=409); self.assertEqual(path.read_text(),'{bad')
    def test_continuous_real_test_evidence(self):
        p=self.project(); s=self.start(p)
        run=self.req('session-check',{'project':p,'kind':'test','exe':sys.executable,'args':'-c\nprint(123)','confirmed':True})
        file=self.data/'sessions'/(run['id']+'.json')
        self.eventually(lambda: file.exists() and json.loads(file.read_text()).get('ended') is not None)
        s=self.op(p,s,'record',note='Chạy thử Python thật',next='Test tiếp',testSession=run['id']); self.assertEqual(s['history'][0]['exitCode'],0)
        self.req('continuous-record',{'project':p,'revision':s['revision'],'note':'again','next':'next','testSession':run['id']},expected=409)
    def test_continuous_role_persistence_and_migration(self):
        p=self.project(); s=self.start(p)
        self.assertEqual(s['role'],0)
        path=self.data/'continuous'/(p+'.json'); old=dict(s); old.pop('role'); path.write_text(json.dumps(old))
        self.assertNotIn('role', self.req('continuous-get',{'project':p}))
        s=self.op(p,s,'role',role=4); self.assertEqual(s['role'],4)
        self.req('continuous-role',{'project':p,'revision':s['revision'],'role':8},expected=409)
        self.req('continuous-role',{'project':p,'revision':s['revision']-1,'role':2},expected=409)
        self.assertEqual(self.req('continuous-get',{'project':p}),s)
        s=self.op(p,s,'record',note='Đã xem code',next='Review code',testSession='')
        self.assertEqual(s['history'][0]['role'],4)
        s=self.op(p,s,'role',role=5)
        self.req('exit');self.proc.wait();self.launch()
        self.assertEqual(self.req('continuous-get',{'project':p}),s)
        self.assertEqual(s['history'][0]['role'],4)
    def test_continuous_role_reject_cross_project(self):
        p=self.project();s=self.start(p)
        other=self.root/'Other';other.mkdir();q=self.req('project-save',{'name':'Other','path':str(other)})['id']
        self.req('continuous-role',{'project':q,'revision':s['revision'],'role':7},expected=409)
        self.assertEqual(self.req('continuous-get',{'project':p}),s)
    def test_continuous_workspace_busy(self):
        rid,ctl,_=self.seed_legacy_run(0,2); p=ctl['project']; self.req('runner-resume',ctl)
        self.req('continuous-start',{'project':p,'revision':0,'goal':'goal','task':'task','flags':1},expected=409)
        self.req('runner-stop',ctl); self.run_state(rid,lambda r:r['mode']=='stopped' and not r['snapshot'])
        self.start(p)
if __name__=='__main__':
    suite=unittest.TestSuite(ContinuousTest(n) for n in dir(ContinuousTest) if n.startswith('test_continuous_'))
    sys.exit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
