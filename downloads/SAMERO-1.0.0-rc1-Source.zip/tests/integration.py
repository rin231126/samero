#!/usr/bin/env python3
import argparse
import re
import hashlib
import json
import os
import queue
import threading
import uuid
from pathlib import Path

import subprocess
import tempfile
import time
import unittest
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import sys
import zipfile

SOURCE_VERSION = re.search(r'^#define SAM_VERSION "([^"]+)"', (Path(__file__).resolve().parents[1]/"src/manager.h").read_text(), re.M).group(1)

FIXTURE = r'''#!/usr/bin/env python3
import json, os, sys, time
from pathlib import Path
home = Path(os.environ["CODEX_HOME"])
assert "OPENAI_API_KEY" not in os.environ
args = sys.argv[1:]
if "--version" in args:
    print("codex-cli fixture")
elif args[:2] == ["login", "status"]:
    print("Not logged in")
    sys.exit(1)
elif args[:1] == ["app-server"]:
    for line in sys.stdin:
        r = json.loads(line)
        if "id" not in r:
            continue
        method = r["method"]
        if method == "initialize":
            ans = {}
        elif method == "config/read":
            import tomllib
            assert r["params"]["cwd"]==os.getcwd()
            flags=[args[i+1] for i,v in enumerate(args) if v=="-c"]
            cfg=tomllib.loads("\n".join(flags))
            if (home/"invalid-cli-config").exists(): cfg["sandbox_mode"]="danger-full-access"
            ans={"config":cfg}
        elif method == "account/read":
            ans = {"account":{"type":"chatgpt","email":home.name+"@example.com","planType":"plus"}}
        elif method == "account/rateLimits/read":
            if (home / "slow-quota").is_file():
                (home / "quota-pending").touch()
                time.sleep(2.2)
            ans = {"rateLimitsByLimitId":{"codex":{"primary":{"usedPercent":22,"windowDurationMins":300,"resetsAt":2040000000},
                   "secondary":{"usedPercent":31,"windowDurationMins":10080,"resetsAt":2050000000},
                   "credits":{"balance":"18.75","unlimited":False},"private":"sk-proj-fixture-secret"}}}
        print(json.dumps({"id":r["id"],"result":ans}),flush=True)
elif args[:1] == ["login"]:
    sys.exit(0)
else:
    (home / "seen.json").write_text(json.dumps({"home":str(home),"cwd":os.getcwd(),"args":args}),encoding="utf-8")
    if "--model" in args and args[args.index("--model")+1] == "fixture-fail":
        sys.exit(7)
    time.sleep(30)
'''
CHAT_FIXTURE = r'''#!/usr/bin/env python3
import json, os, sys, time
from pathlib import Path
home = Path(os.environ["CODEX_HOME"])
assert "OPENAI_API_KEY" not in os.environ
trace = home / "rpc.jsonl"
stored = home / "import-thread"
thread = stored.read_text() if stored.is_file() else "thread-" + home.name
signed_out = (home / "signed-out").exists()
if (home / "keyring-only").exists():
    assert not any(arg.startswith("cli_auth_credentials_store=") for arg in sys.argv[1:])
loaded = False
turn = 0
active = None

def emit(packet):
    print(json.dumps(packet),flush=True)

def result(request, value):
    emit({"id":request["id"],"result":value})

def event(method, **params):
    emit({"method":method,"params":{"threadId":thread,**params}})

def finish(turn_id, status="completed", error=None):
    event("turn/completed",turn={"id":turn_id,"status":status,"error":error})

for line in sys.stdin:
    r = json.loads(line)
    method = r.get("method")
    p = r.get("params",{})
    with trace.open("a",encoding="utf-8") as out:
        out.write(json.dumps(r) + "\n")
    if method == "initialize":
        result(r,{"platformOs":"windows" if (home/"windows-readiness").exists() else "linux"})
    elif method == "initialized":
        continue
    elif method == "account/read":
        if (home / "account-unsupported").exists():
            emit({"id":r["id"],"error":{"code":-32601,"message":"Method not found"}})
            continue
        account = None if signed_out else {"type":"chatgpt","planType":"plus"}
        if account and (home/"auto-fixture").exists(): account["email"]="runner@example.com"
        result(r,{"account":account,"requiresOpenaiAuth":True})
    elif method == "account/rateLimits/read":
        if (home/"rate-offline").exists():
            emit({"id":r["id"],"error":{"code":-32000,"message":"Service temporarily unavailable"}})
            continue
        reset=2040000000; used=20
        if (home/"fast-reset").exists():
            marker=home/"reset-was-read"
            if not marker.exists():
                reset=int(time.time())+2
                used=100; marker.touch()
            else:
                used=4
        result(r,{"rateLimits":{"limitId":"codex","primary":{"usedPercent":used,"windowDurationMins":300,"resetsAt":reset},
                                "secondary":{"usedPercent":31,"windowDurationMins":10080,"resetsAt":2050000000}}})
    elif method == "thread/list":
        result(r,{"data":[],"nextCursor":None})
    elif method == "thread/turns/list":
        if p["itemsView"]=="notLoaded":
            result(r,{"data":[{"id":active}] if active and not (home/"no-durable-turn").exists() else [],"nextCursor":None})
            continue
        assert p["itemsView"] == "full" and p["threadId"]
        result(r,{"data":[{"items":[{"type":"userMessage","content":[{"type":"text","text":"Prompt gốc"}]},
                                    {"type":"agentMessage","text":"Phản hồi từ lịch sử"}]}],"nextCursor":None})
    elif method == "model/list":
        result(r,{"data":[{"model":"fixture-model","displayName":"Fixture model","supportedReasoningEfforts":[{"reasoningEffort":"low"}]}]})
    elif method == "thread/read":
        if (home / "cold-read").exists():
            emit({"id":r["id"],"error":{"code":-32600,"message":"thread not loaded: "+p["threadId"]}})
        elif (home / "missing-rollout").exists():
            emit({"id":r["id"],"error":{"code":-32602,"message":"no rollout found for thread id"}})
        else:
            result(r,{"thread":{"id":p["threadId"],"cwd":str(home if (home / "wrong-cwd").exists() else Path.cwd()),"ephemeral":False}})
    elif method in ("thread/start","thread/resume"):
        if method=="thread/start":
            assert p["cwd"]==os.getcwd() and p.get("ephemeral") is not True and "threadId" not in p
        elif (home/"cold-read").exists():
            assert "cwd" not in p
        else:
            assert p["cwd"]==os.getcwd()
        if method=="thread/resume" and (home/"gone-after-read").exists():
            emit({"id":r["id"],"error":{"code":-32600,"message":"no rollout found for thread id "+thread}})
            continue
        auto=p.get("approvalsReviewer")=="auto_review"
        if auto:
            assert p["sandbox"]=="workspace-write"
            assert p["approvalPolicy"]=={"granular":{"sandbox_approval":False,"rules":True,"mcp_elicitations":False,"request_permissions":False,"skill_approval":False}}
            assert p["config"]["sandbox_workspace_write"]=={"network_access":False,"writable_roots":[],"exclude_slash_tmp":True,"exclude_tmpdir_env_var":True}
        else:
            assert p.get("approvalsReviewer")=="user"
            assert (p["sandbox"],p["approvalPolicy"]) in ([("workspace-write","on-request"),("read-only","never")] if (home/"auto-fixture").exists() else [("workspace-write","on-request")])
        sandbox=p["sandbox"]
        if (home / "multiple-threads").exists():
            if method == "thread/resume":
                thread=p["threadId"]
            else:
                counter=home / "thread-number"
                num=int(counter.read_text())+1 if counter.is_file() else 1
                counter.write_text(str(num))
                thread=(f"01901234-56aa-7a04-b0ff-{num:012x}" if (home/"verify-case").is_file() and (home/"verify-case").read_text()=="late-rollout" else "thread-fixture-" + str(num))
        if method == "thread/resume":
            assert p["threadId"] == thread and p["excludeTurns"] is True
        late_path=sandbox=="read-only" and (home/"verify-case").is_file() and (home/"verify-case").read_text()=="late-rollout"
        path=home / "sessions" / "2026" / "11" / "23" / (("rollout-2026-11-23T00-00-00-" if late_path else "rollout-") + thread + ".jsonl")
        path.parent.mkdir(parents=True,exist_ok=True)
        if not late_path and not (home/"lazy-rollout").exists() and not path.exists():
            meta={"type":"session_meta","payload":{"id":thread,"cwd":os.getcwd(),"source":"vscode"}}
            path.write_text(json.dumps(meta)+"\n")
        loaded=not (home/"absent-runtime").exists()
        effective={"cwd":os.getcwd(),"approvalsReviewer":"auto_review" if auto else "user","approvalPolicy":p["approvalPolicy"],
            "sandbox":{"type":"workspaceWrite","networkAccess":False,"excludeSlashTmp":True,"excludeTmpdirEnvVar":True,"writableRoots":[]}}
        if sandbox=="read-only" and not (home/"unsafe-plan").exists(): effective["sandbox"]={"type":"readOnly","networkAccess":False}
        if (home/"weak-review").exists():
            case=(home/"weak-review").read_text()
            if case=="unavailable":effective.pop("approvalsReviewer")
            elif case=="outside":effective["sandbox"]["writableRoots"]=[str(home)]
            elif case=="network":effective["sandbox"]["networkAccess"]=True
            elif case=="policy":effective["approvalPolicy"]="on-request"
            elif case=="full":effective["sandbox"]["type"]="dangerFullAccess"
        result(r,{**effective,"thread":{"id":thread,"cwd":os.getcwd(),"status":{"type":"idle" if loaded else "notLoaded"},
                           "path":str(path) if path.exists() else None},"model":"fixture-reported-model"})
    elif method=="thread/loaded/list":
        if (home/"list-unsupported").exists():
            emit({"id":r["id"],"error":{"code":-32601,"message":"Method not found"}})
        elif (home/"paged-loaded").exists() and not p.get("cursor"):
            result(r,{"data":["different-id"],"nextCursor":"next-page"})
        else:
            result(r,{"data":[thread] if loaded else [],"nextCursor":None})
    elif method == "windowsSandbox/readiness":
        assert "params" not in r and sandbox=="read-only"
        status=(home/"windows-readiness").read_text()
        if status=="unsupported":
            emit({"id":r["id"],"error":{"code":-32601,"message":"Method not found"}})
        else: result(r,{"status":status})
    elif method == "command/exec":
        assert sandbox=="read-only" and p["cwd"]==os.getcwd()
        assert p["sandboxPolicy"]=={"type":"readOnly","networkAccess":False}
        assert p["timeoutMs"]==10000 and p["outputBytesCap"]==2048
        assert "SAMERO_LIST_FAILED" in p["command"][-1]
        if (home/"preflight-unsupported").exists():
            emit({"id":r["id"],"error":{"code":-32601,"message":"Method not found"}})
        elif (home/"preflight-policy-denied").exists():
            emit({"id":r["id"],"error":{"code":-32603,"message":"CreateProcess: rejected: blocked by policy"}})
        elif (home/"preflight-list-denied").exists():
            result(r,{"exitCode":14,"stdout":"","stderr":"SAMERO_LIST_FAILED UnauthorizedAccessException"})
        elif (home/"preflight-denied").exists():
            result(r,{"exitCode":13,"stdout":"","stderr":"SAMERO_READ_FAILED TASK_QUEUE.json UnauthorizedAccessException"})
        else:
            result(r,{"exitCode":0,"stdout":"SAMERO_READ_OK\n","stderr":""})
    elif method == "turn/start":
        if (home/"reject-turn").exists() or not loaded:
            emit({"id":r["id"],"error":{"code":-32600,"message":"thread not loaded: "+thread}})
            continue
        turn += 1
        active = f"turn-{turn}"
        assert p["threadId"] == thread
        text = p["input"][0]["text"]
        if sandbox == "read-only":
            assert p["cwd"] == os.getcwd()
            assert p["approvalPolicy"] == "never"
            assert p["sandboxPolicy"] == {"type":"readOnly","networkAccess":False}
        else:
            assert "sandboxPolicy" not in p and "approvalPolicy" not in p
        result(r,{"turn":{"id":active,"status":"inProgress"}})
        event("turn/started",turn={"id":active,"status":"inProgress"})
        if text.startswith("SAMERO ") and (home/"auto-fixture").exists():
            phase=text.split()[1].rstrip(".")
            assert sandbox==("workspace-write" if phase=="WORK" else "read-only")
            if phase=="WORK" and auto:
                status=(home/"review-decision").read_text() if (home/"review-decision").exists() else "approved"
                if status=="policy-error":
                    finish(active,"failed",{"codexErrorInfo":"tooManyDenials","message":"Execution policy denied."})
                    continue
                if status=="manual":
                    emit({"method":"item/commandExecution/requestApproval","id":"approval-123","params":{"threadId":thread,"turnId":active,
                        "command":"test-command","cwd":os.getcwd(),"itemId":"cmd","availableDecisions":["decline","accept"]}})
                    continue
                rid="review-1"
                common={"threadId":thread,"turnId":active,"targetItemId":"cmd","reviewId":rid,"startedAtMs":1000,
                    "action":{"type":"command","command":"password=NEVER_COPY","cwd":os.getcwd(),"source":"shell"}}
                emit({"method":"item/autoApprovalReview/completed","params":{**common,"threadId":"other","review":{"status":"denied"}}})
                emit({"method":"item/autoApprovalReview/completed","params":{**common,"turnId":"old","review":{"status":"denied"}}})
                event("item/autoApprovalReview/started",**{k:v for k,v in common.items() if k!="threadId"},review={"status":"inProgress"})
                if status=="wait": continue
                if status=="unfinished": finish(active); continue
                if status=="strict":
                    event("autoApprovalReview/strictReviewRequired",turnId=active,startedAtMs=1001); continue
                if status=="declined-item":
                    event("item/completed",turnId=active,item={"type":"commandExecution","id":"cmd","status":"declined","command":"test"})
                    continue
                packet={"method":"item/autoApprovalReview/completed","params":{**common,"completedAtMs":2000,"decisionSource":"agent",
                       "review":{"status":status,"riskLevel":"high" if status!="approved" else "low","rationale":"Outside granted scope" if status!="approved" else "Workspace check"}}}
                emit(packet);emit(packet)
                if status!="approved":
                    finish(active); continue
            if phase=="PLAN" and (home/"drop-read-once").is_file():
                (home/"drop-read-once").unlink(); sys.exit(9)
            if phase=="PLAN" and (home/"quota-unknown-reset").is_file():
                (home/"quota-unknown-reset").unlink()
                error={"message":"Quota exhausted","codexErrorInfo":"usageLimitExceeded"}
                event("error",turnId=active,error=error,willRetry=False); finish(active,"failed",error)
                continue
            if phase=="PLAN" and (home/"quota-once").is_file():
                (home/"quota-once").unlink()
                error={"message":"Quota exhausted","codexErrorInfo":"usageLimitExceeded"}
                event("account/rateLimits/updated",rateLimits={"limitId":"codex","primary":{"usedPercent":100,"windowDurationMins":300,"resetsAt":int(time.time())+3},"secondary":{"usedPercent":25,"windowDurationMins":10080,"resetsAt":2050000000}})
                event("error",turnId=active,error=error,willRetry=False); finish(active,"failed",error)
                continue
            if phase=="PLAN" and (home/"bad-plan").exists():
                response={"tasks":[{"title":"cyclic","accept":"impossible","after":0}]}
            elif phase=="PLAN" and (home/"long-criteria").exists():
                response={"tasks":[{"title":"Long "+'"'*180,"accept":"Exact acceptance "+'"'*630+" END","after":-1}]}
            elif phase=="PLAN" and (home/"sixteen").exists():
                response={"tasks":[{"title":f"Unit {i+1}","accept":"File exists and configured check passes.","after":i-1} for i in range(16)]}
            elif phase=="PLAN":
                response={"tasks":[{"title":"Create source","accept":"main returns zero","after":-1},
                                   {"title":"Document source","accept":"notes exist","after":0}]}
            else:
                if phase=="WORK":
                    if not (home/"unchanged-work").exists() or not Path("actions.txt").exists():
                        with Path("actions.txt").open("a") as log: log.write("work\n")
                    Path("main.c").write_text("int main(void) { return 0; }\n")
                    if "Document source" in text: Path("notes.md").write_text("Returns zero")
                    if (home/"drop-work-once").exists():
                        (home/"drop-work-once").unlink();sys.exit(9)
                    if (home/"require-repairable-report").exists() and "Task 2:" in text:
                        Path("audit-report.md").write_text("Recovered evidence report.")
                    if (home/"hold-work").exists(): continue
                met=Path("main.c").is_file() and ("Document source" not in text or Path("notes.md").is_file())
                response={"met":met,"evidence":"Checked main.c and the required project documentation."}
                if phase=="VERIFY" and (home/"change-during-verify").exists():
                    Path("main.c").write_text("changed concurrently after tests")
                if (home/"long-review-once").exists() and phase=="VERIFY":
                    (home/"long-review-once").unlink()
                    response={"met":False,"needsReview":True,"evidence":"Diagnostic "+'"'*590+" END"}
                if (home/"review-once").exists() and phase=="VERIFY":
                    (home/"review-once").unlink()
                    response={"met":False,"needsReview":True,"evidence":"Possible missing bookkeeping evidence; verify independently."}
                if phase=="VERIFY" and (home/"turn-policy-denied").exists():
                    finish(active,"failed",{"message":"CreateProcess: rejected: blocked by policy"})
                    continue
                if phase=="VERIFY" and (home/"fill-command-preview").exists():
                    for i in range(16):
                        event("item/completed",turnId=active,item={"id":active+"-fill-"+str(i),"type":"commandExecution","command":"fixture-fill-"+str(i)+" "+"x"*400,"status":"completed","exitCode":0,"aggregatedOutput":""})
                if phase=="VERIFY" and (home/"blocked-access").exists():
                    expected="NOT_VERIFIED" if (home/"preflight-unsupported").exists() else "READ_OK"
                    assert "Bookkeeping probe: "+expected+"." in text
                    if (home/"observed-denial").exists() or (home/"unrelated-failure").exists():
                        out="Permission denied: required-artifact.json" if (home/"observed-denial").exists() else "File not found: optional-artifact.json"
                        event("item/completed",turnId=active,item={"id":active+"-failed","type":"commandExecution","command":"fixture-read","status":"failed","exitCode":1,"aggregatedOutput":out})
                    response={"met":False,"needsReview":True,"evidence":"BLOCKED_ACCESS: read-only fixture cannot read required evidence."}
                if phase=="VERIFY" and (home/"blocked-resource").exists():
                    response={"met":True,"needsReview":False,"evidence":"BLOCKED_RESOURCE: missing required fixture device."}
                if (home/"needs-review").exists() and phase=="VERIFY":
                    response={"met":False,"needsReview":True,"evidence":"A physical device is needed for this criterion."}
                if (home/"unchanged-work").exists() and phase=="VERIFY":
                    response={"met":False,"evidence":"Required file is missing."}
                if (home/"sixteen").exists():
                    import re
                    index=int(re.search(r"Task (\d+):",text).group(1))
                    if index==3 and phase=="WORK" and not (home/"all-sixteen").exists(): continue
                    if phase=="WORK":
                        Path(f"unit-{index}.txt").write_text("complete")
                        response={"met":True,"evidence":"Task 1 and Task 2 PASS according to worker."}
                    else:
                        met=Path(f"unit-{index}.txt").is_file() and Path(f"test-{index}.txt").is_file()
                        response={"met":met,"evidence":f"unit-{index}.txt and test-{index}.txt checked: {met}"}
                        if "Queue hien co 0 tac vu" in text:
                            response={"met":False,"needsReview":True,"evidence":"Legacy criterion requires empty queue and future build; cannot verify."}
            if phase=="VERIFY":
                case=(home/"verify-case").read_text() if (home/"verify-case").exists() else ""
                if case=="revision152" and "Task 5:" not in text: case=""
                if not case and not (home/"blocked-access").exists():
                    # The simulated verifier inspects a real file in its disposable workspace.
                    inspected=Path("main.c")
                    result_text=str(len(inspected.read_bytes())) if inspected.is_file() else "missing"
                    event("item/completed",turnId=active,item={"id":"read-fixture","type":"mcpToolCall",
                          "status":"completed","result":{"content":[{"type":"text","text":result_text}]},"error":None})
                if case in ("early-denial","old-turn","revision152","raw-other-error","quoted-output","early-denial-plus-success","late-rollout","failed-with-tool-error","incomplete-with-success"):
                    def save_record(kind,payload):
                        with path.open("a",encoding="utf-8") as log:
                            log.write(json.dumps({"type":kind,"payload":payload})+"\n")
                    if late_path:
                        save_record("session_meta",{"id":thread,"cwd":os.getcwd(),"source":"vscode"})
                    marker="other-turn" if case=="old-turn" else active
                    save_record("event_msg",{"type":"task_started","turn_id":marker})
                    save_record("response_item",{"type":"function_call","name":"exec_command","call_id":"call-fixture","arguments":"fixture-private-command"})
                    message='exec_command failed: CreateProcess { message: "Rejected: blocked by policy" }'
                    if case=="raw-other-error": message='exec_command failed: CreateProcess { message: "program was not found" }'
                    if case=="incomplete-with-success": message="Process exited with code 0\nFinal output:\nfixture file"
                    if case=="quoted-output": message="Process exited with code 0\nFinal output:\n"+message
                    payload={"type":"function_call_output","call_id":"call-fixture","output":[{"type":"input_text","text":message}]}
                    save_record("response_item",payload); save_record("response_item",payload)
                    if case!="incomplete-with-success":
                        save_record("event_msg",{"type":"task_complete","turn_id":marker})
                    if case=="failed-with-tool-error":
                        finish(active,"failed",{"message":"Verification was stopped after the tool failed."})
                        continue
                    if case=="old-turn":
                        save_record("event_msg",{"type":"task_started","turn_id":active})
                        save_record("event_msg",{"type":"task_complete","turn_id":active})
                    response={"met":False,"needsReview":True,"evidence":"BLOCKED_ACCESS: Required artifact could not be inspected."}
                    if case in ("early-denial-plus-success","late-rollout","incomplete-with-success"):
                        event("item/completed",turnId=active,item={"type":"commandExecution","id":"read-ok","status":"completed","exitCode":0})
                        response={"met":True,"needsReview":False,"evidence":"Claims complete despite a recorded early denial."}
                if case in ("foreign-start", "bad-json", "image-path-only", "dynamic-no-success", "denial-plus-success"):
                    if case=="foreign-start":
                        event("turn/started",turn={"id":"old-turn","status":"inProgress"})
                        event("item/completed",turnId="old-turn",item={"type":"commandExecution","id":"old-success","status":"completed","exitCode":0})
                    elif case=="bad-json":
                        print('{malformed',flush=True)
                        event("item/completed",turnId=active,item={"type":"commandExecution","id":"read","status":"completed","exitCode":0})
                    elif case=="image-path-only":
                        event("item/completed",turnId=active,item={"type":"imageView","id":"image","path":"missing.png"})
                    elif case=="dynamic-no-success":
                        event("item/completed",turnId=active,item={"type":"dynamicToolCall","id":"dynamic","status":"completed","contentItems":[{"type":"inputText","text":"unknown"}]})
                    else:
                        event("item/completed",turnId=active,item={"type":"commandExecution","id":"read","status":"completed","exitCode":0})
                        event("item/completed",turnId=active,item={"type":"mcpToolCall","id":"denied","status":"failed","error":{"message":"Permission denied"}})
                    response={"met":True,"needsReview":False,"evidence":"Positive claim in an incomplete or denied turn."}
                if case=="no-tools":
                    for bad in ({"turnId":"other"},{"turnId":active,"threadId":"other"}):
                        event("item/completed",**bad,item={"type":"commandExecution","id":"foreign-item","status":"completed","exitCode":0})
                    response={"met":True,"needsReview":False,"evidence":"Claim of success without any current tool evidence."}
                if case=="mcp-error":
                    bad={"id":"fs","type":"mcpToolCall","status":"failed","result":None,"error":{"message":"Permission denied"}}
                    event("item/started",turnId=active,item={**bad,"status":"inProgress"})
                    event("item/completed",turnId=active,item=bad);event("item/completed",turnId=active,item=bad)
                    response={"met":False,"needsReview":True,"evidence":"BLOCKED_ACCESS: Could not inspect required artifact."}
            if phase!="PLAN" and (home/"emit-commands").exists():
                event("item/completed",turnId=active,item={"id":active+"-command","type":"commandExecution","command":"fixture-check --safe","status":"completed","exitCode":0})
                event("item/completed",turnId=active,item={"id":active+"-secret","type":"commandExecution","command":"fixture-check --token HIDDEN_FIXTURE_VALUE","status":"completed","exitCode":0})
            if phase=="VERIFY" and (home/"legacy-r61").exists() and "Task 2:" in text:
                # The mock models the reported impossibility, not actual animation assets.
                if "ghi NOT RECORDED cho lệnh gốc mất" not in text or "chạy lại phép kiểm cần thiết" not in text:
                    response={"met":False,"needsReview":True,"evidence":"Missing original command creating TAKEOVER_BASELINE.csv"}
                elif not Path("test-2.txt").is_file() or (home/"legacy-missing-deliverable").exists():
                    response={"met":False,"needsReview":True,"evidence":"Actual backup or SHA-256 evidence missing."}
                else:
                    response={"met":True,"needsReview":False,"evidence":"Mock validated replacement evidence and current check; old command NOT RECORDED."}
            if phase=="VERIFY" and (home/"require-receipt").exists() and "Task 2:" in text:
                receipt=Path("PROJECT_STATUS.md").read_text()
                if "Task 1:" not in receipt or "PASS (Manager journal)" not in receipt or "Test session:" not in receipt:
                    response={"met":False,"needsReview":True,"evidence":"Task 1 receipt missing from PROJECT_STATUS.md"}
            if phase=="VERIFY" and (home/"require-ledger").exists() and "Task 2:" in text:
                task=json.loads(Path("TASK_QUEUE.json").read_text())["tasks"][0]
                if task.get("receiptVersion")!=2 or not task.get("checkpoint") or task.get("changedFilesStatus") not in ("RECORDED","TRUNCATED") or "history-artifact.txt" not in task.get("changedFiles","") or "original failure" not in task.get("errors",""):
                    response={"met":False,"needsReview":True,"evidence":"Task 1 historical ledger missing real file delta, errors, or checkpoint."}
            if phase=="VERIFY" and (home/"require-repairable-report").exists() and "Task 2:" in text and not Path("audit-report.md").exists():
                response={"met":False,"needsReview":False,"evidence":"Missing recoverable audit report."}
            if phase=="VERIFY" and (home/"invalid-verify-once").exists():
                (home/"invalid-verify-once").unlink()
                event("item/completed",turnId=active,item={"id":active+"-reply","type":"agentMessage","phase":"final_answer","text":"invalid reply"})
                finish(active);continue
            if phase!="PLAN":response.setdefault("needsReview",False)
            assert p["outputSchema"]["type"]=="object" and set(response)==set(p["outputSchema"]["required"])
            event("item/completed",turnId=active,item={"id":active+"-reply","type":"agentMessage","phase":"final_answer","text":json.dumps(response)})
            if (home/"late-comment").exists():
                event("item/completed",turnId=active,item={"id":active+"-note","type":"agentMessage","phase":"commentary","text":"Working on the task."})
            finish(active)
        elif text == "quota":
            error = {"message":"Quota exhausted","codexErrorInfo":"usageLimitExceeded"}
            emit({"method":"account/rateLimits/updated","params":{"rateLimits":{
                "limitId":"codex","primary":{"usedPercent":100,"windowDurationMins":300,"resetsAt":2040000000},
                "secondary":{"usedPercent":41,"windowDurationMins":10080,"resetsAt":2050000000}}}})
            event("error",turnId=active,error=error,willRetry=False)
            finish(active,"failed",error)
        elif text == "approve":
            emit({"method":"item/commandExecution/requestApproval","id":"approval-123",
                  "params":{"threadId":thread,"turnId":active,"itemId":"cmd",
                            "command":"printf approved","cwd":os.getcwd(),"availableDecisions":["accept","decline"]}})
        elif text == "unload":
            finish(active)
            loaded=False
            event("thread/status/changed",status={"type":"notLoaded"})
            event("thread/closed")
            finish(active)  # delayed notification must not restore readiness
        elif text == "disconnect-idle":
            finish(active)
            sys.exit(9)
        elif text == "disconnect-busy":
            sys.exit(9)
        elif text == "hold":
            continue
        elif text == "expired":
            error = {"message":"Credential expired","codexErrorInfo":"unauthorized"}
            event("error",turnId=active,error=error,willRetry=False)
            finish(active,"failed",error)
        elif text == "tool":
            item={"type":"commandExecution","id":"tool-example","command":"fixture","status":"inProgress"}
            event("item/started",turnId=active,item=item)
            event("item/commandExecution/outputDelta",turnId=active,itemId="tool-example",delta="Lệnh đang chạy")
            event("item/completed",turnId=active,item={**item,"status":"completed","exitCode":0,"aggregatedOutput":"Kết quả kiểm thử"})
            event("item/completed",turnId=active,item={"type":"fileChange","id":"file-example","changes":[{"path":"src/demo.c"}]})
            event("turn/diff/updated",turnId=active,diff="@@ -1 +1 @@\n-old\n+new")
            finish(active)
        else:
            response = "Đã xử lý ở " + home.name
            event("item/agentMessage/delta",turnId=active,itemId=active+"-line",delta=response[:10])
            time.sleep(.45)
            event("item/completed",turnId=active,item={"id":active+"-line","type":"agentMessage","text":response})
            finish(active)
    elif method == "turn/interrupt":
        result(r,{})
        finish(active,"interrupted")
    elif r.get("id") == "approval-123":
        assert r["result"]["decision"] in ("accept","decline")
        event("serverRequest/resolved",requestId="approval-123")
        finish(active)
'''

SAVED_FIXTURE = r'''#!/usr/bin/env python3
import json, os, sys, time
from pathlib import Path
home = Path(os.environ["CODEX_HOME"])
args = sys.argv[1:]
if args == ["--version"]:
    print("codex-cli fixture")
elif args == ["app-server"]:
    if (home / "legacy-only").exists():
        sys.exit(2)
    for line in sys.stdin:
        request = json.loads(line)
        if "id" not in request:
            continue
        method = request["method"]
        result = {}
        if method == "thread/list":
            assert request["params"]["useStateDbOnly"] is True
            assert request["params"]["sourceKinds"] == ["cli"]
            marked = json.loads((home / "fixture-index.json").read_text(encoding="utf-8"))
            page = request["params"].get("cursor")
            result = {"data":marked[1:] if page else marked[:1],"nextCursor":None if page else "page2"}
        print(json.dumps({"id":request["id"],"result":result}),flush=True)
elif args[:1] == ["resume"] and "--" in args:
    (home / "resume-trace.json").write_text(json.dumps({"home":str(home),"cwd":os.getcwd(),"args":args}),encoding="utf-8")
    time.sleep(25)
else:
    sys.exit(7)
'''

APP = None
REAL_CODEX = None

class ManagerTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="samero-test-")
        self.root = Path(self.temp.name)
        self.data = self.root / "Dữ liệu"
        self.native_home = self.root / "CODEX_HOME Terminal"
        self.native_home.mkdir()
        self.workspace = self.root / "Mã nguồn dự án"
        self.workspace.mkdir()
        self.example = self.workspace / "tiến độ.txt"
        self.git("init","-q","-b","main")
        self.example.write_text("baseline\n",encoding="utf-8")
        self.git("add",".")
        self.git("-c","user.name=Fixture","-c","user.email=fixture@example.com","commit","-qm","initial")
        self.example.write_text("staged state\n",encoding="utf-8")
        self.git("add",self.example.name)
        self.example.write_text("unstaged state\n",encoding="utf-8")
        (self.workspace / "mới thêm.py").write_text("2 + 2\n",encoding="utf-8")
        (self.workspace / ".env").write_text("OPENAI_API_KEY=fake-key")
        (self.workspace / "notes.txt").write_text('authorization: bearer sk-proj-fixture-secret')
        (self.workspace / "node_modules").mkdir()
        (self.workspace / "node_modules" / "ignored").write_text("cache")
        if os.name != "nt":
            (self.workspace / "symlink").symlink_to(self.workspace / ".env")
        self.fixture = self.root / "Codex CLI fixture"
        self.fixture.write_text(FIXTURE)
        self.fixture.chmod(0o755)
        self.launch()

    def tearDown(self):
        try:
            if self.proc.poll() is None:
                self.proc.terminate()
                try:
                    self.proc.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    self.proc.kill()
                    self.proc.wait(timeout=5)
                    raise
        finally:
            self.temp.cleanup()

    def git(self,*args):
        return subprocess.check_output(["git",*args],cwd=self.workspace)

    def launch(self):
        env = os.environ.copy()
        env["OPENAI_API_KEY"] = "inherited-fixture-credential"
        env["CODEX_HOME"] = str(self.native_home)
        self.proc = subprocess.Popen([str(APP),"--headless","--data-dir",str(self.data)],
                                     env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        port_file = self.data / "ui.url"
        self.eventually(lambda: port_file.is_file() and (self.data / "ui.version").is_file() and self.proc.poll() is None)
        self.url,self.key = port_file.read_text().split("/#")

    def req(self,name,body=None,*,origin=None,key=None,expected=200):
        r = Request(f"{self.url}/api/{name}",data=json.dumps(body or {}).encode(),
                    headers={"Origin":origin or self.url, "X-Samero-Key":self.key if key is None else key,
                             "Content-Type":"application/json"},method="POST")
        try:
            response = urlopen(r,timeout=90)
        except HTTPError as e:
            response = e
        self.assertEqual(response.code,expected,detail := response.read().decode("utf-8"))
        return json.loads(detail)

    def eventually(self,predicate,seconds=10):
        until = time.monotonic()+seconds
        while time.monotonic()<until:
            result = predicate()
            if result:
                return result
            time.sleep(.06)
        self.fail("condition exceeded timeout")

    def add_profile(self,name,path=None,model="",auth_store=None):
        auth = {"authStore":auth_store} if auth_store is not None else {}
        return self.req("profile-save",{"name":name,"home":str(self.root / name),
                    "cli":str(path or self.fixture),"model":model,"effort":"high",**auth})["id"]

    def session(self,sid):
        return next(s for s in self.req("state")["sessions"] if s["id"]==sid)

    def runner_fixture(self, test=None):
        self.fixture.write_text(CHAT_FIXTURE)
        profile=self.add_profile("Autonomous")
        (self.root/"Autonomous"/"auto-fixture").touch()
        (self.root/"Autonomous"/"multiple-threads").touch()
        p=self.req("project-save",{"name":"Runner","path":str(self.workspace),"goal":"Build an executable."})["id"]
        import shutil
        cmd={"project":p,"profile":profile,"confirmed":True,"testExe":sys.executable,
             "testArgs":"test-run.py","buildExe":shutil.which("gcc"),"buildArgs":"-O2\nmain.c\n-o\nrelease"}
        (self.workspace/"test-run.py").write_text(test or "from pathlib import Path\nassert 'return 0' in Path('main.c').read_text()\n")
        return cmd

    def run_state(self,identity,condition=lambda r:True):
        def match():
            r=next(r for r in self.req("state")["runs"] if r["id"]==identity)
            return r if condition(r) else None
        return self.eventually(match,seconds=120)

    def test_progress_receipts_before_next_task(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"require-receipt").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        status=(self.workspace/"PROJECT_STATUS.md").read_text()
        for i,t in enumerate(r["tasks"],1):
            self.assertEqual(status.count(f"<!-- SAMERO TASK {rid} {i} -->"),1)
            self.assertIn(t["testSession"],status); self.assertIn(t["verifySession"],status)
        ck=next(c for c in self.req("state")["checkpoints"] if c["id"]==r["checkpoint"])
        with zipfile.ZipFile(Path(ck["directory"])/"workspace.zip") as z:
            self.assertIn(f"<!-- SAMERO TASK {rid} 2 -->",z.read("PROJECT_STATUS.md").decode())

    def test_legacy_missing_progress_receipt_backfilled_on_resume(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        home=self.root/"Autonomous"; (home/"require-receipt").touch()
        self.req("exit");self.proc.wait(timeout=15)
        path=self.data/"runs"/(rid+".json"); journal=json.loads(path.read_bytes())
        journal.update(index=1,mode="review",phase="verify",revision=42,reason="Task 1 receipt missing")
        journal["tasks"][0].update(status="PASS",evidence="Historical verified evidence")
        qpath=self.workspace/"TASK_QUEUE.json"; q=json.loads(qpath.read_bytes());q.update(index=1,mode="review",revision=42,tasks=journal["tasks"])
        raw=(json.dumps(q)+"\n").encode();qpath.write_bytes(raw);journal["queueHash"]=hashlib.sha256(raw).hexdigest();path.write_text(json.dumps(journal))
        self.launch(); self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"] or r["mode"] in ("review","blocked") and not r["snapshot"])
        self.assertEqual(r["index"],2,r["reason"])
        self.req("runner-stop",ctl);self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        status=(self.workspace/"PROJECT_STATUS.md").read_text()
        self.assertIn("Original notes.",status); self.assertIn("Historical verified evidence",status)
        self.assertIn("not recorded in legacy journal",status)
        self.assertEqual(status.count(f"<!-- SAMERO TASK {rid} 1 -->"),1)
        self.assertFalse((self.workspace/"actions.txt").exists())

    def test_legacy_revision49_historical_ledger_recovers_task2(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        home=self.root/"Autonomous"; (home/"require-ledger").touch()
        path=self.data/"runs"/(rid+".json"); qpath=self.workspace/"TASK_QUEUE.json"
        q=json.loads(qpath.read_bytes());q.update(mode="active",phase="work",revision=19,attempt=0)
        qpath.write_text(json.dumps(q)); before=self.req("checkpoint-backup",{"project":ctl["project"],"quiet":True})
        (self.workspace/"history-artifact.txt").write_text("recorded after task start")
        q.update(mode="blocked",phase="verify",revision=22,attempt=1,reason="original failure")
        qpath.write_text(json.dumps(q)); self.req("checkpoint-backup",{"project":ctl["project"],"quiet":True})
        q.update(index=1,mode="review",phase="verify",revision=42,reason="Task 1 PASS, Task 2 needs receipt")
        q["tasks"][0].update(status="PASS",evidence="Task 1 validated by old Manager")
        qpath.write_text(json.dumps(q)); after=self.req("checkpoint-backup",{"project":ctl["project"],"quiet":True})
        self.req("exit");self.proc.wait(timeout=15)
        q.update(revision=49,phase="test",reason="Missing files, errors and checkpoint in Task 1",test="PASS")
        raw=(json.dumps(q)+"\n").encode();qpath.write_bytes(raw)
        journal=json.loads(path.read_bytes());journal.update(q);journal["queueHash"]=hashlib.sha256(raw).hexdigest();path.write_text(json.dumps(journal))
        self.launch();self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"] or r["mode"] in ("review","blocked") and not r["snapshot"])
        self.assertEqual(r["index"],2,r["reason"])
        t=r["tasks"][0];self.assertEqual(t["checkpoint"],after["id"]);self.assertEqual(t["baselineCheckpoint"],before["id"])
        self.assertEqual(t["checkpointKind"],"HISTORICAL OBSERVATION");self.assertEqual(t["errorsStatus"],"PARTIAL")
        self.assertIn("added: history-artifact.txt",t["changedFiles"]);self.assertIn("original failure",t["errors"])
        self.assertTrue(t["recoveryCheckpoint"]);self.assertEqual(t["evidence"],"Task 1 validated by old Manager")
        self.assertFalse((self.workspace/"actions.txt").exists());self.req("runner-stop",ctl)
        self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        self.req("exit");self.proc.wait(timeout=15);self.launch()
        restored=self.run_state(rid);self.assertEqual(restored["tasks"][0],t)

    def seed_revision61_legacy_criteria(self, variant=False):
        rid,ctl,_=self.seed_legacy_run(0,2)
        self.req("exit"); self.proc.wait(timeout=15)
        path=self.data/"runs"/(rid+".json"); qpath=self.workspace/"TASK_QUEUE.json"
        journal=json.loads(path.read_bytes()); q=json.loads(qpath.read_bytes())
        criteria=[{'title': 'Chốt mốc tiếp quản từ hai cây mã nguồn', 'accept': 'Đối chiếu đủ 24 mục đặc tả và 175 tham chiếu tệp với bằng chứng. Xác minh snapshot trước hợp nhất: Workspace 0.3.0-dev, Downloads 0.4.1-dev, cả hai thiếu .git. Kiểm tra SHA-256 ZIP, EXE và HTML khớp manifest. Xác minh queue 0/0 tại pha plan qua nhật ký lịch sử, không yêu cầu queue hiện tại rỗng. Phân biệt kết quả test/build lịch sử với kết quả phiên hiện tại; không đánh dấu PASS khi thiếu bằng chứng.', 'after': -1}, {'title': 'Sao lưu và đưa phần mã mới nhất vào workspace an toàn', 'accept': 'Trước lần sửa đầu, có snapshot hai cây và thử khôi phục khớp SHA-256. Dùng 0.4.1-dev làm nền, đối chiếu từng tệp khác biệt, giữ đặc tả, queue, bàn giao, dữ liệu và sửa đổi riêng của workspace. Sau mỗi tác vụ, PROJECT_STATUS.md và TASK_QUEUE.json ghi tệp sửa, quyết định, lệnh, kết quả, lỗi và checkpoint khôi phục được. Chỉ tự chuyển bước khi mọi bước trước PASS. STOP giữ nguyên điểm tiếp tục.', 'after': 0}, {'title': 'Tái kiểm chứng bản nền, sửa lỗi cốt lõi và đối chiếu công cụ tham chiếu', 'accept': 'npm.cmd test, build, test:browser và kiểm thử gói Windows có log gắn với đúng phiên bản. Lỗi nghiêm trọng tái hiện được có test hồi quy PASS. Ma trận đặc tả dẫn tới thao tác Studio, mã và bằng chứng. Quyết định kỹ thuật dẫn nguồn đã kiểm tra cho AnimaKit, Spine, Aseprite, Adobe Animate, Moho, Cubism và thư viện IK/mesh, ghi giấy phép và phạm vi chưa xác minh.', 'after': 1}, {'title': 'Hoàn thiện nhập ảnh, Canvas và chỉnh layer có hoàn tác', 'accept': 'Kéo thả và mở tệp qua menu đều qua test với PNG thiếu MIME, alpha thấp, nền đặc, WebP, sprite nhỏ, sheet, chuỗi ảnh, GIF, Aseprite và PSD nhiều layer trong phạm vi hỗ trợ. So pixel Canvas sau Fit, zoom, pan, đổi opacity, scale, pivot và ẩn/hiện layer. Grid sai hoặc tệp hỏng báo lỗi và giữ dự án đang mở. Hoàn tác xóa nền, vật thể hoặc sửa viền khôi phục đúng RGBA gốc.', 'after': 2}, {'title': 'Lập bộ tranh đánh giá và kiểm chứng bốn mô hình hiện có', 'accept': 'Bộ tranh có quyền sử dụng, nhãn khớp, mask, góc nhìn và tiếp đất, tách tập theo nhân vật. Tái chạy pipeline tiền xử lý, train, validation và inference trong bản sao. Ghi phiên bản, seed, hash trọng số, PCK, IoU, sai số pose và độ đúng prompt riêng cho dữ liệu thật và tổng hợp. Đánh giá mô hình có sẵn, fine-tuning và chuyển ảnh sang Pixel Art. Hạng mục thiếu dữ liệu hoặc tài nguyên ghi rõ giới hạn.', 'after': 3}, {'title': 'Hoàn thiện phân tích nhân vật, phân đoạn và xử lý vùng khuất', 'accept': 'Trên tranh giữ lại, đối chiếu loại nhân vật, năm góc nhìn, pose, silhouette và mask với nhãn. Có ca người, chibi, thú, robot, sinh vật có cánh, tóc dài, áo choàng và phụ kiện. Studio cho xem, sửa, hoàn tác mask và layer theo bộ phận hoặc vùng màu. Vùng khuất suy đoán nằm ở layer riêng chờ duyệt. Gợi ý rig và chuyển động phản ánh bộ phận hiện diện và nêu rõ điểm chưa chắc chắn.', 'after': 4}, {'title': 'Hoàn thiện Auto Rig theo cấu trúc và kiểm tra biến dạng trên tranh thật', 'accept': 'Rig người, bốn chân và nhân vật có bộ phận phụ tạo đúng cây xương theo nhãn đã duyệt. Test kiểm cha con, đối xứng, pivot, giới hạn khớp, IK/FK, tổng trọng số bằng 1 và mesh ở pose nghỉ/cực trị. Kéo sửa xương, weight và chuỗi tóc, vải, đuôi, cánh, phụ kiện trong Studio rồi mở lại đúng kết quả. Retarget chạy trên rig tương thích và báo rõ khớp thiếu. Có clip thực tế để duyệt biến dạng.', 'after': 5}, {'title': 'Sửa chuyển động tự nhiên và kiểm tra tiếp đất sau retarget', 'accept': 'Trên nhiều tỷ lệ cơ thể và góc nhìn, đo giao chéo chân, trượt bàn chân khi trụ, góc gối, dịch trọng tâm, phối hợp tay chân và sai lệch tại điểm nối vòng trước/sau retarget. Idle, Walk, Run, Jump và Attack đạt ngưỡng ghi trước cho từng mẫu. Duyệt clip phát ở tốc độ thật và ảnh liên tiếp để phát hiện chạy xổm, xoắn mesh, mất thăng bằng hoặc giật khi nội suy, easing và blend.', 'after': 6}, {'title': 'Hoàn thiện sinh clip chỉnh sửa được từ prompt Việt và Anh', 'accept': 'Bảng ca thử phủ toàn bộ hành động cơ bản, chiến đấu và chuyển động phụ ở mục 8, gồm Fall, Land, Turn, Combo, Dodge và Block. Prompt, template, keyframe, pose tham chiếu và clip có sẵn tạo đúng track cho rig. Kiểm hướng, tốc độ, cường độ, thời lượng, FPS, tính liên tục và loop. Gợi ý loại hành động thiếu bộ phận. Mỗi clip sửa được trên Timeline và ghi rõ nguồn quy tắc, template, suy luận hoặc mô hình đã train.', 'after': 7}, {'title': 'Hoàn thiện skin, thay trang phục và bake chuyển động phụ', 'accept': 'Đổi màu từng vùng và thay tóc, đồ, phụ kiện, vũ khí trên ít nhất hai skin. Đối chiếu alpha, bóng, highlight, viền và palette sau lưu/mở. Thay bộ phận giữ đúng liên kết hoặc chỉ ra xương cần gắn lại. Chuỗi tóc, áo choàng, váy, đuôi và phụ kiện phản ứng ổn định khi chỉnh damping, stiffness, trọng lực và constraint. So pose mô phỏng với key đã bake sau xuất và mở lại.', 'after': 8}, {'title': 'Hoàn thiện Pixel Art Studio và xuất sprite nhiều hướng', 'accept': 'Trên sprite 32×32, 48×48, 64×64 và kích thước tùy chọn, kiểm RGBA sau pencil, eraser, fill, selection, picker, outline, đổi palette và undo. Grid, onion skin, layer, sheet editor và chỉnh từng frame hoạt động qua UI. Với bộ ảnh tham chiếu 4/8 hướng, xuất hàng loạt rồi đọc lại đúng hướng, thứ tự, kích thước, timing và màu. Zoom nguyên lần giữ biên pixel sắc nét.', 'after': 9}, {'title': 'Hoàn thiện Timeline, đường cong và thư viện pose', 'accept': 'Từ Studio, sửa riêng các clip Idle, Walk, Run, Attack. Thêm, dời, sao chép, dán và xóa key hoặc frame. Chỉnh bone, layer, graph/curve, easing, FPS, thời lượng và loop. Lưu rồi áp lại pose, blend hai clip và chạy undo/redo. Giá trị track, pose ở frame trung gian, preview và dữ liệu mở lại khớp mong đợi. Các track và clip ngoài vùng sửa giữ nguyên.', 'after': 10}, {'title': 'Xác minh lưu dự án và trao đổi tệp với công cụ đích', 'accept': 'Dự án cũ và mới mở hai chiều Web ↔ Windows, bảo toàn nhân vật, rig, layer, clip, key, timing, palette, skin và metadata. Đọc PNG, sequence, WebP, GIF, sheet/JSON bằng bộ đọc độc lập. Đối chiếu Aseprite về pixel, tag, timing và Spine về atlas, xương, mesh, pose. Ghi riêng kết quả LibreSprite, Spine runtime và editor chính thức theo phiên bản. Chỉ công bố phạm vi tương thích đã mở và so được.', 'after': 11}, {'title': 'Kiểm tra giao diện dùng chung, hiệu năng và khôi phục sự cố', 'accept': 'Web và Electron nạp cùng HTML/engine. Kiểm bố cục tối, Canvas, panel, Timeline và thao tác thật ở nhiều cỡ cửa sổ/DPI. Trên cảnh lớn, ghi máy thử, CPU, RAM, GPU nếu dùng, thời gian nhập, inference và thời gian mỗi frame. Khi xử lý nền, UI vẫn nhận thao tác hủy. Test timeout, dữ liệu lỗi, mở/đóng lặp và ép ngắt tiến trình xác nhận giải phóng tài nguyên và khôi phục lần lưu hợp lệ.', 'after': 12}, {'title': 'Đóng gói và chạy thử Windows x64 portable từ ZIP phát hành', 'accept': 'ZIP mới có manifest SHA-256 cho gói, EXE và HTML, đủ runtime, model, assets và giấy phép. Giải nén trên Windows x64 sạch, ngoại tuyến, mở EXE với sandbox mặc định, không cần bộ công cụ phát triển hay dev server. Chạy luồng nhập PNG/PSD → rig → tạo, sửa, phát clip → lưu → đóng, mở lại → xuất. Đối chiếu ảnh cửa sổ và tệp xuất, lưu log gắn đúng hash của ZIP đã thử.', 'after': 13}, {'title': 'Nghiệm thu toàn bộ đặc tả và lưu checkpoint phát hành', 'accept': 'Từng yêu cầu có PASS, FAIL hoặc NOT VERIFIED kèm mã, lệnh tái hiện, dữ liệu thử và bằng chứng đúng bản phát hành. Rig và motion có duyệt trực quan trên nhân vật thật. Khi còn lỗi, sửa và chạy lại ca lỗi cùng hồi quy liên quan. Nếu bị chặn, lưu nguyên nhân và bước tiếp tục. Chỉ đánh dấu hoàn thành khi mọi tiêu chí bắt buộc PASS, giới hạn có điều kiện đã ghi rõ và checkpoint cuối khôi phục được.', 'after': 14}]
        # Replace only the fixture plan, not the user journal or actual workspace.
        for task,crit in zip(q["tasks"],criteria): task.update(crit)
        if variant: q["tasks"][1]["accept"]+=" Different criterion."
        q.update(index=1,mode="review",phase="verify",attempt=2,revision=61,test="PASS",reason="Missing original command creating TAKEOVER_BASELINE.csv")
        q["tasks"][0].update(status="PASS",evidence="Historical verified fixture evidence",receiptVersion=2,changedFilesStatus="TRUNCATED",errorsStatus="TRUNCATED",changedFileCount=561,errorCount=5)
        raw=(json.dumps(q)+"\n").encode(); qpath.write_bytes(raw); journal.update(q); journal["queueHash"]=hashlib.sha256(raw).hexdigest(); path.write_text(json.dumps(journal))
        old=path.read_bytes()
        home=self.root/"Autonomous"; (home/"legacy-r61").touch()
        self.launch(); return rid,ctl,old,criteria

    def test_revision61_exact_criteria_migration_retests_preserves_plan(self):
        rid,ctl,old,criteria=self.seed_revision61_legacy_criteria()
        self.req("runner-resume",{**ctl,"revision":61})
        r=self.run_state(rid,lambda r:r["index"]==2 or r["mode"] in ("review","blocked") and not r["snapshot"])
        self.assertEqual(r["index"],2,r["reason"])
        self.assertTrue(any(f.read_bytes()==old for f in (self.data/"runrecovery").glob("*.json")))
        self.assertEqual(r["tasks"][0]["accept"],criteria[0]["accept"])
        self.assertEqual(r["tasks"][0]["status"],"PASS")
        self.assertIn("ghi NOT RECORDED cho lệnh gốc mất",r["tasks"][1]["accept"])
        self.assertIn("snapshot hai cây",r["tasks"][1]["accept"])
        self.assertTrue(r["tasks"][1]["testSession"] and r["tasks"][1]["verifySession"])
        self.assertTrue(r["tasks"][1]["commandCount"]>=1)
        self.assertIn("test-run.py",r["tasks"][1]["commands"])
        self.assertEqual([t["accept"] for t in r["tasks"][2:]],[t["accept"] for t in criteria[2:]])
        self.req("runner-stop",ctl); self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        self.req("exit");self.proc.wait(timeout=15);self.launch(); self.assertEqual(self.run_state(rid)["index"],2)

    def test_revision61_migration_cannot_waive_missing_deliverables(self):
        rid,ctl,old,_=self.seed_revision61_legacy_criteria()
        (self.root/"Autonomous"/"legacy-missing-deliverable").touch()
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual(r["index"],1); self.assertIn("Actual backup",r["reason"])
        self.assertEqual(r["tasks"][1]["status"],"NOT VERIFIED")

    def test_revision61_different_criterion_not_silently_rewritten(self):
        rid,ctl,old,criteria=self.seed_revision61_legacy_criteria(variant=True)
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual(r["index"],1)
        self.assertEqual(r["tasks"][1]["accept"],criteria[1]["accept"]+" Different criterion.")

    def test_runner_long_escaped_prompt_preserves_criterion_and_contract(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"long-criteria").touch(); (home/"long-review-once").touch()
        cmd["goal"]="Long goal "+'"'*1190
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",1),r["reason"])
        calls=[json.loads(l) for l in (home/"rpc.jsonl").read_text().splitlines()]
        turns=[x for x in calls if x.get("method")=="turn/start"]
        verify=[x["params"]["input"][0]["text"] for x in turns if x["params"]["input"][0]["text"].startswith("SAMERO VERIFY")]
        self.assertEqual(len(verify),2)
        for prompt in verify:
            self.assertIn(r["tasks"][0]["accept"],prompt)
            self.assertTrue(prompt.endswith("max 600 UTF-8 bytes)."))
        self.assertIn(cmd["goal"],turns[0]["params"]["input"][0]["text"])

    def test_independent_review_probe_rechecks_once_without_user_resume(self):
        cmd=self.runner_fixture(); (self.root/"Autonomous"/"review-once").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        self.assertEqual(r["tasks"][0]["reviewProbe"],1)
        calls=[json.loads(l) for l in (self.root/"Autonomous"/"rpc.jsonl").read_text().splitlines()]
        prompts=[x["params"]["input"][0]["text"] for x in calls if x.get("method")=="turn/start"]
        self.assertEqual(sum(t.startswith("SAMERO VERIFY") and "Task 1:" in t for t in prompts),2)
        self.assertEqual(sum(t.startswith("SAMERO WORK") and "Task 1:" in t for t in prompts),1)

    def test_preflight_denied_stops_before_verify_and_resume_recovers(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"; (home/"preflight-denied").touch()
        rid=self.req("runner-start",cmd)["id"];ctl={"project":cmd["project"],"id":rid,"confirmed":True}
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["phase"],r["blocker"]),(0,"verify","BLOCKED_ACCESS"))
        self.assertIn("TASK_QUEUE.json",r["reason"])
        sid=r["tasks"][0]["testSession"]
        self.assertTrue(sid)
        msgs=[json.loads(x) for x in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertFalse(any(x.get("method")=="turn/start" and x["params"]["input"][0]["text"].startswith("SAMERO VERIFY.") for x in msgs))
        (home/"preflight-denied").unlink()
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        self.assertEqual(r["tasks"][0]["testSession"],sid)

    def test_local_access_diagnostics_are_read_only_and_distinguish_host_from_codex(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"; (home/"preflight-denied").touch()
        rid=self.req("runner-start",cmd)["id"];ctl={"project":cmd["project"],"id":rid,"confirmed":True}
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        q=self.workspace/"TASK_QUEUE.json"; before=q.read_bytes()
        report=self.req("runner-access",ctl)
        self.assertTrue(report["hostReadable"]);self.assertEqual(report["codexBlocker"],"BLOCKED_ACCESS")
        self.assertEqual(report["revision"],r["revision"]);self.assertEqual(before,q.read_bytes())
        self.req("runner-access",ctl,key="bad",expected=403)
        q.unlink(); report=self.req("runner-access",ctl)
        self.assertFalse(report["hostReadable"]);self.assertEqual(report["files"][0]["status"],"MISSING")
        self.req("runner-resume",ctl,expected=409)
        self.assertEqual(self.run_state(rid)["revision"],r["revision"])
        if os.name!="nt":
            q.symlink_to(self.workspace/".env");report=self.req("runner-access",ctl)
            self.assertEqual(report["files"][0]["status"],"UNSAFE_TYPE");q.unlink()
        q.write_bytes(before)
        self.assertTrue(self.req("runner-access",ctl)["hostReadable"])

    def test_preflight_unsupported_does_not_fake_verification(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"; (home/"preflight-unsupported").touch(); (home/"blocked-access").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["phase"],r["blocker"]),(0,"verify","BLOCKED_PREFLIGHT"))
        self.assertFalse(r["tasks"][0]["verifySession"])
        self.assertIn("chưa xác nhận",r["reason"])

    def test_resume_access_blocker_reuses_matching_test(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"blocked-access").touch()
        rid=self.req("runner-start",cmd)["id"]; ctl={"project":cmd["project"],"id":rid,"confirmed":True}
        def held():return self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        r=held(); sid=r["tasks"][0]["testSession"]
        self.assertTrue(sid and r["tasks"][0]["testSignature"])
        self.assertEqual((r["index"],r["blocker"],r["tasks"][0]["reviewProbe"]),(0,"BLOCKED_VERIFY",0))
        self.assertIn("App Server đã đọc được",r["reason"])
        self.req("exit"); self.proc.wait(timeout=15); self.launch()
        self.req("runner-resume",ctl); r=held()
        self.assertEqual(r["tasks"][0]["testSession"],sid)
        self.assertEqual(r["index"],0)
        (home/"blocked-access").unlink()
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        self.assertEqual(r["tasks"][0]["testSession"],sid)

    def test_handover_access_blocker_retests_changed_workspace(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"blocked-access").touch()
        target=self.add_profile("Destination"); (self.root/"Destination"/"auto-fixture").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        sid=r["tasks"][0]["testSession"]
        (self.workspace/"changed-input.txt").write_text("new input after test")
        self.req("runner-handover",{"project":cmd["project"],"id":rid,"confirmed":True,"destination":target})
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"],r["profile"]),("done",2,target),r["reason"])
        self.assertNotEqual(r["tasks"][0]["testSession"],sid)
        self.assertEqual(self.session(r["tasks"][0]["testSession"])["exitCode"],0)

    def test_unrelated_command_failure_does_not_confirm_access_denial(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"blocked-access").touch(); (home/"unrelated-failure").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_VERIFY"))
        self.assertFalse(r["tasks"][0]["verifySession"])

    def verify_case(self,case):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"verify-case").write_text(case)
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("review","blocked","done") and not r["snapshot"])
        t=r["tasks"][0]
        self.assertEqual((r["index"],r["phase"],t["status"],t["verifySession"]),(0,"verify","NOT VERIFIED",""))
        return r,t

    def test_preexecution_denial_has_error_without_child_exit(self):
        r,t=self.verify_case("early-denial")
        self.assertEqual(r["blocker"],"BLOCKED_ACCESS")
        for token in ("commandResults=0;","execCalls=1;","execOutputs=1;","earlyErrors=1;","errors=1;","denials=1;","rollout=complete;"):
            self.assertIn(token,t["verifyObservation"])
        self.assertNotIn("fixture-private-command",json.dumps(t))

    def test_verify_recovers_rollout_created_after_thread_start(self):
        run,task=self.verify_case("late-rollout")
        self.assertEqual(run["blocker"],"BLOCKED_ACCESS")
        for item in ("execCalls=1;", "earlyErrors=1;", "denials=1;", "rollout=complete;"):
            self.assertIn(item,task["verifyObservation"])

    def test_failed_verify_saves_observed_tool_error_without_final_answer(self):
        run,task=self.verify_case("failed-with-tool-error")
        self.assertEqual(run["blocker"],"BLOCKED_ACCESS")
        for item in ("preflight=READ_OK;", "commandResults=0;", "earlyErrors=1;", "denials=1;"):
            self.assertIn(item,task["verifyObservation"])

    def test_verify_with_incomplete_bound_history_cannot_pass(self):
        run,task=self.verify_case("incomplete-with-success")
        self.assertEqual(run["blocker"],"BLOCKED_VERIFY")
        self.assertIn("commandResults=1;",task["verifyObservation"])
        self.assertIn("rollout=partial;",task["verifyObservation"])

    def test_foreign_rollout_turn_cannot_corroborate_denial(self):
        r,t=self.verify_case("old-turn")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("denials=0;",t["verifyObservation"])

    def test_raw_process_error_is_not_automatically_access_denial(self):
        r,t=self.verify_case("raw-other-error")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("earlyErrors=1;",t["verifyObservation"])
        self.assertIn("denials=0;",t["verifyObservation"])

    def test_quoted_denial_in_stdout_is_not_a_tool_denial(self):
        r,t=self.verify_case("quoted-output")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("earlyErrors=0;",t["verifyObservation"])

    def test_empty_positive_and_foreign_events_cannot_pass(self):
        r,t=self.verify_case("no-tools")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("commandResults=0;",t["verifyObservation"])
        self.assertEqual(t["reviewProbe"],0)

    def test_foreign_turn_start_cannot_replace_current_turn(self):
        r,t=self.verify_case("foreign-start")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("successfulResults=0;",t["verifyObservation"])

    def test_invalid_json_invalidates_positive_evidence(self):
        r,t=self.verify_case("bad-json")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("partial=1",t["verifyObservation"])

    def test_image_path_is_not_successful_read_evidence(self):
        r,t=self.verify_case("image-path-only")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("successfulResults=0;",t["verifyObservation"])

    def test_dynamic_tool_missing_success_is_not_evidence(self):
        r,t=self.verify_case("dynamic-no-success")
        self.assertEqual(r["blocker"],"BLOCKED_VERIFY")
        self.assertIn("successfulResults=0;",t["verifyObservation"])

    def test_observed_denial_cannot_be_overridden_by_positive_claim(self):
        r,t=self.verify_case("denial-plus-success")
        self.assertEqual(r["blocker"],"BLOCKED_ACCESS")
        self.assertIn("denials=1;",t["verifyObservation"])

    def test_early_denial_with_success_cannot_pass(self):
        r,t=self.verify_case("early-denial-plus-success")
        self.assertEqual(r["blocker"],"BLOCKED_ACCESS")
        self.assertIn("earlyErrors=1;",t["verifyObservation"])
        self.assertIn("successfulResults=1;",t["verifyObservation"])

    def test_mcp_failure_is_not_a_shell_exit(self):
        r,t=self.verify_case("mcp-error")
        self.assertEqual(r["blocker"],"BLOCKED_ACCESS")
        for token in ("started=1;","commandResults=0;","otherToolResults=1;","errors=1;","denials=1;"):
            self.assertIn(token,t["verifyObservation"])

    def test_windows_readiness_stops_before_verify(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous";(home/"windows-readiness").write_text("notConfigured")
        rid=self.req("runner-start",cmd)["id"];ctl={"id":rid,"project":cmd["project"],"confirmed":True}
        def held():return self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        r=held();self.assertIn("notConfigured",r["reason"]);sid=r["tasks"][0]["testSession"]
        (home/"windows-readiness").write_text("updateRequired")
        self.req("runner-resume",ctl);r=held();self.assertIn("updateRequired",r["reason"])
        packets=[json.loads(line) for line in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertFalse(any(p["method"] in ("command/exec","windowsSandbox/setupStart") or (p["method"]=="turn/start" and p["params"]["input"][0]["text"].startswith("SAMERO VERIFY.")) for p in packets))
        self.assertEqual(r["tasks"][0]["testSession"],sid)
        (home/"windows-readiness").write_text("ready")
        self.req("runner-resume",ctl)
        self.assertEqual(self.run_state(rid,lambda r:r["mode"]=="done")["index"],2)

    def test_task5_denial_preserves_four_receipts_on_restart(self):
        script="from pathlib import Path\nfor p in Path('.').glob('unit-*.txt'):\n assert p.read_text()=='complete'\n p.with_name(p.name.replace('unit-','test-')).write_text('verified')\n"
        cmd=self.runner_fixture(script);home=self.root/"Autonomous"
        (home/"sixteen").touch();(home/"all-sixteen").touch();(home/"verify-case").write_text("revision152")
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        def snapshot(run):
            return [(t["status"],t["checkpoint"],t["testSession"],t["verifySession"]) for t in run["tasks"]]
        before=snapshot(r)
        self.assertEqual((len(before),r["index"],r["blocker"]),(16,4,"BLOCKED_ACCESS"))
        self.assertTrue(all(status=="PASS" and checkpoint and test and verify for status,checkpoint,test,verify in before[:4]))
        self.assertEqual(before[4][0],"NOT VERIFIED");self.assertFalse(before[4][3])
        self.req("exit");self.proc.wait(timeout=15);self.launch()
        resumed=self.run_state(rid)
        self.assertEqual(snapshot(resumed),before)
        self.assertEqual(resumed["tasks"][4]["verifyObservation"],r["tasks"][4]["verifyObservation"])
        packets=[json.loads(line) for line in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertEqual(sum(p["method"]=="turn/start" and p["params"]["input"][0]["text"].startswith("SAMERO VERIFY.") and "Task 5:" in p["params"]["input"][0]["text"] for p in packets),1)

    def test_actual_command_denial_remains_blocked(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"blocked-access").touch(); (home/"observed-denial").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_ACCESS"))
        self.assertFalse(r["tasks"][0]["verifySession"])

    def test_preflight_directory_denial_stops_before_verify(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"preflight-list-denied").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_ACCESS"))
        self.assertIn("directory listing",r["reason"])
        self.assertFalse(r["tasks"][0]["verifySession"])
        msgs=[json.loads(x) for x in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertFalse(any(x.get("method")=="turn/start" and x["params"]["input"][0]["text"].startswith("SAMERO VERIFY.") for x in msgs))

    def test_latest_command_survives_full_preview(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"
        for name in ("fill-command-preview","blocked-access","unrelated-failure"): (home/name).touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_VERIFY"))
        task=r["tasks"][0]
        self.assertIn("fixture-read",task["commands"])
        self.assertEqual(task["commandsStatus"],"PARTIAL")
        self.assertNotIn("fixture-fill-0 ",task["commands"])
        self.assertIn("commandResults=17;",task["verifyObservation"])
        self.assertIn("errors=1;",task["verifyObservation"])
        self.assertFalse(task["verifySession"])

    def test_preflight_rpc_policy_refusal_preserves_checkpoint(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"; (home/"preflight-policy-denied").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_ACCESS"))
        self.assertTrue(r["tasks"][0]["testSession"])
        self.assertFalse(r["tasks"][0]["verifySession"])
        self.assertNotIn("command/exec:",r["tasks"][0]["commands"])
        self.assertIn("exit NOT RECORDED",r["reason"])
        msgs=[json.loads(x) for x in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertFalse(any(x.get("method")=="turn/start" and x["params"]["input"][0]["text"].startswith("SAMERO VERIFY.") for x in msgs))

    def test_turn_policy_refusal_preserves_checkpoint(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"; (home/"turn-policy-denied").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"]),(0,"BLOCKED_ACCESS"))
        self.assertTrue(r["tasks"][0]["testSession"])
        self.assertFalse(r["tasks"][0]["verifySession"])
        self.assertEqual(r["tasks"][0]["status"],"NOT VERIFIED")

    def test_reported_resource_blocker_never_passes(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"blocked-resource").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["blocker"],r["tasks"][0]["reviewProbe"]),(0,"BLOCKED_RESOURCE",0))
        self.assertEqual(r["tasks"][0]["status"],"NOT VERIFIED")
        self.assertFalse(r["tasks"][0]["verifySession"])
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),1)

    def test_command_receipt_observed_and_redacted(self):
        cmd=self.runner_fixture(); (self.root/"Autonomous"/"emit-commands").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        for task in r["tasks"]:
            self.assertGreaterEqual(task["commandCount"],3)
            self.assertIn("fixture-check --safe",task["commands"])
            self.assertIn("test-run.py",task["commands"])
            self.assertEqual(task["commandsStatus"],"PARTIAL")
            self.assertNotIn("HIDDEN_FIXTURE_VALUE",task["commands"])
        status=(self.workspace/"PROJECT_STATUS.md").read_text()
        self.assertIn("SAMERO COMMANDS V1",status); self.assertNotIn("HIDDEN_FIXTURE_VALUE",status)
        self.req("exit");self.proc.wait(timeout=15);self.launch()
        self.assertEqual(self.run_state(rid)["tasks"],r["tasks"])

    def test_new_ledger_records_actual_changes_and_failures(self):
        cmd=self.runner_fixture("from pathlib import Path\nif not Path('first-test').exists():\n Path('first-test').touch(); raise SystemExit(7)\nassert 'return 0' in Path('main.c').read_text()\n")
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        a,b=r["tasks"]
        for t in (a,b):
            self.assertEqual(t["receiptVersion"],2); self.assertEqual(t["checkpointKind"],"ACCEPTANCE")
            self.assertEqual(t["changedFilesStatus"],"RECORDED");self.assertTrue(t["baselineCheckpoint"]);self.assertTrue(t["checkpoint"])
            self.assertEqual(self.session(t["testSession"])["exitCode"],0)
            self.req("checkpoint-verify",{"id":t["checkpoint"]})
        self.assertIn("added: main.c",a["changedFiles"]);self.assertIn("added: notes.md",b["changedFiles"])
        self.assertIn("mã thoát 7",a["errors"]);self.assertGreaterEqual(a["errorCount"],1)
        self.assertNotIn("TASK_QUEUE.json",a["changedFiles"]);self.assertEqual(b["errorsStatus"],"RECORDED")
        status=(self.workspace/"PROJECT_STATUS.md").read_text()
        self.assertIn("SAMERO RECEIPT V2",status);self.assertIn(a["checkpoint"],status)

    def test_recoverable_evidence_repaired_without_manual_resume(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        (self.root/"Autonomous"/"require-repairable-report").touch()
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"] or r["mode"] in ("review","blocked") and not r["snapshot"])
        self.assertEqual(r["index"],2,r["reason"])
        self.assertTrue((self.workspace/"audit-report.md").exists());self.assertIn("Missing recoverable audit report",r["tasks"][1]["errors"])
        self.req("runner-stop",ctl);self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])

    def test_recoverable_disconnect_and_invalid_readonly_response(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"
        (home/"drop-work-once").touch(); (home/"invalid-verify-once").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["index"]),("done",2),r["reason"])
        self.assertEqual(r["tasks"][0]["workRecoveries"],1)
        self.assertIn("Mất kết nối",r["tasks"][0]["errors"])
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),2)

    def test_tampered_history_is_not_used_to_invent_file_changes(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        path=self.data/"runs"/(rid+".json"); qpath=self.workspace/"TASK_QUEUE.json"
        q=json.loads(qpath.read_bytes());q.update(mode="active",phase="work",revision=19,attempt=0)
        qpath.write_text(json.dumps(q));before=self.req("checkpoint-backup",{"project":ctl["project"],"quiet":True})
        (Path(before["directory"])/"MANIFEST.json").write_text('{}')
        q.update(index=1,mode="review",phase="test",revision=49,reason="legacy receipt missing")
        q["tasks"][0].update(status="PASS",evidence="Task 1 accepted")
        raw=(json.dumps(q)+"\n").encode();qpath.write_bytes(raw)
        self.req("exit");self.proc.wait(timeout=15)
        journal=json.loads(path.read_bytes());journal.update(q);journal["queueHash"]=hashlib.sha256(raw).hexdigest();path.write_text(json.dumps(journal))
        self.launch();self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"] or r["mode"] in ("review","blocked") and not r["snapshot"])
        self.assertEqual(r["index"],2,r["reason"])
        t=r["tasks"][0];self.assertEqual(t["changedFilesStatus"],"NOT RECORDED");self.assertEqual(t["changedFiles"],"");self.assertEqual(t["baselineCheckpoint"],"")
        self.assertNotEqual(t["checkpoint"],before["id"]);self.assertTrue(t["recoveryCheckpoint"])
        self.req("runner-stop",ctl);self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])

    def test_state_ignores_transient_metadata_temp_files(self):
        p=self.req("project-save",{"name":"Race","path":str(self.workspace)})["id"]
        done=threading.Event(); errors=[]
        def churn():
            try:
                while not done.is_set():
                    for _ in range(24):
                        t=self.data/"checkpoints"/(uuid.uuid4().hex+".json."+uuid.uuid4().hex+".tmp")
                        t.write_text("temporary")
                        t.unlink()
            except Exception as e:errors.append(e)
        thread=threading.Thread(target=churn);thread.start()
        try:
            for _ in range(75):self.assertEqual(self.req("state")["projects"][0]["id"],p)
        finally:done.set();thread.join(10)
        self.assertFalse(errors)
        self.assertFalse(thread.is_alive())

    def test_runner_acceptance_with_real_test_evidence(self):
        script="from pathlib import Path\nfor p in Path('.').glob('unit-*.txt'):\n assert p.read_text() == 'complete'\n Path(p.name.replace('unit-', 'test-')).write_text('verified')\n"
        cmd=self.runner_fixture(script)
        (self.root/"Autonomous"/"sixteen").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:(r["mode"]=="blocked" and not r["snapshot"]) or (r["index"]==2 and r["inflight"] and r["phase"]=="work"))
        self.assertEqual((r["index"],len(r["tasks"])),(2,16),r["reason"])
        self.req("runner-stop",{"project":cmd["project"],"id":rid,"confirmed":True})
        r=self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        q=json.loads((self.workspace/"TASK_QUEUE.json").read_bytes())
        journal=json.loads((self.data/"runs"/(rid+".json")).read_bytes())
        for obj in [q,journal]:
            self.assertEqual((obj["index"],obj["revision"]),(2,r["revision"]))
            for task in obj["tasks"][:2]:
                self.assertEqual(task["status"],"PASS")
                self.assertEqual(self.session(task["testSession"])["exitCode"],0)
                self.assertTrue(task["verifySession"])
        self.assertIn(f"<!-- SAMERO {rid} {r['revision']} -->",(self.workspace/"PROJECT_STATUS.md").read_text())
        ck=next(c for c in self.req("state")["checkpoints"] if c["id"]==r["checkpoint"])
        with zipfile.ZipFile(Path(ck["directory"])/"workspace.zip") as z:
            self.assertEqual(json.loads(z.read("TASK_QUEUE.json")),q)
        self.req("exit");self.proc.wait(timeout=15);self.launch()
        self.assertEqual(self.run_state(rid)["index"],2)

    def seed_legacy_run(self,claimed,implemented,stale=False):
        # Build a self-contained v1.6.1 disk image at revision 18. The model's
        # claims are not used to create test receipts or advance the journal.
        import shutil
        script="from pathlib import Path\nfor p in Path('.').glob('unit-*.txt'):\n assert p.read_text()=='complete'\n Path(p.name.replace('unit-', 'test-')).write_text('verified')\n"
        cmd=self.runner_fixture(script); home=self.root/"Autonomous"; (home/"sixteen").touch()
        self.req("exit"); self.proc.wait(timeout=15)
        rid=uuid.uuid4().hex
        tasks=[{"title":f"Unit {i+1}","accept":"File exists and configured check passes.","after":i-1,
                "evidence":"","status":"NOT VERIFIED"} for i in range(16)]
        if stale:
            tasks[0]["accept"]="File exists and configured check passes; Queue hien co 0 tac vu. Future Release build PASS."
            shutil.rmtree(self.workspace/".git")
        q={"id":rid,"project":cmd["project"],"profile":cmd["profile"],"goal":"Build an executable.",
            "mode":"blocked","phase":"verify","reason":"Đã hết hai lần sửa tự động.","test":"NOT VERIFIED",
            "build":"NOT VERIFIED","index":0,"attempt":2,"revision":18,"at":int(time.time()),"tasks":tasks}
        raw=(json.dumps(q)+"\n").encode()
        journal={**q,"queueHash":hashlib.sha256(raw).hexdigest(),"workspace":str(self.workspace),"home":str(home),
            **{k:cmd[k] for k in ["testExe","testArgs","buildExe","buildArgs"]},"log":[]}
        path=self.data/"runs"/(rid+".json");path.write_text(json.dumps(journal))
        if claimed:
            q["index"]=claimed; q["revision"]=25
            for t in tasks[:claimed]:t.update(status="PASS",evidence="Worker reported PASS")
            raw=(json.dumps(q)+"\n").encode()
        (self.workspace/"TASK_QUEUE.json").write_bytes(raw)
        (self.workspace/"PROJECT_STATUS.md").write_text("Original notes. Task 1 and Task 2 PASS according to worker.\n")
        for n in range(1,implemented+1):(self.workspace/f"unit-{n}.txt").write_text("complete")
        self.launch()
        return rid,{"project":cmd["project"],"id":rid,"confirmed":True},raw

    def test_legacy_revision18_revalidates_without_replaying_accepted_work(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"])
        self.assertGreater(r["revision"],18)
        self.req("runner-stop",ctl)
        self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        calls=[json.loads(l) for l in (self.root/"Autonomous"/"rpc.jsonl").read_text().splitlines()]
        work=[x["params"]["input"][0]["text"] for x in calls if x.get("method")=="turn/start"]
        self.assertFalse(any(t.startswith("SAMERO WORK") and ("Task 1:" in t or "Task 2:" in t) for t in work))
        self.assertEqual(self.example.read_text(),"unstaged state\n")

    def test_legacy_stale_criterion_amendment_preserves_evidence_and_reverifies(self):
        rid,ctl,_=self.seed_legacy_run(0,2,stale=True)
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["attempt"],r["test"]),(0,2,"PASS"))
        self.assertIn("Legacy criterion",r["reason"])
        old=(self.data/"runs"/(rid+".json")).read_bytes()
        body={**ctl,"revision":r["revision"],"taskIndex":0,"accept":"File exists and configured check passes."}
        self.req("runner-amend",{**body,"revision":r["revision"]-1},expected=409)
        self.req("runner-amend",{**body,"taskIndex":1},expected=409)
        self.req("runner-amend",{**body,"confirmed":False},expected=409)
        self.req("runner-amend",body)
        r=self.run_state(rid,lambda r:not r["snapshot"] and r["mode"]=="review")
        self.assertEqual((r["index"],r["attempt"],r["test"]),(0,0,"NOT VERIFIED"))
        self.assertEqual(r["tasks"][0]["status"],"NOT VERIFIED")
        self.assertTrue(any(f.read_bytes()==old for f in (self.data/"runrecovery").glob("*.json")))
        self.assertEqual(r["tasks"][0]["accept"],body["accept"])
        self.req("exit");self.proc.wait(timeout=15);self.launch()
        self.assertEqual(self.run_state(rid)["tasks"][0]["accept"],body["accept"])
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"])
        self.assertEqual(r["tasks"][0]["status"],"PASS")
        self.assertTrue(r["tasks"][0]["testSession"] and r["tasks"][0]["verifySession"])
        self.req("runner-stop",ctl);self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        self.assertFalse((self.workspace/"actions.txt").exists())

    def test_confirmed_amendment_resumes_after_checkpoint(self):
        rid,ctl,_=self.seed_legacy_run(0,2,stale=True)
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        old=(self.data/"runs"/(rid+".json")).read_bytes()
        body={**ctl,"revision":r["revision"],"taskIndex":0,"accept":"File exists and configured check passes.","resumeAfter":True}
        self.req("runner-amend",{**body,"confirmed":False},expected=409)
        self.req("runner-amend",body)
        r=self.run_state(rid,lambda r:r["index"]==2 and r["phase"]=="work" and r["inflight"])
        self.assertTrue(any(f.read_bytes()==old for f in (self.data/"runrecovery").glob("*.json")))
        self.assertTrue(all(t["testSession"] and t["verifySession"] for t in r["tasks"][:2]))
        self.req("runner-stop",ctl)
        self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])

    def test_newer_queue_is_retained_until_evidence_catches_up(self):
        rid,ctl,raw=self.seed_legacy_run(2,1)
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["catchupIndex"]),(1,2))
        self.assertEqual((self.workspace/"TASK_QUEUE.json").read_bytes(),raw)
        self.assertFalse((self.workspace/"actions.txt").exists())
        self.assertTrue(any(f.read_bytes()==raw for f in (self.data/"runrecovery").glob("*.json")))
        self.req("exit"); self.proc.wait(timeout=15); self.launch()
        (self.workspace/"unit-2.txt").write_text("complete")
        self.req("runner-resume",ctl)
        self.run_state(rid,lambda r:r["index"]==2 and r["inflight"] and r["phase"]=="work")
        self.req("runner-stop",ctl); self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        q=json.loads((self.workspace/"TASK_QUEUE.json").read_bytes())
        self.assertEqual(q["index"],2); self.assertGreater(q["revision"],25)
        self.assertTrue(q["tasks"][1]["verifySession"])

    def test_checkpoint_recovers_rolled_back_journal(self):
        cmd=self.runner_fixture();rid=self.req("runner-start",cmd)["id"]
        path=self.data/"runs"/(rid+".json"); old=path.read_bytes()
        complete=self.run_state(rid,lambda r:r["mode"]=="done" and not r["snapshot"])
        self.req("exit");self.proc.wait(timeout=15)
        path.write_bytes(old)
        self.launch();r=self.run_state(rid)
        self.assertEqual((r["mode"],r["index"],r["revision"]),("done",2,complete["revision"]))
        self.assertTrue(any(f.read_bytes()==old for f in (self.data/"runrecovery").glob("*.json")))
        self.assertEqual((self.workspace/"actions.txt").read_text(),"work\nwork\n")

    def test_stale_control_and_concurrent_journal(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        path=self.data/"runs"/(rid+".json")
        self.req("runner-resume",{**ctl,"revision":17},expected=409)
        self.assertEqual(json.loads(path.read_bytes())["revision"],18)
        data=json.loads(path.read_bytes()); data["revision"]=25
        raw=json.dumps(data).encode();path.write_bytes(raw)
        self.req("runner-resume",ctl,expected=409)
        self.assertEqual(path.read_bytes(),raw)
        self.assertTrue(self.req("state")["runnerFault"])
        self.assertFalse((self.workspace/"actions.txt").exists())

    def test_runner_no_progress_and_uncertain_review(self):
        cmd=self.runner_fixture(); home=self.root/"Autonomous"; (home/"unchanged-work").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked" and not r["snapshot"])
        self.assertEqual((r["index"],r["attempt"]),(0,1));self.assertIn("tiến triển",r["reason"])
        (home/"unchanged-work").unlink(); (home/"needs-review").touch()
        self.req("runner-resume",{"id":rid,"project":cmd["project"],"confirmed":True})
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertIn("physical device",r["reason"]);self.assertEqual(r["index"],0)

    def test_runner_uses_final_answer_and_redacts_long_check_output(self):
        script="import sys\nprint('api_key='+'SENSITIVE_SUFFIX'*900)\nprint('SENSITIVE_SUFFIX')\nsys.exit(3)\n"
        cmd=self.runner_fixture(script); (self.root/"Autonomous"/"late-comment").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked" and not r["snapshot"])
        self.assertEqual(r["test"],"FAIL")
        self.assertNotIn("SENSITIVE_SUFFIX",json.dumps(self.req("state")))
        self.assertGreater(len(r["tasks"]),0)

    def test_run_held_if_workspace_changed_during_verification(self):
        cmd=self.runner_fixture();(self.root/"Autonomous"/"change-during-verify").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["phase"]),(0,"test"))
        self.assertEqual(r["tasks"][0]["status"],"NOT VERIFIED")
        self.assertIn("thay đổi",r["reason"])

    def test_readonly_planner_requires_effective_sandbox(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous";(home/"unsafe-plan").touch()
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual(r["phase"],"plan")
        msgs=[json.loads(x) for x in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertFalse(any(m.get("method")=="turn/start" for m in msgs))

    def test_full_sixteen_task_queue(self):
        script="from pathlib import Path\nunits=list(Path('.').glob('unit-*.txt'))\nassert units\nfor p in units:\n assert p.read_text()=='complete'\n Path(p.name.replace('unit-','test-')).write_text('verified')\n"
        cmd=self.runner_fixture(script); home=self.root/"Autonomous"
        (home/"sixteen").touch(); (home/"all-sixteen").touch()
        rid=self.req("runner-start",cmd)["id"]
        def finished():
            r=next(x for x in self.req("state")["runs"] if x["id"]==rid)
            return r if r["mode"] in ("done","blocked","review") and not r["snapshot"] else None
        r=self.eventually(finished,seconds=240)
        self.assertEqual((r["mode"],r["index"],r["test"],r["build"]),("done",16,"PASS","PASS"),r["reason"])
        self.assertEqual(len({t["testSession"] for t in r["tasks"]}),16)
        self.assertEqual(len({t["verifySession"] for t in r["tasks"]}),16)
        self.assertEqual((self.workspace/"actions.txt").read_text(),"work\n"*16)
        self.assertEqual(self.example.read_text(),"unstaged state\n")
        self.assertEqual(self.git("show",":"+self.example.name),b"staged state\n")
        self.assertEqual(subprocess.run([str(self.workspace/"release")]).returncode,0)

    def test_journal_recovery_between_atomic_file_operations(self):
        rid,ctl,_=self.seed_legacy_run(0,2)
        self.req("exit");self.proc.wait(timeout=15)
        path=self.data/"runs"/(rid+".json");park=path.with_suffix(".json.saving")
        original=path.read_bytes();path.rename(park)
        self.launch();self.assertEqual(self.run_state(rid)["revision"],18)
        self.assertEqual(path.read_bytes(),original);self.assertFalse(park.exists())
        self.req("exit");self.proc.wait(timeout=15)
        park.write_bytes(original)
        updated=json.loads(original);updated.update(parentHash=hashlib.sha256(original).hexdigest(),revision=19)
        current=json.dumps(updated).encode();path.write_bytes(current)
        self.launch();self.assertEqual(self.run_state(rid)["revision"],19)
        self.assertEqual(path.read_bytes(),current);self.assertFalse(park.exists())

    def test_auto_resume_waits_for_fresh_quota_without_reset_timestamp(self):
        cmd=self.runner_fixture();home=self.root/"Autonomous"
        self.req("account-refresh",{"profile":cmd["profile"]})
        (home/"quota-unknown-reset").touch()
        rid=self.req("runner-start",{**cmd,"autoResume":True})["id"]
        stopped=self.run_state(rid,lambda r:r["mode"]=="quota")
        self.assertEqual(stopped["limitedAt"],0)
        self.assertTrue(stopped["limitOwner"])
        done=self.run_state(rid,lambda r:r["mode"]=="done" and not r["snapshot"])
        self.assertEqual((done["index"],done["profile"]),(2,cmd["profile"]))

    def test_failed_check_preserves_long_nonsecret_diagnostic(self):
        cmd=self.runner_fixture("print('Precise diagnostic about the missing resource')\nraise SystemExit(9)\n")
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked" and not r["snapshot"])
        self.assertIn("Precise diagnostic about the missing resource",r["reason"])
        self.assertIn("9",r["reason"])

    def test_runner_pipeline(self):
        cmd=self.runner_fixture()
        st=self.workspace/"PROJECT_STATUS.md"
        st.write_text("# Existing notes\nDo not erase.\n")
        rid=self.req("runner-start",cmd)["id"]
        self.req("runner-start",cmd,expected=409)
        r=self.run_state(rid,lambda x:x["mode"] in ("done","blocked","review") and not x["snapshot"])
        self.assertEqual((r["mode"],r["phase"],r["index"],r["test"],r["build"]),("done","finish",2,"PASS","PASS"),r)
        self.assertEqual(subprocess.run([str(self.workspace/"release")]).returncode,0)
        self.assertEqual(json.loads((self.workspace/"TASK_QUEUE.json").read_text())["index"],2)
        self.assertTrue(st.read_text().startswith("# Existing notes\nDo not erase.\n"))
        ck=next(c for c in self.req("state")["checkpoints"] if c["id"]==r["checkpoint"])
        with zipfile.ZipFile(Path(ck["directory"])/"workspace.zip") as z:
            self.assertIn("main.c",z.namelist())
            self.assertNotIn(".env",z.namelist())
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),2)

    def test_runner_foreign_queue_and_unconfigured_checks(self):
        cmd=self.runner_fixture()
        self.req("runner-start",{**cmd,"buildExe":""},expected=409)
        foreign=self.workspace/"TASK_QUEUE.json"; foreign.write_text('{"from":"user"}')
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked")
        self.assertIn("TASK_QUEUE",r["reason"])
        self.assertEqual(foreign.read_text(),'{"from":"user"}')
        self.assertFalse((self.workspace/"actions.txt").exists())

    def test_runner_crash_handover_resume(self):
        cmd=self.runner_fixture()
        (self.root/"Autonomous"/"hold-work").touch()
        target=self.add_profile("Destination")
        (self.root/"Destination"/"auto-fixture").touch()
        rid=self.req("runner-start",cmd)["id"]
        control={"project":cmd["project"],"id":rid,"confirmed":True}
        self.eventually(lambda:(self.workspace/"actions.txt").exists(),seconds=30)
        self.proc.kill(); self.proc.wait(timeout=15)
        for f in ("ui.url","ui.version"):
            (self.data/f).unlink(missing_ok=True)
        self.launch()
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual(r["phase"],"verify")
        self.req("runner-handover",{**control,"destination":target})
        r=self.run_state(rid,lambda r:r["mode"] in ("review","done","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["profile"]),("done",target),r)
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),2)

    def test_runner_stop_and_retry_limit(self):
        cmd=self.runner_fixture("raise SystemExit(11)\n")
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked" and not r["snapshot"])
        self.assertEqual((r["attempt"],r["test"],r["build"]),(2,"FAIL","NOT VERIFIED"),r)
        control={"project":cmd["project"],"id":rid,"confirmed":True}
        self.req("runner-stop",control)
        self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),3)

    def test_runner_quota_pause_and_resume(self):
        cmd=self.runner_fixture()
        (self.root/"Autonomous"/"quota-once").touch()
        rid=self.req("runner-start",{**cmd,"autoResume":True})["id"]
        self.run_state(rid,lambda r:r["mode"]=="quota")
        self.run_state(rid,lambda r:r["mode"]=="active" and r["phase"]=="work")
        ctl={"project":cmd["project"],"id":rid,"confirmed":True}
        self.req("runner-pause",ctl)
        self.run_state(rid,lambda r:r["mode"]=="paused" and not r["inflight"] and not r["snapshot"])
        self.req("runner-resume",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="done" and not r["snapshot"])
        self.assertEqual(r["profile"],cmd["profile"])

    def test_runner_rejects_cycle_and_conflicting_editor(self):
        cmd=self.runner_fixture()
        (self.root/"Autonomous"/"bad-plan").touch()
        rid=self.req("runner-start",cmd)["id"]
        self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertFalse((self.workspace/"actions.txt").exists())
        q=self.workspace/"TASK_QUEUE.json"; q.write_text("edited outside manager")
        self.req("runner-resume",{"project":cmd["project"],"id":rid,"confirmed":True},expected=409)
        self.assertEqual(self.run_state(rid)["mode"],"review")
        self.assertEqual(q.read_text(),"edited outside manager")

    def test_runner_stop_during_write(self):
        cmd=self.runner_fixture()
        hold=self.root/"Autonomous"/"hold-work"; hold.touch()
        rid=self.req("runner-start",cmd)["id"]
        self.eventually(lambda:(self.workspace/"actions.txt").exists(),seconds=24)
        ctl={"project":cmd["project"],"id":rid,"confirmed":True}
        self.req("runner-stop",ctl)
        r=self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"] and r["checkpoint"])
        self.assertEqual(r["phase"],"verify"); hold.unlink()
        self.req("runner-resume",ctl)
        self.run_state(rid,lambda r:r["mode"]=="done" and not r["snapshot"])
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),2)

    def test_runner_reconnects_read_only(self):
        cmd=self.runner_fixture(); (self.root/"Autonomous"/"drop-read-once").touch()
        rid=self.req("runner-start",cmd)["id"]
        self.run_state(rid,lambda r:r["mode"]=="done" and not r["snapshot"])
        self.assertEqual((self.workspace/"actions.txt").read_text().count("work\n"),2)

    def test_runner_release_failure(self):
        cmd=self.runner_fixture()
        rid=self.req("runner-start",{**cmd,"buildExe":"/usr/bin/false","buildArgs":""})["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="blocked" and not r["snapshot"])
        self.assertEqual((r["attempt"],r["test"],r["build"]),(2,"PASS","FAIL"),r)
        self.assertFalse((self.workspace/"release").exists())

    def set_auto_approval(self,value):
        cfg=self.req("state")["settings"]
        self.req("settings-save",{**cfg,"autoApproval":value})
        self.assertIs(self.req("state")["settings"]["autoApproval"],value)

    def test_auto_review_terminal_verifies_effective_config(self):
        import tomllib
        profile=self.add_profile("Terminal")
        p=self.req("project-save",{"name":"Terminal","path":str(self.workspace)})["id"]
        self.set_auto_approval(True)
        scope={"profile":profile,"project":p}
        sid=self.req("session-start",scope)["id"]
        home=self.root/"Terminal"
        trace=home/"seen.json"
        self.eventually(trace.exists)
        args=json.loads(trace.read_text())["args"]
        config=tomllib.loads("\n".join(args[i+1] for i,v in enumerate(args) if v=="-c"))
        self.assertEqual(config["approvals_reviewer"],"auto_review")
        self.assertEqual(config["sandbox_mode"],"workspace-write")
        self.assertEqual(config["approval_policy"]["granular"],{"sandbox_approval":False,"rules":True,
            "mcp_elicitations":False,"skill_approval":False,"request_permissions":False})
        self.assertEqual(config["sandbox_workspace_write"],{"writable_roots":[],"network_access":False,
            "exclude_tmpdir_env_var":True,"exclude_slash_tmp":True})
        self.assertEqual(self.session(sid)["reviewer"],"auto_review")
        self.req("session-stop",{"id":sid,"confirmed":True})
        self.eventually(lambda:self.session(sid)["status"]=="Stopped")
        (home/"invalid-cli-config").touch()
        trace.unlink()
        self.req("session-start",scope,expected=409)
        self.assertFalse(trace.exists())

    def test_auto_review_runner_approved(self):
        cmd=self.runner_fixture()
        self.assertFalse(self.req("state")["settings"]["autoApproval"])
        self.set_auto_approval(True)
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"] in ("done","review","blocked") and not r["snapshot"])
        self.assertEqual((r["mode"],r["test"],r["build"]),("done","PASS","PASS"),r)
        events=self.req("review-history",{"project":cmd["project"]})["events"]
        self.assertEqual([e["status"] for e in events],["approved","approved"])
        self.assertTrue(all(e["source"]=="codex" for e in events))
        self.assertNotIn("NEVER_COPY",json.dumps(events))
        self.assertEqual((self.workspace/"actions.txt").read_text(),"work\nwork\n")

    def test_auto_review_denied_persists_and_never_retries(self):
        cmd=self.runner_fixture(); self.set_auto_approval(True)
        (self.root/"Autonomous"/"review-decision").write_text("denied")
        rid=self.req("runner-start",cmd)["id"]
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertEqual((r["index"],r["phase"],r["attempt"]),(0,"verify",0))
        self.assertIn("Outside granted scope",r["reason"])
        self.assertFalse((self.workspace/"actions.txt").exists())
        self.req("exit"); self.proc.wait(timeout=15); self.launch()
        self.assertTrue(self.req("state")["settings"]["autoApproval"])
        self.assertEqual(self.run_state(rid)["mode"],"review")
        events=self.req("review-history",{"project":cmd["project"]})["events"]
        self.assertEqual([(e["source"],e["status"]) for e in events],[("codex","denied")])
        self.set_auto_approval(False)

    def test_auto_review_bounds_and_resume(self):
        cmd=self.runner_fixture(); self.set_auto_approval(True)
        scope={k:cmd[k] for k in ("project","profile")}; home=self.root/"Autonomous"
        def state():return self.req("chat-state",scope)
        for weak in ["unavailable","outside","network","full","policy"]:
            (home/"weak-review").write_text(weak)
            self.req("chat-open",{**scope,"fresh":True})
            self.eventually(lambda:not state()["active"])
            self.assertFalse(any(json.loads(l).get("method")=="turn/start" for l in (home/"rpc.jsonl").read_text().splitlines()))
        (home/"weak-review").unlink()
        sid=self.req("chat-send",{**scope,"text":"first","requestId":uuid.uuid4().hex})["id"]
        self.eventually(lambda:state()["stage"]=="ready" and self.session(sid).get("chatThread"))
        self.req("chat-close",{**scope,"session":sid}); self.eventually(lambda:not state()["active"])
        self.req("chat-open",scope)
        self.eventually(lambda:state()["stage"]=="ready")
        msgs=[json.loads(l) for l in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertTrue(any(m.get("method")=="thread/resume" and m["params"]["approvalsReviewer"]=="auto_review" for m in msgs))

    def test_auto_review_manual_decline(self):
        cmd=self.runner_fixture(); self.set_auto_approval(True); home=self.root/"Autonomous"
        (home/"review-decision").write_text("manual")
        rid=self.req("runner-start",cmd)["id"]
        p=cmd["project"]
        state=self.eventually(lambda:(s if (s:=self.req("chat-state",{"project":p}))["approvals"] else None),seconds=30)
        self.assertFalse(any(json.loads(l).get("id")=="approval-123" for l in (home/"rpc.jsonl").read_text().splitlines()))
        self.req("chat-approval",{"project":p,"session":state["session"],"id":state["approvals"][0]["id"],"decision":"decline"})
        r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
        self.assertIn("từ chối",r["reason"])
        events=self.req("review-history",{"project":p})["events"]
        self.assertEqual([(e["source"],e["status"]) for e in events],[("user","denied")])

    def test_auto_review_stop_while_waiting(self):
        cmd=self.runner_fixture(); self.set_auto_approval(True)
        (self.root/"Autonomous"/"review-decision").write_text("wait")
        rid=self.req("runner-start",cmd)["id"]; p=cmd["project"]
        self.eventually(lambda:self.req("review-history",{"project":p})["events"],seconds=25)
        self.req("runner-stop",{"project":p,"id":rid,"confirmed":True})
        r=self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])
        self.assertEqual(r["phase"],"verify")
        self.assertFalse((self.workspace/"actions.txt").exists())
        self.assertEqual(self.req("review-history",{"project":p})["events"][-1]["status"],"unconfirmed")

    def test_auto_review_nonapproval_states(self):
        cmd=self.runner_fixture(); self.set_auto_approval(True); p=cmd["project"]
        for scenario in ("timedOut","aborted","unfinished","strict","declined-item","policy-error"):
            (self.root/"Autonomous"/"review-decision").write_text(scenario)
            rid=self.req("runner-start",cmd)["id"]
            r=self.run_state(rid,lambda r:r["mode"]=="review" and not r["snapshot"])
            self.assertEqual((r["phase"],r["index"],r["attempt"]),("verify",0,0),r)
            self.assertFalse((self.workspace/"actions.txt").exists())
            self.req("runner-stop",{"project":p,"id":rid,"confirmed":True})
            self.run_state(rid,lambda r:r["mode"]=="stopped" and not r["snapshot"])

    def test_checkpoint_and_profiles(self):
        self.req("state",key="bad",expected=403)
        self.req("state",origin="http://attacker.invalid",expected=403)
        a,b = self.add_profile("Phiên nguồn"),self.add_profile("Phiên đích",auth_store="file")
        self.req("profile-save",{"name":"Trùng", "home":str(self.root / "Phiên đích" / "."), "cli":str(self.fixture)},expected=409)
        self.assertEqual(self.req("cli-check",{"profile":a})["version"],"codex-cli fixture")
        for profile in (a,b):
            q = self.req("account-refresh",{"profile":profile})
            self.assertEqual((q["h"],q["w"],q["credits"],q["status"]),(78,69,"18.75","Signed in"))
            self.assertNotIn("private",q)
        self.assertNotEqual(*(q["email"] for q in self.req("state")["quota"]))
        self.req("quota-manual",{"profile":b,"h":20,"w":90,"credits":"10.25","creditUnit":"credits",
                                 "creditPool":"independent","source":"manual"})
        self.req("quota-manual",{"profile":b,"h":101,"source":"manual"},expected=409)
        p = self.req("project-save",{"name":"Dự án", "path":str(self.workspace), "next":"Tiếp tục tính năng X", "build":"Đã ghi nhận build xanh"})["id"]
        state = self.req("project-status",{"project":p})
        self.assertEqual(state["branch"],"main")
        self.assertIn({"status":"MM","path":self.example.name},state["changes"])
        s = self.req("session-start",{"profile":a,"project":p})["id"]
        self.eventually(lambda: (self.root / "Phiên nguồn" / "seen.json").exists())
        self.req("session-start",{"profile":b,"project":p},expected=409)
        self.req("checkpoint-backup",{"project":p,"quiet":True},expected=409)
        self.req("session-stop",{"id":s},expected=409)
        self.req("session-stop",{"id":s,"confirmed":True})
        self.eventually(lambda: self.session(s)["status"]=="Stopped")
        payload = {"project":p,"source":s,"destination":b,"quiet":True}
        check = self.req("session-check",{"project":p,"kind":"test","exe":"/bin/true","confirmed":True})["id"]
        self.eventually(lambda: self.session(check)["status"]=="Completed")
        c = self.req("checkpoint-prepare",payload)
        folder = Path(c["directory"])
        archive = folder / "workspace.zip"
        self.assertEqual(hashlib.sha256(archive.read_bytes()).hexdigest(),c["sha256"])
        manifest = json.loads((folder / "MANIFEST.json").read_text(encoding="utf-8"))
        with zipfile.ZipFile(archive) as z:
            self.assertIsNone(z.testzip())
            self.assertEqual(z.read(self.example.name),b"unstaged state\n")
            self.assertEqual(z.read(f".samero-staged/0/{self.example.name}"),b"staged state\n")
            for entry in manifest["files"]:
                if entry["kind"]=="file":
                    self.assertEqual(hashlib.sha256(z.read(entry["path"])).hexdigest(),entry["sha256"])
            self.assertFalse(set(z.namelist()) & {".env","notes.txt","symlink","node_modules/ignored"})
        preview = self.req("checkpoint-preview",{"id":c["id"]})
        self.assertIn("Tiếp tục tính năng X",preview["status"])
        report = json.loads(preview["json"])
        self.assertEqual((report["sourceSession"],report["destinationProfile"]), (s,b))
        self.assertEqual(report["checks"]["test"]["exitCode"],0)
        self.assertIsNone(report["checks"]["build"])
        self.assertEqual(report["checks"]["test"]["session"],check)
        self.assertEqual((Path(c["handoverDir"]) / "PROJECT_STATUS.md").read_text(encoding="utf-8"), preview["status"])
        self.req("checkpoint-verify",{"id":c["id"]})
        self.req("checkpoint-launch",{"id":c["id"],"quiet":True},expected=409)
        self.example.write_text("external edit\n",encoding="utf-8")
        self.req("checkpoint-launch",{"id":c["id"],"quiet":True,"confirmed":True},expected=409)
        self.example.write_text("unstaged state\n",encoding="utf-8")
        result = self.req("checkpoint-launch",{"id":c["id"],"quiet":True,"confirmed":True})
        target_file = self.root / "Phiên đích" / "seen.json"
        self.eventually(target_file.is_file)
        seen = json.loads(target_file.read_text(encoding="utf-8"))
        self.assertEqual(seen["cwd"],str(self.workspace))
        self.assertEqual(seen["home"],str(self.root / "Phiên đích"))
        self.assertIn("cli_auth_credentials_store=\"file\"",seen["args"])
        self.assertIn(c["id"],seen["args"][-1])
        self.assertEqual(self.git("show",":"+self.example.name),b"staged state\n")
        self.assertEqual(self.example.read_text(encoding="utf-8"),"unstaged state\n")
        self.req("session-stop",{"id":result["id"],"confirmed":True})
        self.eventually(lambda: self.session(result["id"])["status"]=="Stopped")
        restored = Path(self.req("checkpoint-restore",{"id":c["id"],"directory":str(self.root),"confirmed":True})["path"])
        self.assertEqual((restored / self.example.name).read_text(encoding="utf-8"),"unstaged state\n")
        self.assertFalse((restored / ".env").exists())
        zip_data = archive.read_bytes()
        archive.write_bytes(zip_data[:-1]+bytes([zip_data[-1]^0xff]))
        self.req("checkpoint-verify",{"id":c["id"]},expected=409)
        archive.write_bytes(zip_data)
        backup = self.req("checkpoint-backup",{"project":p,"quiet":True})
        self.req("checkpoint-verify",{"id":backup["id"]})
        config = self.req("state")["settings"]
        config["theme"]="light"
        self.req("settings-save",config)
        self.req("exit")
        self.proc.wait(timeout=10)
        self.launch()
        reopened = self.req("state")
        self.assertEqual(reopened["settings"]["theme"],"light")
        self.assertEqual(len(reopened["profiles"]),2)
        self.assertEqual(len(reopened["checkpoints"]),2)
        self.assertGreaterEqual(len(reopened["samples"]),3)
        self.req("profile-delete",{"id":b,"confirmed":True})
        self.assertTrue((self.root / "Phiên đích").exists())

    def test_chat_persists_and_hands_over_manually(self):
        with urlopen(f"{self.url}/",timeout=5) as page:
            self.assertIn(b"Workspace",page.read())
        fixture = self.root / "Streaming Codex"
        fixture.write_text(CHAT_FIXTURE,encoding="utf-8")
        fixture.chmod(0o755)
        a = self.add_profile("Codex 1",fixture)
        b = self.add_profile("Codex 2",fixture)
        p = self.req("project-save",{"name":"Chat workspace","path":str(self.workspace),"next":"Bổ sung kiểm thử"})["id"]

        def state(**kwargs):
            return self.req("chat-state",{"project":p,**kwargs})
        def until(status):
            return self.eventually(lambda: (s if (s:=state())["stage"] == status else None))
        def send(text, profile=a, expected=200):
            return self.req("chat-send",{"project":p,"profile":profile,"text":text},expected=expected)
        def action(method, session, **kwargs):
            return self.req(method,{"project":p,"session":session,**kwargs})

        self.assertEqual(state()["stage"],"closed")
        opened=self.req("chat-open",{"project":p,"profile":a})["id"]
        self.assertEqual(until("ready")["messages"],[])
        action("chat-close",opened)
        until("closed")
        send("OPENAI_API_KEY=sk-proj-do-not-store",expected=409)
        first=send("Tiến độ riêng của hồ sơ 1")["id"]
        self.eventually(lambda: state().get("draft","").startswith("Đã xử"))
        ready = until("ready")
        self.assertEqual([m["role"] for m in ready["messages"]],["user","assistant"])
        self.assertEqual(ready["messages"][-1]["text"],"Đã xử lý ở Codex 1")
        self.assertTrue(state(revision=ready["revision"])["unchanged"])
        self.assertTrue(self.session(first)["chatThread"].startswith("thread-"))
        self.assertEqual(ready["model"],"fixture-reported-model")
        self.eventually(lambda: any(q.get("h")==80 and q["profile"]==a for q in self.req("quota-state")["quota"]))
        self.req("session-start",{"project":p,"profile":b},expected=409)
        send("Start elsewhere",b,409)

        send("approve")
        pending=self.eventually(lambda: state()["approvals"])
        self.assertTrue(pending[0]["acceptable"])
        self.assertIn("printf approved",pending[0]["detail"])
        action("chat-approval",first,id=pending[0]["id"],decision="accept")
        until("ready")

        send("hold")
        self.eventually(lambda: state()["canInterrupt"])
        send("hold",expected=409)
        action("chat-interrupt",first)
        interrupted = until("ready")
        self.assertTrue(any("Đã dừng lượt" in m["text"] for m in interrupted["messages"]))

        action("chat-close",first)
        until("closed")
        resumed=send("Tiếp tục trong hồ sơ đang dùng")["id"]
        until("ready")
        trace_a=(self.root / "Codex 1" / "rpc.jsonl").read_text(encoding="utf-8")
        self.assertIn('"method": "thread/resume"',trace_a)
        send("quota")
        limited=until("limited")
        self.assertEqual(limited["profile"],a)
        updated=next(q for q in self.req("quota-state")["quota"] if q["profile"]==a)
        self.assertEqual((updated["h"],updated["w"]),(0,59))
        other_trace=self.root / "Codex 2" / "rpc.jsonl"
        # Idle accounts may receive telemetry. Switching accounts must never start work.
        if other_trace.exists():
            methods={json.loads(line).get("method") for line in other_trace.read_text().splitlines()}
            self.assertLessEqual(methods,{"initialize","initialized","account/read","account/rateLimits/read"})
        send("No direct switching",b,409)
        action("chat-close",resumed)
        until("closed")
        send("Requires a checkpoint",b,409)

        handover = self.req("checkpoint-prepare",{"project":p,"source":resumed,"destination":b,"quiet":True})
        self.req("checkpoint-launch",{"id":handover["id"],"chat":True,"quiet":True},expected=409)
        target=self.req("checkpoint-launch",{"id":handover["id"],"chat":True,"quiet":True,"confirmed":True})["id"]
        target_ready=until("ready")
        self.assertEqual(target_ready["profile"],b)
        self.assertEqual(target_ready["messages"][-1]["text"],"Đã xử lý ở Codex 2")
        self.assertIn("Tiến độ riêng của hồ sơ 1",[m["text"] for m in target_ready["messages"]])
        trace_b=json.loads("[" + ",".join((self.root / "Codex 2" / "rpc.jsonl").read_text(encoding="utf-8").splitlines()) + "]")
        sent=[r["params"]["input"][0]["text"] for r in trace_b if r.get("method")=="turn/start"]
        self.assertEqual(len(sent),1)
        self.assertIn(handover["id"],sent[0])
        self.assertNotIn("Tiến độ riêng",sent[0])
        self.assertFalse(any(r.get("method")=="thread/resume" for r in trace_b))
        action("chat-close",target)
        until("closed")
        self.req("exit")
        self.proc.wait(timeout=10)
        self.launch()
        self.assertEqual(state()["session"],target)
        self.assertGreaterEqual(len(state()["messages"]),8)

    def test_chat_retries_auth_without_losing_previous_thread(self):
        fixture = self.root / "Auth Codex"
        fixture.write_text(CHAT_FIXTURE,encoding="utf-8")
        fixture.chmod(0o755)
        profile = self.add_profile("Terminal Home",fixture)
        home = self.root / "Terminal Home"
        (home / "keyring-only").touch()
        p = self.req("project-save",{"name":"Chat auth","path":str(self.workspace)})["id"]
        scope = {"project":p,"profile":profile}

        def until(stage, active):
            return self.eventually(lambda: state if (state := self.req("chat-state",scope))["stage"]==stage and state["active"]==active else None)

        opened = self.req("chat-open",scope)["id"]
        until("ready",True)
        self.req("chat-close",{**scope,"session":opened})
        until("closed",False)
        signed_out = home / "signed-out"
        signed_out.touch()
        self.req("chat-send",{**scope,"text":"Giữ bản nháp này"})
        declined = until("auth",False)
        self.assertIn("Giữ bản nháp này",[m["text"] for m in declined["messages"]])
        self.assertEqual(next(a for a in self.req("quota-state")["auth"] if a["profile"]==profile)["status"],"Signed out")
        trace = home / "rpc.jsonl"
        self.assertNotIn('"method": "turn/start"',trace.read_text(encoding="utf-8"))
        signed_out.unlink()
        self.req("chat-send",{**scope,"text":"Gửi sau khi đăng nhập"})
        ready = until("ready",True)
        self.assertEqual(ready["messages"][-1]["role"],"assistant")
        self.assertIn('"method": "thread/resume"',trace.read_text(encoding="utf-8"))
        self.req("chat-close",{**scope,"session":ready["session"]})
        until("closed",False)
        fresh = self.req("chat-open",{**scope,"fresh":True})["id"]
        fresh_state = until("ready",True)
        methods = [json.loads(line).get("method") for line in trace.read_text(encoding="utf-8").splitlines()]
        self.assertEqual([m for m in methods if m in ("thread/start","thread/resume")],
                         ["thread/start","thread/resume","thread/start"])
        self.assertIn("Gửi sau khi đăng nhập",[m["text"] for m in fresh_state["messages"]])
        self.req("chat-close",{**scope,"session":fresh})
        until("closed",False)

    def test_resume_preflight_and_empty_thread(self):
        fixture=self.root/"Resume probe"
        fixture.write_text(CHAT_FIXTURE); fixture.chmod(0o755)
        profile=self.add_profile("Resume profile",fixture)
        home=self.root/"Resume profile"
        (home/"lazy-rollout").touch()
        project=self.req("project-save",{"name":"Probe","path":str(self.workspace)})["id"]
        scope={"project":project,"profile":profile}
        def until(stage,active):
            return self.eventually(lambda: s if (s:=self.req("chat-state",scope))["stage"]==stage and s["active"]==active else None)
        def close(id):
            self.req("chat-close",{**scope,"session":id}); until("closed",False)
        empty=self.req("chat-open",scope)["id"]
        until("ready",True); close(empty)
        self.assertFalse(self.session(empty)["chatKey"])
        sent=self.req("chat-send",{**scope,"text":"Tin đầu tiên"})["id"]
        self.eventually(lambda: any(m["role"]=="assistant" for m in self.req("chat-state",scope)["messages"]))
        close(sent)
        self.assertTrue(self.session(sent)["chatKey"])
        for marker in ("missing-rollout","wrong-cwd"):
            (home/marker).touch()
            self.req("thread-resume",{"id":sent})
            state=until("startup",False)
            self.assertIn("Tin đầu tiên",[m["text"] for m in state["messages"]])
            (home/marker).unlink()
        trace=[json.loads(line).get("method") for line in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertEqual(trace.count("thread/read"),2)
        self.assertNotIn("thread/resume",trace)
        self.req("thread-resume",{"id":sent}); until("ready",True)

    def test_loaded_thread_required_and_revoked(self):
        cli=self.root/"Codex"; cli.write_text(CHAT_FIXTURE); cli.chmod(0o755)
        profile=self.add_profile("Runtime state",cli)
        home=self.root/"Runtime state"
        project=self.req("project-save",{"name":"Live state","path":str(self.workspace)})["id"]
        scope={"profile":profile,"project":project}
        def until(stage, active):
            return self.eventually(lambda: s if (s:=self.req("chat-state",scope))["stage"]==stage and s["active"]==active else None)
        def turns():
            return sum(json.loads(row).get("method")=="turn/start" for row in (home/"rpc.jsonl").read_text().splitlines())
        (home/"absent-runtime").touch()
        self.req("chat-send",{**scope,"text":"Wait for load"})
        state=until("startup",False)
        self.assertIn("Wait for load",[m["text"] for m in state["messages"]])
        self.assertEqual(turns(),0)
        (home/"absent-runtime").unlink()
        (home/"paged-loaded").touch()
        self.req("chat-send",{**scope,"fresh":True,"text":"unload"})
        until("startup",False)
        self.assertEqual(turns(),1)
        self.req("chat-open",scope)
        until("ready",True)
        (home/"reject-turn").touch()
        self.req("chat-send",{**scope,"text":"Rejected by server"})
        until("startup",False)
        self.assertEqual(turns(),2)

    def test_cold_rollout_restart_stale_id_and_fresh(self):
        cli=self.root/"Codex"; cli.write_text(CHAT_FIXTURE); cli.chmod(0o755)
        profile=self.add_profile("Cold Home",cli)
        home=self.root/"Cold Home"
        tid="bd6944e1-8573-47b0-9348-a36166cc6356"
        (home/"import-thread").write_text(tid)
        project=self.req("project-save",{"name":"Cold","path":str(self.workspace)})["id"]
        scope={"profile":profile,"project":project}
        def until(stage,active):
            return self.eventually(lambda: s if (s:=self.req("chat-state",scope))["stage"]==stage and s["active"]==active else None)
        def trace():
            return [json.loads(line).get("method") for line in (home/"rpc.jsonl").read_text().splitlines()]
        first=self.req("chat-send",{**scope,"text":"First"})["id"]
        until("ready",True)
        self.req("chat-send",{**scope,"text":"Second"})
        state=until("ready",True)
        self.assertEqual(sum(m["role"]=="assistant" for m in state["messages"]),2)
        self.req("chat-close",{**scope,"session":first}); until("closed",False)
        self.req("exit"); self.proc.wait(timeout=5); self.launch()
        (home/"cold-read").touch()
        current=self.req("thread-resume",{"id":first})["id"]
        until("ready",True)
        self.req("chat-send",{**scope,"text":"Third"})
        self.assertEqual(sum(m["role"]=="assistant" for m in until("ready",True)["messages"]),3)
        self.req("chat-close",{**scope,"session":current}); until("closed",False)
        rollout=next((home/"sessions").rglob("*.jsonl"))
        original=rollout.read_bytes()
        forged=json.loads(original); forged["payload"]["cwd"]=str(home)
        rollout.write_text(json.dumps(forged)+"\n")
        count=trace().count("thread/resume")
        self.req("chat-open",scope); until("startup",False)
        self.assertEqual(trace().count("thread/resume"),count)
        self.assertEqual(trace().count("turn/start"),3)
        reads=trace().count("thread/read")
        self.req("chat-send",{**scope,"text":"Must not re-submit to stale ID"},expected=409)
        self.assertEqual(trace().count("thread/read"),reads)
        rollout.write_bytes(original)
        self.req("thread-resume",{"id":first}); state=until("ready",True)
        self.req("chat-close",{**scope,"session":state["session"]}); until("closed",False)
        (home/"multiple-threads").touch()
        fresh=self.req("chat-open",{**scope,"fresh":True})["id"]
        until("ready",True)
        self.assertNotEqual(self.session(fresh)["chatThread"],tid)
        self.assertEqual(rollout.read_bytes(),original)
        self.assertEqual(trace().count("thread/start"),2)

    def test_missing_history_after_read_and_unpersisted_ack(self):
        cli=self.root/"Codex"; cli.write_text(CHAT_FIXTURE); cli.chmod(0o755)
        profile=self.add_profile("Delayed Store",cli)
        home=self.root/"Delayed Store"
        project=self.req("project-save",{"name":"After read","path":str(self.workspace)})["id"]
        scope={"profile":profile,"project":project}
        def until(stage,active):
            return self.eventually(lambda: s if (s:=self.req("chat-state",scope))["stage"]==stage and s["active"]==active else None)
        (home/"lazy-rollout").touch(); (home/"no-durable-turn").touch(); (home/"list-unsupported").touch()
        new=self.req("chat-send",{**scope,"text":"Only acknowledged"})["id"]
        until("ready",True)
        self.req("chat-close",{**scope,"session":new}); until("closed",False)
        rec=self.session(new)
        self.assertTrue(rec["chatCandidate"]); self.assertFalse(rec["chatThread"]); self.assertFalse(rec["chatKey"])
        (home/"gone-after-read").touch()
        self.req("chat-send",{**scope,"text":"Must wait for resume"})
        until("startup",False)
        self.req("chat-send",{**scope,"text":"Must wait for resume"},expected=409)
        methods=[json.loads(row).get("method") for row in (home/"rpc.jsonl").read_text().splitlines()]
        self.assertEqual(methods.count("turn/start"),1)
        self.assertEqual(methods.count("thread/resume"),1)
        self.assertEqual(methods.count("thread/start"),1)
        self.assertLess(methods.index("thread/read"),methods.index("thread/resume"))

    def test_open_saved_terminal_thread_in_chat(self):
        fixture = self.root / "Resume Codex"
        fixture.write_text(CHAT_FIXTURE,encoding="utf-8")
        fixture.chmod(0o755)
        a = self.add_profile("Resume Home",fixture)
        b = self.add_profile("Other Home",fixture)
        home = self.root / "Resume Home"
        thread = "aaaaaaaa-aaaa-4aaa-aaaa-aaaaaaaaaaaa"
        (home / "import-thread").write_text(thread)
        p = self.req("project-save",{"name":"Workspace gốc","path":str(self.workspace)})["id"]
        registered = self.req("saved-import",{"manual":True,"home":str(home),"workspace":str(self.workspace),"thread":thread})
        args = {"id":registered["id"],"chat":True,"confirmed":True}
        self.req("saved-resume",{**args,"profile":b},expected=409)
        self.req("saved-resume",{"id":registered["id"],"chat":True,"profile":a},expected=409)
        opened=self.req("saved-resume",{**args,"profile":a})
        self.assertEqual(opened["project"],p)
        ready = self.eventually(lambda: s if (s:=self.req("chat-state",{"project":p}))["stage"]=="ready" else None)
        self.assertEqual(ready["profile"],a)
        self.assertEqual(opened["id"],ready["session"])
        self.assertEqual(self.session(ready["session"])["chatThread"],thread)
        self.assertIn('"method": "thread/resume"',(home / "rpc.jsonl").read_text(encoding="utf-8"))
        self.req("saved-resume",{**args,"profile":a},expected=409)
        self.req("chat-close",{"project":p,"session":ready["session"]})

    def test_thread_library_profile_catalog_and_task_details(self):
        fixture=self.root/"Thread CLI"
        fixture.write_text(CHAT_FIXTURE,encoding="utf-8"); fixture.chmod(0o755)
        ref=self.add_profile("Thư viện",fixture)
        home=self.root/"Thư viện"
        (home/"multiple-threads").touch()
        (home/"account-unsupported").touch()
        p=self.req("project-save",{"name":"Nhiều luồng","path":str(self.workspace)})["id"]
        scope={"project":p,"profile":ref}
        def until(stage,active=True):
            return self.eventually(lambda: s if (s:=self.req("chat-state",scope))["stage"]==stage and s["active"]==active else None)
        def close(id):
            self.req("chat-close",{**scope,"session":id}); until("closed",False)
        self.req("chat-draft-save",{**scope,"text":"Bản nháp tiếng Việt"})
        self.assertEqual(self.req("chat-draft-read",scope)["text"],"Bản nháp tiếng Việt")
        self.req("chat-draft-save",{**scope,"text":"OPENAI_API_KEY=sk-proj-do-not-store"},expected=409)
        self.assertEqual(self.req("codex-models",{"profile":ref})["models"][0]["efforts"],["low"])
        a=self.req("chat-open",scope)["id"]
        until("ready")
        self.req("chat-send",{**scope,"text":"tool"})
        tools=self.eventually(lambda: s if (s:=self.req("chat-state",scope))["toolOutput"]=="Kết quả kiểm thử" and s["stage"]=="ready" else None)
        self.assertIn("src/demo.c",tools["files"])
        self.assertIn("+new",tools["diff"])
        close(a)
        b=self.req("chat-open",{**scope,"fresh":True})["id"]
        until("ready")
        self.assertNotEqual(self.session(a)["chatKey"],self.session(b)["chatKey"])
        self.req("thread-edit",{"id":a,"title":"Luồng ghim","pinned":True,"archived":True})
        self.assertEqual(self.req("state")["threadprefs"][0]["title"],"Luồng ghim")
        self.req("thread-resume",{"id":a},expected=409)
        close(b)
        self.req("exit"); self.proc.wait(timeout=5); self.launch()
        self.assertEqual(self.req("chat-draft-read",scope)["text"],"Bản nháp tiếng Việt")
        self.assertEqual(self.req("thread-read",{"id":a})["messages"][-1]["text"],"Phản hồi từ lịch sử")
        resumed=self.req("thread-resume",{"id":a})["id"]
        self.assertEqual(until("ready")["chatKey"],self.session(a)["chatKey"])
        self.req("chat-send",{**scope,"text":"expired"})
        self.assertIn("từ chối xác thực",until("auth",False)["messages"][-1]["text"])
        self.assertTrue(resumed)

    def test_import_terminal_uses_exact_home_id_and_workspace(self):
        source = self.native_home
        root = source / "sessions" / "2026" / "11" / "22"
        root.mkdir(parents=True)
        original, newer, exec_id = ("aaaaaaaa-aaaa-4aaa-aaaa-aaaaaaaaaaaa",
            "bbbbbbbb-bbbb-4bbb-bbbb-bbbbbbbbbbbb","dddddddd-dddd-4ddd-dddd-dddddddddddd")
        history = root / f"rollout-2026-11-22T12-00-00-{original}.jsonl"
        def row(thread,cwd,kind):
            return {"type":"session_meta","payload":{"id":thread,"cwd":str(cwd),
                "timestamp":"2026-11-22T12:00:00Z","source":kind}}
        history.write_text(json.dumps(row(original,self.workspace,"cli")) + "\n"
          + json.dumps({"text":"sk-proj-secret-only-in-original-chat"})+"\n",encoding="utf-8")
        (root / f"rollout-{exec_id}.jsonl").write_text(json.dumps(row(exec_id,self.workspace,"exec"))+"\n")
        auth=source / "auth.json"
        auth.write_text('{"access_token":"must-never-be-copied"}')
        original_bytes=history.read_bytes()
        fixture = self.root / "Installed Codex CLI"
        fixture.write_text(SAVED_FIXTURE,encoding="utf-8")
        fixture.chmod(0o755)
        (source / "fixture-index.json").write_text(json.dumps([
            {"id":newer,"cwd":str(self.workspace),"updatedAt":1888800000,"createdAt":1888700000,
             "preview":"preview-must-not-be-returned"},
            {"id":original,"cwd":str(self.workspace),"updatedAt":1888700000,"createdAt":1888600000}
        ]))
        s=self.req("state")["settings"]
        self.assertEqual(s["version"],SOURCE_VERSION)
        self.assertEqual(s["terminalHome"],str(source))
        self.assertEqual((self.data/"ui.version").read_text(),f"{s['version']}\n{s['buildId']}\n{self.url}/#{self.key}")
        s["codex"]=str(fixture)
        self.req("settings-save",s)
        listing=self.req("saved-list")
        self.assertTrue(listing["indexed"])
        self.assertEqual({x["thread"] for x in listing["sessions"]},{original,newer})
        self.assertNotIn("preview-must-not",json.dumps(listing))
        self.assertEqual(listing["sessions"][0]["workspace"],str(self.workspace))
        self.assertNotIn("must-never",json.dumps(listing))
        (source/"legacy-only").touch()
        fallback=self.req("saved-list")
        self.assertFalse(fallback["indexed"])
        self.assertEqual([x["thread"] for x in fallback["sessions"]],[original])
        self.assertEqual(fallback["sessions"][0]["source"],"rollout")
        self.assertEqual(fallback["processes"]["daemon"],0)
        manual_id="eeeeeeee-eeee-4eee-aeee-eeeeeeeeeeee"
        manual=self.req("saved-import",{"thread":manual_id,"manual":True,"workspace":str(self.workspace)})
        self.assertEqual(manual["source"],"manual")
        self.assertEqual(manual["workspace"],str(self.workspace))
        self.assertEqual(history.read_bytes(),original_bytes)
        self.req("saved-import",{"thread":exec_id},expected=409)
        imported=self.req("saved-import",{"thread":original})
        self.assertEqual(self.req("saved-import",{"thread":original})["id"],imported["id"])
        self.assertEqual(len(self.req("state")["imports"]),2)
        self.req("saved-resume",{"id":imported["id"]},expected=409)
        missing_dir=history.parent / "not-found"
        older="cccccccc-cccc-4ccc-accc-cccccccccccc"
        (root/f"rollout-{older}.jsonl").write_text(json.dumps(row(older,missing_dir,"cli"))+"\n")
        orphaned=self.req("saved-import",{"thread":older})
        self.req("saved-resume",{"id":orphaned["id"],"confirmed":True},expected=409)
        self.assertFalse(missing_dir.exists())
        p=self.req("project-save",{"name":"Existing project","path":str(self.workspace)})["id"]
        external_id="b"*32
        external=self.data/"external"
        (external/f"{external_id}.json").write_text(json.dumps({"id":external_id,"workspace":str(self.workspace),
            "home":str(source),"thread":original,"started":1900000000}))
        self.assertFalse(self.req("state")["external"][0]["closed"])
        self.req("saved-resume",{"id":imported["id"],"confirmed":True},expected=409)
        self.req("checkpoint-backup",{"project":p,"quiet":True},expected=409)
        (external/f"{external_id}.done").write_text("done")
        self.assertTrue(self.req("state")["external"][0]["closed"])
        if os.name != "nt":
            self.req("saved-resume",{"id":imported["id"],"external":True,"confirmed":True},expected=409)
        launched=self.req("saved-resume",{"id":imported["id"],"confirmed":True})["id"]
        trace=source/"resume-trace.json"
        self.eventually(trace.is_file)
        payload=json.loads(trace.read_text())
        self.assertEqual(payload,{"args":["resume","-c",'approvals_reviewer="user"',"--",original],"home":str(source),"cwd":str(self.workspace)})
        self.assertEqual(self.session(launched)["project"],p)
        self.assertEqual(self.session(launched)["resumedThread"],original)
        self.req("saved-resume",{"id":imported["id"],"confirmed":True},expected=409)
        self.req("session-stop",{"id":launched,"confirmed":True})
        self.eventually(lambda:self.session(launched)["status"]=="Stopped")
        self.assertEqual(history.read_bytes(),original_bytes)
        self.assertEqual(auth.read_text(),'{"access_token":"must-never-be-copied"}')
        self.req("exit")
        self.proc.wait(timeout=5)
        self.launch()
        self.assertIn(imported["id"],[x["id"] for x in self.req("state")["imports"]])

    def test_real_app_server_cold_rollout_and_missing_id(self):
        if not REAL_CODEX:
            self.skipTest("Provide --codex for the real protocol check")
        home=self.native_home
        tid=str(uuid.uuid4())
        root=home/"sessions"/"2026"/"11"/"23"
        root.mkdir(parents=True)
        path=root/f"rollout-2026-11-23T00-00-00-{tid}.jsonl"
        stamp="2026-11-23T00:00:00Z"
        meta={"timestamp":stamp,"type":"session_meta","payload":{"id":tid,"timestamp":stamp,
            "cwd":str(self.workspace),"originator":"codex_cli_rs","cli_version":"0.172.0-alpha.2",
            "source":"cli","model_provider":"openai"}}
        row={"timestamp":stamp,"type":"response_item","payload":{"type":"message","role":"user",
             "content":[{"type":"input_text","text":"QA"}]}}
        original=(json.dumps(meta)+"\n"+json.dumps(row)+"\n").encode()
        path.write_bytes(original)
        replies=queue.Queue()
        env={**os.environ,"CODEX_HOME":str(home)}
        with subprocess.Popen([str(REAL_CODEX),"app-server"],cwd=self.workspace,env=env,
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,text=True) as child:
            def read_output():
                for line in child.stdout:
                    replies.put(json.loads(line))
            reader=threading.Thread(target=read_output,daemon=True)
            reader.start()
            def send(method,params,seq=None):
                packet={"method":method,"params":params}
                if seq is not None: packet["id"]=seq
                child.stdin.write(json.dumps(packet)+"\n"); child.stdin.flush()
                if seq is None: return None
                deadline=time.monotonic()+10
                while time.monotonic()<deadline:
                    obj=replies.get(timeout=max(.01,deadline-time.monotonic()))
                    if obj.get("id")==seq and "method" not in obj: return obj
                self.fail("Timed out waiting for "+method)
            try:
                self.assertIn("result",send("initialize",{"clientInfo":{"name":"samero_qa","version":"1.6.2-rc1"}},1))
                send("initialized",{})
                info=send("thread/read",{"threadId":tid},2)["result"]["thread"]
                self.assertEqual((info["id"],info["cwd"],info["status"]["type"]),(tid,str(self.workspace),"notLoaded"))
                self.assertNotIn(tid,send("thread/loaded/list",{"limit":100},3)["result"]["data"])
                missing=str(uuid.uuid4())
                for seq,method in enumerate(("thread/read","thread/resume"),4):
                    message=send(method,{"threadId":missing},seq)["error"]["message"]
                    self.assertIn(missing,message)
                self.assertEqual(path.read_bytes(),original)
            finally:
                child.stdin.close()
                try: child.wait(timeout=4)
                except subprocess.TimeoutExpired: child.terminate(); child.wait(timeout=5)
                reader.join(timeout=2)

    def test_real_codex_auto_review_config(self):
        if not REAL_CODEX:
            self.skipTest("Provide --codex to verify the official reviewer configuration")
        ref=self.add_profile("Official reviewer",REAL_CODEX)
        project=self.req("project-save",{"name":"Reviewer","path":str(self.workspace)})["id"]
        self.set_auto_approval(True)
        sid=self.req("session-start",{"project":project,"profile":ref})["id"]
        self.assertEqual(self.session(sid)["reviewer"],"auto_review")
        self.assertEqual(self.req("review-history",{"project":project})["events"],[])

    def test_real_codex_unauthenticated(self):
        if not REAL_CODEX:
            self.skipTest("Provide --codex for a real unauthenticated CLI handshake")
        ref = self.add_profile("CLI chính thức",REAL_CODEX)
        self.assertTrue(self.req("cli-check",{"profile":ref})["version"].startswith("codex-cli "))
        result = self.req("account-refresh",{"profile":ref})
        self.assertEqual(result["source"], "official")
        self.assertIn(result["status"], {"Signed out","Unknown"})
        self.assertIsNone(result.get("h"))
        models=self.req("codex-models",{"profile":ref})["models"]
        self.assertTrue(models and all("id" in model and "efforts" in model for model in models))
        threads=self.req("saved-list",{"profile":ref})
        self.assertTrue(threads["indexed"])
        self.assertEqual(threads["sessions"],[])
        if result["status"]=="Signed out":
            project = self.req("project-save",{"name":"CLI thật","path":str(self.workspace)})["id"]
            self.req("chat-open",{"project":project,"profile":ref})
            auth = self.eventually(lambda: s if (s:=self.req("chat-state",{"project":project}))["stage"]=="auth" else None)
            self.assertIn("chưa đăng nhập",auth["messages"][-1]["text"])

    def test_project_details_source_status_and_safe_creation(self):
        status=self.workspace/"PROJECT_STATUS.md"
        (self.workspace/"package.json").write_text("{}")
        (self.workspace/"CODEX_HANDOVER.md").write_text("Handoff verified")
        p=self.req("project-save",{"name":"Tên dự án","path":str(self.workspace)})["id"]
        detail=self.req("project-details",{"project":p})
        self.assertEqual(detail["git"]["branch"],"main")
        self.assertIn("package.json",detail["configFiles"])
        self.assertEqual(detail["documents"]["PROJECT_STATUS.md"]["state"],"missing")
        self.assertIsNone(detail["checks"]["test"])
        self.assertEqual(detail["documents"]["CODEX_HANDOVER.md"]["content"],"Handoff verified")
        self.req("project-create-status",{"project":p})
        self.assertIn("Tên dự án",status.read_text())
        status.write_text("Tiếp tục kiểm thử hồi quy",encoding="utf-8")
        self.req("project-create-status",{"project":p},expected=409)
        self.req("project-save",{"id":p,"name":"Updated","path":str(self.workspace),"notes":"Ghi chú cũ"})
        self.req("project-save",{"id":p,"name":"Renamed","path":str(self.workspace)})
        self.assertEqual(self.req("state")["projects"][0]["notes"],"Ghi chú cũ")
        self.assertEqual(self.req("project-details",{"project":p})["documents"]["PROJECT_STATUS.md"]["content"],"Tiếp tục kiểm thử hồi quy")
        destination=self.add_profile("Destination only")
        c=self.req("checkpoint-prepare",{"project":p,"destination":destination,"quiet":True})
        self.assertTrue(c["handover"])
        self.assertIn("Tiếp tục kiểm thử hồi quy",self.req("checkpoint-preview",{"id":c["id"]})["status"])
        self.assertEqual(status.read_text(encoding="utf-8"),"Tiếp tục kiểm thử hồi quy")

    def test_slow_git_does_not_block_ui_state(self):
        from concurrent.futures import ThreadPoolExecutor
        fixture=self.root/"slow-git"
        ready=self.root/"git-started"
        fixture.write_text("#!/bin/sh\nprintf ready > '" + str(ready) + "'\nsleep 2\nexit 128\n")
        fixture.chmod(0o755)
        s=self.req("state")["settings"]
        s["git"]=str(fixture)
        self.req("settings-save",s)
        p=self.req("project-save",{"name":"Async","path":str(self.workspace)})["id"]
        with ThreadPoolExecutor(max_workers=1) as pool:
            request=pool.submit(self.req,"project-details",{"project":p})
            self.eventually(ready.is_file)
            before=time.monotonic()
            self.assertEqual(self.req("state")["settings"]["version"],SOURCE_VERSION)
            self.assertLess(time.monotonic()-before,1.4)
            self.assertTrue(request.result()["gitError"])

    def test_only_idle_disconnect_recovers_and_never_replays(self):
        cli=self.root/"Recovery CLI"; cli.write_text(CHAT_FIXTURE); cli.chmod(0o755)
        profile=self.add_profile("Recovery",cli)
        project=self.req("project-save",{"name":"Recovery","path":str(self.workspace)})["id"]
        scope={"project":project,"profile":profile}
        first=self.req("chat-send",{**scope,"text":"disconnect-idle"})["id"]
        self.eventually(lambda: (s:=self.req("chat-state",scope))["stage"]=="ready" and s["active"] and s["session"]!=first)
        self.req("chat-send",{**scope,"text":"disconnect-busy"})
        state=self.eventually(lambda:s if (s:=self.req("chat-state",scope))["stage"]=="error" and not s["active"] else None)
        self.assertIn("disconnect-busy",[m["text"] for m in state["messages"]])
        calls=[json.loads(x) for x in (self.root/"Recovery"/"rpc.jsonl").read_text().splitlines()]
        self.assertEqual([r["params"]["input"][0]["text"] for r in calls if r.get("method")=="turn/start"],
            ["disconnect-idle","disconnect-busy"])
        self.assertEqual(sum(r.get("method")=="thread/resume" for r in calls),1)

    def test_chat_send_idempotency_survives_restart(self):
        fixture=self.root/"Receipts CLI"; fixture.write_text(CHAT_FIXTURE); fixture.chmod(0o755)
        profile=self.add_profile("Receipts",fixture)
        project=self.req("project-save",{"name":"Receipts","path":str(self.workspace)})["id"]
        payload={"project":project,"profile":profile,"text":"Một lượt duy nhất","requestId":"c"*32}
        session=self.req("chat-send",payload)["id"]
        self.assertTrue(self.req("chat-send",payload)["duplicate"])
        self.req("chat-send",{**payload,"text":"Nội dung khác"},expected=409)
        self.eventually(lambda:any(m["role"]=="assistant" for m in self.req("chat-state",payload)["messages"]))
        self.req("chat-close",{**payload,"session":session})
        self.eventually(lambda:not self.req("chat-state",payload)["active"])
        self.req("exit"); self.proc.wait(timeout=5); self.launch()
        self.assertTrue(self.req("chat-send",payload)["duplicate"])
        self.assertFalse(self.req("chat-state",payload)["active"])
        trace=(self.root/"Receipts"/"rpc.jsonl").read_text()
        self.assertEqual(trace.count('"method": "turn/start"'),1)
        self.assertNotIn(payload["text"],(self.data/"chatreceipts"/("c"*32+".json")).read_text())

    def test_automatic_quota_reset_offline_and_restart(self):
        fixture=self.root/"Telemetry CLI"; fixture.write_text(CHAT_FIXTURE); fixture.chmod(0o755)
        profile=self.add_profile("Telemetry",fixture)
        home=self.root/"Telemetry"
        (home/"fast-reset").touch()
        def reading(expected):
            s=self.req("quota-state"); q=next((q for q in s["quota"] if q["profile"]==profile),{})
            w=next(w for w in s["quotaSync"] if w["profile"]==profile)
            return (q,w) if q.get("h")==expected and w["verified"]==q.get("at") else None
        q,w=self.eventually(lambda:reading(0))
        self.assertEqual(q["w"],69)
        q,w=self.eventually(lambda:reading(96))
        (home/"rate-offline").touch()
        self.req("account-refresh",{"profile":profile})
        s=self.req("quota-state")
        self.assertTrue(next(w for w in s["quotaSync"] if w["profile"]==profile)["offline"])
        cached=next(q for q in s["quota"] if q["profile"]==profile)
        self.assertEqual((cached["at"],cached["h"]),(q["at"],96))
        self.req("exit"); self.proc.wait(timeout=5); self.launch()
        self.assertEqual(self.req("quota-state")["quotaSync"][0]["verified"],0)
        (home/"rate-offline").unlink()
        self.eventually(lambda:reading(96))
        before=len(self.req("state")["samples"])
        self.req("account-refresh",{"profile":profile})
        self.assertEqual(len(self.req("state")["samples"]),before)

    def test_active_quota_reuses_connection_after_turn(self):
        fixture=self.root/"Active CLI"; fixture.write_text(CHAT_FIXTURE); fixture.chmod(0o755)
        profile=self.add_profile("Active quota",fixture)
        project=self.req("project-save",{"name":"Quota","path":str(self.workspace)})["id"]
        scope={"project":project,"profile":profile}
        self.req("chat-send",{**scope,"text":"Test quota"})
        self.eventually(lambda:any(m["role"]=="assistant" for m in self.req("chat-state",scope)["messages"]))
        log=self.root/"Active quota"/"rpc.jsonl"
        def methods():
            return [json.loads(x).get("method") for x in log.read_text().splitlines()]
        self.eventually(lambda: methods().count("account/rateLimits/read")>=2)
        before=methods().count("account/rateLimits/read")
        self.req("account-refresh",{"profile":profile})
        self.eventually(lambda:methods().count("account/rateLimits/read")>before)
        self.assertEqual(methods().count("initialize"),1)

    def test_slow_quota_does_not_block_chat(self):
        from concurrent.futures import ThreadPoolExecutor
        account=self.add_profile("Slow quota")
        home=self.root/"Slow quota"
        (home/"slow-quota").touch()
        fixture=self.root/"Chat available"; fixture.write_text(CHAT_FIXTURE); fixture.chmod(0o755)
        profile=self.add_profile("Chat available profile",fixture)
        project=self.req("project-save",{"name":"Workspace available","path":str(self.workspace)})["id"]
        with ThreadPoolExecutor(max_workers=1) as pool:
            request=pool.submit(self.req,"account-refresh",{"profile":account})
            self.eventually((home/"quota-pending").is_file)
            before=time.monotonic()
            self.req("chat-send",{"project":project,"profile":profile,"text":"Thử gửi khi quota đang đọc"})
            self.assertLess(time.monotonic()-before,1.4)
            self.assertEqual(request.result()["h"],78)
        self.eventually(lambda: any(m["role"]=="assistant" for m in self.req("chat-state",{"project":project})["messages"]))

    def test_does_not_reopen_an_old_manager(self):
        version=self.data/"ui.version"
        original=version.read_text()
        current_version=original.splitlines()[0]
        version.write_text(original.replace(current_version,"0.1.0",1))
        args=[str(APP),"--data-dir",str(self.data)]
        old=subprocess.run(args,capture_output=True,text=True,timeout=5)
        self.assertEqual(old.returncode,1)
        self.assertFalse(old.stdout)
        self.assertIn(current_version,old.stderr)
        version.write_text(original.replace(original.splitlines()[1],"old-build",1))
        old_build=subprocess.run(args,capture_output=True,text=True,timeout=5)
        self.assertEqual(old_build.returncode,1)
        self.assertFalse(old_build.stdout)
        version.write_text(original)
        same=subprocess.run(args,capture_output=True,text=True,timeout=5)
        self.assertEqual(same.returncode,0)
        self.assertEqual(same.stdout.strip(),f"{self.url}/#{self.key}")

    def test_process_exit_and_unsafe_paths(self):
        p = self.req("project-save",{"name":"Project","path":str(self.workspace)})["id"]
        a = self.add_profile("Failure",model="fixture-fail")
        s = self.req("session-start",{"profile":a,"project":p})["id"]
        self.eventually(lambda: self.session(s)["status"]=="Failed")
        self.assertEqual(self.session(s)["exitCode"],7)
        self.req("project-save",{"name":"Nested","path":str(self.root)},expected=409)
        self.req("checkpoint-backup",{"project":p},expected=409)
        unintended = self.workspace / "nested"
        self.req("profile-save",{"name":"Invalid","home":str(unintended),"cli":str(self.fixture)},expected=409)
        self.assertFalse(unintended.exists())
        self.req("project-save",{"id":p,"name":"Project","path":str(self.workspace),"notes":"OPENAI_API_KEY=test"},expected=409)
        secondary = subprocess.run([str(APP),"--headless","--data-dir",str(self.data)],timeout=5)
        self.assertNotEqual(secondary.returncode,0)

if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("app",type=Path)
    parser.add_argument("--codex",type=Path)
    parser.add_argument("--fixture-only",action="store_true",help="Require every local fixture; real Codex checks remain separate and NOT VERIFIED.")
    cli = parser.parse_args()
    APP = cli.app.resolve()
    REAL_CODEX = cli.codex
    if cli.fixture_only:
        excluded={"test_real_app_server_cold_rollout_and_missing_id","test_real_codex_auto_review_config","test_real_codex_unauthenticated"}
        names=unittest.defaultTestLoader.getTestCaseNames(ManagerTest)
        assert excluded.issubset(names)
        result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(ManagerTest(n) for n in names if n not in excluded))
        print("Real Codex checks: NOT VERIFIED (3 excluded)",flush=True)
        sys.exit(0 if result.wasSuccessful() and not result.skipped and result.testsRun==len(names)-len(excluded) else 1)
    unittest.main(argv=[__file__],verbosity=2)
