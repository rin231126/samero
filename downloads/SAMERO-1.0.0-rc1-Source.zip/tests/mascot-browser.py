#!/usr/bin/env python3
"""Test bundled assets and real Chromium (when available) against a temporary Manager."""
import hashlib,sys,struct
from pathlib import Path
from urllib.request import urlopen
from urllib.error import HTTPError
from playwright.sync_api import sync_playwright
import integration as t
ROOT=Path(__file__).resolve().parents[1]
t.APP=Path(sys.argv[1]).resolve();t.REAL_CODEX=None
case=t.ManagerTest('test_process_exit_and_unsafe_paths');case.setUp()
try:
    assets=['mascot.js','music.js','studio.js','mini.js','blue-current.ogg','harbor-lofi.ogg','deep-ocean.ogg','samero.ico']+[f'mascot/{p.name}' for p in sorted((ROOT/'web/mascot').glob('*.png'))]
    for path in assets:
        remote='favicon.ico' if path=='samero.ico' else path
        with urlopen(case.url+'/'+remote,timeout=10) as response:
            assert response.read()==(ROOT/'web'/path).read_bytes(),path
            assert response.headers['Content-Type'].startswith('image/' if path.endswith(('.png','.ico')) else 'audio/ogg' if path.endswith('.ogg') else 'text/javascript'),path
            assert "script-src 'self'" in response.headers['Content-Security-Policy']
            assert "media-src 'self'" in response.headers['Content-Security-Policy']
    for path in ['mascot/../app.js','mascot/unknown.png','mascot/%2e%2e/manager.h']:
        try:
            urlopen(case.url+'/'+path,timeout=5)
            raise AssertionError('Unexpected asset route: '+path)
        except HTTPError as e: assert e.code==404
    print('PASS: exact embedded asset bytes, MIME, CSP and unknown routes',flush=True)
    if "--assets-only" in sys.argv: sys.exit(0)
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage','--no-proxy-server'])
        page=browser.new_page(viewport={'width':1440,'height':900});page.set_default_timeout(8000)
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(case.url+'/#'+case.key,wait_until='domcontentloaded',timeout=10000)
        page.locator('#mascot-toggle').wait_for()
        assert page.locator('#music-toggle').get_attribute('aria-pressed')=='false'
        page.locator('#music-toggle').click();page.wait_for_function("document.querySelector('#music-toggle').getAttribute('aria-pressed')==='true'")
        page.locator('#music-toggle').click();assert page.locator('#music-toggle').get_attribute('aria-pressed')=='false'
        page.get_by_role('button',name='Hạn mức',exact=True).click()
        page.get_by_role('heading',name='Dashboard',exact=True).wait_for()
        page.locator('#mascot-toggle').click();assert page.locator('#mascot-image').get_attribute('src')=='/mascot/open.png'
        page.locator('#mascot-toggle').focus();page.keyboard.press('Enter');assert page.locator('#mascot-image').get_attribute('src')!='/mascot/open.png'
        page.get_by_role('button',name='Cài đặt',exact=True).click()
        assert page.locator('[data-mascot-preview]').count()==9
        page.locator('[data-mascot-preview="success"]').click();assert page.locator('#mascot-image').get_attribute('src')=='/mascot/success.png'
        page.locator('#mascot-auto').uncheck();page.locator('#mascot-motion').uncheck()
        assert not page.locator('#mascot-auto').is_checked()
        page.reload();page.get_by_role('button',name='Cài đặt',exact=True).click();assert not page.locator('#mascot-auto').is_checked()
        page.locator('#mascot-auto').check();page.locator('#mascot-motion').check()
        if len(sys.argv)>2:page.screenshot(path=sys.argv[2],full_page=True)
        for size in [(1280,720),(1024,768),(700,720)]:
            page.set_viewport_size({'width':size[0],'height':size[1]})
            page.get_by_role('button',name='Hạn mức',exact=True).click()
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'),size
        assert not errors,errors
        browser.close()
    print('PASS: real Chromium navigation, logo click, keyboard, nine expressions, settings persistence, responsive dashboard')
finally:case.tearDown()
