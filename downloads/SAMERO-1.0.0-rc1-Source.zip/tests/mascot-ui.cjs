const assert=require('node:assert/strict');
const fs=require('node:fs');const vm=require('node:vm');
const source=fs.readFileSync(require('node:path').join(__dirname,'../web/mascot.js'),'utf8');
let clock=1000000000;let timer;const events={};const btnEvents={};
const el=(id)=>({id,src:'',textContent:'',offsetWidth:64,attrs:{},classList:{add(){},remove(){}},setAttribute(k,v){this.attrs[k]=v;},addEventListener(k,v){btnEvents[k]=v;}});
const img=el('mascot-image'),btn=el('mascot-toggle'),status=el('mascot-status');
const elements={'mascot-image':img,'mascot-toggle':btn,'mascot-status':status};
const saved={};const c=vm.createContext({Date:{now:()=>clock},Number,Object,JSON,Math,
  document:{getElementById:k=>elements[k],addEventListener:(k,v)=>events[k]=v},
  localStorage:{getItem:k=>saved[k],setItem:(k,v)=>saved[k]=v},
  matchMedia:()=>({matches:false}),setInterval:f=>timer=f});
vm.runInContext(source+'\nthis.mascot=SameroMascot;',c);
const m=c.mascot; const select=m.select;
for(const [input,expected] of [
  [{},'normal'],[{idleMs:8*60000},'idle'],[{idleMs:20*60000},'sleep'],
  [{runs:[{mode:'active',phase:'plan'}],idleMs:9999999},'research'],
  [{runs:[{mode:'active',phase:'work'}]},'focus'],
  [{runs:[{mode:'active',phase:'verify'}]},'test'],
  [{runs:[{mode:'active',phase:'release'}]},'test'],
  [{runs:[{mode:'review'}]},'warning'],[{fault:true},'warning'],
  [{chatStage:'running'},'focus'],[{chatStage:'limited'},'warning'],
  [{runs:[{mode:'done',at:clock/1000}],now:clock},'success'],
  [{runs:[{mode:'done',at:clock/1000,snapshot:true}],now:clock},'normal'],
  [{runs:[{mode:'active',retired:true,phase:'plan'}]},'normal']]) assert.equal(select(input),expected);
assert.equal(Object.keys(m.states).length,9);
assert.equal((m.gallery().match(/data-mascot-preview=/g)||[]).length,9);
let current={};m.mount(()=>current);
assert.equal(img.src,'/mascot/normal.png');
btnEvents.click();assert.equal(img.src,'/mascot/open.png');assert.equal(btn.attrs['aria-pressed'],'true');
clock+=25*60000;timer();assert.equal(img.src,'/mascot/open.png');
btnEvents.click();assert.equal(img.src,'/mascot/normal.png');assert.equal(btn.attrs['aria-pressed'],'false');
clock+=8*60000;timer();assert.equal(img.src,'/mascot/idle.png');
clock+=12*60000;timer();assert.equal(img.src,'/mascot/sleep.png');events.keydown();assert.equal(img.src,'/mascot/normal.png');
current={runs:[{mode:'active',phase:'work'}]};clock+=25*60000;timer();assert.equal(img.src,'/mascot/focus.png');
events.click({target:{closest:()=>({dataset:{mascotPreview:'success'}})}});assert.equal(img.src,'/mascot/success.png');clock+=5001;timer();assert.equal(img.src,'/mascot/focus.png');
events.change({target:{id:'mascot-auto',checked:false}});assert.equal(img.src,'/mascot/normal.png');assert.equal(JSON.parse(saved['samero-mascot-v1']).auto,false);
assert.match(m.gallery(),/id="mascot-auto" type="checkbox"><span>/);
console.log('PASS: 14 state mappings, nine gallery images, click/keyboard, idle/sleep, active override, preview, opt-out persistence.');
