/* Runs the generated PE entry point on Linux x64 against narrowly scoped API fixtures.
   This exercises the emitted machine code, not Windows loader behavior. */
#define _GNU_SOURCE
#include <assert.h>
#include <locale.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <uchar.h>

#define MS __attribute__((ms_abi))
typedef void (MS *Function)(void);

static uint16_t u16(const unsigned char *p) { uint16_t v; memcpy(&v,p,2); return v; }
static uint32_t u32(const unsigned char *p) { uint32_t v; memcpy(&v,p,4); return v; }
static uint64_t u64(const unsigned char *p) { uint64_t v; memcpy(&v,p,8); return v; }

static const char16_t *MS command(void) { return u"SAMERO --self-test \"Tiếng Việt\""; }
static char16_t **MS arguments(const char16_t *line, int *count) {
    assert(line==command());
    static char16_t executable[]=u"SAMERO.exe", flag[]=u"--self-test", unicode[]=u"Tiếng Việt";
    static char16_t *argv[]={executable,flag,unicode,NULL};
    *count=3;
    return argv;
}
static void *MS local_free(void *p) { assert(p); return NULL; }
static int MS utf16_to_utf8(unsigned codepage, unsigned flags, const char16_t *text, int length,
                            char *out, int cap, void *fallback, void *used) {
    assert(codepage==65001 && flags==128 && length==-1 && !fallback && !used);
    mbstate_t state={0};
    int n=0;
    for (;;) {
        char bytes[16];
        size_t m=c16rtomb(bytes,*text,&state);
        assert(m<sizeof(bytes) && n+(int)m<=cap);
        memcpy(out+n,bytes,m);
        n+=(int)m;
        if (!*text++) break;
    }
    return n;
}
static void MS finish(unsigned code) { exit((int)code); }
static int MS random_bytes(void *handle, void *out, unsigned n, unsigned flags) {
    assert(!handle && n==16 && flags==2);
    memset(out,0xa5,n);
    return 0;
}
static int MS format_hex(uint64_t options, char *out, size_t size, const char *pattern,
                         void *locale, const unsigned char *args) {
    assert(options==2 && !strcmp(pattern,"%08x") && !locale && size==9);
    return snprintf(out,size,"%08x",u32(args));
}
static void *MS sam_calloc(size_t n,size_t size) { return calloc(n,size); }
static void MS sam_free(void *p) { free(p); }
static int MS sam_strcmp(const char *a,const char *b) { return strcmp(a,b); }
static size_t MS sam_strlen(const char *s) { return strlen(s); }
static void *MS sam_memcpy(void *d,const void *s,size_t n) { return memcpy(d,s,n); }
static void *MS sam_memset(void *p,int c,size_t n) { return memset(p,c,n); }
static void MS unsupported(void) { fputs("Unexpected Windows API in startup self-test\n",stderr); abort(); }

static Function resolve(const char *name) {
#define IMPORT(symbol, fn) if (!strcmp(name,#symbol)) return (Function)fn
    IMPORT(GetCommandLineW,command);
    IMPORT(CommandLineToArgvW,arguments);
    IMPORT(LocalFree,local_free);
    IMPORT(WideCharToMultiByte,utf16_to_utf8);
    IMPORT(ExitProcess,finish);
    IMPORT(BCryptGenRandom,random_bytes);
    IMPORT(__stdio_common_vsprintf,format_hex);
    IMPORT(calloc,sam_calloc);
    IMPORT(free,sam_free);
    IMPORT(strcmp,sam_strcmp);
    IMPORT(strlen,sam_strlen);
    IMPORT(memcpy,sam_memcpy);
    IMPORT(memset,sam_memset);
#undef IMPORT
    return unsupported;
}
int main(int argc,char **argv) {
    assert(argc==2 && setlocale(LC_CTYPE,"C.UTF-8"));
    FILE *f=fopen(argv[1],"rb");
    assert(f && !fseek(f,0,SEEK_END));
    long size=ftell(f);
    assert(size>0 && !fseek(f,0,SEEK_SET));
    unsigned char *file=malloc((size_t)size);
    assert(file && fread(file,1,(size_t)size,f)==(size_t)size);
    fclose(f);
    const unsigned char *pe=file+u32(file+60), *opt=pe+24;
    const unsigned char *section=opt+u16(pe+20);
    uint32_t image_size=u32(opt+56);
    unsigned char *image=mmap(NULL,image_size,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    assert(image!=MAP_FAILED);
    for (unsigned i=0;i<u16(pe+6);++i,section+=40) {
        if (u32(section+16)) memcpy(image+u32(section+12),file+u32(section+20),u32(section+16));
    }
    uintptr_t delta=(uintptr_t)image-u64(opt+24);
    const unsigned char *reloc=image+u32(opt+152), *end=reloc+u32(opt+156);
    assert(delta && reloc<end);
    while (reloc<end) {
        for (uint32_t j=8;j<u32(reloc+4);j+=2) {
            unsigned item=u16(reloc+j);
            if (!item) continue;
            assert(item>>12==10);
            unsigned char *target=image+u32(reloc)+(item & 0xfff);
            uint64_t value=u64(target)+delta;
            memcpy(target,&value,sizeof(value));
        }
        reloc+=u32(reloc+4);
    }
    const unsigned char *header=image+u32(opt+120);
    for (;u32(header);header+=20) {
        const unsigned char *src=image+u32(header);
        unsigned char *dest=image+u32(header+16);
        while (u64(src)) {
            Function fn=resolve((const char *)image+u64(src)+2);
            memcpy(dest,&fn,sizeof(fn));
            src+=8; dest+=8;
        }
    }
    section=opt+u16(pe+20);
    for (unsigned i=0;i<u16(pe+6);++i,section+=40) {
        if (u32(section+36) & 0x20000000)
            assert(!mprotect(image+u32(section+12),u32(section+8),PROT_READ|PROT_EXEC));
    }
    Function entry=(Function)(image+u32(opt+16));
    free(file);
    entry();
    fputs("Unexpected return from Windows entry point\n",stderr);
    return 1;
}
