#!/usr/bin/env python3
"""Validate native icon resources independently from the resource generator."""
from pathlib import Path
import struct,sys
p=Path(sys.argv[1]);d=p.read_bytes();ico=(Path(__file__).resolve().parents[1]/'web/samero.ico').read_bytes()
pe=struct.unpack_from('<I',d,60)[0];n=struct.unpack_from('<H',d,pe+6)[0];osz=struct.unpack_from('<H',d,pe+20)[0];opt=pe+24
rrva,rsz=struct.unpack_from('<II',d,opt+112+16);assert rrva and rsz
sections=[]
for i in range(n):
 off=opt+osz+40*i;name,vs,rva,size,raw=struct.unpack_from('<8sIIII',d,off);sections.append((rva,size,raw))
def rd(rva,size):
 for base,n,raw in sections:
  if base<=rva and rva+size<=base+n:return d[raw+rva-base:raw+rva-base+size]
 raise AssertionError((rva,size))
def tree(offset=0,depth=0):
 assert depth<4 and offset<rsz
 head=rd(rrva+offset,16);nn,ni=struct.unpack_from('<HH',head,12);assert nn==0
 out={}
 for i in range(ni):
  name,v=struct.unpack('<II',rd(rrva+offset+16+8*i,8))
  if v&0x80000000:out[name]=tree(v&0x7fffffff,depth+1)
  else:
   a,size,_,_=struct.unpack('<IIII',rd(rrva+v,16));out[name]=rd(a,size)
 return out
r=tree();count=struct.unpack_from('<H',ico,4)[0];assert set(r)=={3,14} and len(r[3])==count==7
expected=bytearray(struct.pack('<HHH',0,1,count))
for i in range(count):
 entry=ico[6+16*i:22+16*i];size,off=struct.unpack_from('<II',entry,8);assert r[3][i+1][1033]==ico[off:off+size];expected.extend(entry[:12]+struct.pack('<H',i+1))
assert r[14][1][1033]==expected
print('PASS: 7 native icon images and group directory match source ICO')
