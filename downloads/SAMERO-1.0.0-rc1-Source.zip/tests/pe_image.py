#!/usr/bin/env python3
"""Validate an emitted SAMERO Windows image without the build toolchain."""
import argparse
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]

def align(value, alignment):
    return ((value + alignment - 1) // alignment) * alignment

def check(image):
    data = image.read_bytes()
    def unpack(fmt, offset):
        return struct.unpack_from("<" + fmt, data, offset)
    assert data[:2] == b"MZ", "DOS header"
    pe, = unpack("I", 60)
    assert data[pe:pe+4] == b"PE\0\0", "PE signature"
    machine, count, _, syms, symbol_count, optional_size, flags = unpack("HHIIIHH", pe+4)
    assert machine == 0x8664 and count > 0 and not flags & 1 and flags & 2
    assert not syms and not symbol_count, "Image includes a COFF symbol table"
    optional = pe+24
    assert unpack("H", optional) == (0x20b,)
    assert unpack("H", optional+68) == (2,)
    entry, = unpack("I", optional+16)
    image_alignment, file_alignment = unpack("II", optional+32)
    image_size, header_size, checksum = unpack("III", optional+56)
    assert pe+24+optional_size+count*40 <= header_size <= len(data)
    total = 0
    offset_checksum = optional+64
    for offset in range(0,len(data),2):
        if offset_checksum <= offset < offset_checksum+4:
            continue
        total += int.from_bytes(data[offset:offset+2], "little")
        total = (total & 0xffff) + (total >> 16)
    assert checksum == (total & 0xffff) + (total >> 16) + len(data), "PE checksum mismatch"

    sections = []
    next_rva = align(header_size, image_alignment)
    next_raw = header_size
    for i in range(count):
        name, vsize, rva, raw_size, raw, reloc, line, nr, nl, chars = unpack(
            "8sIIIIIIHHI", optional+optional_size+i*40
        )
        assert not (reloc or line or nr or nl), "Object metadata found in image"
        assert vsize > 0 and rva == next_rva, f"Non-adjacent section {name!r} at {rva:#x}"
        next_rva = align(rva + max(vsize,raw_size), image_alignment)
        if raw_size:
            assert raw == next_raw and raw_size % file_alignment == 0
            next_raw += raw_size
            assert next_raw <= len(data)
        else:
            assert not raw
        sections.append((rva, vsize, raw, raw_size, chars))
    assert next_rva == image_size and len(data) == next_raw
    assert any(start <= entry < start+size and chars & 0x20000000
               for start,size,_,_,chars in sections)

    def read_at(fmt, rva):
        return unpack(fmt, mapped(rva, struct.calcsize("<"+fmt)))

    def mapped(rva, size):
        for start, _, raw, raw_size, _ in sections:
            if raw and start <= rva and rva + size <= start + raw_size:
                return raw + rva - start
        raise AssertionError(f"Invalid mapped range {rva:#x}, {size}")

    def string_at(rva):
        pos = mapped(rva,1)
        end = data.index(b"\0",pos,pos+256)
        return data[pos:end].decode("ascii")

    import_rva, import_size = unpack("II", optional+112+8)
    iat_rva, iat_size = unpack("II", optional+112+8*12)
    assert import_size and iat_size
    expected = {}
    for line in (ROOT/"tools/imports.txt").read_text().splitlines():
        lib, *symbols = line.split()
        expected[f"{lib}.dll"] = symbols
    found = {}
    for i in range(len(expected)+1):
        ilt, stamp, forward, name, iat = read_at("IIIII", import_rva+i*20)
        if not (ilt or stamp or forward or name or iat):
            break
        assert not (stamp or forward) and iat_rva <= iat < iat_rva+iat_size
        lib = string_at(name)
        assert lib not in found
        found[lib] = []
        for j in range(len(expected[lib])+1):
            target, = read_at("Q",ilt+j*8)
            assert read_at("Q",iat+j*8) == (target,)
            if not target:
                break
            found[lib].append(string_at(target+2))
        else:
            raise AssertionError("Missing end of thunk table")
    else:
        raise AssertionError("Missing end of import descriptors")
    assert found == expected, f"Import mismatch: {found.keys()}"

    reloc_rva, reloc_size = unpack("II", optional+112+8*5)
    assert reloc_rva and reloc_size
    end = reloc_rva+reloc_size
    while reloc_rva < end:
        page, n = read_at("II",reloc_rva)
        assert n >= 8 and n % 4 == 0 and reloc_rva+n <= end
        for i in range(reloc_rva+8,reloc_rva+n,2):
            entry, = read_at("H",i)
            if not entry:
                continue
            assert entry >> 12 == 10, "Unexpected x64 base relocation"
            value, = read_at("Q",page+(entry & 0xfff))
            base, = unpack("Q",optional+24)
            assert base <= value < base+image_size
        reloc_rva += n
    print(f"{image.name}: checksum, sections, entry, imports, IAT and x64 relocations OK")

if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("image",type=Path)
    check(parser.parse_args().image)
