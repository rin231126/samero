#include "base.h"
#include <assert.h>
int main(void) {
    const char *daemon="C:/Users/Name/.codex-nick2/packages/app-server-daemon/releases/v/bin/codex.exe";
    const char *server[]={"codex.exe","-c","someOption=true","app-server","--listen","stdio://"};
    const char *background[]={"codex.exe","app-server","daemon","start"};
    const char *interactive[]={"codex.exe","resume","--","aaaaaaaa-aaaa-4aaa-aaaa-aaaaaaaaaaaa"};
    const char *normal[]={"codex.exe"};
    const char *batch[]={"codex.exe","exec","--","resume"};
    assert(classify_codex(daemon,NULL,0,0)==CODEX_DAEMON);
    assert(classify_codex(daemon,server,6,0)==CODEX_DAEMON);
    assert(classify_codex("C:/bin/codex.exe",background,4,0)==CODEX_DAEMON);
    assert(classify_codex("C:/bin/codex.exe",server,6,0)==CODEX_SERVER);
    assert(classify_codex(daemon,interactive,4,0)==CODEX_INTERACTIVE);
    assert(classify_codex("C:/bin/codex.exe",normal,1,0)==CODEX_INTERACTIVE);
    assert(classify_codex("C:/bin/codex.exe",batch,4,0)==CODEX_BATCH);
    assert(classify_codex("C:/bin/codex.exe",NULL,0,0)==CODEX_UNKNOWN);
    assert(classify_codex("C:/bin/codex-code-mode-host.exe",NULL,0,0)==CODEX_HOST);
    assert(classify_codex("C:/bin/codex.exe",server,6,1)==CODEX_MANAGED);
    puts("Codex process classification passed (10 fixtures)");
    return 0;
}
