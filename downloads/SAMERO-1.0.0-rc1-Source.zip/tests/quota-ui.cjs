/* Checks the real frontend views and timer/aggregation logic without a browser. */
const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");
const { runInNewContext } = require("node:vm");
const root = join(__dirname, "..");
const elements = new Map();
function node(selector) {
  if (!elements.has(selector)) elements.set(selector,{
    dataset:{}, handlers:{}, querySelector:node, querySelectorAll:() => [], setAttribute() {}, value:"", scrollTop:0, clientHeight:100, scrollHeight:100,
    addEventListener(type,fn) { this.handlers[type] = fn; },
    showModal() { this.open = true; },
    close() { this.open = false; }
  });
  return elements.get(selector);
}
// Mascot behavior has a separate state/DOM test in mascot-ui.cjs.
const context = {
  SameroMascot: {mount(){},gallery(){return "";}},
  SameroStudio: {mount(){},observe(){},settings(){return "";},milestones(){return "";},office(){return "";}},
  document: { documentElement:{dataset:{}},body:{dataset:{}},querySelector: node, querySelectorAll: () => [], addEventListener() {} },
  window: { addEventListener() {}, getSelection: () => null },
  sessionStorage: { getItem: () => null },
  location: { hash: "" },
  TextEncoder,
  FormData: class { *[Symbol.iterator]() {} },
  fetch: () => new Promise(() => {}),
  setInterval() {}
};
const entry = readFileSync(join(root, "web", "app.js"),"utf8");
const ui = runInNewContext(entry + `
  ({reload, latestState:()=>data, selectView:v=>{page=v;}, settingsPage,autonomousPanel,projectForm,visibleChatMessages,quotaSource,windowQuota,quotaWindows,quotaTotals,quotaBars,totalQuotaBars,countdown,guidePage,dashboard,
    accountsPage,chatPage,chatMessage,chatInspector,chatStatus,drawChat,drawChatSend,chooseChatProfile,actions,savedPanel,externalPanel,
    load(value) { data=value; }, setChat(value) { chatCache.set(chatProject,value); },
    rememberPrompt(text) { submittedPrompts.set(chatProject,{text,recoverable:false}); }
  })
`,context);
const now = 2000000000000;
const future = now / 1000 + 3705;
const week = now / 1000 + 86400 + 3705;
const official = {source:"official",status:"Signed in",at:now/1000,sync:{verified:now/1000},h:82,w:67,hr:future,wr:week};
const waiting = {...official,w:0};
const expired = {...official,hr:now / 1000};
const manual = {...official,source:"manual",h:28};
const unknown = {...official,h:12,w:null,wr:null};
const samples = [official,waiting,expired,manual,unknown];
const [shortWindow,weekWindow] = ui.quotaWindows;
assert.deepEqual({...ui.quotaTotals(samples,now,shortWindow)},{available:3,waiting:0,unknown:2,total:5});
assert.deepEqual({...ui.quotaTotals(samples,now,weekWindow)},{available:2,waiting:1,unknown:2,total:5});
assert.deepEqual({...ui.quotaTotals(samples,future * 1000,shortWindow)},{available:0,waiting:0,unknown:5,total:5});
assert.deepEqual({...ui.quotaTotals(samples,future * 1000,weekWindow)},{available:0,waiting:0,unknown:5,total:5});
const refreshed=samples.map(q=>({...q,at:future,sync:{verified:future}}));
assert.deepEqual({...ui.quotaTotals(refreshed,future * 1000,shortWindow)},{available:0,waiting:0,unknown:5,total:5});
assert.deepEqual({...ui.quotaTotals(refreshed,future * 1000,weekWindow)},{available:2,waiting:1,unknown:2,total:5});
assert.deepEqual({...ui.quotaTotals([{...official,sync:undefined}],now,shortWindow)},{available:0,waiting:0,unknown:1,total:1});
assert.equal(ui.windowQuota(0,future,now).percent,0);
assert.equal(ui.windowQuota(100,0,now).resetAt,null);
assert.equal(ui.windowQuota(150,future,now).percent,null);
assert.equal(ui.windowQuota(88,now / 1000,now).percent,null);
assert.equal(ui.countdown(future,now),"01:01:45");
assert.equal(ui.countdown(future,now + 1000),"01:01:44");
assert.equal(ui.countdown(week,now),"1 ngày 01:01:45");
assert.equal(ui.countdown(future,future * 1000 + 1),"00:00:00");

const observed={...official,at:now/1000,sync:{verified:now/1000}};
assert.equal(ui.quotaSource(observed,now),"Live");
assert.equal(ui.quotaSource({...observed,sync:{verified:0}},now),"Cached");
assert.equal(ui.quotaSource({...observed,sync:{offline:true}},now),"Offline");
assert.equal(ui.quotaSource({},now),"Unknown");
assert.equal(ui.quotaSource(observed,now+360000),"Cached");
assert.match(ui.quotaBars({...observed,h:0,w:15},now),/data-level="critical"[\s\S]*data-level="low"/);
assert.match(ui.quotaBars(observed,now),/data-level="normal"/);
assert.match(ui.quotaBars({...observed,sync:{}},now),/data-level="unknown"/);
assert.equal(ui.quotaTotals([{...observed,sync:{offline:true}}],now,shortWindow).available,0);
const bars = ui.quotaBars(official,now);
assert.match(bars, /5 giờ[\s\S]*82% còn lại/);
assert.match(bars, /1 tuần[\s\S]*67% còn lại/);
assert.match(bars, /Còn 1 ngày 01:01:45/);
const totals = ui.totalQuotaBars(samples,now);
assert.match(totals, /Tổng 5 giờ[\s\S]*<progress max="5" value="3"/);
assert.match(totals, /Tổng 1 tuần[\s\S]*<progress max="5" value="2"/);
assert.match(totals, /1 chờ reset · 2 chưa rõ/);
assert.match(ui.quotaBars(manual,now), /28% còn lại/);
assert.doesNotMatch(ui.totalQuotaBars([manual],now), /<progress/);
const emptyBars = ui.quotaBars({},now) + ui.totalQuotaBars([],now);
assert.equal((emptyBars.match(/class="quota-track"/g) || []).length,4);
assert.doesNotMatch(emptyBars, /<progress/);
assert.match(ui.quotaBars(expired,now), /Đã qua mốc reset/);
assert.doesNotMatch(ui.quotaBars(expired,now), /82% còn lại/);

ui.load({profiles:[{id:"a",name:"<Hồ sơ A>"}], quota:[{...official,profile:"a"}], sessions:[], auth:[]});
const dashboard = ui.dashboard(now);
assert.match(dashboard, /id="quota-profile"/);
assert.match(dashboard, /&lt;Hồ sơ A&gt;/);
assert.match(dashboard, /data-action="quota-refresh" data-id="a"/);
assert.match(ui.accountsPage(), /data-quota-total[\s\S]*data-quota-profile="a"/);
assert.match(ui.guidePage(), /Hướng dẫn sử dụng/);
assert.match(ui.guidePage(), /Kiểm tra và sao lưu/);
assert.match(ui.guidePage(), /Workspace → Tiếp tục phiên cũ/);
const shell = readFileSync(join(root,"web","index.html"),"utf8");
assert.match(shell, /data-page="guide"/);
assert.doesNotMatch(shell, /workspace\.webp/);
assert.match(shell, /data-page="chat" aria-current="page"/);
ui.load({profiles:[{id:"a",name:"Codex 1"},{id:"b",name:"Codex 2"}], projects:[{id:"p",name:"Dự án mẫu",path:"C:/Workspace"}],
  quota:[], auth:[], checkpoints:[]});
assert.match(ui.chatPage(), /id="chat-project-menu"[\s\S]*\+ Thêm dự án[\s\S]*id="chat-prompt"/);
assert.match(ui.chatPage(), /id="chat-profile-menu"[\s\S]*\+ Thêm hồ sơ/);
assert.match(ui.chatPage(), /id="chat-quota-profile"[\s\S]*data-quota-total/);
assert.match(ui.chatInspector(), /Workspace[\s\S]*Bàn giao gần nhất/);
assert.equal(ui.chatStatus({stage:"limited"})[0],"Đã chạm hạn mức");
assert.equal(ui.chatStatus({stage:"auth"})[0],"Cần đăng nhập");
ui.setChat({profile:"",active:false,stage:"closed"});
ui.drawChat();
assert.equal(node("#chat-prompt").readOnly,false);
assert.equal(node("#chat-project-selection").textContent,"Dự án mẫu");
assert.equal(node("#chat-send").disabled,true);
node("#chat-prompt").value = "Xin chào";
ui.drawChatSend(node("#chat-prompt"));
assert.equal(node("#chat-send").disabled,false);
ui.rememberPrompt("Prompt vừa gửi");
ui.setChat({profile:"a",active:false,stage:"auth"});
ui.drawChat();
assert.equal(node("#chat-prompt").readOnly,false);
assert.equal(node("#chat-notice").hidden,false);
assert.equal(node("#chat-login").hidden,false);
assert.equal(node("#chat-send").disabled,false);
assert.match(node("#chat-controls").innerHTML, /Lấy lại tin nhắn/);
ui.setChat({profile:"a",active:true,stage:"ready",model:"model-fixture"});
ui.drawChat();
assert.equal(node("#chat-model").textContent,"model-fixture");
assert.equal(node("#chat-send").disabled,false);
assert.match(node("#chat-controls").innerHTML, /Lấy lại tin nhắn/);
ui.setChat({profile:"a",active:false,stage:"closed",session:"saved-session"});
ui.drawChat();
assert.match(node("#chat-profile-options").innerHTML,/aria-current="true">Codex 1[\s\S]*>Codex 2/);
ui.chooseChatProfile("b");
assert.match(node("#dialog-body").innerHTML,/Bàn giao hồ sơ[\s\S]*value="b" selected/);
ui.actions["chat-fresh"]();
assert.match(node("#dialog-body").innerHTML,/Tạo luồng Codex mới[\s\S]*Tạo và mở luồng/);
const shown = ui.chatMessage({role:"assistant",profile:"a",text:'<script>bad()</script>\n```js\nconst x = "value";\n```'});
assert.match(shown, /&lt;script&gt;bad\(\)&lt;\/script&gt;/);
assert.match(shown, /<pre><code>const x = &quot;value&quot;;<\/code><\/pre>/);
ui.load({profiles:[], settings:{terminalHome:"C:/Users/example/.codex",windowsTerminal:true},
  imports:[{id:"x",thread:"saved-id",workspace:"C:/Workspace",home:"C:/Users/example/.codex",updated:1000}], external:[]});
const prior = ui.savedPanel();
assert.match(prior, /Phiên Codex Terminal hiện có[\s\S]*saved-id[\s\S]*Đã nhập/);
assert.match(prior, /Tiếp tục phiên đã chọn/);
assert.match(prior, /Mở trong chat/);
assert.match(prior, /Mở trong terminal ngoài/);
assert.match(ui.externalPanel(), /Terminal bên ngoài/);
ui.load({projects:[{id:"p",name:"Sample"}],profiles:[{id:"a",name:"One"},{id:"b",name:"Two"}],
  runs:[{id:"r",project:"p",profile:"a",mode:"paused",phase:"test",goal:"<goal>",tasks:[{title:"T",accept:"C",after:-1,status:"NOT VERIFIED"}],index:0,log:[],test:"PASS",build:"NOT VERIFIED"}]});
const auto=ui.autonomousPanel();
for (const a of ["runner-new","runner-resume","runner-handover","runner-stop"]) {
  assert.match(auto,new RegExp('data-action="'+a+'"')); assert.equal(typeof ui.actions[a],"function");
}
assert.match(auto,/&lt;goal&gt;/);
ui.projectForm({id:"p",name:"Demo",path:"C:/Demo",goal:"Test"});
assert.match(node("#dialog-body").innerHTML,/name="goal"/);
assert.doesNotMatch(node("#dialog-body").innerHTML,/name="architecture"|name="errors"/);
ui.load({settings:{theme:"dark",autoApproval:true}});
assert.match(ui.settingsPage(),/name="autoApproval" checked/);
ui.load({settings:{theme:"dark",autoApproval:false}});
assert.doesNotMatch(ui.settingsPage(),/name="autoApproval" checked/);
assert.equal(typeof ui.actions["review-history"],"function");
async function verifyFreshChatRequest() {
  ui.load({profiles:[{id:"a",name:"Codex 1"}],projects:[{id:"p",name:"Dự án mẫu"}],quota:[],auth:[],checkpoints:[]});
  ui.chatPage();
  ui.setChat({profile:"a",active:false,stage:"closed",session:"saved-session"});
  ui.actions["chat-fresh"]();
  const requests = [];
  context.fetch = async (url,opts) => {
    requests.push({url,body:JSON.parse(opts.body)});
    return {ok:true,json:async () => url.endsWith("chat-open") ? {id:"new-session"} :
      {stage:"ready",profile:"a",active:true,session:"new-session"}};
  };
  node("#dialog-form").handlers.submit({preventDefault(){}});
  await new Promise(resolve => setImmediate(resolve));
  assert.deepEqual(requests.map(x => x.url),["/api/chat-open","/api/chat-state"]);
  assert.deepEqual(requests[0].body,{project:"p",profile:"a",fresh:true});
  const logs=[{session:"previous",text:"no rollout found"},{session:"new-session",text:"new"}];
  const shown=ui.visibleChatMessages({session:"new-session",messages:logs});
  assert.deepEqual(Array.from(shown,m=>m.text),["new"]);
  assert.equal(node("#dialog").open,false);
  assert.match(node("#chat-stage").innerHTML,/Sẵn sàng/);
}
async function verifyOutOfOrderState() {
  ui.selectView("guide"); node("#dialog").open=false;
  const pending=[];
  context.fetch=()=>new Promise(resolve=>pending.push(value=>resolve({ok:true,json:async()=>value})));
  const old=ui.reload(),fresh=ui.reload();
  pending[1]({settings:{theme:"dark"},runs:[{revision:25}]}); await fresh;
  pending[0]({settings:{theme:"dark"},runs:[{revision:18}]}); await old;
  assert.equal(ui.latestState().runs[0].revision,25);
}
const markup=entry+"\n"+readFileSync(join(root,"web","index.html"),"utf8");
const fixedActions=new Set([...markup.matchAll(/data-action="([a-z][a-z-]*)"/g),
  ...entry.matchAll(/button\(\s*"[^"]*"\s*,\s*"([a-z][a-z-]*)"/g)].map(m=>m[1]));
for (const name of fixedActions) assert.equal(typeof ui.actions[name],"function",name);
verifyFreshChatRequest().then(verifyOutOfOrderState).then(() => {
  console.log("UI tests passed, including stale state responses and "+fixedActions.size+" literal button routes.");
}).catch(error => {
  console.error(error);
  process.exitCode = 1;
});
