#include "../src/runner.c"
int main(void) {
    Run *run=allocate(sizeof(*run));
    run->count=16; run->index=4; run->phase=TEST; run->mode=ACTIVE;
    strcpy(run->session,"11111111111111111111111111111111");
    for (int i=0;i<4;++i) strcpy(run->tasks[i].evidence,"accepted evidence");
    Task *task=&run->tasks[4];
    const char *old="BLOCKED_PREFLIGHT: command/exec timed out";
    strcpy(task->evidence,old);
    strcpy(task->test_signature,"3333333333333333333333333333333333333333333333333333333333333333");
    strcpy(task->verify_observation,"session=22222222222222222222222222222222");
    Task *expected=allocate(4*sizeof(Task));
    memcpy(expected,run->tasks,4*sizeof(Task));
    check_finished(run,0,"");
    int ok=run->phase==VERIFY && run->mode==ACTIVE && run->index==4 && run->test==1 &&
        run->snapshot && !run->inflight && !strcmp(task->test_session,run->session) &&
        !memcmp(expected,run->tasks,4*sizeof(Task)) && !strcmp(task->evidence,old) &&
        !strcmp(task->test_signature,"3333333333333333333333333333333333333333333333333333333333333333") &&
        !*review_blocker(run->reason);
    run->mode=REVIEW;
    ok=ok && !*current_verify_blocker(run);
    note(run,old);
    ok=ok && !strcmp(current_verify_blocker(run),"BLOCKED_PREFLIGHT");
    free(expected);free(run);
    if (!ok) return 1;
    puts("PASS: R183 historical evidence, current blocker, preserved receipts and TEST-to-VERIFY");
    return 0;
}
