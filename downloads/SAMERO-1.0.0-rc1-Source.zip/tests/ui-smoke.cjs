/* Run against the Linux development build with Playwright and Chromium. */
const assert = require("node:assert/strict");
const { mkdtemp, mkdir, readFile, rm } = require("node:fs/promises");
const { tmpdir } = require("node:os");
const { join } = require("node:path");
const { spawn } = require("node:child_process");
const { chromium } = require("playwright");

(async () => {
  const root = await mkdtemp(join(tmpdir(), "samero-ui-"));
  const storage = join(root, "Dữ liệu");
  const project = join(root, "Mã nguồn ứng dụng");
  await mkdir(project);
  const app = spawn(process.argv[2], ["--headless", "--data-dir", storage], { stdio: "inherit" });
  let browser;
  try {
    let url;
    for (let i=0; i<150 && !url; i++) {
      try { url=await readFile(join(storage,"ui.url"),"utf8"); }
      catch { await new Promise(resolve => setTimeout(resolve,30)); }
    }
    assert(url);
    browser = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || "/usr/bin/chromium", headless:true, args:["--no-sandbox"]});
    const page = await browser.newPage({ viewport: {width:1380,height:900} });
    const errors = [];
    page.on("pageerror", error => errors.push(error.message));
    await page.goto(url);
    await page.getByRole("button", {name:"Mở phiên",exact:true}).waitFor();
    await page.getByRole("heading",{name:"Tổng 5 giờ",exact:true}).waitFor();
    await page.getByRole("heading",{name:"Tổng 1 tuần",exact:true}).waitFor();
    for (const viewport of [{width:1920,height:1080},{width:1024,height:660},{width:430,height:640}]) {
      await page.setViewportSize(viewport);
      const rect=await page.locator("#chat-prompt").boundingBox();
      assert(rect && rect.y >= 0 && rect.y+rect.height <= viewport.height);
      assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    }
    await page.getByRole("button",{name:"Hồ sơ Codex",exact:true}).click();
    await page.getByRole("button",{name:"Hạn mức",exact:true}).click();
    await page.getByRole("heading", {name:"Dashboard",exact:true}).waitFor();
    await page.getByRole("heading", {name:"Tổng 5 giờ",exact:true}).waitFor();
    await page.getByRole("heading", {name:"Tổng 1 tuần",exact:true}).waitFor();
    await page.getByRole("button",{name:"Hướng dẫn",exact:true}).click();
    await page.getByRole("heading",{name:"Hướng dẫn sử dụng",exact:true}).waitFor();
    await page.getByRole("button",{name:"Mở Dashboard",exact:true}).click();
    await page.locator(".hero").getByRole("button",{name:"+ Thêm hồ sơ"}).click();
    await page.getByLabel("Tên hồ sơ").fill("Codex thử nghiệm");
    await page.getByLabel("CODEX_HOME").fill(join(root,"Hồ sơ riêng"));
    await page.getByRole("button",{name:"Lưu hồ sơ"}).click();
    await page.getByText("Đã lưu hồ sơ.").waitFor();
    await page.getByRole("button",{name:"Hồ sơ Codex",exact:true}).click();
    await page.getByRole("button",{name:"Nhập hạn mức"}).click();
    await page.getByLabel("Còn lại 5 giờ (%)").fill("42");
    await page.getByLabel("Còn lại 1 tuần (%)").fill("81");
    const reset = new Date(Date.now() + 3600000);
    const localReset = new Date(reset - reset.getTimezoneOffset()*60000).toISOString().slice(0,16);
    await page.getByLabel("Reset 5 giờ").fill(localReset);
    await page.getByLabel("Reset 1 tuần").fill(localReset);
    await page.getByLabel("Số credit").fill("10.25");
    await page.getByLabel("Đơn vị credit").fill("credits");
    await page.getByLabel("Mã nhóm credit do bạn xác minh").fill("fixture");
    await page.getByRole("button",{name:"Lưu mẫu"}).click();
    await page.getByText("Đã ghi nhận hạn mức.").waitFor();
    await page.getByRole("button",{name:"Hạn mức",exact:true}).click();
    await page.getByText("10.25 credits").first().waitFor();
    await page.getByText("42% còn lại", {exact:true}).waitFor();
    await page.getByText("81% còn lại", {exact:true}).waitFor();
    assert.equal(await page.locator("[data-countdown]").count(),2);
    const firstTimer = await page.locator("[data-countdown]").first().textContent();
    await page.waitForFunction(initial => document.querySelector("[data-countdown]")?.textContent !== initial,firstTimer);
    assert.equal(await page.getByText("0 chờ reset · 1 chưa rõ",{exact:true}).count(),2);
    await page.locator("#chart-wrap").waitFor();
    await page.getByRole("button",{name:"Dự án",exact:true}).click();
    await page.getByRole("button",{name:"+ Thêm dự án"}).click();
    await page.getByLabel("Tên dự án").fill("Workspace mẫu");
    await page.getByLabel("Thư mục mã nguồn").fill(project);
    assert.equal(await page.locator("#dialog-form input").count(),2);
    await page.getByRole("dialog").getByRole("button",{name:"Thêm dự án",exact:true}).click();
    await page.getByText("Đã thêm dự án.").waitFor();
    await page.getByRole("button",{name:"Workspace",exact:true}).click();
    // Trusted input must reach the original DOM node throughout the click.
    await page.evaluate(() => {
      window.pickerBeforeClick=document.querySelector("#chat-project");
      document.addEventListener("click",e => { window.pickerClickTarget=e.target.closest("summary")?.id; },{once:true,capture:true});
    });
    await page.locator("#chat-project").click();
    assert(await page.evaluate(() => window.pickerClickTarget==="chat-project" &&
      document.querySelector("#chat-project")===window.pickerBeforeClick && document.querySelector("#chat-project-menu").open));
    await page.locator("#chat-project-options").getByRole("button",{name:"Workspace mẫu"}).waitFor();
    await page.locator("#chat-project-menu").getByRole("button",{name:"+ Thêm dự án"}).waitFor();
    await page.keyboard.press("Escape");
    assert.equal(await page.locator("#chat-project-menu").getAttribute("open"),null);
    await page.locator("#chat-profile").click();
    await page.locator("#chat-profile-options").getByRole("button",{name:"Codex thử nghiệm"}).waitFor();
    await page.locator("#chat-profile-menu").getByRole("button",{name:"+ Thêm hồ sơ"}).click();
    await page.getByRole("dialog").getByRole("heading",{name:"Thêm hồ sơ"}).waitFor();
    await page.getByRole("dialog").getByRole("button",{name:"Hủy"}).click();
    assert.equal(await page.locator("#chat-send").isDisabled(),true);
    await page.locator("#chat-prompt").click();
    assert(await page.locator("#chat-prompt").evaluate(el => el===document.activeElement));
    await page.keyboard.insertText("Bản nháp kiểm thử");
    assert.equal(await page.locator("#chat-send").isEnabled(),true);
    await page.getByRole("button",{name:"Dự án",exact:true}).click();
    await page.getByRole("button",{name:"Chi tiết",exact:true}).click();
    await page.getByRole("heading",{name:"PROJECT_STATUS.md",exact:true}).waitFor();
    await page.getByRole("button",{name:"Tạo tệp trạng thái",exact:true}).click();
    await page.getByText("Đã tạo PROJECT_STATUS.md.",{exact:true}).waitFor();
    await page.getByRole("button",{name:"Sao lưu workspace",exact:true}).click();
    await page.getByRole("checkbox").check();
    await page.getByRole("button",{name:"Tạo ZIP"}).click();
    await page.getByText("Đã lưu và xác minh", {exact:false}).waitFor();
    await page.getByText("Checkpoint dự án",{exact:true}).click();
    await page.getByRole("button",{name:"Xác minh",exact:true}).click();
    await page.getByText("Đã xác minh manifest", {exact:false}).waitFor();
    await page.locator("nav").getByRole("button",{name:"Bàn giao",exact:true}).click();
    await page.getByRole("heading",{name:"Bàn giao workspace"}).waitFor();
    await page.getByRole("button",{name:"Cài đặt",exact:true}).click();
    await page.getByLabel("Giao diện").selectOption("light");
    await page.getByRole("button",{name:"Lưu cài đặt"}).click();
    await page.getByText("Đã lưu cài đặt.").waitFor();
    assert.equal(await page.locator("html").getAttribute("data-theme"),"light");
    assert.deepEqual(errors,[]);
    console.log("Browser smoke: dashboard, profiles, chart, project, backup, verification, handover, settings OK");
  } finally {
    if (browser) await browser.close();
    app.kill();
    await rm(root,{recursive:true,force:true});
  }
})().catch(error => { console.error(error); process.exitCode=1; });
