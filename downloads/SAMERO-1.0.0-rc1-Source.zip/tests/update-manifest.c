#include "../src/manager.h"
#include <assert.h>
static const char *sha="0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";
static void check(const char *channel,long long sequence,long long current,const char *version,const char *digest,long long size,int ok,const char *status) {
    char body[512],actual[32]; Buf out={0}; Error e={0};
    int n=sam_format(body,sizeof(body),"{\"schema\":1,\"channel\":\"%s\",\"version\":\"%s\",\"sequence\":%lld,\"sha256\":\"%s\",\"bytes\":%lld,\"url\":\"https://untrusted.invalid/evil.exe\"}",channel,version,sequence,digest,size);
    assert(n>0 && n<(int)sizeof(body));
    assert(public_update_parse(body,(size_t)n,current,&out,&e)==ok);
    if(ok) { JSON j; assert(json_parse(&j,out.s,out.n)); ARG(&j,"status",actual); assert(!strcmp(actual,status)); assert(!strstr(out.s,"untrusted.invalid")); json_free(&j); }
    else assert(e.msg[0] && !out.n);
    buffer_free(&out);
}
int main(void) {
    check("public",11,10,SAM_VERSION,sha,1000,1,"available");
    check("public",10,10,SAM_VERSION,sha,1000,1,"current");
    check("public",9,10,SAM_VERSION,sha,1000,1,"current");
    check("developer",11,10,SAM_VERSION,sha,1000,0,"");
    check("public",11,10,"1.1",sha,1000,0,"");
    check("public",11,10,SAM_VERSION,"bad",1000,0,"");
    check("public",11,10,SAM_VERSION,sha,0,0,"");
    check("public",11,10,SAM_VERSION,sha,64*MIB+1,0,"");
    check("public",-1,10,SAM_VERSION,sha,1000,0,"");
    puts("PASS: 9 manifest cases; fixed update URL; downgrade not offered");
}
