#include "../src/manager.h"
#include <assert.h>
static void copy(const char *src,const char *dest,char digest[65],long long *size){
 Error e={0}; Buf bytes={0};assert(read_file(src,64*MIB,&bytes,&e));Sha256 s={0};sha_update(&s,bytes.s,bytes.n);sha_finish(&s,digest);*size=(long long)bytes.n;assert(write_new_atomic(dest,bytes.s,bytes.n,&e));buffer_free(&bytes);
}
int main(int argc,char **argv){
 assert(argc==3);Path p={0},bad={0};char digest[65];long long size; Error e={0};
 assert(path_join(&p,argv[1],"SAMERO-update-0123456789abcdef0123456789abcdef.exe"));copy(argv[2],p.p,digest,&size);
 FILE *f=public_update_verified_file(argv[1],p.p,size,digest,&e);assert(f);fclose(f);
 assert(!public_update_verified_file(argv[1],p.p,size+1,digest,&e));
 assert(!public_update_verified_file(argv[1],p.p,size,"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",&e));
 assert(!public_update_verified_file("/not-the-manager-root",p.p,size,digest,&e));
 assert(path_join(&bad,argv[1],"wrong-name.exe"));assert(move_file(p.p,bad.p,0));assert(!public_update_verified_file(argv[1],bad.p,size,digest,&e));assert(move_file(bad.p,p.p,0));
 assert(remove_file(p.p));unsigned char sample[128]={0};Sha256 h={0};sha_update(&h,sample,sizeof(sample));sha_finish(&h,digest);assert(write_new_atomic(p.p,sample,sizeof(sample),&e));assert(!public_update_verified_file(argv[1],p.p,sizeof(sample),digest,&e));assert(remove_file(p.p));
 assert(acquire_instance(argv[1]));release_instance();assert(acquire_instance(argv[1]));release_instance();
 puts("PASS: staged PE verification, size/hash/path/name rejection, non-PE rejection, release/reacquire instance lock");
}
