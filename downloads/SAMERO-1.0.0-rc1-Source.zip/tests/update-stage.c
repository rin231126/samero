#include "../src/manager.h"
#include <assert.h>
typedef struct { const char *bytes; size_t len,off; int broken; long long last,total; } Input;
static int read_chunk(void *v,void *buf,size_t cap){Input *i=v;if(i->off>=i->len)return i->broken?-1:0;size_t n=i->len-i->off;if(n>cap)n=cap;if(n>2)n=2;memcpy(buf,i->bytes+i->off,n);i->off+=n;return (int)n;}
static void progress(long long done,long long total,void *v){Input *i=v;assert(done>=i->last&&done<=total);assert(!i->total||i->total==total);i->last=done;i->total=total;}
static void test(const char *dir,const char *bytes,int size,int broken,int ok,const char *digest){
 Input i={bytes,strlen(bytes),0,broken,0,0};Buf out={0};Error e={0};assert(public_update_stage(dir,size,digest,read_chunk,&i,progress,&out,&e)==ok);
 if(ok){JSON j;assert(json_parse(&j,out.s,out.n));Path path;assert(ARG(&j,"path",path.p));assert(within(dir,path.p));Buf contents={0};assert(read_file(path.p,100,&contents,&e));assert(contents.n==strlen(bytes)&&!memcmp(contents.s,bytes,contents.n));buffer_free(&contents);json_free(&j);assert(remove_file(path.p));assert(i.last==size);}
 else { assert(e.msg[0]&&!out.n); } buffer_free(&out);
}
int main(int argc,char **argv){assert(argc==2);const char *hash="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";test(argv[1],"abc",3,0,1,hash);test(argv[1],"ab",3,0,0,hash);test(argv[1],"abcd",3,0,0,hash);test(argv[1],"abd",3,0,0,hash);test(argv[1],"abc",3,1,0,hash);test(argv[1],"abc",0,0,0,hash);test(argv[1],"abc",3,0,0,"bad");puts("PASS: 7 streaming and integrity cases");}
