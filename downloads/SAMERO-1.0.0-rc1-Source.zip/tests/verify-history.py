"""Offline regression cases for the privacy-preserving historical diagnostic."""
import importlib.util
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

MODULE = Path(__file__).resolve().parents[1] / "tools/inspect-verify-history.py"
spec = importlib.util.spec_from_file_location("inspect_history", MODULE)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class HistoricalVerify(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        folder = Path(temp.name)
        self.session, self.trace = folder/"session.json", folder/"rollout.jsonl"
        self.manager = {"id":"a"*32, "kind":"chat", "chatThread":"th-1", "workspace":r"C:\Example"}
        self.session.write_text(json.dumps(self.manager))
        self.records = [("session_meta", {"id":"th-1","cwd":r"c:\example"})]
        self.add_turn("first","SAMERO WORK.","exec_command failed: CreateProcess { message: denied by policy }")
        self.add_turn("second","SAMERO VERIFY. Inspect fixture.",
                      'exec_command failed: CreateProcess { message: "Rejected(\\"fixture rejected: blocked by policy\\")" }')

    def add_turn(self, tid, prompt, output, completed=True):
        self.records += [
            ("event_msg", {"type":"task_started","turn_id":tid}),
            ("turn_context", {"turn_id":tid}),
            ("response_item", {"type":"message","role":"user","content":[{"type":"input_text","text":prompt}]}),
            ("response_item", {"type":"function_call","call_id":"reused","name":"exec_command","arguments":"private-fixture"}),
            ("response_item", {"type":"function_call_output","call_id":"reused","output":output}),
            ("response_item", {"type":"function_call_output","call_id":"reused","output":output})]
        if completed:
            self.records.append(("event_msg", {"type":"task_complete","turn_id":tid}))

    def inspect(self, tid=None):
        self.trace.write_text("".join(json.dumps({"type":k,"payload":p})+"\n" for k,p in self.records))
        return audit.inspect(self.session,self.trace,tid)

    def test_only_exact_verify_turn_and_no_content(self):
        original=self.session.read_bytes()
        before=self.inspect(); self.assertEqual((before["toolErrorsWithoutCommandEnd"],before["commandEndEventsObserved"],before["denialOutputsObserved"]),(1,0,1))
        trace_bytes=self.trace.read_bytes(); same=audit.inspect(self.session,self.trace)
        self.assertEqual(before,same);self.assertEqual(original,self.session.read_bytes());self.assertEqual(trace_bytes,self.trace.read_bytes())
        for private in ("private-fixture","blocked by policy","Example","SAMERO VERIFY"):
            self.assertNotIn(private,json.dumps(before))

    def test_wrong_binding_and_ambiguous_turn_fail(self):
        self.add_turn("third","SAMERO VERIFY. Another.","ordinary output")
        with self.assertRaises(ValueError):self.inspect()
        self.assertEqual(self.inspect("third")["toolErrorsWithoutCommandEnd"],0)
        self.manager["chatThread"]="foreign";self.session.write_text(json.dumps(self.manager))
        with self.assertRaises(ValueError):self.inspect("third")
        self.manager.update(chatThread="th-1",workspace=r"D:\Other");self.session.write_text(json.dumps(self.manager))
        with self.assertRaises(ValueError):self.inspect("third")

    def test_incomplete_turn_and_quoted_text(self):
        self.add_turn("third","SAMERO VERIFY. Check.","Process exited with code 0\nOutput:\nexec_command failed: CreateProcess { denied by policy }",False)
        result=self.inspect("third")
        self.assertFalse(result["turnEndRecorded"]);self.assertEqual(result["denialOutputsObserved"],0)

    def make_layout(self):
        root = self.session.parent
        data, home = root / "manager", root / "profile"
        profile = "b" * 32
        thread = "0a12b456-1234-45ef-86ab-55d5000000aa"
        self.manager.update(profile=profile, chatThread=thread,
                            chatHome=hashlib.sha256(str(home).encode()).hexdigest())
        self.records[0][1]["id"] = thread
        (data / "sessions").mkdir(parents=True)
        (data / "profiles").mkdir()
        day = home / "sessions" / "2026" / "11" / "25"
        day.mkdir(parents=True)
        self.session = data / "sessions" / (self.manager["id"] + ".json")
        self.session.write_text(json.dumps(self.manager))
        (data / "profiles" / (profile + ".json")).write_text(json.dumps({"id":profile, "home":str(home)}))
        self.trace = day / ("rollout-test-" + thread + ".jsonl")
        self.inspect()
        return data, home

    def test_locate_exact_profile_and_journal(self):
        data, home = self.make_layout()
        (home / "auth.json").write_text("unreadable as JSON")
        self.trace.with_name("rollout-other-thread.jsonl").write_text("unreadable as JSON")
        before = self.trace.read_bytes()
        paths = audit.locate(self.manager["id"], data)
        self.assertEqual(paths,(self.session,self.trace))
        self.assertEqual(audit.inspect(*paths)["toolErrorsWithoutCommandEnd"],1)
        self.assertEqual(before,self.trace.read_bytes())

    def test_locate_rejects_ambiguity_and_changed_profile(self):
        data, _ = self.make_layout()
        self.trace.with_name(self.trace.name.replace("test","duplicate")).write_bytes(self.trace.read_bytes())
        with self.assertRaisesRegex(audit.BindingError,"đúng một"): audit.locate(self.manager["id"], data)
        self.manager["chatHome"] = "f" * 64
        self.session.write_text(json.dumps(self.manager))
        with self.assertRaisesRegex(audit.BindingError,"không khớp"): audit.locate(self.manager["id"], data)
        with self.assertRaises(audit.BindingError): audit.locate("../profiles", data)

    def test_locate_ignores_directory_link_and_foreign_thread(self):
        data, home = self.make_layout()
        elsewhere = self.session.parent.parent.parent / "different-history"
        self.trace.parent.rename(elsewhere)
        if hasattr(Path,"symlink_to"):
            try:
                (home / "sessions" / "2026" / "11" / "25").symlink_to(elsewhere,target_is_directory=True)
            except OSError:
                pass
        self.trace = home / "sessions" / self.trace.name
        self.records[0][1]["id"] = "foreign"
        with self.assertRaises(ValueError): self.inspect()
        with self.assertRaisesRegex(ValueError,"mismatch"): audit.inspect(*audit.locate(self.manager["id"], data))
        self.trace.unlink()
        with self.assertRaises(audit.BindingError): audit.locate(self.manager["id"], data)

if __name__=="__main__":unittest.main(verbosity=2)
