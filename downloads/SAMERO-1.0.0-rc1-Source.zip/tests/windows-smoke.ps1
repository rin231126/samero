param(
    [Parameter(Mandatory=$true)][string]$Exe,
    [string]$CodexExe,
    [switch]$Pickers,
    [switch]$LiveChat,
    [switch]$LiveAutonomous,
    [switch]$LiveAutoApproval,
    [string]$CodexHome
)
$ErrorActionPreference = 'Stop'
if ($LiveAutoApproval) { $LiveAutonomous = $true }
$Exe = (Resolve-Path -LiteralPath $Exe).Path
if (($LiveChat -or $LiveAutonomous) -and (!$CodexExe -or !$CodexHome)) { throw 'Live checks require -CodexExe and an existing -CodexHome.' }
$self = Start-Process -FilePath $Exe -ArgumentList '--self-test' -Wait -PassThru
if ($self.ExitCode -ne 0) { throw "EXE startup self-test failed, exit code $($self.ExitCode)" }
$root = Join-Path ([IO.Path]::GetTempPath()) ("SAMERO smoke " + [guid]::NewGuid())
$storage = Join-Path $root 'data'
$workspace = Join-Path $root ("workspace " + [char]0x1EBF)
$backup = Join-Path $root 'restore'
$null = New-Item -ItemType Directory -Path $workspace,$backup
$file = Join-Path $workspace ("progress " + [char]0x1EBF + ".txt")
$null = Set-Content -LiteralPath $file -Value 'local changes'
$null = Set-Content -LiteralPath (Join-Path $workspace '.env') -Value 'OPENAI_API_KEY=test-only'

function Api([string]$Action,[hashtable]$Body = @{}) {
    $json = ConvertTo-Json -InputObject $Body -Depth 8 -Compress
    Invoke-RestMethod -Uri "$origin/api/$Action" -Method Post -Headers $headers -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes($json))
}
function Wait-ChatReady([string]$Session,[string]$Reply) {
    for ($i=0; $i -lt 240; $i++) {
        $chat = Api 'chat-state' @{project=$project.id}
        if ($chat.stage -in @('auth','error','startup','limited')) { throw "Chat failed: $($chat.stage)" }
        if ($chat.active -and $chat.stage -eq 'ready' -and $chat.session -eq $Session) {
            if (!$Reply) { return }
            $answer = @($chat.messages | Where-Object {
                $_.session -eq $Session -and $_.role -eq 'assistant' -and $_.text.Trim() -ceq $Reply
            })
            if ($answer.Count) { return }
        }
        Start-Sleep -Milliseconds 500
    }
    throw 'Timed out waiting for the selected session or its expected reply.'
}
function Close-Chat([string]$Session) {
    $null = Api 'chat-close' @{project=$project.id;session=$Session}
    for ($i=0; $i -lt 40; $i++) {
        if (!(Api 'chat-state' @{project=$project.id}).active) { return }
        Start-Sleep -Milliseconds 250
    }
    throw 'The Codex process did not close.'
}
function Open-Manager {
    $script:child = Start-Process -FilePath $Exe -ArgumentList @('--headless','--data-dir',('"' + $storage + '"')) -PassThru
    $urlFile = Join-Path $storage 'ui.url'
    for ($i=0; $i -lt 100 -and !(Test-Path -LiteralPath $urlFile); $i++) {
        if ($child.HasExited) { throw "Manager exited with $($child.ExitCode)" }
        Start-Sleep -Milliseconds 75
    }
    $script:origin,$token = ([IO.File]::ReadAllText($urlFile)) -split '/#'
    $script:headers = @{Origin=$origin;'X-Samero-Key'=$token}
}
try {
    Open-Manager
    $settings = (Api 'state').settings
    $profile = Api 'profile-save' @{name='Profile A';home=(Join-Path $root 'home-a');cli=$CodexExe}
    $other = Api 'profile-save' @{name='Profile B';home=(Join-Path $root 'home-b');cli=$CodexExe}
    if ($profile.id -eq $other.id) { throw 'Profiles collided' }
    if ($CodexExe) {
        $version = Api 'cli-check' @{profile=$profile.id}
        if (!$version.version) { throw 'Codex version missing' }
        $null = Api 'account-refresh' @{profile=$profile.id}
    }
    if ($settings.version -ne '1.0.0-rc1') { throw "Wrong executable version $($settings.version)" }
    $quotaState = Api 'quota-state'
    if ($null -eq $quotaState.quota -or $null -eq $quotaState.auth) { throw 'Quota state missing' }
    $history = Join-Path $root 'old-home'
    $rollouts = Join-Path $history 'sessions\2026\11\22'
    $null = New-Item -ItemType Directory -Path $rollouts
    $thread = 'aaaaaaaa-aaaa-4aaa-aaaa-aaaaaaaaaaaa'
    $rollout = Join-Path $rollouts "rollout-$thread.jsonl"
    $entry = @{type='session_meta';payload=@{id=$thread;cwd=$workspace;source='cli';timestamp='2026-11-22T00:00:00Z'}}
    [IO.File]::WriteAllText($rollout,(ConvertTo-Json -InputObject $entry -Depth 5 -Compress) + "`n")
    $before = (Get-FileHash -LiteralPath $rollout).Hash
    $list = Api 'saved-list' @{home=$history}
    if (@($list.sessions | Where-Object {$_.thread -eq $thread}).Count -ne 1) { throw 'Saved terminal session missing' }
    $imported = Api 'saved-import' @{home=$history;thread=$thread}
    if (!$imported.id -or (Get-FileHash -LiteralPath $rollout).Hash -ne $before) { throw 'Import changed source history' }
    $project = Api 'project-save' @{name='Work';path=$workspace;next='Continue the smoke test'}
    # User-mediated Workforce and Bridge verification on the isolated workspace.
    $wf = Api 'continuous-start' @{project=$project.id;revision=0;goal='Verify workforce';task='Check isolated file';flags=63;role=4}
    if ($wf.mode -ne 'waiting_user' -or $wf.role -ne 4) { throw 'Workforce start/role failed' }
    $wf = Api 'continuous-role' @{project=$project.id;revision=$wf.revision;role=5}
    $wf = Api 'continuous-record' @{project=$project.id;revision=$wf.revision;note='No live test yet';next='Review';testSession=''}
    if ($wf.rounds -ne 1 -or $wf.history[0].role -ne 5 -or $wf.history[0].exitCode -ne -1) { throw 'Workforce evidence failed' }
    $wf = Api 'continuous-stop' @{project=$project.id;revision=$wf.revision}
    if ($wf.mode -ne 'stopped') { throw 'Workforce stop failed' }
    $wfFile = Join-Path $workspace 'workforce-smoke.txt'
    [IO.File]::WriteAllText($wfFile,'original')
    $read = Api 'bridge-read' @{project=$project.id;path='workforce-smoke.txt'}
    $patch = @{project=$project.id;path='workforce-smoke.txt';baseSha256=$read.sha256;content='updated'}
    $review = Api 'bridge-preview' $patch
    $patch.ticket=$review.ticket; $patch.confirm=$true
    $applied = Api 'bridge-apply' $patch
    if ([IO.File]::ReadAllText($wfFile) -cne 'updated') { throw 'Bridge write failed' }
    $null = Api 'bridge-rollback' @{project=$project.id;backup=$applied.backup;confirm=$true}
    if ([IO.File]::ReadAllText($wfFile) -cne 'original') { throw 'Bridge rollback failed' }
    Remove-Item -LiteralPath $wfFile
    if ($LiveChat -or $LiveAutonomous) {
        $real = Api 'profile-save' @{name='Live smoke';home=(Resolve-Path -LiteralPath $CodexHome).Path;cli=$CodexExe;authStore='config';existing=$true}
    }
    if ($LiveChat) {
        $account = Api 'account-refresh' @{profile=$real.id}
        if ($account.status -ne 'Signed in') { throw "Codex has not verified this profile as signed in: $($account.status)" }
        $code = 'SAMERO-' + [guid]::NewGuid().ToString('N')
        $first = Api 'chat-send' @{project=$project.id;profile=$real.id;requestId=[guid]::NewGuid().ToString('N');text="Remember this test code: $code. Reply only with the code. Do not use tools or change files."}
        Wait-ChatReady $first.id $code
        $null = Api 'chat-send' @{project=$project.id;profile=$real.id;requestId=[guid]::NewGuid().ToString('N');text='Reply only with the original test code followed by -2. Do not use tools.'}
        Wait-ChatReady $first.id ($code + '-2')
        Close-Chat $first.id
        $null = Api 'exit'
        if (!$child.WaitForExit(10000) -or $child.ExitCode -ne 0) { throw 'Manager did not exit before resume.' }
        Open-Manager
        $resumed = Api 'thread-resume' @{id=$first.id}
        Wait-ChatReady $resumed.id
        $null = Api 'chat-send' @{project=$project.id;profile=$real.id;requestId=[guid]::NewGuid().ToString('N');text='Recall the original test code from the start. Reply only with the original code followed by -3. Do not use tools.'}
        Wait-ChatReady $resumed.id ($code + '-3')
        Close-Chat $resumed.id
        Write-Output 'Authenticated Codex chat, follow-up context and closed-thread resume passed'
    }
    $detail = Api 'project-details' @{project=$project.id}
    if ($detail.documents.'PROJECT_STATUS.md'.state -ne 'missing') { throw 'Status document initial state is incorrect' }
    $null = Api 'project-create-status' @{project=$project.id}
    $detail = Api 'project-details' @{project=$project.id}
    if ($detail.documents.'PROJECT_STATUS.md'.state -ne 'available') { throw 'Status document could not be read' }
    if ($Pickers) {
        Write-Output "Select this Unicode workspace in the native folder dialog: $workspace"
        $folder = Api 'pick' @{start=$root}
        if (!$folder.path -or (Resolve-Path -LiteralPath $folder.path).Path -ne $workspace) { throw 'Native folder result mismatch' }
        Write-Output "Select the SAMERO EXE in the native file dialog: $Exe"
        $picked = Api 'pick' @{file=$true;start=(Split-Path -Parent $Exe)}
        if (!$picked.path -or (Resolve-Path -LiteralPath $picked.path).Path -ne $Exe) { throw 'Native file result mismatch' }
    }
    $checkpoint = Api 'checkpoint-backup' @{project=$project.id;quiet=$true}
    $zip = Join-Path $checkpoint.directory 'workspace.zip'
    $hash = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($hash -ne $checkpoint.sha256) { throw 'Archive digest mismatch' }
    $null = Api 'checkpoint-verify' @{id=$checkpoint.id}
    $restored = Api 'checkpoint-restore' @{id=$checkpoint.id;directory=$backup;confirmed=$true}
    $newFile = Join-Path $restored.path (Split-Path -Leaf $file)
    if ((Get-Content -LiteralPath $newFile) -ne 'local changes') { throw 'Restored content mismatch' }
    if (Test-Path -LiteralPath (Join-Path $restored.path '.env')) { throw 'Secret file was restored' }
    if ($LiveAutonomous) {
        $trial = Join-Path $root 'autonomous'
        $null = New-Item -ItemType Directory -Path $trial
        $compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
        if (!(Test-Path -LiteralPath $compiler)) { throw 'The native Windows smoke needs the .NET Framework x64 C# compiler.' }
        $verify = @'
$ErrorActionPreference = "Stop"
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
& $csc /nologo /out:Smoke-Test.exe Program.cs
if ($LASTEXITCODE -ne 0) { exit 1 }
$result = & .\Smoke-Test.exe
if ($LASTEXITCODE -ne 0 -or $result -ne "SAMERO-OK") { exit 2 }
'@
        [IO.File]::WriteAllText((Join-Path $trial 'verify.ps1'),$verify)
        $sample = Api 'project-save' @{name='Autonomous live smoke';path=$trial}
        if ($LiveAutoApproval) {
            $s=(Api 'state').settings
            $null=Api 'settings-save' @{projects=$s.projects;backup=$s.backup;codex=$s.codex;git=$s.git;theme=$s.theme;caches=$s.caches;autoApproval=$true}
        }
        $run = Api 'runner-start' @{project=$sample.id;profile=$real.id;confirmed=$true;goal='Create Program.cs, C# compatible with .NET Framework, printing exactly SAMERO-OK. The existing verify.ps1 must stay intact.';
            testExe=(Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe');testArgs="-NoProfile`n-File`nverify.ps1";buildExe=$compiler;buildArgs="/nologo`n/optimize+`n/out:Release.exe`nProgram.cs"}
        $deadline=(Get-Date).AddMinutes(20)
        do {
            Start-Sleep -Seconds 1
            $current=(Api 'state').runs | Where-Object { $_.id -eq $run.id }
            if ($current.mode -in @('review','blocked','quota')) { throw "Live runner interrupted: $($current.reason)" }
        } until (($current.mode -eq 'done' -and !$current.snapshot) -or (Get-Date) -gt $deadline)
        if ($current.mode -ne 'done' -or $current.snapshot -or $current.test -ne 'PASS' -or $current.build -ne 'PASS') { throw 'Live autonomous acceptance incomplete' }
        $release=Join-Path $trial 'Release.exe'
        if ((& $release) -ne 'SAMERO-OK' -or $LASTEXITCODE -ne 0) { throw 'Release output mismatch' }
        if ($LiveAutoApproval) {
            $sessions=(Api 'state').sessions | Where-Object { $_.project -eq $sample.id -and $_.reviewer -eq 'auto_review' }
            if (!@($sessions).Count) { throw 'No managed workspace-write thread requested Auto-review.' }
            $events=@((Api 'review-history' @{project=$sample.id}).events | Where-Object { $_.source -eq 'codex' })
            $approved=@($events | Where-Object { $_.status -eq 'approved' })
            if ($approved.Count) { Write-Output "PASS: Codex returned $($approved.Count) completed approvals." }
            else { Write-Output 'NOT VERIFIED: no completed automatic approval was observed in this workspace.' }
        }
        Write-Output 'Autonomous live model, tests, release executable and checkpoint verified'
    }
    $null = Api 'exit'
    if (!$child.WaitForExit(10000) -or $child.ExitCode -ne 0) { throw 'Manager did not exit cleanly' }
    Write-Output 'Windows smoke test passed'
}
finally {
    if ($child -and !$child.HasExited) { $child.Kill(); $child.WaitForExit() }
    Remove-Item -LiteralPath $root -Recurse -Force
}
