# Native Windows test, isolated storage only. Run on an older-sequence PREVIEW
# against the currently published official HTTPS manifest. Windows warnings
# are not disabled. This script does not modify the original executable.
param([Parameter(Mandatory=$true)][string]$Exe,[switch]$StageOnly)
$ErrorActionPreference='Stop'
$Exe=(Resolve-Path -LiteralPath $Exe).Path
$root=Join-Path ([IO.Path]::GetTempPath()) ('SAMERO Update QA '+[guid]::NewGuid())
$storage=Join-Path $root 'data'; $workspace=Join-Path $root 'workspace'
$null=New-Item -ItemType Directory -Path $storage,$workspace
$original=(Get-FileHash -LiteralPath $Exe -Algorithm SHA256).Hash
$child=$null; $candidate=$null; $headers=$null; $origin=$null
function Api([string]$Action,[hashtable]$Body=@{}) {
  Invoke-RestMethod -Uri "$origin/api/$Action" -Method Post -Headers $headers -ContentType 'application/json' -Body ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $Body -Depth 8 -Compress))) -TimeoutSec 310
}
function Connect([string]$Previous='') {
  $file=Join-Path $storage 'ui.url'
  for($i=0;$i -lt 200;$i++) {
    if(Test-Path -LiteralPath $file) {
      $url=[IO.File]::ReadAllText($file)
      if($url -ne $Previous -and $url -match '^http://127\.0\.0\.1:[0-9]+/#([0-9a-f]{32})$') {
        $script:origin,$token=$url -split '/#';$script:headers=@{Origin=$origin;'X-Samero-Key'=$token};return $url
      }
    }
    Start-Sleep -Milliseconds 100
  }
  throw 'Manager did not create a new local UI lease. Windows prompt or launch failure remains unverified.'
}
function MustReject([string]$Action,[hashtable]$Body) {
  try { $null=Api $Action $Body; throw 'Unexpected success' } catch {
    if(!$_.Exception.Response -or [int]$_.Exception.Response.StatusCode -ne 409) { throw }
  }
}
try {
  $child=Start-Process -FilePath $Exe -ArgumentList @('--headless','--data-dir',('"'+$storage+'"')) -PassThru
  $oldUrl=Connect
  $project=Api 'project-save' @{name='Update QA';path=$workspace;goal='Keep this project unchanged'}
  $meta=Api 'public-update-check'
  if($meta.status -ne 'available') {throw 'Use a sequence-0 test build; a higher published release is required.'}
  MustReject 'public-update-restart' @{update=[string]$meta.sequence;confirmed=$true}
  $download=Api 'public-update-download' @{update=[string]$meta.sequence;confirmed=$true}
  if($download.status -ne 'verified-download') {throw 'Download not verified'}
  $candidate=$download.path
  if((Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant() -ne $meta.sha256) {throw 'Candidate digest mismatch'}
  $zone=Get-Content -LiteralPath $candidate -Stream Zone.Identifier -Raw
  if($zone -notmatch 'ZoneId=3') {throw 'Internet-zone metadata missing'}
  MustReject 'public-update-restart' @{update=[string]$meta.sequence}
  if($StageOnly) {
    $state=Api 'state'
    if(@($state.projects | Where-Object {$_.id -eq $project.id -and $_.goal -eq 'Keep this project unchanged'}).Count -ne 1){throw 'Project state not preserved'}
    if((Get-FileHash -LiteralPath $Exe -Algorithm SHA256).Hash -ne $original){throw 'Old executable changed'}
    $null=Api 'exit'
    if(!$child.WaitForExit(15000) -or $child.ExitCode -ne 0){throw 'Old Manager did not exit normally after staging'}
    Write-Output 'PASS: HTTPS download, SHA-256, Internet-zone metadata, rejection without approval, preserved state and normal exit.'
    Write-Output 'NOT VERIFIED: interactive Internet-zone launch; use the full Windows test on an attended desktop.'
    return
  }
  $r=Api 'public-update-restart' @{update=[string]$meta.sequence;confirmed=$true}
  if($r.status -ne 'restarting') {throw 'Restart request not accepted'}
  if(!$child.WaitForExit(30000)) {
    throw 'Old Manager did not exit within 30 seconds; Windows shell launch may be awaiting a security prompt. No prompt is bypassed.'
  }
  if($child.ExitCode -ne 0) {
    $detail=Join-Path $storage 'update-launch-error.txt'
    $reason=if(Test-Path -LiteralPath $detail){[IO.File]::ReadAllText($detail)}else{'No launch error recorded'}
    throw "Old Manager exit code $($child.ExitCode): $reason"
  }
  $newUrl=Connect $oldUrl
  $state=Api 'state'
  if(@($state.projects | Where-Object {$_.id -eq $project.id -and $_.goal -eq 'Keep this project unchanged'}).Count -ne 1){throw 'Project state not preserved'}
  if((Get-FileHash -LiteralPath $Exe -Algorithm SHA256).Hash -ne $original){throw 'Old executable changed'}
  $null=Api 'exit'
  Write-Output 'PASS: native HTTPS download, SHA-256, Internet zone, explicit approval, side-by-side restart, same project, old EXE retained.'
} finally {
  if($origin -and $headers) {try {$null=Api 'exit'} catch {}}
  if($child -and !$child.HasExited) {Stop-Process -Id $child.Id -ErrorAction SilentlyContinue}
  # Do not force-delete files if a new candidate is still running.
  Start-Sleep -Seconds 1
  Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction SilentlyContinue
}
