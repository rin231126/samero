#!/usr/bin/env python3
"""Real browser + manager fixture. No ChatGPT web automation."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright
import integration as t
t.APP=Path(sys.argv[1]).resolve();t.REAL_CODEX=None
case=t.ManagerTest('test_process_exit_and_unsafe_paths');case.setUp()
try:
    pid=case.req('project-save',{'name':'Workforce UI','path':str(case.workspace)})['id']
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1380,'height':900}); page.set_default_timeout(8000)
        errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
        page.goto(case.url+'/#'+case.key)
        page.get_by_role('button',name='AI Workforce',exact=True).click()
        page.locator('#cont-goal').wait_for()
        assert page.locator('[data-team-role]').count()==8
        page.locator('[data-team-role="4"]').click(); assert page.locator('[data-team-role="4"]').get_attribute('aria-pressed')=='true'
        page.locator('#cont-goal').fill('Nâng cấp ứng dụng')
        page.locator('#cont-start').click();page.locator('#cont-prompt').wait_for()
        assert 'AI Developer' in page.locator('#cont-prompt').input_value()
        assert case.req('continuous-get',{'project':pid})['role']==4
        page.locator('[data-team-role="5"]').click();page.wait_for_function("document.querySelector('[data-team-role=\"5\"]').getAttribute('aria-pressed')==='true'")
        page.locator('#cont-note').fill('Kiểm tra code; chưa có test');page.locator('#cont-next').fill('Thử test hồi quy')
        page.locator('#cont-record').click();page.wait_for_function("document.querySelector('#cont-task').value==='Thử test hồi quy'")
        assert case.req('continuous-get',{'project':pid})['history'][0]['role']==5
        page.locator('#cont-pause').click();page.wait_for_function("!document.querySelector('#cont-resume').disabled")
        assert case.req('continuous-get',{'project':pid})['mode']=='paused'
        page.get_by_role('button',name='ChatGPT Web',exact=True).click();page.locator('#bridge-pick').wait_for()
        assert not errors, errors
        browser.close()
    print('PASS: real Chromium UI, visible roles, START, role change, record, pause, navigation')
finally:case.tearDown()
