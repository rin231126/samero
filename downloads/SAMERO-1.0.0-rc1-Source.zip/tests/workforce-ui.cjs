const assert=require('node:assert/strict');const fs=require('node:fs');const vm=require('node:vm');const src=fs.readFileSync(require('node:path').join(__dirname,'../web/app.js'),'utf8');
const c=vm.createContext({TextEncoder,html:v=>String(v),flag:v=>String(v)});
vm.runInContext(src.slice(src.indexOf('function historicalCriterion('),src.indexOf('function runnerControl(')),c);
vm.runInContext(src.slice(src.indexOf('const teamRoles='),src.indexOf('const contModes=')),c);
assert.match(c.historicalCriterion('A; Queue hiện có 0 tác vụ; B'),/^A; Queue 0\/0 ở pha plan.*; B$/);
assert.equal(c.historicalCriterion('Other acceptance criterion'), 'Other acceptance criterion');
assert.equal(c.historicalCriterion('x'.repeat(650)+'Queue hiện có 0 tác vụ'), 'x'.repeat(650)+'Queue hiện có 0 tác vụ');
assert.match(c.teamInstructions(0),/không phải agent độc lập/);assert.match(c.teamInstructions(6),/không tự báo đã chạy test/);
assert.equal(c.parseTeamReport('```json\n{"note":"test","next":"check"}\n```').next,'check');
for(const bad of ['null','[]','{"note":"","next":"x"}','{"note":"x","next":"y","extra":1}', JSON.stringify({note:'é'.repeat(2001),next:'x'})]) assert.throws(()=>c.parseTeamReport(bad));
console.log('PASS: historical criterion suggestion, length bounds, team prompt and JSON report validation (JS unit test).');

const historical='Đối chiếu đủ 24 mục đặc tả với mã, test và bằng chứng. Workspace là 0.3.0-dev, Downloads/SAMERO-Animation-AI-dev là 0.4.1-dev, cả hai thiếu .git. SHA-256 của ZIP, EXE và HTML 0.4.1-dev khớp manifest. Bảng tiến độ phân biệt kết quả chạy trước đây với lần khảo sát chỉ đọc này. Queue hiện có 0 tác vụ, test/build của phiên là NOT VERIFIED.';
const fixed=c.historicalCriterion(historical);assert.match(fixed,/Snapshot trước hợp nhất/);assert.match(fixed,/ghi riêng kết quả hiện tại/);assert.match(fixed,/Queue 0\/0 ở pha plan/);assert.match(fixed,/SHA-256/);assert.ok(new TextEncoder().encode(fixed).length<=679);
const cards=c.workforceCards(4,'idle');assert.equal((cards.match(/data-team-role=/g)||[]).length,8);assert.match(cards,/data-team-role="4" aria-pressed="true"/);assert.match(cards,/không mô phỏng trạng thái AI đang chạy/i);assert.ok(src.includes('workforce: workforcePage'));
console.log('PASS: 7 visible role cards before START, selected role, historical criterion from screenshot.');

vm.runInContext(src.slice(src.indexOf('function bridgeRelativePath('),src.indexOf('function bridgePage(')),c);
assert.equal(c.bridgeRelativePath('C:/project','c:\\project\\src\\a.js'),'src/a.js');assert.equal(c.bridgeRelativePath('/tmp/project','/tmp/project/src/a.js'),'src/a.js');
for(const path of ['/tmp/project2/a.js','/tmp/project/../a.js','/tmp/project/'])assert.throws(()=>c.bridgeRelativePath('/tmp/project',path));
console.log('PASS: native picker path conversion and project boundary.');
