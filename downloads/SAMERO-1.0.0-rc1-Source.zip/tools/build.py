#!/usr/bin/env python3
"""Cross-build using GNU x86-64 GCC and GNU binutils. No downloads needed."""
import argparse
import hashlib
import os
from pathlib import Path
import subprocess
import struct
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def run(*args):
    subprocess.run([str(arg) for arg in args], check=True)

def assets(directory):
    with (directory / "assets.h").open("w") as out:
        for name in ("index.html", "theme.css", "app.js", "mascot.js", "music.js", "studio.js", "mini.html", "mini.js", "blue-current.ogg", "harbor-lofi.ogg", "deep-ocean.ogg", "samero.ico", *[f"mascot/{p.name}" for p in sorted((ROOT/"web/mascot").glob("*.png"))]):
            data = (ROOT / "web" / name).read_bytes()
            out.write(f"static const unsigned char {name.replace('.', '_').replace('/', '_').replace('-', '_')}[] = {{\n")
            for offset in range(0, len(data), 24):
                out.write(",".join(map(str, data[offset:offset+24])) + ",\n")
            out.write("};\n")

def elf_to_coff(elf, obj):
    """Translate x64 compiler objects and preserve every relocation target."""
    original = elf.read_bytes()
    if original[:6] != b"\x7fELF\x02\x01" or struct.unpack_from("<HH", original, 16) != (1, 62):
        raise ValueError("Expected an x86-64 little-endian ELF object")
    section_offset, = struct.unpack_from("<Q", original, 40)
    section_size, section_count, names_index = struct.unpack_from("<HHH", original, 58)
    sections = [
        struct.unpack_from("<IIQQQQIIQQ", original, section_offset + i * section_size)
        for i in range(section_count)
    ]

    def cstring(start):
        return original[start:original.index(0, start)]

    names = [cstring(sections[names_index][4] + section[0]) for section in sections]
    output_sections = [i for i, section in enumerate(sections) if section[2] & 2]
    section_map = {index: i + 1 for i, index in enumerate(output_sections)}
    source_symtab = next(section for section in sections if section[1] == 2)
    source_symnames = sections[source_symtab[6]][4]
    relocations = {section[7]: section for section in sections if section[1] == 4}
    strings = bytearray(b"\0" * 4)

    def name_field(name, is_section=False):
        if len(name) <= 8:
            return name.ljust(8, b"\0")
        at = len(strings)
        strings.extend(name + b"\0")
        if is_section:
            return f"/{at}".encode().ljust(8, b"\0")
        return struct.pack("<II", 0, at)

    symbols = bytearray()
    symbol_map = {}

    def translate_symbol(index):
        if index in symbol_map:
            return symbol_map[index]
        pos = source_symtab[4] + index * source_symtab[9]
        field, info, _, section, address, _ = struct.unpack_from("<IBBHQQ", original, pos)
        kind, binding = info & 15, info >> 4
        dest = section_map.get(section, 0)
        if section and not dest:
            raise ValueError(f"Relocation points to an unsupported ELF section: {section}")
        name = names[section] if kind == 3 else cstring(source_symnames + field)
        if not name:
            raise ValueError("Relocation points to an unnamed non-section ELF symbol")
        i = len(symbols) // 18
        symbols.extend(struct.pack("<8sIhHBB", name_field(name), address, dest, 0x20 if kind == 2 else 0,
                                   2 if binding else 3, 0))
        symbol_map[index] = i
        return i

    for index in range(1, source_symtab[5] // source_symtab[9]):
        pos = source_symtab[4] + index * source_symtab[9]
        _, info, _, section = struct.unpack_from("<IBBH", original, pos)
        if info >> 4 == 1 and section in section_map:
            translate_symbol(index)

    header_size = 20 + len(output_sections) * 40
    data = bytearray()
    headers = bytearray()
    for index in output_sections:
        _, kind, flags, _, offset, size, _, _, alignment, _ = sections[index]
        name = names[index]
        if name == b".rodata" or name.startswith(b".rodata."):
            name = b".rdata" + (b"$" + name[8:] if name.startswith(b".rodata.") else b"")
        if name.startswith(b".data.rel."):
            name = b".data$" + name[len(b".data.rel."):]
        section = bytearray(original[offset:offset+size]) if kind != 8 else bytearray()
        rel = bytearray()
        if index in relocations:
            item = relocations[index]
            if kind == 8:
                raise ValueError("Unexpected relocation in zero-initialized data")
            for pos in range(item[4], item[4] + item[5], item[9]):
                address, info, addend = struct.unpack_from("<QQq", original, pos)
                number = info & 0xffffffff
                if number in (2, 4):
                    typ, fmt, addend = 4, "<i", addend + 4  # REL32
                elif number == 1:
                    typ, fmt = 1, "<q"  # ADDR64
                elif number == 10 and (name.startswith(b".idata$") or name.startswith(b".rsrc")):
                    typ, fmt = 3, "<I"  # ADDR32NB (RVA)
                else:
                    raise ValueError(f"Unsupported ELF relocation {number} in {name!r}")
                struct.pack_into(fmt, section, address, addend)
                rel.extend(struct.pack("<IIH", address, translate_symbol(info >> 32), typ))
        content = 0x20 if flags & 4 else 0x80 if kind == 8 else 0x40
        access = 0x40000000 | (0x80000000 if flags & 1 else 0) | (0x20000000 if flags & 4 else 0)
        align = max(1, alignment).bit_length() << 20
        data_offset = header_size + len(data)
        headers.extend(struct.pack("<8sIIIIIIHHI", name_field(name, True), 0, 0, size,
                                   data_offset if section else 0, data_offset + len(section) if rel else 0,
                                   0, len(rel) // 10, 0, content | access | align))
        data.extend(section)
        data.extend(rel)

    head = struct.pack("<HHIIIHH", 0x8664, len(output_sections), 0, header_size + len(data), len(symbols) // 18, 0, 0)
    struct.pack_into("<I", strings, 0, len(strings))
    obj.write_bytes(head + headers + data + symbols + strings)

def windows_imports(directory):
    libraries = {}
    for line in (ROOT / "tools" / "imports.txt").read_text().splitlines():
        tokens = line.split()
        if tokens:
            libraries[tokens[0]] = tokens[1:]
    asm = [".text"]
    for functions in libraries.values():
        for function in functions:
            asm += [f".globl {function}", f"{function}:", f"jmp *iat_{function}(%rip)"]
    # Let the PE linker place .idata, compute RVAs, and populate both
    # import data directories. The PE linker script orders .idata$2..$7.
    asm += ['.section .idata$2,"a"']
    for i in range(len(libraries)):
        asm += [f".long ilt{i},0,0,name{i},iat{i}"]
    for index, (library, functions) in enumerate(libraries.items()):
        for table, subsection in (("ilt", 4), ("iat", 5)):
            asm += [f'.section .idata${subsection},"aw"', ".balign 8", f"{table}{index}:"]
            for function in functions:
                if table == "iat":
                    asm += [f"iat_{function}:"]
                asm += [f".long hint_{function},0"]
            asm += [".quad 0"]
        asm += ['.section .idata$6,"a"', f"name{index}:", f'.asciz "{library}.dll"']
        for function in functions:
            asm += [".balign 2", f"hint_{function}:", ".short 0", f'.asciz "{function}"']
    source = directory / "imports.s"
    source.write_text("\n".join(asm) + "\n")
    run("as", "--64", "-o", directory/"imports.elf", source)
    elf_to_coff(directory/"imports.elf", directory/"imports.obj")

def windows_icon(directory):
    """Create RT_ICON / RT_GROUP_ICON entries from the shipped ICO, without external resource tools."""
    ico=(ROOT/"web/samero.ico").read_bytes()
    reserved,kind,count=struct.unpack_from("<HHH",ico)
    if reserved or kind!=1 or not 1<=count<=32:
        raise ValueError("Invalid ICO")
    icons=[]
    group=bytearray(struct.pack("<HHH",0,1,count))
    for i in range(count):
        entry=ico[6+i*16:22+i*16]
        size,offset=struct.unpack_from("<II",entry,8)
        if offset<6+16*count or offset+size>len(ico) or not size:
            raise ValueError("Invalid icon entry")
        group.extend(entry[:12]+struct.pack("<H",i+1))
        icons.append(ico[offset:offset+size])
    files=icons+[bytes(group)]
    # Resource directory tree: types 3 and 14; integer IDs; language 0x0409.
    asm=['.section .rsrc,"a"','.balign 4','resource_root:']
    def header(n): asm.extend(['.long 0,0','.short 0,0,0,'+str(n)])
    def branch(key,label): asm.extend([f'.long {key}',f'.long 0x80000000+({label}-resource_root)'])
    header(2);branch(3,'type_icons');branch(14,'type_group')
    asm.append('type_icons:');header(count)
    for i in range(count):branch(i+1,f'lang_{i}')
    asm.append('type_group:');header(1);branch(1,f'lang_{count}')
    for i in range(len(files)):
        asm.append(f'lang_{i}:');header(1)
        asm.extend(['.long 1033',f'.long entry_{i}-resource_root'])
    for i,blob in enumerate(files):
        asm.extend([f'entry_{i}:',f'.long payload_{i}',f'.long {len(blob)},0,0'])
    for i,blob in enumerate(files):
        file=directory/f'icon-{i}.bin';file.write_bytes(blob)
        asm.extend(['.balign 4',f'payload_{i}:',f'.incbin "{file}"'])
    src=directory/'icon.s';src.write_text('\n'.join(asm)+'\n')
    run('as','--64','-o',directory/'icon.elf',src)
    elf_to_coff(directory/'icon.elf',directory/'icon.obj')
    return directory/'icon.obj'

def build(target, output):
    with tempfile.TemporaryDirectory() as work:
        work = Path(work)
        assets(work)
        sources = sorted((ROOT / "src").glob("*.c"))
        flags = ["-std=c11", "-O2", "-Wall", "-Wextra", "-Werror", f"-I{work}"]
        digest = hashlib.sha256()
        for f in sorted([*sources, *(ROOT/'src').glob('*.h'), *[p for p in (ROOT/'web').rglob('*') if p.is_file()], Path(__file__).resolve()]):
            digest.update(f.relative_to(ROOT).as_posix().encode()+b'\0'+hashlib.sha256(f.read_bytes()).digest())
        flags.append('-DSAM_BUILD_ID="'+digest.hexdigest()[:16]+'"')
        if target == "linux":
            run(os.environ.get("CC", "gcc"), *flags, "-D_GNU_SOURCE", *sources, "-lm", "-o", output)
            return
        windows_imports(work)
        objects = []
        for source in sources:
            elf = work / f"{source.stem}.elf"
            obj = work / f"{source.stem}.obj"
            run("gcc", *flags, "-U_FORTIFY_SOURCE", "-D_FORTIFY_SOURCE=0", "-DSAM_WINDOWS", "-mabi=ms", "-fshort-wchar", "-mno-red-zone", "-ffreestanding",
                "-fno-stack-protector", "-fno-asynchronous-unwind-tables", "-fpie", "-fno-jump-tables",
                "-fno-merge-constants", "-fstack-check=no", "-c", source, "-o", elf)
            elf_to_coff(elf, obj)
            objects.append(obj)
        run("ld", "-m", "i386pep", "--subsystem", "windows", "--entry", "sam_entry",
            "--enable-reloc-section", "--dynamicbase", "--nxcompat", "--high-entropy-va",
            "--major-os-version", "10", "--minor-os-version", "0",
            "--major-subsystem-version", "6", "--minor-subsystem-version", "0",
            "--stack", "8388608,262144", "--no-insert-timestamp", "--strip-all",
            "-o", output, *objects, work/"imports.obj", windows_icon(work))

if __name__ == "__main__":
    args = argparse.ArgumentParser()
    args.add_argument("target", choices=("linux", "windows"))
    args.add_argument("output", type=Path)
    ns = args.parse_args()
    ns.output.parent.mkdir(parents=True, exist_ok=True)
    build(ns.target, ns.output.resolve())
