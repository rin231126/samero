#!/usr/bin/env python3
"""Inspect a saved SAMERO VERIFY turn locally. Outputs counts without file contents."""
import argparse
import hashlib
import json
import ntpath
import os
import re
import sys
from pathlib import Path

LINE_LIMIT = 8 * 1024 * 1024
SESSION_ID = re.compile(r"[0-9a-f]{32}")
TURN_ID = re.compile(r"[A-Za-z0-9_-]{1,159}")
THREAD_UUID = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")


class BindingError(ValueError):
    """A fixed diagnostic safe to show without disclosing local paths or content."""


def read_record(path):
    with path.open("rb") as stream:
        data = stream.read(1024 * 1024 + 1)
    if len(data) > 1024 * 1024:
        raise BindingError("Bản ghi Manager vượt giới hạn 1 MiB.")
    record = json.loads(data.decode("utf-8-sig"))
    if not isinstance(record, dict):
        raise BindingError("Bản ghi Manager không phải đối tượng JSON.")
    return record


def locate(manager_id, manager_dir=None):
    if not SESSION_ID.fullmatch(manager_id):
        raise BindingError("Mã phiên Manager phải có 32 ký tự hex viết thường.")
    if manager_dir is None:
        local = os.environ.get("LOCALAPPDATA")
        if os.name != "nt" or not local:
            raise BindingError("Hãy chỉ định thư mục dữ liệu Manager bằng --data-dir.")
        manager_dir = Path(local) / "SAMERO Codex Manager"
    data = Path(manager_dir).resolve(strict=True)

    def bound_record(table, identity):
        path = data / table / (identity + ".json")
        if not path.is_file() or path.resolve(strict=True) != path:
            raise BindingError("Không tìm được bản ghi trong thư mục " + table + " của Manager đã chọn.")
        record = read_record(path)
        if record.get("id") != identity:
            raise BindingError("Mã trong bản ghi Manager không khớp tên tệp.")
        return path, record

    session_path, session = bound_record("sessions", manager_id)
    thread = session.get("chatThread", "")
    profile = session.get("profile", "")
    if session.get("kind") != "chat" or not isinstance(thread, str) or not THREAD_UUID.fullmatch(thread):
        raise BindingError("Phiên chưa lưu được mã luồng Codex chính thức.")
    if not isinstance(profile, str) or not SESSION_ID.fullmatch(profile):
        raise BindingError("Không xác định được hồ sơ Codex của phiên.")
    _, account = bound_record("profiles", profile)
    home = account.get("home")
    if (not isinstance(home, str) or not Path(home).is_absolute()
            or hashlib.sha256(home.encode("utf-8")).hexdigest() != session.get("chatHome")):
        raise BindingError("Thư mục hồ sơ hiện tại không khớp hồ sơ lúc tạo phiên.")
    sessions = Path(home) / "sessions"
    if not sessions.is_dir() or sessions.resolve(strict=True) != sessions:
        raise BindingError("Hồ sơ gốc không có thư mục sessions hợp lệ.")
    pending, matches, scanned = [(sessions, 0)], [], 0
    suffix = "-" + thread.lower() + ".jsonl"
    while pending:
        directory, depth = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                scanned += 1
                if scanned > 20000:
                    raise BindingError("Vượt giới hạn tìm lịch sử. Có thể chỉ định hai tệp trực tiếp.")
                name, path = entry.name, Path(entry.path)
                if depth < 5 and re.fullmatch(r"[0-9]{1,4}", name) and entry.is_dir(follow_symlinks=False):
                    if path.resolve(strict=True) == path:
                        pending.append((path, depth + 1))
                elif (name.startswith("rollout-") and name.lower().endswith(suffix)
                        and entry.is_file(follow_symlinks=False) and path.resolve(strict=True) == path):
                    matches.append(path)
    if len(matches) != 1:
        raise BindingError("Không tìm được đúng một nhật ký cho luồng này trong hồ sơ gốc.")
    return session_path, matches[0]


def same_workspace(a, b):
    if not isinstance(a, str) or not a or not isinstance(b, str):
        return False
    if ntpath.splitdrive(a)[0]:
        return ntpath.normcase(ntpath.normpath(a)) == ntpath.normcase(ntpath.normpath(b))
    return a == b


def inspect(session_file, rollout, requested=None):
    session = read_record(session_file)
    if (not isinstance(session, dict) or not SESSION_ID.fullmatch(str(session.get("id", "")))
            or session.get("kind") != "chat" or not session.get("chatThread")):
        raise ValueError("Missing Manager chat session binding.")
    turns, active = {}, None
    with rollout.open("rb") as stream:
        def rows():
            while line := stream.readline(LINE_LIMIT + 1):
                if len(line) > LINE_LIMIT or not line.endswith(b"\n"):
                    raise ValueError("Oversized or incomplete record. No conclusion.")
                row = json.loads(line)
                if not isinstance(row, dict) or not isinstance(row.get("payload"), dict):
                    raise ValueError("Unrecognized record. No conclusion.")
                yield row["type"], row["payload"]

        records = rows()
        header, meta = next(records, (None, {}))
        if (header != "session_meta" or meta.get("id") != session["chatThread"]
                or not same_workspace(session.get("workspace"), meta.get("cwd"))):
            raise ValueError("Session, thread or workspace mismatch.")
        for kind, p in records:
            tag, identity = p.get("type"), p.get("turn_id")
            if kind == "turn_context" or (kind == "event_msg" and tag in ("task_started", "turn_started")):
                active = identity if isinstance(identity, str) and TURN_ID.fullmatch(identity) else None
                if active and active not in turns:
                    turns[active] = dict(verify=False, closed=False, commands={}, calls={}, outputs=set(),
                                         errors=set(), denials=set())
                continue
            if active is None:
                continue
            t = turns[active]
            if kind == "event_msg" and tag in ("task_complete", "turn_complete", "turn_aborted"):
                t["closed"] = identity == active
                active = None
                continue
            if kind == "event_msg" and tag == "user_message":
                t["verify"] |= str(p.get("message", "")).startswith("SAMERO VERIFY.")
            if kind == "response_item" and tag == "message" and p.get("role") == "user":
                content = p.get("content")
                if isinstance(content, list):
                    t["verify"] |= any(isinstance(c, dict) and str(c.get("text", "")).startswith("SAMERO VERIFY.")
                                       for c in content)
            cid = p.get("call_id")
            if not isinstance(cid, str) or not cid:
                continue
            if kind == "event_msg" and tag == "exec_command_end":
                t["commands"][cid] = p.get("exit_code") if type(p.get("exit_code")) is int else None
            if kind != "response_item" or p.get("namespace") not in (None, "functions"):
                continue
            if tag == "function_call" and p.get("name") == "exec_command":
                t["calls"][cid] = True
            if tag != "function_call_output" or cid not in t["calls"] or cid in t["outputs"]:
                continue
            t["outputs"].add(cid)
            output = p.get("output")
            texts = [output] if isinstance(output, str) else [
                c.get("text") for c in (output if isinstance(output, list) else [])
                if isinstance(c, dict) and c.get("type") == "input_text"]
            for text in texts:
                if not isinstance(text, str):
                    continue
                reject = text.startswith("approval policy is Never; reject command")
                if reject or text.startswith("exec_command failed:"):
                    t["errors"].add(cid)
                if reject or (text.startswith("exec_command failed: CreateProcess {") and any(
                    phrase in text.lower() for phrase in ("rejected: blocked by policy", "denied by policy",
                        "rejected: policy forbids commands starting with", "permission denied",
                        "access is denied", "unauthorizedaccessexception"))):
                    t["denials"].add(cid)
    matched = [(tid, t) for tid, t in turns.items() if t["verify"] and (not requested or tid == requested)]
    if len(matched) != 1:
        raise ValueError("No unique matching SAMERO VERIFY turn. Specify its recorded --turn when needed.")
    tid, t = matched[0]
    return {"managerSession": session["id"], "turnId": tid, "turnEndRecorded": t["closed"],
            "execCallsObserved": len(t["calls"]), "pairedOutputsObserved": len(t["outputs"]),
            "commandEndEventsObserved": len(t["commands"]), "knownExitCodes": sum(v is not None for v in t["commands"].values()),
            "toolErrorsWithoutCommandEnd": len(t["errors"] - t["commands"].keys()),
            "denialOutputsObserved": len(t["denials"]), "scope": "saved records only"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("session", type=Path, nargs="?", help="Copy of SAMERO sessions/<Manager-session-id>.json")
    parser.add_argument("rollout", type=Path, nargs="?", help="Copy of the corresponding Codex rollout JSONL")
    parser.add_argument("--locate", metavar="MANAGER_SESSION_ID", help="Locate the matching journal under the bound profile")
    parser.add_argument("--data-dir", type=Path, help="Manager data directory for --locate (Windows uses its usual default)")
    parser.add_argument("--turn", help="Recorded Codex turn ID when the thread contains several VERIFY turns")
    args = parser.parse_args()
    if args.locate:
        if args.session or args.rollout:
            parser.error("Use --locate or supply two files.")
    elif not (args.session and args.rollout) or args.data_dir:
        parser.error("Supply two files, or use --locate with an optional --data-dir.")
    try:
        files = locate(args.locate, args.data_dir) if args.locate else (args.session, args.rollout)
        summary = inspect(*files, args.turn)
    except BindingError as exc:
        print("NOT VERIFIED. " + str(exc), file=sys.stderr)
        sys.exit(2)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"NOT VERIFIED ({type(exc).__name__}). Check the session binding, turn selector and complete JSONL.", file=sys.stderr)
        sys.exit(2)
    print(json.dumps(summary, indent=2))
