"""Generate original SAMERO 'Blue Current' chiptune (no third-party melody/samples)."""
from pathlib import Path
import math, wave, subprocess, tempfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
rate=32000; beat=60/100; beats=64
mix=np.zeros(int(beats*beat*rate),dtype=np.float64)
# Four phrases, deliberately composed for this app. None are based on existing songs.
melody=[
 [76,None,79,81,79,None,74,None],[76,74,None,72,74,None,71,None],
 [72,None,76,79,76,None,74,None],[71,74,76,None,74,72,None,None],
 [76,None,79,83,81,None,79,None],[74,76,None,74,71,None,72,None],
 [72,76,79,None,81,79,76,None],[74,None,71,74,72,None,None,None],
 [79,None,81,84,83,None,79,None],[76,74,76,None,79,None,74,None],
 [76,None,79,81,84,81,79,None],[74,76,None,74,72,None,71,None],
 [72,None,76,79,76,74,None,None],[74,None,77,81,79,None,76,None],
 [79,76,74,None,71,74,76,None],[72,None,74,71,72,None,None,None]]
chords=[(48,55,64,67),(43,50,59,62),(45,52,60,64),(41,48,57,60),
        (48,55,64,67),(43,50,59,62),(45,52,60,64),(41,48,57,60),
        (45,52,60,64),(41,48,57,60),(48,55,64,67),(43,50,59,62),
        (41,48,57,60),(43,50,62,65),(43,50,59,62),(48,55,60,64)]
def tone(start,dur,note,amp,kind):
 length=int(dur*beat*rate); pos=round(start*beat*rate); t=np.arange(length)/rate
 phase=t*(440*2**((note-69)/12)); tri=2*np.abs(2*(phase%1)-1)-1
 if kind=='lead': sig=.83*tri+.17*np.sin(2*math.pi*phase); env=np.exp(-t*2.6)
 elif kind=='bass':sig=.85*np.sin(2*math.pi*phase)+.15*tri;env=np.exp(-t*2.1)
 else:sig=.7*tri+.3*np.sin(2*math.pi*phase);env=np.exp(-t*5)
 env*=np.minimum(1,t/.012)*np.minimum(1,(length-1-np.arange(length))/(rate*.065))
 v=amp*sig*env; end=min(len(mix),pos+length);mix[pos:end]+=v[:end-pos]
for bar,(notes,chord) in enumerate(zip(melody,chords)):
 start=bar*4
 for j,note in enumerate(notes):
  if note is not None:tone(start+j*.5,.45,note,.125,'lead')
 for j,k in enumerate([0,2,1,3,0,2,1,3]):tone(start+j*.5,.42,chord[k]+12,.036,'arp')
 for j,note in enumerate([chord[0],chord[1]]):tone(start+j*2,1.75,note,.10,'bass')
# Clean loop boundaries; peak below clipping.
assert np.max(np.abs(mix))<1
with tempfile.TemporaryDirectory() as td:
 f=Path(td)/'blue.wav'
 with wave.open(str(f),'wb') as w:w.setparams((1,2,rate,len(mix),'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(f),'-c:a','libvorbis','-q:a','4',str(ROOT/'web/blue-current.ogg')],check=True)
