"""Original SAMERO pixel sprites: integer coordinates, no resampling/AI filtering."""
from PIL import Image, ImageDraw
from pathlib import Path
import struct
from io import BytesIO
ROOT=Path(__file__).resolve().parents[1]; out=ROOT/'web/mascot'
P={'ink':'#12223e','dark':'#21385b','blue0':'#214f93','blue1':'#3079d0','blue2':'#55a7ed','blue3':'#a0dcff','white':'#f9eee0','shade':'#bdcfe5','orange0':'#a74d31','orange1':'#e87838','orange2':'#ffad51','orange3':'#ffd18a','pink':'#ef9e9a','eye':'#123e77','shine':'#ffffff','gold':'#ffe275','red':'#e96677'}
S=48
states=['normal','open','focus','research','test','success','warning','idle','sleep']
def draw(state):
 im=Image.new('RGBA',(S,S));d=ImageDraw.Draw(im)
 def poly(p,c):d.polygon(p,fill=P[c])
 def rect(x,y,X,Y,c):d.rectangle((x,y,X,Y),fill=P[c])
 def line(p,c,w=1):d.line(p,fill=P[c],width=w)
 # shark tail, visible behind body
 poly([(33,40),(38,35),(40,30),(46,27),(45,33),(42,37),(46,39),(46,44),(40,43),(36,45)],'ink')
 poly([(35,40),(39,35),(41,31),(44,30),(43,34),(40,38),(44,40),(44,42),(40,41),(36,43)],'blue1');line([(41,32),(42,30),(44,30)],'blue3')
 # cozy hoodie body
 poly([(13,31),(34,31),(38,36),(38,43),(34,46),(11,46),(7,42),(8,36)],'ink')
 poly([(13,33),(33,33),(36,37),(36,42),(33,44),(12,44),(9,41),(10,37)],'blue0')
 poly([(10,38),(13,35),(17,36),(20,40),(17,44),(10,43)],'blue1');poly([(26,38),(31,35),(35,37),(36,42),(29,44)],'blue1')
 rect(22,36,24,44,'dark');rect(22,36,23,42,'shade');rect(24,37,25,38,'blue3')
 # hood outer silhouette, dorsal fin
 if state=='open':
  poly([(5,15),(9,9),(16,5),(22,4),(25,2),(30,1),(32,7),(39,11),(42,16),(42,26),(36,34),(10,34),(5,27)],'ink')
  poly([(7,16),(11,10),(18,7),(24,6),(28,3),(30,3),(30,8),(37,12),(40,17),(40,26),(35,32),(11,32),(7,26)],'blue1')
  poly([(9,17),(13,12),(21,10),(30,10),(36,14),(39,21),(36,29),(11,29),(8,24)],'dark')
  line([(10,13),(17,9),(22,8)],'blue3')
 else:
  poly([(3,22),(5,15),(10,9),(17,6),(24,5),(29,1),(34,1),(33,7),(39,11),(43,17),(44,25),(41,31),(36,35),(11,35),(6,31),(3,27)],'ink')
  poly([(5,22),(7,15),(12,10),(18,8),(25,7),(30,3),(32,3),(31,9),(38,12),(41,17),(42,25),(39,30),(35,33),(12,33),(8,30),(5,26)],'blue1')
  poly([(7,18),(12,12),(19,9),(25,9),(25,11),(17,12),(11,16),(8,22)],'blue2')
  line([(13,12),(18,10),(22,10)],'blue3');poly([(27,7),(30,4),(31,4),(30,8)],'blue2')
  poly([(36,13),(41,18),(42,25),(39,30),(35,33),(33,31),(38,26),(39,21)],'blue0')
  # shark eyes and gills
  poly([(9,17),(10,15),(13,15),(14,18),(12,20),(10,20)],'white');rect(10,16,12,18,'ink');rect(10,16,10,16,'shine')
  poly([(33,15),(36,15),(38,17),(36,20),(34,20),(32,18)],'white');rect(34,16,36,18,'ink');rect(34,16,34,16,'shine')
  for i in range(2):line([(39+i,22),(38+i,25)],'dark')
  # mouth hole + teeth
  poly([(6,24),(9,20),(14,17),(20,16),(27,16),(34,18),(39,22),(41,26),(37,32),(32,35),(15,35),(8,31)],'ink')
  poly([(7,24),(10,21),(15,18),(21,17),(27,17),(34,19),(39,23),(40,25),(37,27),(34,23),(31,26),(28,21),(24,25),(21,21),(17,25),(14,22),(11,26),(9,24),(8,28)],'white')
 # fox head; ears only with hood open
 if state=='open':
  poly([(9,26),(8,12),(11,10),(19,16),(26,16),(34,10),(37,11),(37,25),(40,28),(38,34),(30,38),(16,38),(8,34),(6,29)],'ink')
  poly([(11,25),(10,13),(17,18),(26,18),(35,13),(35,25),(38,29),(36,33),(30,36),(16,36),(10,33),(8,29)],'orange1')
  poly([(12,15),(16,19),(13,22)],'pink');poly([(33,15),(29,19),(33,22)],'pink')
  top=19
 else: top=23
 poly([(10,28),(14,24),(18,top),(28,top),(33,24),(37,28),(39,30),(36,34),(30,37),(17,37),(11,34),(7,30)],'ink')
 poly([(11,28),(15,25),(18,top+1),(28,top+1),(32,25),(36,28),(37,30),(34,33),(29,35),(17,35),(12,33),(9,30)],'orange1')
 poly([(13,27),(18,top+1),(25,top+1),(32,26),(33,30),(28,33),(17,33),(13,30)],'orange2')
 rect(19,top+1,24,top+2,'orange3')
 # creamy cheeks and chin
 poly([(10,30),(14,28),(18,30),(21,32),(24,32),(28,30),(32,28),(36,30),(35,33),(29,36),(18,36),(12,33)],'white')
 line([(13,34),(18,36),(28,36),(34,33)],'shade')
 # eyes with distinct expressions, at y27-30
 if state in ('open','success'):
  line([(14,28),(16,26),(18,26),(20,28)],'ink',2);line([(27,28),(29,26),(31,26),(33,28)],'ink',2)
 elif state=='sleep':
  line([(14,29),(16,30),(18,30),(20,29)],'ink');line([(27,29),(29,30),(31,30),(33,29)],'ink')
 elif state=='idle':
  rect(15,28,19,30,'eye');rect(28,28,32,30,'eye');rect(14,27,20,28,'ink');rect(27,27,33,28,'ink');rect(16,29,16,29,'blue3');rect(29,29,29,29,'blue3')
 else:
  for x in (14,27):
   rect(x+1,26,x+5,30,'ink');rect(x+2,27,x+4,30,'eye');rect(x+2,27,x+3,28,'shine');rect(x+4,30,x+4,30,'blue3')
  if state=='focus':line([(13,25),(20,27)],'ink',2);line([(27,27),(34,25)],'ink',2)
  if state=='warning':line([(14,26),(18,24)],'orange0');line([(29,24),(33,26)],'orange0')
 # nose and mouth
 rect(22,31,24,32,'ink')
 if state in ('open','success'):poly([(20,33),(26,33),(25,35),(22,35)],'ink');rect(22,34,24,34,'pink')
 elif state in ('warning','idle'):line([(21,35),(23,34),(25,34),(26,35)],'ink')
 else:line([(20,33),(22,34),(23,33),(24,34),(26,33)],'ink')
 # paws
 for x in (12,27):
  poly([(x-2,40),(x,38),(x+5,38),(x+7,40),(x+7,44),(x+5,45),(x,45),(x-2,43)],'ink')
  poly([(x-1,40),(x+1,39),(x+5,39),(x+6,41),(x+6,43),(x+4,44),(x,44),(x-1,42)],'orange2' if state not in ('sleep','idle') else 'orange1')
  rect(x,40,x+2,41,'orange3');line([(x+3,42),(x+3,44)],'orange0')
 # accessories independent of faces, not anti-aliased
 if state=='test':
  for x in (13,26):line([(x,25),(x+8,25),(x+8,31),(x,31),(x,25)],'dark');line([(x+1,25),(x+7,25)],'blue3')
  line([(21,27),(26,27)],'ink')
 if state=='research':line([(38,4),(41,2),(44,2),(46,4),(46,6),(43,9),(43,11)],'blue3',2);rect(42,13,44,14,'blue3')
 if state=='success':
  for x,y in [(4,9),(43,8)]:line([(x,y-2),(x,y+2)],'gold');line([(x-2,y),(x+2,y)],'gold')
 if state=='focus':line([(42,9),(44,6),(46,9),(44,12),(42,9)],'gold')
 if state=='warning':poly([(4,8),(1,13),(1,16),(3,18),(6,17),(7,14)],'ink');poly([(4,10),(2,14),(3,16),(5,16),(6,14)],'blue3')
 if state=='idle':line([(42,12),(45,12),(46,14),(44,16),(41,16)],'shade')
 if state=='sleep':line([(38,3),(43,3),(38,8),(43,8)],'blue3');line([(44,10),(47,10),(44,13),(47,13)],'blue2')
 return im
out.mkdir(exist_ok=True)
for s in states:draw(s).save(out/(s+'.png'),optimize=True)
# Multi-resolution native icon; use nearest neighbor only; explicit entries avoid resampler in Pillow ICO writer.
base=draw('normal'); sizes=[16,24,32,48,64,128,256]; blobs=[]
for n in sizes:
 b=BytesIO();base.resize((n,n),Image.Resampling.NEAREST).save(b,format='PNG');blobs.append(b.getvalue())
header=bytearray(struct.pack('<HHH',0,1,len(sizes)));off=6+16*len(sizes)
for n,b in zip(sizes,blobs):header.extend(struct.pack('<BBBBHHII',n%256,n%256,0,0,1,32,len(b),off));off+=len(b)
(ROOT/'web/samero.ico').write_bytes(header+b''.join(blobs))
# contact sheet, original sprite grid with true pixel scaling
sheet=Image.new('RGBA',(144,144))
for i,s in enumerate(states):sheet.paste(draw(s),((i%3)*48,(i//3)*48))
sheet.save(ROOT/'web/pixel-sprites.png');sheet.resize((576,576),Image.Resampling.NEAREST).save('/tmp/samero-pixel-preview.png')
