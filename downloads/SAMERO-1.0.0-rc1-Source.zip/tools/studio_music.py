"""Original additional instrumental loops, generated offline."""
import numpy as np, wave, tempfile, subprocess
from pathlib import Path
W=Path(__file__).resolve().parents[1]/'web'; rate=24000
for name,bpm,notes,kind in [('harbor-lofi',78,[(48,55,59,62),(45,52,55,60),(41,48,52,57),(43,50,55,59)],'lofi'),('deep-ocean',60,[(45,52,60,64),(41,48,57,60),(48,55,60,67),(43,50,55,62)],'ambient')]:
 beat=60/bpm; mix=np.zeros(round(rate*beat*32)); rng=np.random.default_rng(26)
 def add(pos,dur,n,amp,slow=False):
  start=round(pos*beat*rate); t=np.arange(round(dur*beat*rate))/rate; f=440*2**((n-69)/12); phase=2*np.pi*f*t
  sig=np.sin(phase)+.18*np.sin(phase*2)+.07*np.sin(phase*3)
  env=np.minimum(1,t/(.65 if slow else .025))*np.minimum(1,(len(t)-1-np.arange(len(t)))/(rate*(.8 if slow else .12)))
  if not slow:env*=np.exp(-t*1.9)
  end=min(len(mix),start+len(t)); mix[start:end]+=amp*(sig*env)[:end-start]
 for bar in range(8):
  chord=notes[bar%4]
  for j,n in enumerate(chord):add(bar*4+(j*.25 if kind=='lofi' else 0),3.4 if kind=='ambient' else 1.8,n,.043,kind=='ambient')
  if kind=='lofi':
   add(bar*4,1.8,chord[0]-12,.10);add(bar*4+2,1.5,chord[1]-12,.08)
   for j,k in enumerate([2,3,1,2]):add(bar*4+j*.75,.55,chord[k]+12,.035)
  else:add(bar*4+1,2.7,chord[3]+12,.022,True)
 assert np.max(abs(mix))<1
 with tempfile.TemporaryDirectory() as td:
  f=Path(td)/'a.wav'
  with wave.open(str(f),'wb') as w:w.setparams((1,2,rate,len(mix),'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
  subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(f),'-c:a','libvorbis','-q:a','3',str(W/(name+'.ogg'))],check=True)
