"use strict";
// Decorative, local-only mascot. It neither runs an AI nor changes project state.
const SameroMascot = (() => {
  const states = Object.freeze({
    normal: "Sẵn sàng", open: "Mũ đã mở", focus: "Đang phát triển",
    research: "Đang lập kế hoạch", test: "Đang kiểm thử / nghiệm thu", success: "Đã hoàn tất",
    warning: "Cần kiểm tra", idle: "Đang nghỉ chờ", sleep: "Chế độ nghỉ"
  });
  const prefs = { auto:true, motion:true };
  try { const saved=JSON.parse(localStorage.getItem("samero-mascot-v1")||"{}");
    if(typeof saved.auto==='boolean')prefs.auto=saved.auto;
    if(typeof saved.motion==='boolean')prefs.motion=saved.motion;
  } catch (_) { /* local storage may be disabled */ }
  // Long inactivity only selects an illustration: no reminders, notifications, or interruptions.
  function select({runs=[],sessions=[],chatStage='',fault=false,requestBusy=false,requestError=false,idleMs=0,now=Date.now()}={}) {
    const rows=runs.filter(r=>r&&!r.retired);
    const active=rows.find(r=>r.mode==='active');
    if(active) {
      if(active.phase==='plan')return 'research';
      if(['verify','test','final-test','release','finish'].includes(active.phase))return 'test';
      return 'focus';
    }
    if(fault||requestError||['error','startup','auth','limited'].includes(chatStage))return 'warning';
    if(chatStage==='running'||sessions.some(s=>s.status==='Running'))return 'focus';
    if(requestBusy||chatStage==='starting'||chatStage==='loading')return 'research';
    if(rows.some(r=>['review','blocked'].includes(r.mode)))return 'warning';
    if(rows.some(r=>r.mode==='done'&&!r.snapshot&&Number.isFinite(r.at)&&now-r.at*1000>=0&&now-r.at*1000<120000))return 'success';
    if(idleMs>=20*60000)return 'sleep';
    if(idleMs>=8*60000)return 'idle';
    return 'normal';
  }
  let hoodOpen=false,lastActivity=Date.now(),lastState='',preview=null,previewUntil=0,provider=()=>({});
  function paint() {
    const icon=document.getElementById('mascot-image'),toggle=document.getElementById('mascot-toggle'),status=document.getElementById('mascot-status');
    if(!icon||!toggle||!status)return;
    const now=Date.now();
    const state=hoodOpen?'open':preview&&now<previewUntil?preview:prefs.auto?select({...provider(),idleMs:Math.max(0,now-lastActivity),now}):'normal';
    if(lastState!==state) {
      icon.src='/mascot/'+state+'.png';status.textContent=states[state];
      toggle.setAttribute('data-mascot-state',state);
      const mini=document.getElementById('studio-mini-sprite'),label=document.getElementById('studio-mini-status');if(mini)mini.src=icon.src;if(label)label.textContent=states[state];
      icon.classList.remove('mascot-pop');
      if(prefs.motion&&!matchMedia('(prefers-reduced-motion: reduce)').matches){void icon.offsetWidth;icon.classList.add('mascot-pop');}
      lastState=state;
    }
    toggle.setAttribute('data-mascot-motion',String(prefs.motion));
    toggle.setAttribute('aria-pressed',String(hoodOpen));
    toggle.setAttribute('aria-label',hoodOpen?'Đóng mũ cá mập':'Mở mũ cá mập');
  }
  function gallery() {
    return `<section class="card section" aria-label="Mascot SAMERO"><div class="section-head"><h2>Mascot SAMERO</h2></div><p class="muted">Cáo đội mũ cá mập · nhấp logo để mở hoặc đóng mũ. Biểu cảm chỉ minh họa trạng thái, không ảnh hưởng đến tiến trình AI.</p><div class="mascot-gallery">${Object.entries(states).map(([id,title])=>`<button type="button" class="mascot-preview" data-mascot-preview="${id}" aria-label="Xem biểu cảm ${title}"><img src="/mascot/${id}.png" alt="" width="96" height="96" loading="lazy"><small>${title}</small></button>`).join('')}</div><div class="actions"><label class="check"><input id="mascot-auto" type="checkbox"${prefs.auto?' checked':''}><span>Biểu cảm tự động</span></label><label class="check"><input id="mascot-motion" type="checkbox"${prefs.motion?' checked':''}><span>Hiệu ứng chuyển biểu cảm</span></label></div><small>Không thao tác 8 phút: nghỉ chờ; 20 phút: ngủ, nếu không có công việc đang chạy. Bạn có thể tắt hiệu ứng bất cứ lúc nào. Cài đặt này chỉ lưu trong trình duyệt hiện tại.</small></section>`;
  }
  function mount(getState) {
    provider=getState;
    document.getElementById('mascot-toggle').addEventListener('click',()=>{hoodOpen=!hoodOpen;preview=null;lastActivity=Date.now();paint();});
    const activity=()=>{const wasIdle=Date.now()-lastActivity>=8*60000;lastActivity=Date.now();if(wasIdle)paint();};
    for(const event of ['pointerdown','keydown','wheel','pointermove'])document.addEventListener(event,activity,{passive:true});
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)paint();});
    document.addEventListener('click',e=>{const item=e.target.closest('[data-mascot-preview]');if(item&&Object.hasOwn(states,item.dataset.mascotPreview)){preview=item.dataset.mascotPreview;hoodOpen=false;previewUntil=Date.now()+5000;paint();}});
    document.addEventListener('change',e=>{if(e.target.id!=='mascot-auto'&&e.target.id!=='mascot-motion')return;
      prefs[e.target.id==='mascot-auto'?'auto':'motion']=e.target.checked;
      try{localStorage.setItem('samero-mascot-v1',JSON.stringify(prefs));}catch(_){};
      if(!prefs.motion)document.getElementById('mascot-image').classList.remove('mascot-pop');
      paint();
    });
    paint();setInterval(paint,1000);
  }
  return Object.freeze({select,gallery,mount,states});
})();
