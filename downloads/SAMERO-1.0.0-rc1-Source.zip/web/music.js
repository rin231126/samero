"use strict";
// Original bundled track; explicit opt-in on each page load. No external fetches.
(() => {
  const button=document.getElementById('music-toggle'), slider=document.getElementById('music-volume'), status=document.getElementById('music-status');
  if(!button||!slider||!status)return;
  let volume=20;
  try { const v=localStorage.getItem('samero-music-volume-v1');if(v!==null&&Number.isFinite(Number(v)))volume=Math.min(100,Math.max(0,Number(v))); } catch(_){}
  const audio=new Audio();audio.preload='none';audio.loop=true;audio.volume=volume/100;slider.value=String(volume);
  const tracks=['blue-current','harbor-lofi','deep-ocean'];
  const chooser=document.getElementById('music-track');let track='blue-current';
  try{const saved=localStorage.getItem('samero-music-track-v1');if(tracks.includes(saved))track=saved;}catch(_){}
  if(chooser)chooser.value=track;
  let desired=false, generation=0, focused=false;
  function sync(){button.setAttribute('aria-pressed',String(desired));button.textContent=desired?'♪ Nhạc: Bật':'♪ Nhạc: Tắt';}
  function stop(){generation++;desired=false;audio.pause();sync();}
  function fail(){stop();status.textContent='Không phát được nhạc.';status.hidden=false;}
  async function play(){
    if(focused)return;
    desired=true;const token=++generation;status.hidden=true;sync();
    try {if(!audio.getAttribute('src'))audio.src='/'+track+'.ogg';await audio.play();if(token!==generation&&!desired)audio.pause();}
    catch(_){if(token===generation)fail();}
  }
  button.addEventListener('click',async()=>{if(desired){stop();return;}await play();});
  chooser?.addEventListener('change',async()=>{if(!tracks.includes(chooser.value)){chooser.value=track;return;}const was=desired;stop();track=chooser.value;try{localStorage.setItem('samero-music-track-v1',track);}catch(_){}audio.src='/'+track+'.ogg';if(was)await play();});
  window.addEventListener('samero-focus',e=>{focused=!!e.detail;button.disabled=focused;if(focused&&desired)stop();});
  slider.addEventListener('input',()=>{const v=Number(slider.value);if(!Number.isFinite(v))return;volume=Math.max(0,Math.min(100,v));audio.volume=volume/100;try{localStorage.setItem('samero-music-volume-v1',String(volume));}catch(_){} });
  audio.addEventListener('error',()=>{if(desired)fail();});
  window.addEventListener('pagehide',stop);
  sync();
})();
