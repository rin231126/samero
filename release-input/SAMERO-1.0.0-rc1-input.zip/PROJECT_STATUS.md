# SAMERO Codex Manager — 1.8.1-pixel-rc1

## Ocean Edition

Thêm mascot 9 trạng thái, logo đóng/mở mũ, giao diện xanh dương Dark/Light, biểu tượng menu/vai trò và icon Windows PE. Không đổi runner, lưu trạng thái hoặc các quyền. Kết quả kiểm thử bản mới trong TEST-RESULTS.txt; các mục dưới là lịch sử 1.7.3 và các bản trước.

Đợt này xử lý revision 61 của SAMERO Animation AI dựa trên hai tệp người dùng cung cấp, với một migration giới hạn chính xác tiêu chí lịch sử Task 2; không sửa hàng đợi gốc từ xa và không cấp PASS. Bổ sung log lệnh quan sát, chẩn đoán VERIFY chỉ đọc một lần, giới hạn prompt theo số byte JSON. Phạm vi kiểm thử của bản cuối nằm trong TEST-RESULTS.txt; kết quả các bản cũ bên dưới chỉ là lịch sử.

# 1.7.0-workforce-rc1

- Trang AI Workforce độc lập, 7 vai trò hiển thị trước START; lưu vai trò và lịch sử theo dự án. Chọn tệp bằng picker Windows, giữ xác nhận sửa/hoàn tác.
- Gợi ý sửa tiêu chí lịch sử và giảm bước mở prompt; không bỏ nghiệm thu.
- 23/23 ca HTTP tích hợp trọng điểm trên Linux (6 Continuous, 5 Bridge, 12 Autonomous/Codex fixture). JavaScript và PE PASS. Windows/Codex thật, giao diện Chromium và toàn bộ regression chưa xác minh.
- Không tự chạy AI nền qua ChatGPT Web. Xem TEST-RESULTS.txt.

# 1.6.4-continuous-rc1

Thêm trang ChatGPT Web và tiện ích Chrome chuyển văn bản do người dùng chọn. Bản sửa file yêu cầu xem trước, SHA-256, xác nhận, backup và rollback. Xem TEST-RESULTS.txt. Chưa xác minh Windows/Chrome thật.

# PROJECT_STATUS

## 1.6.2-rc2 — Ứng viên sửa tiêu chí nghiệm thu lỗi thời

- Sửa hướng dẫn PLAN/VERIFY để phân biệt điều kiện lịch sử với trạng thái hiện tại, tránh yêu cầu build Release tương lai ở bước nghiệm thu.
- Thêm sửa tiêu chí nhiệm vụ chưa đạt có xác nhận, kiểm tra revision và hash, lưu journal gốc, chạy test và nghiệm thu lại. Không đổi số nhiệm vụ đã PASS.
- Bảy ca hồi quy Linux PASS, bao gồm ca mới không có .git. PE Windows x64 đã build và kiểm tra cấu trúc; Windows/Codex thật chưa kiểm chứng. Chromium bị chính sách môi trường chặn; ca build-failure chưa có kết quả trong thời hạn chạy. Xem TEST-RESULTS.txt.

---

## Lịch sử từ rc1

# PROJECT_STATUS

## 1.6.2-rc1 · Ứng viên đã sửa lỗi Task 1

Đã tái hiện 0/16 trên 1.6.1. Ứng viên ghi ID phiên test và nghiệm thu cho từng nhiệm vụ, kiểm tra checkpoint trước khi cấp PASS, bảo vệ journal trước các lần ghi cũ và phục hồi có đối chiếu khi hàng đợi mới hơn. Trong bản sao revision 18, Manager tiếp tục đến 2/16 mà không chạy lại WORK của Task 1 hoặc 2. Sau khi dừng, journal, queue và archive đều ở revision 35. Mở lại ứng dụng giữ đúng chỉ mục. Một lần chạy riêng hoàn thành đủ 16/16, biên dịch và chạy được chương trình thử nghiệm Linux.

Đã kiểm tra 51/51 ca tích hợp trên Linux ở bản thường và UBSan. Các mốc mã nguồn là 242dccd, 33e267f, 1ba1d54 và 131b5e8. Bằng chứng cho từng lỗi và các giới hạn kiểm thử nằm trong TEST-RESULTS.txt.

**Chưa nghiệm thu Release.** Đã build EXE Windows x64 và kiểm tra PE. Chưa chạy trực tiếp trên Windows 11. Live Autonomous dừng trước khi mở phiên do SQLite code 14 ở CODEX_HOME được cung cấp. Bước tiếp theo là kiểm tra trên Windows với tests/windows-smoke.ps1, gồm -LiveChat và -LiveAutoApproval. Workflow Windows native nằm trong .github/workflows/windows-audit.yml và chưa được chạy. Trường hợp gốc của người dùng chưa có journal để đối chiếu riêng.

## 1.6.1 · Auto Approval cho phiên do SAMERO quản lý

Đã tích hợp reviewer của Codex vào cài đặt, Chat, Terminal và Autonomous. Runner lưu checkpoint ở nhiệm vụ hiện tại khi bị từ chối. Dashboard và Workspace hiển thị nhật ký xét duyệt theo dự án. Mã triển khai và kiểm thử tại c99c001.

Đã build EXE Windows x64 và kiểm tra PE, entry point, tài nguyên nhúng. Đạt 38/38 ca tích hợp trên Linux ở bản Release và bản bật UndefinedBehaviorSanitizer. App Server chính thức xác nhận cấu hình qua config/read.

**Còn mở.** Chạy bài Windows 11 đã đăng nhập bằng tests/windows-smoke.ps1 với -LiveChat và -LiveAutoApproval. Cần xác minh hai phản hồi thật, nối lại hội thoại, một lượt duyệt chính thức và hành vi STOP trên Windows. Lần chạy Autonomous dùng hồ sơ thật tại đây dừng trước khi mở phiên do App Server không mở được cơ sở dữ liệu trạng thái. Xem TEST-RESULTS.txt để phân biệt kết quả thực và mô phỏng.

## 1.6.0 · Bản kiểm thử Windows x64

Đã build EXE portable, kiểm tra PE và xác minh giao diện nhúng. Bộ chạy thực hiện kế hoạch có phụ thuộc, nghiệm thu chỉ đọc, kiểm thử, build Release, tạo checkpoint nền và bàn giao theo xác nhận. Đã đạt 30/30 ca tích hợp trên Linux ở bản thường và bản bật UndefinedBehaviorSanitizer. Báo cáo chi tiết nằm trong TEST-RESULTS.txt.

**Còn mở cho phiên sau.** Chạy tests/windows-smoke.ps1 trên Windows 11 với Codex đã đăng nhập, bật -LiveChat và -LiveAutonomous. Kiểm tra hai phản hồi thật, lượt thứ ba sau khi mở lại, kết quả chương trình C# mẫu và hành vi sau Sleep. Đối chiếu log trên đúng CODEX_HOME khi người dùng cung cấp. Môi trường Linux hiện tại dừng ở lỗi SQLite trước khi mở được luồng mô hình thật.

## Mục tiêu

SAMERO Codex Manager quản lý hồ sơ Codex độc lập, dự án Git và bàn giao an toàn phần công việc lưu trên ổ đĩa.

## 1.5.2 · Bản kiểm thử Chat Engine

- Nền 1.5.1 ở 725165e. Hai ca mới tái hiện lỗi xác nhận luồng và khôi phục phiên trên mã gốc. Mã ứng dụng sau sửa ở 6a41f61.
- Luồng gửi yêu cầu xác minh luồng trong chính tiến trình App Server. Phục hồi lạnh dùng xác nhận của Codex hoặc metadata rollout đúng CODEX_HOME và workspace. Phân biệt lượt đã nhận với lịch sử đã lưu.
- 21/21 ca tích hợp Linux đạt ở cả bản thường và bản bật UndefinedBehaviorSanitizer. Đã biên dịch và kiểm tra PE x64. Báo cáo TEST-RESULTS.txt ghi phép thử trực tiếp với Codex, lỗi môi trường, và kịch bản Windows cần chạy.
- Chưa nghiệm thu chat nhiều lượt và mở lại lịch sử với mô hình thật trên Windows 11. Chưa thể xác định tình trạng ID cụ thể trên máy người dùng.

## Kiểm toán 1.5.1 (bản kiểm thử)

- Mốc ban đầu 10eabde, sao lưu Git trước chỉnh sửa. Không có dữ liệu tài khoản thật trong bộ thử.
- Đã đọc cấu trúc backend C/Win32, HTTP loopback và metadata JSON, frontend JS/CSS/HTML nhúng, bộ build GCC/binutils cùng các module chat, CLI, phiên, hạn mức, dự án và ZIP.
- Trước sửa, 12/12 ca tích hợp Linux đạt. Chrome với dữ liệu kiểm thử tái hiện P1: hit-test vào đúng summary Dự án nhưng sau click menu vẫn đóng. Bộ xử lý sự kiện tìm cả body[data-page] rồi gọi goto/render, thay toàn bộ vùng tương tác. Ca Node cũ không gửi sự kiện qua cây DOM.
- P2: Workspace đọc bản hạn mức cục bộ khi rảnh, mốc reset chỉ đổi dòng chữ. P1: resume có thể được gửi trực tiếp cho ID đã mất. Theo dõi những mục này bằng kiểm thử giao thức và giao diện.

- Tương tác: sửa selector nhận click trong web/app.js, thêm ca bắt thay phần tử và mất focus vào tests/ui-smoke.cjs. Chrome qua trang QA tái hiện bản cũ; sau sửa đã đổi dự án bằng chuột, chọn hồ sơ bằng Enter, nhập tiếng Việt và thấy Gửi bật.

- Chat và phiên (src/chat.c, src/threads.c, src/codex.c): xác nhận thread/read và cwd trước khi resume. Chỉ đăng ký luồng mới vào danh sách sau khi có rollout trên đĩa hoặc lượt có ID được xác nhận. Biên nhận bền vững tránh gửi trùng. Sau mất kết nối, chỉ thử nối lại một lần cho luồng rảnh có lịch sử, kiểm tra tiến trình và khóa rồi mới mở.
- Hạn mức (src/quota_watch.c, src/main.c, src/manager.c): lịch kiểm tra riêng theo hồ sơ, đọc nền lần lượt, dùng kết nối chat hiện có, làm mới theo reset và sau tác vụ. web/app.js và web/theme.css hiển thị nguồn và độ mới của số liệu.
- Trước lần build cuối, bộ hồi quy đạt 17/17 trên Linux với CLI thử nghiệm và một ca CLI thật chưa đăng nhập. Chưa có bằng chứng nghiệm thu trên Windows và tài khoản thật.

## Checkpoint đóng gói 1.5.1

- Git xác minh được bản sao lưu 10eabde. Mã ứng dụng cuối b327d5f. Đã sửa thêm lỗi ô nhập nằm ngoài khung 430 × 640 và lỗi tính mẫu thiếu trạng thái xác minh vào thanh tổng.
- Trình duyệt đã kiểm tra 7 mục điều hướng, tương tác chọn/gửi và bố cục 5 kích thước. Bộ 17 ca tích hợp đạt trên cả bản thường và bản bật UndefinedBehaviorSanitizer. Bản PE Windows x64 qua kiểm tra cấu trúc và tự kiểm theo ABI. Chi tiết trong TEST-RESULTS.txt.
- Nghiệm thu còn mở trên Windows 11 với tài khoản thật, gồm chat nhiều lượt, resume, đồng bộ hạn mức, native picker, Windows Terminal, DPI và sleep/wake. Bộ thử Windows trong mã nguồn có bước lưu mã ngẫu nhiên và xác minh lại sau khi đóng/mở luồng.

## Checkpoint phát hành 1.5.0

- Tách lỗi xác thực của lượt, lỗi kết nối, lỗi mở luồng và giới hạn sử dụng. Chat gửi lại sau khi xác thực được kiểm tra bởi Codex; luồng chưa mở được báo nguyên nhân và không tự thay bằng luồng mới.
- Danh sách Phiên chat hỗ trợ nhiều luồng đồng thời trong danh sách, ghim, đổi tên hiển thị và lưu trữ cục bộ. Khóa workspace vẫn chỉ cho một tiến trình ghi. Đọc tin nhắn gần đây qua App Server và dùng lịch sử cục bộ khi CLI chưa hỗ trợ.
- Workspace thêm bản nháp lưu trên máy, tìm và sao chép tin nhắn, Copy cho khối code, kết quả lệnh, tệp thay đổi và diff. Danh mục model và effort đọc từ CLI. Có tùy chọn mở nhanh các CODEX_HOME sẵn có.
- Kiểm tra hạn mức chạy trong tiến trình nền, tách khỏi gửi và nhận tin nhắn. Luồng kiểm thử và phần chưa xác minh ghi trong TEST-RESULTS.txt.

## Checkpoint phát hành 1.4.1

- Dự án và Hồ sơ Codex mở menu bên trong giao diện, có mục thêm ngay tại Workspace. Chọn hồ sơ khác sau khi có lịch sử mở bước xác nhận bàn giao.
- **Tạo luồng mới** gửi yêu cầu mở luồng khi đã xác nhận. **Gửi** chỉ bật khi có nội dung và phiên nhận được yêu cầu. Model và đăng nhập có thể truy cập từ Workspace.
- Kết quả kiểm thử ghi trong `TEST-RESULTS.txt`.

## Checkpoint phát hành 1.4.0

- Workspace và trang Hạn mức có hai thanh tổng theo kỳ 5 giờ và 1 tuần. Mỗi hồ sơ có hai thanh riêng. Giờ reset, nguồn số liệu và trạng thái chưa rõ được hiển thị theo dữ liệu nhận được.
- Chat xác minh trạng thái đăng nhập, giữ tham chiếu đến luồng hoạt động gần nhất nếu một lần mở thất bại và cho phép lấy lại nội dung vừa gửi sau lỗi. Hồ sơ Terminal có thể dùng cấu hình xác thực gốc.
- Mở phiên Terminal đã lưu trong Workspace qua App Server với CODEX_HOME và thư mục dự án trùng khớp. Khóa phiên và bàn giao theo xác nhận tiếp tục có hiệu lực.
- Kết quả kiểm thử và giới hạn Windows native được ghi trong `TEST-RESULTS.txt`.

## Checkpoint phát hành 1.3.0

- Phân loại tiến trình Codex theo đường dẫn và đối số. Daemon và Code Mode Host được tách khỏi CLI tương tác. Phiên ngoài thiếu thông tin phạm vi được ghi nhận Unknown.
- Thêm nhập Session ID thủ công và chọn CMD, PowerShell hoặc Windows Terminal. Resume dùng CODEX_HOME và workspace gốc. Khóa do Manager ghi nhận tiếp tục có hiệu lực.
- Chọn thư mục bằng IFileOpenDialog với FOS_PICKFOLDERS, chọn tệp bằng cùng Common Item Dialog. Tác vụ đọc Git và trình chọn chạy ngoài tiến trình xử lý UI.
- Form dự án hai trường. Chi tiết tự đọc Git, tệp trạng thái, tài liệu bàn giao, tên tệp cấu hình và kết quả build/test đã xác minh. Tạo tệp trạng thái có dùng thao tác ghi nguyên tử với điều kiện tệp đích chưa tồn tại.
- Workspace gọn với ô prompt trong vùng cố định và hội thoại cuộn riêng. Hạn mức, tiến độ và checkpoint vẫn có thể mở. Bàn giao lấy thêm trạng thái từ tệp trong dự án.
- Kết quả hiện có và phần chưa kiểm thử trực tiếp trên Windows 11 được ghi trong TEST-RESULTS.txt.

## Checkpoint phát hành 1.2.0

- Dò Codex CLI theo môi trường tiến trình, Windows Registry, các vị trí cài đặt thông dụng và tiến trình Codex Windows. Hỗ trợ định vị native executable của nhiều bố cục npm.
- Phiên Codex hiển thị phiên do Manager theo dõi, phiên Terminal đã lưu và các cửa sổ Windows Terminal từng mở từ app. Nhập metadata và mở lại phiên bằng đúng ID, CODEX_HOME và workspace gốc. Duy trì khóa workspace giữa các chế độ.
- EXE và ZIP có tên ghi phiên bản. Manager kiểm tra phiên bản của cửa sổ đang chạy trước khi mở lại giao diện từ EXE khác.
- Linux: chỉ mục CLI thật, metadata JSONL mẫu, khởi chạy đúng đối số với CLI giả lập, retry cùng ID, khóa, dữ liệu xác thực và lịch sử gốc giữ nguyên, dự án Unicode, chat và bàn giao cũ.
- EXE Windows x64 đã qua kiểm tra PE và self-test điểm khởi động trong mô phỏng ABI Linux. Chưa chạy Windows Terminal và các nhánh Registry/Job Object trực tiếp trên Windows 11.

## Checkpoint phát hành 1.1.0

- Chat tổng mở Codex App Server theo dự án và hồ sơ, hiển thị phản hồi trực tiếp và lưu lịch sử gần đây trên máy. Hỗ trợ phê duyệt một lần, dừng lượt và tiếp tục luồng cùng hồ sơ.
- Khi dịch vụ trả về lỗi hạn mức, chat hiển thị trạng thái chạm hạn mức. Bàn giao yêu cầu chọn hồ sơ đích, tạo checkpoint và xác nhận khởi chạy. Workspace giữ khóa đến khi tiến trình nguồn dừng. Hồ sơ đích nhận đường dẫn checkpoint.
- Giao diện mới gồm trang chat chính, khung workspace và hạn mức, bố cục sáng/tối và ảnh tiêu đề nhúng.
- Kiểm thử Linux với CLI giả lập bao phủ streaming, phê duyệt, dừng, tiếp tục luồng, quota, xác nhận chuyển hồ sơ, khóa và lưu lịch sử. CLI thật xác nhận giao thức khởi tạo. Sandbox bwrap trong môi trường kiểm thử hạn chế chạy `thread/start`. Chưa thử chat với tài khoản đã đăng nhập trên Windows.

## Checkpoint phát hành 1.0.2

- Bổ sung mục Hướng dẫn trong thanh bên và ba thanh ở đầu Dashboard. Hai cửa sổ hạn mức hiện giờ reset và đếm ngược theo hồ sơ. Thanh tổng hiển thị số hồ sơ còn cả hai hạn mức theo dữ liệu Codex đã xác minh.
- Giữ giao diện ổn định trong lúc đếm ngược. Quá mốc reset, số liệu cũ chuyển sang chờ làm mới. Kiểm thử tính tổng, bộ đếm, mẫu thủ công và trạng thái chưa có dữ liệu bằng Node.js.

## Checkpoint phát hành 1.0.1

- Dùng C và Win32 API để biên dịch EXE trong môi trường Linux x86-64. Giao diện nhúng và hiển thị bằng Edge ở chế độ ứng dụng hoặc trình duyệt mặc định. Công cụ biên dịch không cần trên máy chạy.
- Hồ sơ, xác thực Codex CLI, App Server, mức sử dụng, phiên, dự án, Git status, build/test, sao lưu, checksum và khôi phục đều có luồng xử lý chạy từ giao diện.
- Checkpoint gồm hồ sơ nguồn và đích, tài liệu bàn giao, SHA-256 của ZIP và từng tệp, phiên bản staged đủ điều kiện, và kiểm tra workspace trước khi mở phiên đích.
- Ứng dụng theo dõi cây tiến trình do chính nó mở. Tiến trình tương tác Codex hiển thị yêu cầu phê duyệt trong terminal. Phiên chạy khi Manager bị ngắt bất thường có thể hiển thị Unknown ở lần mở sau.
- Có thể đăng ký thư mục Git worktree được tạo trước. Khôi phục mã nguồn, phiên bản staged riêng và manifest. Lịch sử repo được quản lý bằng Git.
- Thông tin tác vụ build/test xác thực gồm trạng thái tiến trình, thời gian và mã thoát. Báo cáo chi tiết do người dùng ghi nhận.

## Xác minh

- Linux x64: bộ test tích hợp chạy với Git thật, hai hồ sơ giả lập và Codex CLI thật trên hồ sơ thử nghiệm chưa đăng nhập. Test gồm đường dẫn Unicode và dấu cách, staged và unstaged, khóa, dừng, chuyển hồ sơ, đọc trả báo cáo, lỗi tiến trình, checksum, khôi phục, lọc bí mật phổ biến và lưu cấu hình qua khởi động lại.
- Windows x64: phiên bản 1.0.1 sửa liên kết địa chỉ và để linker tạo bảng import và IAT theo bố cục PE chuẩn. Trình kiểm tra xác minh checksum PE và vị trí các section, toàn bộ import và các mục tái định vị.
- Bài kiểm tra `pe_entry_smoke.c` chạy mã máy trong chính EXE sau khi nạp PE tại địa chỉ khác trên Linux x64. Bài kiểm tra thay các hàm hệ thống bằng dữ liệu kiểm thử để xác nhận điểm vào, lời gọi theo ABI x64, đối số Unicode và xác minh SHA-256. Chưa trực tiếp khởi chạy trên Windows 10 hay Windows 11.
- Cần xác minh đăng nhập bằng hai tài khoản thật, hạn mức xác thực và thao tác trong cửa sổ Edge/terminal trên máy Windows. Test `tests/windows-smoke.ps1` dùng dữ liệu tạm và kiểm tra luồng API trên Windows. Test Chromium cần môi trường cho phép tiến trình trình duyệt kết nối localhost.

## Giới hạn

- Giữ thông tin xác thực và dự án ở các thư mục riêng. Một bộ lọc tệp chỉ nhận biết các mẫu bí mật đã liệt kê.
- Snapshot là cơ chế đọc và kiểm tra lại, phụ thuộc workspace đã ngừng ghi. Không có snapshot nguyên tử cho công cụ bên ngoài hoặc hệ thống tập tin từ xa.
- ZIP32 lưu các tệp đủ điều kiện, không chứa toàn bộ kho Git. Tên không tương thích Windows, kích thước vượt giới hạn hoặc tệp đổi trong thời gian sao lưu có thể khiến tạo checkpoint thất bại an toàn.


## 1.6.0 · Giai đoạn 1
Đã xác nhận mã C/Win32 và giao diện nhúng của SAMERO 1.5.2. Đã tạo và xác minh Git bundle trước khi sửa. Form dự án chỉ còn tên, đường dẫn và mục tiêu. Backend giữ nguyên ghi chú cũ khi biểu mẫu bỏ qua trường. Chi tiết dự án đọc thêm TASK_QUEUE.json.

## 1.6.0 · Giai đoạn 2
Đã biên dịch backend Linux với cảnh báo là lỗi. Runner dùng App Server hiện tại, lập kế hoạch và nghiệm thu bằng phiên chỉ đọc, sửa trong workspace, rồi chạy test/build bằng tiến trình cục bộ. Nhật ký ghi trước lúc phát lệnh. Checkpoint dùng bộ sao lưu Git và ZIP hiện có. Kiểm thử tích hợp các nhánh lỗi và bản EXE còn đang thực hiện.

## 1.6.0 · Giai đoạn 3
Dashboard đã có bộ điều khiển Autonomous, hàng đợi, bằng chứng nghiệm thu, log, checkpoint, kết quả test/build và bàn giao có xác nhận. README ghi cách chọn lệnh trên Windows. JavaScript đã qua kiểm tra cú pháp.

## 1.6.0 · Giai đoạn 4
Đã chuyển việc tạo ZIP sang tiến trình riêng có watchdog để Dashboard còn phản hồi, bổ sung xác minh mẫu quota mới trên cùng danh tính và bảo vệ trạng thái khi sao lưu gián đoạn. Kiểm thử đã chạy lập kế hoạch, sửa, nghiệm thu, hai lần test, build và khởi chạy artefact mẫu Linux. Ca kill Manager sau lần ghi đầu tiên rồi bàn giao sang hồ sơ khác không lặp lượt ghi. Codex thật vẫn thoát trên CODEX_HOME chỉ đọc của môi trường này. Bản chạy Windows và mô hình thật cần xác minh.

## 1.6.0 · Giai đoạn 5
Đã thêm phục hồi có giới hạn cho lượt đọc mất kết nối, watchdog theo hoạt động thật và cập nhật TASK_QUEUE.json qua thao tác xuất bản độc quyền. Khi cạnh tranh, giữ lại bản đã có để đối chiếu. Tiến trình runner thu phần cuối stdout/stderr của test/build và lọc nội dung trước khi ghi log. Đã kiểm tra mã máy EXE tại điểm vào và đối chiếu byte của cả ba tài nguyên giao diện. Lệnh kiểm thử Windows trong README dùng hồ sơ thật do người dùng chọn.

## 1.6.4-continuous-rc1 — ChatGPT Web Continuous Development
- Added `src/continuous.c` and per-project atomic journal with revision check, preserved history and explicit controls.
- Added Continuous Development panel, prompt preparation, local journal export and optional real test-session reference.
- Tested 4 new local HTTP cases, 4 Bridge cases and 2 targeted runner regressions; Windows cross-build/PE structural check passed. Real Windows/browser and full suite not verified. No autonomous Web automation. See TEST-RESULTS.txt.

## 1.6.5-workforce-rc1
- Narrow historical queue criterion suggestion; explicit amendment can resume automatically after backup/checkpoint, preserving actual test/verification gates. Longer runner log lines.
- ChatGPT Workforce: seven prompt roles, team mode and validated JSON report import. User-mediated only.
- Bridge clears project-scoped UI state on switching projects and checks selected project for rollback.
- See TEST-RESULTS.txt for final-build evidence and limitations.

## 1.7.1-recovery-rc1
- Publish per-task accepted evidence and test/verify session IDs from the authoritative Manager journal into PROJECT_STATUS.md at checkpoint boundaries; backfill missing old receipts without promoting workspace claims. Keep old notes and skip already present markers.
- Clarify planner and verifier responsibilities; current-task receipt comes only after acceptance.
- See TEST-RESULTS.txt for this build and limits.

## 1.7.2-ledger-rc1
- Added durable task ledger with manifest-derived observed changes, accepted checkpoint, baseline, errors, test and verification sessions. Legacy migration preserves accepted index and reconstructs recorded intervals from verified checkpoint queue members (bounded search). Unknown history remains NOT RECORDED; no PASS import.
- Added bounded recovery after a fully ended work process and malformed read-only replies. Planner/verifier distinguish repairable evidence gaps from real user intervention. No automatic permission escalation or policy bypass.
- Metadata enumeration filters out transient .tmp/.saving names before stat; source snapshot walks remain strict.
- Dashboard has per-task receipts and local, user-reviewed diagnostic excerpt.
- See TEST-RESULTS.txt for actual final build validation and remaining limits.


## Pixel Edition 1.8.1
Mascot cáo cá mập 48×48, 9 biểu cảm. Nhấp logo mở/đóng mũ. Nhấn ♪ Nhạc ở thanh trên để bật/tắt Blue Current; thanh trượt chỉnh âm lượng. Mặc định không tự phát nhạc. Xem TEST-RESULTS.txt để biết phạm vi kiểm thử.

## 1.9.0-studio-rc1 — Pixel AI Studio
Nâng cấp lớp trình bày trên nền 1.8.1, không chỉnh runner. Xem README.md và TEST-RESULTS.txt. Không tuyên bố Windows/Chromium tích hợp đã PASS.
