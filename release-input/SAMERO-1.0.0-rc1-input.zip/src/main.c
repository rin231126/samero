#include "manager.h"
#include "assets.h"

static int response(Socket fd, int code, const char *mime, const void *data, size_t n) {
    const char *text = code == 200 ? "OK" : code == 400 ? "Bad Request" :
        code == 403 ? "Forbidden" : code == 404 ? "Not Found" : "Conflict";
    Buf h = {0};
    buffer_fmt(&h,"HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %zu\r\n"
        "Connection: close\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n"
        "Cross-Origin-Resource-Policy: same-origin\r\nReferrer-Policy: no-referrer\r\n"
        "X-Frame-Options: DENY\r\n"
        "Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self'; "
        "img-src 'self' data:; media-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'\r\n\r\n",
        code,text,mime,n);
    int ok = socket_write(fd,h.s,h.n) && socket_write(fd,data,n);
    buffer_free(&h);
    return ok;
}
static void send_error(Socket fd, int code, const char *message) {
    Buf b = {0};
    buffer_char(&b,'{'); json_pair(&b,"error",message); buffer_char(&b,'}');
    response(fd,code,"application/json; charset=utf-8",b.s,b.n);
    buffer_free(&b);
}
typedef struct { char *host, *origin, *key, *type; size_t length; char *path; int post; } Request;
static int parse_headers(Request *r, char *raw) {
    char *first = strstr(raw,"\r\n");
    if (!first) return 0;
    *first = 0;
    char *path = strchr(raw,' ');
    if (!path) return 0;
    *path++ = 0;
    if (!strcmp(raw,"POST")) r->post = 1;
    else if (strcmp(raw,"GET")) return 0;
    char *version = strchr(path,' ');
    if (!version || strcmp(version+1,"HTTP/1.1")) return 0;
    *version = 0; r->path = path;
    int length_seen = 0;
    for (char *line = first+2; *line;) {
        char *next = strstr(line,"\r\n");
        if (next) *next = 0;
        char *value = strchr(line,':');
        if (!value || !*line) return 0;
        *value++ = 0;
        value += strspn(value," \t");
        char *last=value+strlen(value);
        while (last>value && (last[-1]==' ' || last[-1]=='\t')) *--last=0;
        if (ascii_equal(line,"Transfer-Encoding")) return 0;
        if (ascii_equal(line,"Content-Length")) {
            if (length_seen++ || !*value || strlen(value)>7 || strspn(value,"0123456789")!=strlen(value)) return 0;
            for (; *value; ++value) r->length=r->length*10+(size_t)(*value-'0');
        }
        char **target = ascii_equal(line,"Host") ? &r->host : ascii_equal(line,"Origin") ? &r->origin :
            ascii_equal(line,"X-Samero-Key") ? &r->key : ascii_equal(line,"Content-Type") ? &r->type : NULL;
        if (target) {
            if (*target) return 0;
            *target=value;
        }
        if (!next) break;
        line=next+2;
    }
    return 1;
}
static int token_equal(const char *a, const char *b) {
    if (!a || strlen(a)!=32) return 0;
    int diff=0;
    for(int i=0;i<32;++i) diff |= a[i]^b[i];
    return diff==0;
}
typedef struct {
    Process process;
    Buf data;
    Socket client;
    uint64_t deadline;
    long long started;
    unsigned revision;
    char profile[33], profile_digest[65];
} ReadWorker;
static ReadWorker workers[3];

static const char *worker_argument(const char *action) {
    if (!strcmp(action,"project-details") || !strcmp(action,"project-status")) return "project";
    if (!strcmp(action,"codex-models") || !strcmp(action,"account-refresh")) return "profile";
    if (!strcmp(action,"thread-read")) return "id";
    return !strcmp(action,"pick")?"start":NULL;
}
static int profile_digest(Manager *m,const char *id,char digest[65],Error *e) {
    Document d;
    if (!get_doc(m,"profiles",id,&d,e)) return 0;
    Sha256 hash={0};
    sha_update(&hash,d.raw.s,d.raw.n); sha_finish(&hash,digest);
    doc_free(&d);
    return 1;
}
static int put_worker(Manager *m,Socket fd,const char *action,const JSON *input,Error *e) {
    ReadWorker *w=NULL;
    int picking=!strcmp(action,"pick");
    for (size_t i=0;i<ARRAY_LEN(workers);++i) {
        if (picking && workers[i].process.handle && !workers[i].deadline)
            return errorf(e,"Cửa sổ chọn đang mở.");
        if (!w && !workers[i].process.handle) w=&workers[i];
    }
    if (!w) return errorf(e,"Đang đọc workspace. Hãy thử lại sau.");
    Path *p=allocate(2*sizeof(*p));
    ARG(input,"start",p[1].p);
    char id[33]; ARG(input,worker_argument(action),id);
    if (!picking && !valid_id(id)) { free(p); return errorf(e,"Chọn đúng phiên, dự án hoặc hồ sơ."); }
    int quota=!strcmp(action,"account-refresh");
    char digest[65];
    if (quota && !profile_digest(m,id,digest,e)) { free(p); return 0; }
    for (size_t i=0;quota && i<ARRAY_LEN(workers);++i) if (workers[i].process.handle && !strcmp(workers[i].profile,id)) {
        if (workers[i].client==BAD_SOCKET && fd!=BAD_SOCKET) {
            workers[i].client=fd; free(p); return 1;
        }
        free(p); return errorf(e,"Hồ sơ đang được kiểm tra hạn mức.");
    }
    const char *argv[]={"--read-worker",action,m->data.p,picking?p[1].p:id,YES(input,"file")?"file":"folder",NULL};
    int ok=self_executable(&p[0]) && process_start(&w->process,p[0].p,argv,m->data.p,NULL,1,0,e);
    if (ok) {
        process_close_input(&w->process);
        w->client=fd;
        w->deadline=picking?0:monotonic_ms()+90000;
        w->started=timestamp();
        if (quota) { w->revision=quota_revision(m,id); strcpy(w->profile,id); strcpy(w->profile_digest,digest); }
    }
    free(p); return ok;
}
void quota_yield_worker(const char *profile) {
    for (size_t i=0;i<ARRAY_LEN(workers);++i) {
        ReadWorker *w=&workers[i];
        if (!w->process.handle || strcmp(w->profile,profile)) continue;
        process_stop(&w->process); process_dispose(&w->process);
        if (w->client!=BAD_SOCKET) {
            send_error(w->client,409,"Phiên mới sẽ đồng bộ hạn mức trên kết nối của chính nó.");
            socket_close(w->client);
        }
        buffer_free(&w->data); memset(w,0,sizeof(*w));
    }
}
int quota_background_worker(Manager *m,const char *profile) {
    for (size_t i=0;i<ARRAY_LEN(workers);++i)
        if (workers[i].process.handle && *workers[i].profile) return 0;
    Buf body={0}; buffer_char(&body,'{'); json_pair(&body,"profile",profile); buffer_char(&body,'}');
    JSON j; Error ignored={0}; int ok=0;
    if (json_parse(&j,body.s,body.n)) {
        ok=put_worker(m,BAD_SOCKET,"account-refresh",&j,&ignored);
        json_free(&j);
    }
    buffer_free(&body); return ok;
}
static int drain_worker(ReadWorker *w) {
    char chunk[4096];
    for (int i=0;i<64;++i) {
        int bytes=process_read(&w->process,chunk,sizeof(chunk));
        if (bytes<=0) break;
        if (w->data.n+(size_t)bytes>3*MIB) return 0;
        buffer_add(&w->data,chunk,(size_t)bytes);
    }
    return 1;
}
static void tick_workers(Manager *m) {
    for (size_t i=0;i<ARRAY_LEN(workers);++i) {
        ReadWorker *w=&workers[i];
        if (!w->process.handle) continue;
        int oversized=!drain_worker(w);
        int code=0,running=process_poll(&w->process,&code);
        if (!running && !oversized) oversized=!drain_worker(w);
        if (running>0 && !oversized && (!w->deadline || monotonic_ms()<w->deadline)) continue;
        if (running) process_stop(&w->process);
        JSON result;
        if (!oversized && !running && !code && w->data.n && json_parse(&result,w->data.s,w->data.n)) {
            int status=json_get(&result,0,"error")>=0?409:200;
            Error e={0}; char digest[65];
            int current=!*w->profile || (profile_digest(m,w->profile,digest,&e) && !strcmp(digest,w->profile_digest));
            int fresh=current && (!*w->profile || w->revision==quota_revision(m,w->profile));
            if (!current) { status=409; errorf(&e,"Hồ sơ đã thay đổi trong lúc kiểm tra."); }
            else if (status==200 && *w->profile && fresh &&
                !codex_commit_account(m,w->profile,&result,&w->data,w->started,&e)) status=409;
            if (status!=200 && fresh && *w->profile) quota_observed(m,w->profile,NULL,1);
            if (w->client!=BAD_SOCKET) {
                if (e.msg[0]) send_error(w->client,409,e.msg);
                else response(w->client,status,"application/json; charset=utf-8",w->data.s,w->data.n);
            }
            json_free(&result);
        } else {
            if (*w->profile && w->revision==quota_revision(m,w->profile)) quota_observed(m,w->profile,NULL,1);
            if (w->client!=BAD_SOCKET) send_error(w->client,409,"Không lấy được kết quả. Kiểm tra đường dẫn và thử lại.");
        }
        if (w->client!=BAD_SOCKET) socket_close(w->client);
        process_dispose(&w->process);
        buffer_free(&w->data);
        memset(w,0,sizeof(*w));
    }
}
static int read_worker(const char *action,const char *root,const char *argument,const char *mode) {
    const char *field=worker_argument(action);
    if (!field) return 1;
    Manager *m=allocate(sizeof(*m));
    Error e={0};
    Buf request={0}, result={0};
    buffer_char(&request,'{');
    json_pair(&request,field,argument);
    if (!strcmp(mode,"file")) { RAW(&request,"file","true"); }
    buffer_char(&request,'}');
    if (manager_readonly(m,root,&e)) {
        JSON json;
        if (json_parse(&json,request.s,request.n)) {
            dispatch(m,action,&json,&result,&e);
            json_free(&json);
        }
    }
    if (!result.n) {
        buffer_char(&result,'{'); json_pair(&result,"error",e.msg[0]?e.msg:"Không đọc được yêu cầu."); buffer_char(&result,'}');
    }
    int ok=worker_stdout(result.s,result.n);
    buffer_free(&result); buffer_free(&request); free(m); return !ok;
}
static int serve(Manager *m, Socket fd, const char *host, const char *origin, const char *token) {
    Buf b={0}, out={0};
    int deferred=0;
    char chunk[2048];
    uint64_t end=monotonic_ms()+3000;
    char *header_end=NULL;
    while (b.n<16384 && monotonic_ms()<end) {
        int n=socket_read(fd,chunk,sizeof(chunk));
        if (n<=0) goto done;
        buffer_add(&b,chunk,(size_t)n);
        header_end=strstr(b.s,"\r\n\r\n");
        if (header_end) break;
    }
    if (!header_end) { send_error(fd,400,"HTTP header không hợp lệ."); goto done; }
    size_t head=(size_t)(header_end-b.s)+4;
    *header_end=0;
    *(header_end+1)=0;
    Request r={0};
    /* Preserve the CRLF ending the request line for a headerless request. */
    if (!parse_headers(&r,b.s)) { send_error(fd,400,"HTTP request không hợp lệ."); goto done; }
    if (!r.host || strcmp(r.host,host)) { send_error(fd,403,"Địa chỉ kết nối không hợp lệ."); goto done; }
    if (!r.post && !r.length) {
        if (!strcmp(r.path,"/")) response(fd,200,"text/html; charset=utf-8",index_html,sizeof(index_html));
        else if (!strcmp(r.path,"/theme.css")) response(fd,200,"text/css; charset=utf-8",theme_css,sizeof(theme_css));
        else if (!strcmp(r.path,"/app.js")) response(fd,200,"text/javascript; charset=utf-8",app_js,sizeof(app_js));
        else if (!strcmp(r.path,"/mini.html")) response(fd,200,"text/html; charset=utf-8",mini_html,sizeof(mini_html));
        else if (!strcmp(r.path,"/mini.js")) response(fd,200,"text/javascript; charset=utf-8",mini_js,sizeof(mini_js));
        else if (!strcmp(r.path,"/studio.js")) response(fd,200,"text/javascript; charset=utf-8",studio_js,sizeof(studio_js));
        else if (!strcmp(r.path,"/harbor-lofi.ogg")) response(fd,200,"audio/ogg",harbor_lofi_ogg,sizeof(harbor_lofi_ogg));
        else if (!strcmp(r.path,"/deep-ocean.ogg")) response(fd,200,"audio/ogg",deep_ocean_ogg,sizeof(deep_ocean_ogg));
        else if (!strcmp(r.path,"/mascot/anim-focus.png")) response(fd,200,"image/png",mascot_anim_focus_png,sizeof(mascot_anim_focus_png));
        else if (!strcmp(r.path,"/mascot/anim-idle.png")) response(fd,200,"image/png",mascot_anim_idle_png,sizeof(mascot_anim_idle_png));
        else if (!strcmp(r.path,"/mascot/anim-normal.png")) response(fd,200,"image/png",mascot_anim_normal_png,sizeof(mascot_anim_normal_png));
        else if (!strcmp(r.path,"/mascot/anim-open.png")) response(fd,200,"image/png",mascot_anim_open_png,sizeof(mascot_anim_open_png));
        else if (!strcmp(r.path,"/mascot/anim-research.png")) response(fd,200,"image/png",mascot_anim_research_png,sizeof(mascot_anim_research_png));
        else if (!strcmp(r.path,"/mascot/anim-sleep.png")) response(fd,200,"image/png",mascot_anim_sleep_png,sizeof(mascot_anim_sleep_png));
        else if (!strcmp(r.path,"/mascot/anim-success.png")) response(fd,200,"image/png",mascot_anim_success_png,sizeof(mascot_anim_success_png));
        else if (!strcmp(r.path,"/mascot/anim-test.png")) response(fd,200,"image/png",mascot_anim_test_png,sizeof(mascot_anim_test_png));
        else if (!strcmp(r.path,"/mascot/anim-warning.png")) response(fd,200,"image/png",mascot_anim_warning_png,sizeof(mascot_anim_warning_png));
        else if (!strcmp(r.path,"/mascot/ocean-tile.png")) response(fd,200,"image/png",mascot_ocean_tile_png,sizeof(mascot_ocean_tile_png));
        else if (!strcmp(r.path,"/mascot/office-beaver.png")) response(fd,200,"image/png",mascot_office_beaver_png,sizeof(mascot_office_beaver_png));
        else if (!strcmp(r.path,"/mascot/office-cat.png")) response(fd,200,"image/png",mascot_office_cat_png,sizeof(mascot_office_cat_png));
        else if (!strcmp(r.path,"/mascot/office-owl.png")) response(fd,200,"image/png",mascot_office_owl_png,sizeof(mascot_office_owl_png));
        else if (!strcmp(r.path,"/mascot/office-penguin.png")) response(fd,200,"image/png",mascot_office_penguin_png,sizeof(mascot_office_penguin_png));
        else if (!strcmp(r.path,"/mascot/office-rabbit.png")) response(fd,200,"image/png",mascot_office_rabbit_png,sizeof(mascot_office_rabbit_png));
        else if (!strcmp(r.path,"/mascot/office-wolf.png")) response(fd,200,"image/png",mascot_office_wolf_png,sizeof(mascot_office_wolf_png));
        else if (!strcmp(r.path,"/music.js")) response(fd,200,"text/javascript; charset=utf-8",music_js,sizeof(music_js));
        else if (!strcmp(r.path,"/blue-current.ogg")) response(fd,200,"audio/ogg",blue_current_ogg,sizeof(blue_current_ogg));
        else if (!strcmp(r.path,"/mascot.js")) response(fd,200,"text/javascript; charset=utf-8",mascot_js,sizeof(mascot_js));
        else if (!strcmp(r.path,"/favicon.ico")) response(fd,200,"image/x-icon",samero_ico,sizeof(samero_ico));
        else if (!strcmp(r.path,"/mascot/normal.png")) response(fd,200,"image/png",mascot_normal_png,sizeof(mascot_normal_png));
        else if (!strcmp(r.path,"/mascot/open.png")) response(fd,200,"image/png",mascot_open_png,sizeof(mascot_open_png));
        else if (!strcmp(r.path,"/mascot/focus.png")) response(fd,200,"image/png",mascot_focus_png,sizeof(mascot_focus_png));
        else if (!strcmp(r.path,"/mascot/research.png")) response(fd,200,"image/png",mascot_research_png,sizeof(mascot_research_png));
        else if (!strcmp(r.path,"/mascot/test.png")) response(fd,200,"image/png",mascot_test_png,sizeof(mascot_test_png));
        else if (!strcmp(r.path,"/mascot/success.png")) response(fd,200,"image/png",mascot_success_png,sizeof(mascot_success_png));
        else if (!strcmp(r.path,"/mascot/warning.png")) response(fd,200,"image/png",mascot_warning_png,sizeof(mascot_warning_png));
        else if (!strcmp(r.path,"/mascot/idle.png")) response(fd,200,"image/png",mascot_idle_png,sizeof(mascot_idle_png));
        else if (!strcmp(r.path,"/mascot/sleep.png")) response(fd,200,"image/png",mascot_sleep_png,sizeof(mascot_sleep_png));
        else send_error(fd,404,"Không tìm thấy trang.");
        goto done;
    }
    if (!r.post || strncmp(r.path,"/api/",5) || !r.origin || strcmp(r.origin,origin) ||
        !token_equal(r.key,token) || !r.type || !ascii_equal(r.type,"application/json")) {
        send_error(fd,403,"Phiên giao diện không hợp lệ. Hãy mở lại SAMERO."); goto done;
    }
    char action[80];
    int size=sam_format(action,sizeof(action),"%s",r.path+5);
    if (size<=0 || size>=(int)sizeof(action) || !r.length || r.length>512*1024 || b.n>head+r.length) {
        send_error(fd,400,"Dữ liệu yêu cầu không hợp lệ."); goto done;
    }
    while (b.n<head+r.length && monotonic_ms()<end) {
        size_t need=head+r.length-b.n;
        int n=socket_read(fd,chunk,need<sizeof(chunk)?need:sizeof(chunk));
        if (n<=0) goto done;
        buffer_add(&b,chunk,(size_t)n);
    }
    if (b.n!=head+r.length) goto done;
    JSON input;
    if (!json_parse(&input,b.s+head,r.length)) { send_error(fd,400,"JSON yêu cầu bị lỗi."); goto done; }
    if (input.t[0].type!='{') { json_free(&input); send_error(fd,400,"JSON phải là object."); goto done; }
    Error e={0};
    char requested_profile[33]; ARG(&input,"profile",requested_profile);
    if (!strcmp(action,"account-refresh") && chat_quota_refresh(m,requested_profile)) {
        const char msg[]="{\"note\":\"Đã yêu cầu cập nhật trên kết nối hiện có.\"}";
        response(fd,200,"application/json; charset=utf-8",msg,sizeof(msg)-1);
    } else if (worker_argument(action)) {
        deferred=put_worker(m,fd,action,&input,&e);
        if (!deferred) send_error(fd,409,e.msg[0]?e.msg:"Không mở được tác vụ đọc.");
    } else {
        int pending=0;
        if (!strcmp(action,"exit")) for (size_t i=0;i<ARRAY_LEN(workers);++i) pending |= workers[i].process.handle!=0 && workers[i].client!=BAD_SOCKET;
        if (pending) send_error(fd,409,"Đóng cửa sổ chọn và đợi tác vụ đọc hoàn thành trước khi thoát.");
        else if (dispatch(m,action,&input,&out,&e))
            response(fd,200,"application/json; charset=utf-8",out.s,out.n);
        else send_error(fd,409,e.msg[0] ? e.msg : "Không hoàn tất được thao tác.");
    }
    json_free(&input);
done:
    buffer_free(&b); buffer_free(&out);
    return deferred;
}
static int self_test(const char *unicode) {
    Sha256 sha={0};
    char hex[65], nonce[33];
    sha_update(&sha,"abc",3);
    sha_finish(&sha,hex);
    new_id(nonce);
    return (unicode && strcmp(unicode,"Tiếng Việt")) || !valid_id(nonce) ||
        strcmp(hex,"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") ? 1 : 0;
}
static int app_main(int argc, char **argv) {
    if (argc==6 && !strcmp(argv[1],"--runner-checkpoint")) return runner_checkpoint_worker(argv[2],argv[3],argv[4],argv[5]);
    if (argc==6 && !strcmp(argv[1],"--read-worker")) return read_worker(argv[2],argv[3],argv[4],argv[5]);
    if (argc>1 && !strcmp(argv[1],"--self-test")) return self_test(argc>2 ? argv[2] : NULL);
    const char *root=NULL;
    int headless=0;
    for (int i=1;i<argc;++i) {
        if (!strcmp(argv[i],"--headless")) headless=1;
        else if (!strcmp(argv[i],"--data-dir") && i+1<argc) root=argv[++i];
    }
    Manager *m=allocate(sizeof(*m));
    Path *url_file=allocate(2*sizeof(*url_file)), *version_file=&url_file[1];
    Error e={0};
    int init=manager_init(m,root,&e);
    int result=1;
    if (init<0) {
        Buf url={0}, version={0};
        int valid=path_join(url_file,m->data.p,"ui.url") && read_file(url_file->p,200,&url,&e) &&
            !strncmp(url.s,"http://127.0.0.1:",17) &&
            strspn(url.s+17,"0123456789/#abcdef")==strlen(url.s+17);
        const char prefix[]=SAM_VERSION "\n";
        int same=valid && path_join(version_file,m->data.p,"ui.version") &&
            read_file(version_file->p,250,&version,&e) &&
            !strncmp(version.s,prefix,sizeof(prefix)-1) && !strcmp(version.s+sizeof(prefix)-1,url.s);
        if (same && !headless && open_url(url.s,1)) result=0;
        else if (!headless) alert_user("Đang có một SAMERO mở. Nếu đang cập nhật, vào Cài đặt → Thoát Manager trong bản cũ, rồi mở lại SAMERO " SAM_VERSION ".");
        buffer_free(&version); buffer_free(&url);
        goto done;
    }
    if (!init) { alert_user(e.msg); goto done; }
    unsigned short port=0;
    Socket server=listen_local(&port);
    if (server==BAD_SOCKET) { alert_user("Không khởi động được giao diện cục bộ."); goto done; }
    char host[48], origin[64], token[33], url[128];
    new_id(token);
    sam_format(host,sizeof(host),"127.0.0.1:%u",(unsigned)port);
    sam_format(origin,sizeof(origin),"http://%s",host);
    sam_format(url,sizeof(url),"%s/#%s",origin,token);
    if (!path_join(url_file,m->data.p,"ui.url") || !write_atomic(url_file->p,url,strlen(url),&e)) {
        alert_user("Không lưu được địa chỉ giao diện."); socket_close(server); goto done;
    }
    char proof[200];
    int proof_len=sam_format(proof,sizeof(proof),"%s\n%s",SAM_VERSION,url);
    if (proof_len<=0 || proof_len>=(int)sizeof(proof) || !path_join(version_file,m->data.p,"ui.version") ||
        !write_atomic(version_file->p,proof,(size_t)proof_len,&e)) {
        alert_user("Không ghi được phiên bản đang chạy."); remove_file(url_file->p); socket_close(server); goto done;
    }
    if (!headless && !open_url(url,1)) {
        alert_user("Không mở được giao diện. Hãy cài Microsoft Edge hoặc trình duyệt mặc định.");
        remove_file(version_file->p); remove_file(url_file->p); socket_close(server); goto done;
    }
    if (!runner_init(m,&e)) m->runner_fault=1;
    quota_init(m);
    while (!m->quit) {
        tick_sessions(m);
        tick_workers(m);
        quota_tick(m);
        runner_tick(m);
        Socket fd=accept_local(server);
        if (fd==BAD_SOCKET) { sleep_ms(30); continue; }
        if (!serve(m,fd,host,origin,token)) socket_close(fd);
    }
    for (size_t i=0;i<ARRAY_LEN(workers);++i) if (workers[i].process.handle) {
        process_stop(&workers[i].process); process_dispose(&workers[i].process); buffer_free(&workers[i].data);
    }
    quota_dispose(m);
    remove_file(version_file->p); remove_file(url_file->p); socket_close(server); result=0;
done:
    runner_free(m); free(url_file); free(m);
    return result;
}
#ifdef SAM_WINDOWS
extern void ExitProcess(unsigned int);
extern const unsigned short *GetCommandLineW(void);
extern unsigned short **CommandLineToArgvW(const unsigned short *, int *);
extern void *LocalFree(void *);
extern int WideCharToMultiByte(uint32_t, uint32_t, const unsigned short *, int, char *, int, void *, void *);
static int (*volatile entry)(int,char **)=app_main;
void sam_entry(void) {
    int count=0;
    unsigned short **args=CommandLineToArgvW(GetCommandLineW(),&count);
    if (!args || count<1 || count>16) { alert_user("Tham số khởi động không hợp lệ."); ExitProcess(1); return; }
    char **utf=allocate((size_t)count*sizeof(*utf));
    for (int i=0;i<count;++i) {
        utf[i]=allocate(PATH_CAP);
        if (!WideCharToMultiByte(65001,128,args[i],-1,utf[i],PATH_CAP,NULL,NULL)) {
            alert_user("Đường dẫn khởi động quá dài hoặc không hợp lệ."); ExitProcess(1); return;
        }
    }
    LocalFree(args);
    int result=entry(count,utf);
    for (int i=0;i<count;++i) free(utf[i]);
    free(utf);
    ExitProcess((unsigned int)result);
}
#else
int main(int argc,char **argv) { return app_main(argc,argv); }
#endif
