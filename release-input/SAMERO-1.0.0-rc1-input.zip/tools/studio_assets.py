"""Original pixel-art tiles, office animal sprites, and 8-frame mascot motion."""
from pathlib import Path
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]; W=ROOT/'web'; out=W/'mascot'
ink='#182b47'; paper='#fff2df'; shadow='#7990ac'
# Eight actual pixel frames per state. Keep the original art and alpha.
for name in ('normal','open','focus','research','test','success','warning','idle','sleep'):
 base=Image.open(out/f'{name}.png').convert('RGBA'); strip=Image.new('RGBA',(384,48))
 for i in range(8):
  frame=base.copy(); d=ImageDraw.Draw(frame)
  if name in ('normal','focus','research','warning','idle') and i in (5,6):
   for x in (14,27):
    d.rectangle((x+1,26,x+5,28),fill='#ffad51');d.line((x+1,29,x+5,29),fill=ink,width=1)
  # Tail movement by shifting only the outer tail tip; keep rest of body intact.
  if i in (2,3,4,5):
   tip=frame.crop((40,27,48,45));d.rectangle((40,27,47,44),fill=(0,0,0,0));frame.paste(tip,(40,26))
  if name=='focus':
   # Tiny keyboard in front of the fox, alternating highlighted keys.
   d.rectangle((12,41,35,46),fill=ink);d.rectangle((13,42,34,44),fill='#7990ac');
   for k in range(6):
    x=14+k*3;d.rectangle((x,42,x+1,43),fill='#a0dcff' if k==i%6 else '#dbe6ee')
  if name=='sleep' and i%4>=2:
   d.rectangle((38,2,47,14),fill=(0,0,0,0));d.line([(39,3),(43,3),(39,7),(43,7)],fill='#a0dcff');d.line([(44,9),(47,9),(44,12),(47,12)],fill='#55a7ed')
  strip.paste(frame,(i*48,0))
 strip.save(out/f'anim-{name}.png',optimize=True)
# Canonical launch artwork: preserve the same six source PNGs as the website and EXE.
for p in sorted((ROOT/'tools/launch-role-art').glob('office-*.png')):
 im=Image.open(p).convert('RGBA')
 assert im.size==(48,48) and im.getchannel('A').getextrema()==(0,255)
 im.save(out/p.name,optimize=True)
# Small repeatable ocean pixel decorations (no gradients).
im=Image.new('RGBA',(96,48));d=ImageDraw.Draw(im)
for x,y,c in [(12,12,'#66c4ee'),(60,28,'#9cd6fa')]:
 d.polygon([(x,y),(x+3,y-3),(x+10,y-3),(x+14,y),(x+10,y+3),(x+3,y+3)],fill=c);d.polygon([(x+14,y),(x+19,y-4),(x+19,y+4)],fill=c);d.point((x+3,y-1),fill=ink)
for x,y in [(42,8),(46,16),(80,9),(33,36)]:d.rectangle((x,y,x+2,y+2),outline='#8bd3ff')
im.save(out/'ocean-tile.png',optimize=True)
